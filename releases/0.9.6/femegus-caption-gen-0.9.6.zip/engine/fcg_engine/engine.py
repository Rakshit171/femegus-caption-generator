"""High-level engine: language-mode routing, model cache (models stay loaded), quality flags.

english  -> stock Whisper (default "turbo"), language forced to "en".  NOTE: forcing English makes Whisper TRANSLATE spoken Hindi into
            English, so use it only for English speech.
hinglish -> HYBRID (default): stock turbo in Hindi mode as the skeleton (English stays Latin, Hindi comes out Devanagari = free word-level
            language ID) + the Hinglish fine-tune (Oriserve Apex) supplying Roman text for each Hindi span. See hybrid.py, docs/HINGLISH.md.
            ``hinglish_strategy`` = "hybrid" | "apex" (fine-tune only) | "stock_prompt" (stock + Roman prompt, prompt-leak prone).
auto     -> run the skeleton pass; if >= ``auto_min_devanagari`` words (and >= ``auto_min_fraction`` of words) are Devanagari the audio is
            treated as Hinglish (hybrid), otherwise as English (forced-en pass). Per-FILE decision; the hybrid itself is word-level.
"""
from __future__ import annotations

import os
from typing import Callable, Optional

from . import coverage as cov
from .coverage import fuse, uncovered_gaps
from .hybrid import is_devanagari, merge
from .models import HINGLISH_PROMPT
from .quality import flag_words
from .transcribe import Transcriber, resolve_model, sanitize_words

STOCK_KEYS = ("turbo", "large-v3", "medium", "small", "distil-large-v3")
Progress = Optional[Callable[[float], None]]


def _slice(progress: Progress, a: float, b: float) -> Progress:
    return (lambda p: progress(a + (b - a) * p)) if progress else None


class Engine:
    def __init__(self, device: str = "auto", models_local_path: Optional[str] = None,
                 english_model: str = "turbo", hinglish_model: str = "hinglish-apex",
                 hinglish_strategy: str = "hybrid", auto_min_devanagari: int = 3, auto_min_fraction: float = 0.03):
        self.device = device
        self.models_local_path = models_local_path
        self.english_model, self.hinglish_model = english_model, hinglish_model
        self.hinglish_strategy = hinglish_strategy
        self.auto_min_devanagari, self.auto_min_fraction = auto_min_devanagari, auto_min_fraction
        self._cache: dict[str, Transcriber] = {}

    def _get(self, key: str) -> Transcriber:
        if key not in self._cache:
            self._cache[key] = Transcriber(key, self.device, models_local_path=self.models_local_path)
        return self._cache[key]

    def hinglish_model_available(self) -> bool:
        key = self.hinglish_model
        return key in STOCK_KEYS or os.path.isdir(resolve_model(key, self.models_local_path))

    # ------------------------------------------------------------------ passes
    def _skeleton(self, path: str, progress: Progress, kw: dict) -> dict:
        """Stock model, Hindi mode, NO prompt: English words in Latin, Hindi words in Devanagari."""
        return self._get(self.english_model).transcribe(path, "hinglish", progress=progress, initial_prompt="", **kw)

    def _hinglish(self, path: str, progress: Progress, kw: dict, skeleton: Optional[dict] = None):
        """Returns (result, prompt_used, warnings) for the configured Hinglish strategy."""
        warns: list[str] = []
        strategy = self.hinglish_strategy
        if strategy in ("hybrid", "apex") and not self.hinglish_model_available():
            warns.append(f"Hinglish model '{self.hinglish_model}' not found; used stock {self.english_model} + Roman prompt "
                         "(lower quality, may repeat the prompt text — check flagged words)")
            strategy = "stock_prompt"
        if strategy == "hybrid":
            sk = skeleton or self._skeleton(path, _slice(progress, 0.0, 0.5), dict(kw))
            hg = self._get(self.hinglish_model).transcribe(path, "hinglish", progress=_slice(progress, 0.5, 1.0),
                                                           initial_prompt="", **dict(kw))
            flag_words(hg["words"], hg["segments"], "hinglish")
            res = merge(sk, hg)
            res["words"] = sanitize_words(res["words"], res["warnings"])   # sources can overlap at span borders
            if getattr(self, "_env", None) and cov.APEX_FILL_GAPS:
                # the skeleton can miss stretches the Hinglish model heard (e.g. the stock model's first seconds): fill those from it
                res = fuse(res, hg, self._env, min_gap=cov.MIN_GAP_S)       # only long holes: the Hinglish model is weak on English words
                if res["fusion"]["patched_words"]:
                    warns.append(f"filled {res['fusion']['patched_words']} word(s) the stock model missed from the Hinglish model")
            if not res["hybrid_stats"]["hindi_runs"]:
                warns.append("no Hindi detected; result equals the English-script skeleton")
            return res, None, warns
        if strategy == "apex":
            return self._get(self.hinglish_model).transcribe(path, "hinglish", progress=progress,
                                                             initial_prompt="", **dict(kw)), None, warns
        prompt = kw.get("initial_prompt") or HINGLISH_PROMPT
        k = {x: y for x, y in kw.items() if x != "initial_prompt"}
        return self._get(self.english_model).transcribe(path, "hinglish", progress=progress, initial_prompt=prompt, **k), prompt, warns

    # ------------------------------------------------------------------ public
    def transcribe(self, path: str, language_mode: str = "english", progress: Progress = None, envelope: Optional[dict] = None,
                   fusion: bool = True, **kw) -> dict:
        """Transcribe with a coverage safety net.

        1. decode sequentially (long-form): the most ACCURATE mode when it works (digits, English words), measured 3.4 % WER on the reference clip
        2. measure LOUD audio that has NO usable words (coverage gaps) against the loudness envelope. Long-form decoding can silently drop most
           of a clip or fall into "market market market…" loops (both seen on real clips); junk/looping words do not count as coverage
        3. only if there are gaps: decode in independent VAD chunks (batched: robust, but less accurate on digits) and fill each gap from
           whichever pass has the words
        Remaining gaps are reported (result["quality"]["speech_gaps"]) and warned about — never silently ignored.
        """
        if not fusion or "batched" in kw:
            return self._transcribe_once(path, language_mode, progress, **kw)
        from .audio import compute_envelope
        env = envelope or compute_envelope(path)
        self._env = env
        try:
            res = self._transcribe_once(path, language_mode, _slice(progress, 0.0, 0.65), batched=False, **kw)
            gaps = uncovered_gaps(res["words"], env, cov.PATCH_GAP_S)
            info = {"primary": "sequential", "alternate_used": False, "gaps_first_pass": [(round(a, 2), round(b, 2)) for a, b in gaps], "patched_words": 0}
            if gaps:
                alt = self._transcribe_once(path, language_mode, _slice(progress, 0.65, 1.0), batched=True, **kw)
                ga = uncovered_gaps(alt["words"], env, cov.PATCH_GAP_S)
                a_sec, b_sec = sum(b - a for a, b in gaps), sum(b - a for a, b in ga)
                primary, secondary, pname = (alt, res, "batched") if a_sec - b_sec >= cov.SWITCH_MARGIN_S else (res, alt, "sequential")
                merged = fuse(primary, secondary, env)
                merged["warnings"] = sorted(set(merged["warnings"]) | set(res["warnings"]) | set(alt["warnings"]))
                merged["quality"] = merged.get("quality") or {}
                info.update({"primary": pname, "alternate_used": True, "patched_words": merged["fusion"]["patched_words"],
                             "gaps_after_fusion": merged["fusion"]["gaps_after"]})
                res = merged
                res.pop("fusion", None)
            res, info["head_rescue"] = self._rescue_head(path, env, res, kw)
            info["patched_words"] += info["head_rescue"]["patched_words"]
            remaining = uncovered_gaps(res["words"], env)
            spans = cov.speech_spans(env)
            if spans:                                    # a hole at the very start is reported from 0.6 s on: it is where listeners notice a missing caption first
                remaining += [g for g in uncovered_gaps(res["words"], env, cov.PATCH_GAP_S) if g[0] <= spans[0][0] + 0.05 and g not in remaining]
            info["gaps_remaining"] = [(round(a, 2), round(b, 2)) for a, b in remaining]
            res.setdefault("quality", {})["fusion"] = info
            res["quality"]["speech_gaps"] = info["gaps_remaining"]
            for a, b in remaining:
                res["warnings"].append(f"possible missing speech {a:.1f}–{b:.1f}s: the audio is loud there but no words were recognised — listen and add them in the transcript editor")
            if info["patched_words"]:
                res["warnings"].append(f"{info['patched_words']} word(s) were recovered from a second decoding pass ({info['primary']} was the main pass)")
            return res
        finally:
            self._env = None

    def _rescue_head(self, path: str, env: dict, res: dict, kw: dict) -> tuple[dict, dict]:
        """Start-of-clip rescue. A clip cut in the middle of a sentence has no lead-in, and decoders then often skip the first words (seen on every real
        Hinglish clip tried; the same can happen to English). If the audio is loud from the start but the first usable word comes later, the first seconds
        are decoded once more on their own behind a second of silence, with the same language route as the main result, moved back to the real timeline
        and used ONLY to fill that hole. Never raises: the main result is returned unchanged if anything goes wrong."""
        info = {"attempted": False, "patched_words": 0, "tries": 0}
        if not cov.HEAD_RESCUE:
            return res, info

        def head_gap(r: dict):
            spans = cov.speech_spans(env)
            if not spans:
                return None
            found = [g for g in uncovered_gaps(r["words"], env, cov.PATCH_GAP_S) if g[0] <= spans[0][0] + 0.05]       # a hole that starts where the speech starts
            return found[0] if found else None

        try:
            gap = head_gap(res)
            if gap is None:
                return res, info
            info.update(attempted=True, gap=[round(gap[0], 2), round(gap[1], 2)])
            from faster_whisper.audio import decode_audio
            audio = decode_audio(path, sampling_rate=16000)
            route = str((res.get("language") or {}).get("route") or "")
            mode = "hinglish" if route.startswith("hinglish") else "english"          # the route chosen for the WHOLE file (a 5 s window must not re-decide it)
            sub_kw = {k: v for k, v in kw.items() if k != "batched"}
            for pad, context in cov.HEAD_ATTEMPTS:                                    # a short decode is itself fickle: a few windows/paddings, stop once the hole is closed
                moved = self._decode_head(audio, mode, sub_kw, pad, gap[1] + context)
                info["tries"] += 1
                merged = fuse(res, {"words": moved}, env, min_gap=cov.PATCH_GAP_S, min_conf=cov.HEAD_MIN_CONF)
                if merged["fusion"]["patched_words"]:
                    info["patched_words"] += merged["fusion"]["patched_words"]
                    merged.pop("fusion", None)
                    res = merged
                gap = head_gap(res)
                if gap is None:
                    break
            if info["patched_words"]:
                res["warnings"] = list(res["warnings"]) + [f"{info['patched_words']} word(s) at the very start were recovered by decoding the first seconds again"]
            return res, info
        except Exception as exc:                                                       # never let the safety net break a transcription
            info["error"] = f"{type(exc).__name__}: {exc}"
            return res, info

    def _decode_head(self, audio, mode: str, kw: dict, pad: float, end_s: float) -> list[dict]:
        """Decode the first ``end_s`` seconds of ``audio`` behind ``pad`` seconds of silence; the words come back on the REAL timeline (silence removed)."""
        import tempfile
        import wave

        import numpy as np
        sr = 16000
        clip = np.concatenate([np.zeros(int(pad * sr), dtype=np.float32), audio[: int(min(len(audio) / sr, end_s) * sr)]])
        fd, tmp = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        try:
            with wave.open(tmp, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(sr)
                w.writeframes((np.clip(clip, -1.0, 1.0) * 32767).astype("<i2").tobytes())
            saved, self._env = getattr(self, "_env", None), None                       # the full-file envelope does not describe this clip
            try:
                sub = self._transcribe_once(tmp, mode, None, batched=False, **kw)
            finally:
                self._env = saved
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
        moved = []
        for w in sub["words"]:
            w = dict(w)
            w["start"], w["end"] = round(w["start"] - pad, 3), round(w["end"] - pad, 3)
            if w["end"] > 0.0:                                                         # anything inside the added silence is not speech
                w["start"] = max(0.0, w["start"])
                moved.append(w)
        return moved

    def _transcribe_once(self, path: str, language_mode: str = "english", progress: Progress = None, **kw) -> dict:
        warnings: list[str] = []
        prompt_used = None
        auto_info = None
        route = language_mode

        if language_mode == "english":
            res = self._get(self.english_model).transcribe(path, "english", progress=progress, **kw)
        elif language_mode == "hinglish":
            res, prompt_used, warnings = self._hinglish(path, progress, kw)
        elif language_mode == "auto":
            sk = self._skeleton(path, _slice(progress, 0.0, 0.3), dict(kw))
            n = len(sk["words"])
            d = sum(is_devanagari(w["text"]) for w in sk["words"])
            hindi = bool(n) and d >= self.auto_min_devanagari and d / n >= self.auto_min_fraction
            route = "hinglish" if hindi else "english"
            auto_info = {"devanagari_words": d, "words": n, "fraction": round(d / n, 3) if n else 0.0, "decision": route}
            if hindi:
                res, prompt_used, warnings = self._hinglish(path, _slice(progress, 0.3, 1.0), kw, skeleton=sk)
            else:
                res = self._get(self.english_model).transcribe(path, "english", progress=_slice(progress, 0.3, 1.0), **kw)
        else:
            raise ValueError("language_mode must be english, hinglish or auto")

        counts = flag_words(res["words"], res["segments"], "hinglish" if route == "hinglish" else "english", prompt_used)
        res["language"]["mode"] = language_mode
        res["language"].setdefault("route", route)
        if auto_info:
            res["language"]["auto"] = auto_info
        res["quality"] = {**(res.get("quality") or {}), "flag_counts": counts}
        res["warnings"] = warnings + res["warnings"] + [
            f"{n} word(s) flagged '{f}' — review in transcript editor" for f, n in counts.items()]
        return res
