import { S, on, emit, boot, loadProject } from './store.js';
import { get, post, waitJob } from './api.js';
import { h, $, fmtTime, toast, setStatus } from './dom.js';
import { Preview } from './preview.js';
import { Timeline } from './timeline.js';
import { renderInput } from './panel_input.js';
import { renderTranscript, renderGrouping, bindVideo } from './panel_transcript.js';
import { renderTypography, renderColors, renderAnimation, renderLayout } from './panel_style.js';
import { renderLook } from './panel_look.js';
import { renderGenerate, renderExport, paintUpdateBadge } from './panel_ae.js';

const SECTIONS = [
  ['input', 'Video & input', renderInput], ['transcript', 'Transcript & timing', renderTranscript], ['grouping', 'Caption grouping', renderGrouping],
  ['look', 'Caption look', renderLook], ['typography', 'Typography', renderTypography], ['colors', 'Colours & emphasis', renderColors], ['animation', 'Animation', renderAnimation],
  ['layout', 'Position & layout', renderLayout], ['generate', 'Generate in AE', renderGenerate], ['export', 'Export & help', renderExport],
];
const video = $('#video');

function renderNav() {
  $('#nav').replaceChildren(...SECTIONS.map(([id, label], i) => h('button', { class: id === S.section ? 'active' : '', onclick: () => show(id), title: label, 'aria-label': (i + 1) + ' ' + label, 'aria-current': id === S.section ? 'page' : null },
    h('span', { class: 'num' }, i + 1), h('span', { class: 't' }, label))));
}
let editing = false;
function show(id) {
  S.section = id; renderNav();
  const sec = SECTIONS.find((s) => s[0] === id);
  const scroll = $('#panel').scrollTop;
  const root = h('div', {}); $('#panel').replaceChildren(root); sec[2](root);
  $('#panel').scrollTop = scroll;
}
// re-render the current panel on data changes, but never while the user is typing in it
function refresh() {
  const a = document.activeElement;
  if (a && $('#panel').contains(a) && ['INPUT', 'SELECT', 'TEXTAREA'].includes(a.tagName) && a.type !== 'checkbox') return;
  show(S.section);
}
on('section', (id) => show(id || S.section));
on('groups', () => { if (['transcript', 'grouping', 'generate'].includes(S.section)) refresh(); });
on('selection', () => { if (S.section === 'transcript') show('transcript'); });
on('project', () => {
  $('#projname').textContent = S.meta ? S.meta.id : 'No project'; $('#noVideo').style.display = S.meta ? 'none' : '';
  const audioOnly = !!(S.meta && S.meta.probe && S.meta.probe.has_video === false);
  video.style.display = audioOnly ? 'none' : '';            // an audio file still plays through the same element
  if (S.meta) video.src = '/api/video?v=' + Date.now();
  else { video.pause(); video.removeAttribute('src'); video.load(); }          // project closed/deleted: let go of the file so it can be removed
  show(S.section);
  setTimeout(() => window.dispatchEvent(new Event('resize')), 50);
});
on('ae', () => paintAE());

// Browsers often cannot decode the PICTURE of phone / screen-recorder videos (HEVC/H.265, 10-bit, ...): the picture stays black while the sound plays.
// Then the app makes a small copy the browser can play. Only this preview uses it; After Effects and the transcription keep using the original file.
let proxyBusy = false;
const usingCopy = () => video.src.includes('proxy=1');
const isAudioOnly = () => !!(S.meta && S.meta.probe && S.meta.probe.has_video === false);
async function usePreviewCopy(force = false) {
  if (proxyBusy || !S.meta || isAudioOnly()) return;
  proxyBusy = true;
  const note = $('#noVideo'), t = video.currentTime || 0;
  try {
    note.style.display = '';
    note.textContent = 'Your browser cannot show this video’s picture (common with phone and screen-recorder files). Making a small preview copy… After Effects and the transcription still use your original file.';
    const r = await post('/api/preview-proxy', { force });
    if (!r.ready) {
      const done = await waitJob(r.job, (j) => { note.textContent = (j.message || 'Making a preview copy…') + '  (the original file is not changed)'; setStatus(`preview copy: ${Math.round(j.progress * 100)} %`); });
      if (done.state !== 'done') throw new Error(done.error || done.state);
    }
    video.addEventListener('loadedmetadata', () => { try { video.currentTime = t; } catch (e) { /* ignore */ } }, { once: true });
    video.src = '/api/video?proxy=1&v=' + Date.now();
    note.style.display = 'none';
    toast('Preview copy ready', 'ok');
  } catch (e) {
    note.textContent = 'Could not make a preview copy: ' + e.message;
    toast('Could not make a preview copy: ' + e.message, 'err', 9000);
  } finally { proxyBusy = false; setStatus(''); }
}
S.usePreviewCopy = usePreviewCopy;                                        // also behind the "picture black?" button in section 1
video.addEventListener('loadedmetadata', () => { if (S.meta && !isAudioOnly() && !usingCopy() && video.videoWidth === 0) usePreviewCopy(); });
video.addEventListener('error', () => { if (S.meta && !isAudioOnly() && !usingCopy() && video.error && video.error.code === 4) usePreviewCopy(); });

function paintAE() {
  const a = S.ae || {}, el = $('#aepill');
  el.className = 'pill ' + (a.connected ? 'on' : a.ae_running ? 'warn' : 'off');
  el.textContent = a.connected ? `After Effects ${a.ae_version || ''} · connected` : a.ae_running ? 'After Effects open · not connected' : 'After Effects · not running';
}

// ---- transport
const btn = $('#btnPlay');
btn.onclick = () => (video.paused ? video.play() : video.pause());
video.addEventListener('play', () => (btn.textContent = '⏸')); video.addEventListener('pause', () => (btn.textContent = '▶'));
$('#chkMute').onchange = (e) => (video.muted = e.target.checked);
setInterval(() => { const d = (S.meta && S.meta.probe && S.meta.probe.duration) || video.duration || 0; $('#timeLabel').textContent = `${fmtTime(video.currentTime)} / ${fmtTime(d)}`; }, 100);
document.addEventListener('keydown', (e) => {
  if (['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
  if (e.code === 'Space') { e.preventDefault(); btn.click(); }
  if (e.code === 'ArrowLeft') video.currentTime = Math.max(0, video.currentTime - (e.shiftKey ? 1 : 0.1));
  if (e.code === 'ArrowRight') video.currentTime += e.shiftKey ? 1 : 0.1;
});

(async function start() {
  try {
    const st = await boot();
    $('#ver').textContent = 'v' + st.version;
    const preview = new Preview(video, $('#overlay'));
    $('#chkCaps').onchange = (e) => { preview.show = e.target.checked; preview.draw(); };
    new Timeline($('#timeline'), $('#tlScroll'), video, $('#tlZoom'));
    bindVideo(video); paintAE(); renderNav();
    window.__fcg = { S, preview, show, video };               // handy for debugging in the browser console
    if (st.project) { await loadProject(); } else show('input');
    $('#updpill').onclick = () => show('export');
    // files on disk newer than this running program (an update was installed but the app was not restarted): remind in the header
    get('/api/update/status').then((u) => { if (u.restart_needed) { S.update = { ...(S.update || {}), restart_needed: true, current: u.current }; paintUpdateBadge(); } }).catch(() => {});
    // silent update check: only when the user switched it on, at most once a day (the server enforces both); a failure shows nothing
    if (st.settings && st.settings.update_check) post('/api/update/check', { auto: true }).then((r) => { if (r && r.latest) { S.update = r; paintUpdateBadge(); } }).catch(() => {});
    setInterval(async () => { try { S.ae = await get('/api/ae/status'); emit('ae'); if (S.section === 'generate' && !document.activeElement.matches('input,select')) { /* keep UI stable */ } } catch (e) { /* offline */ } }, 6000);
  } catch (e) { $('#panel').replaceChildren(h('div', { class: 'bad' }, 'Could not start: ' + e.message)); }
})();
