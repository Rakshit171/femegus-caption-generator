"""FemeGus Caption Generator — local transcription engine (no After Effects dependency)."""
