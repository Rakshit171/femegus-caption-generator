# Start the caption editor (local web app). Run from PowerShell:   .\scripts\fcgapp.ps1
# It prints an address with a one-time token and opens it in your browser. Nothing leaves this computer.
$root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = (Join-Path $root "app")
$env:PYTHONIOENCODING = "utf-8"
& (Join-Path $root ".venv\Scripts\python.exe") -m fcg_app @args
