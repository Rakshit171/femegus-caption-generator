"""System check: is this computer ready to use the tool, and if not, what exactly should the user do?

Every check returns {id, status: ok|warn|fail, title, detail, fix}. It reads things only (no installs, no changes), and each check is isolated so one failure
never hides the others. Run it with:  python -m fcg_app --check   (or the 'Run system check' button in section 10).
"""
from __future__ import annotations

import glob
import importlib
import os
import re
import shutil
import socket
import subprocess
import sys
from typing import Callable

from .ops import ROOT

MIN_PY = (3, 10)
RUNTIME_PACKAGES = [("faster_whisper", "faster-whisper"), ("ctranslate2", "ctranslate2"), ("av", "PyAV (av)"), ("numpy", "numpy"), ("onnxruntime", "onnxruntime")]
WARN_FREE_GB = 5.0


def _r(id_: str, status: str, title: str, detail: str = "", fix: str = "") -> dict:
    return {"id": id_, "status": status, "title": title, "detail": detail, "fix": fix}


def check_python() -> dict:
    v = sys.version_info
    ok = (v.major, v.minor) >= MIN_PY
    in_venv = os.path.abspath(sys.prefix).lower().startswith(os.path.abspath(os.path.join(ROOT, ".venv")).lower())
    if not ok:
        return _r("python", "fail", f"Python {v.major}.{v.minor} is too old", "Python 3.10 or newer is needed.", "Install Python 3.10–3.12 from python.org, then run scripts\\setup.ps1 again.")
    if not in_venv:
        return _r("python", "warn", f"Python {v.major}.{v.minor}.{v.micro} (not the project's own environment)", f"Running from {sys.prefix}",
                  "Start the app with scripts\\fcgapp.ps1 (or Start-FemeGus.cmd) so the project's .venv is used.")
    return _r("python", "ok", f"Python {v.major}.{v.minor}.{v.micro} in the project environment")


def check_packages() -> dict:
    missing, vers = [], []
    for mod, label in RUNTIME_PACKAGES:
        try:
            m = importlib.import_module(mod)
            vers.append(f"{label} {getattr(m, '__version__', '')}".strip())
        except Exception as e:
            missing.append(f"{label} ({type(e).__name__})")
    if missing:
        return _r("packages", "fail", "Missing Python packages: " + ", ".join(missing), "", "Run scripts\\setup.ps1 (it installs everything from requirements.txt).")
    return _r("packages", "ok", "Python packages installed", "; ".join(vers))


def check_gpu() -> dict:
    name = None
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"], capture_output=True, text=True, timeout=15)
        if out.returncode == 0 and out.stdout.strip():
            name = out.stdout.strip().splitlines()[0]
    except Exception:
        pass
    try:
        from fcg_engine.cuda_setup import prepare_cuda_dlls
        dirs = prepare_cuda_dlls()
        import ctranslate2
        n = ctranslate2.get_cuda_device_count()
    except Exception as e:
        return _r("gpu", "warn", "GPU check could not run", str(e), "The CPU will be used (slower).")
    if n > 0:
        return _r("gpu", "ok", "NVIDIA GPU ready for transcription", f"{name or 'GPU'} · CUDA devices seen by the engine: {n} · CUDA libraries from pip: {len(dirs)} folder(s)")
    if name:
        return _r("gpu", "warn", "NVIDIA GPU found but not usable by the engine", name + " — the CUDA 12 / cuDNN 9 libraries are probably missing",
                  "Run scripts\\setup.ps1 (installs nvidia-cublas-cu12 and nvidia-cudnn-cu12) and update the NVIDIA driver. Until then the CPU is used (about 7x slower).")
    return _r("gpu", "warn", "No NVIDIA GPU detected — the CPU will be used", "Transcription still works, roughly 7x slower on this class of machine.", "")


def _hf_cache_dirs() -> list[str]:
    base = os.environ.get("HF_HOME") or os.path.join(os.path.expanduser("~"), ".cache", "huggingface")
    return [os.path.join(os.environ.get("HF_HUB_CACHE", os.path.join(base, "hub")))]


def check_models() -> list[dict]:
    res = []
    cached = False
    for d in _hf_cache_dirs():
        if os.path.isdir(d):
            cached = any("large-v3-turbo" in n for n in os.listdir(d))
    res.append(_r("model_english", "ok" if cached else "warn", "English / stock speech model " + ("downloaded" if cached else "not downloaded yet"),
                  "large-v3-turbo (about 1.6 GB)" if cached else "It is downloaded automatically the first time you transcribe (internet needed once).",
                  "" if cached else "Optional: run scripts\\setup.ps1 -PreloadModels to download it now."))
    ct2 = os.path.join(ROOT, "models", "ct2", "hinglish-apex-fp16", "model.bin")
    ml = os.path.join(ROOT, "engine", "models_local.json")
    ok = os.path.isfile(ct2) and os.path.isfile(ml)
    res.append(_r("model_hinglish", "ok" if ok else "warn", "Hinglish model " + ("ready" if ok else "not set up"),
                  "Oriserve Whisper-Hindi2Hinglish-Apex (Apache-2.0), converted for CTranslate2" if ok else "Hinglish and Auto modes will fall back to a lower-quality method.",
                  "" if ok else "Run scripts\\setup_hinglish.ps1 once (about 3 GB download, a few minutes)."))
    return res


def check_fonts() -> dict:
    try:
        from . import fontscan
        fonts = fontscan.scan(cache_path=os.path.join(ROOT, "work", "fonts_cache.json"))
        have_arial = any(f["postscript"] == "ArialMT" for f in fonts)
        if not fonts:
            return _r("fonts", "fail", "No fonts found", "", "Check that C:\\Windows\\Fonts exists.")
        return _r("fonts", "ok" if have_arial else "warn", f"{len(fonts)} fonts found" + ("" if have_arial else " (Arial missing)"),
                  "" if have_arial else "The default look uses Arial.", "" if have_arial else "Pick other fonts in section 5.")
    except Exception as e:
        return _r("fonts", "warn", "Font scan failed", str(e), "")


def find_after_effects() -> list[dict]:
    out = []
    for exe in glob.glob(r"C:\Program Files\Adobe\Adobe After Effects *\Support Files\AfterFX.exe"):
        m = re.search(r"After Effects (\d{4}|[\w. ]+)\\Support", exe)
        ver = None
        try:
            ps = ["powershell", "-NoProfile", "-Command", f"(Get-Item '{exe}').VersionInfo.ProductVersion"]
            ver = subprocess.run(ps, capture_output=True, text=True, timeout=20).stdout.strip() or None
        except Exception:
            pass
        out.append({"path": exe, "name": m.group(1) if m else "?", "version": ver})
    return out


def read_script_pref(prefs_root: str | None = None) -> dict:
    """Read-only look at the 'Allow Scripts to Write Files and Access Network' preference of each installed After Effects version."""
    root = prefs_root or os.path.join(os.environ.get("APPDATA", ""), "Adobe", "After Effects")
    res: dict[str, bool | None] = {}
    if not os.path.isdir(root):
        return res
    for d in sorted(os.listdir(root)):
        pf = os.path.join(root, d, f"Adobe After Effects {d} Prefs.txt")
        if os.path.isfile(pf):
            val = None
            try:
                with open(pf, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        if "Pref_SCRIPTING_FILE_NETWORK_SECURITY" in line:
                            val = '"1"' in line
                            break
            except OSError:
                pass
            res[d] = val if val is not None else False
    return res


def check_after_effects() -> list[dict]:
    res = []
    inst = find_after_effects()
    if not inst:
        res.append(_r("ae_install", "warn", "No After Effects installation found in C:\\Program Files\\Adobe", "You can still transcribe and edit captions; generating layers needs After Effects.",
                      "Install After Effects (tested: 2025 / 25.2 only)."))
    else:
        res.append(_r("ae_install", "ok", "After Effects found: " + ", ".join(f"{i['name']} ({i['version'] or 'version unknown'})" for i in inst),
                      "Only 2025 (25.2) has been tested; other versions are not claimed.", ""))
    prefs = read_script_pref()
    if prefs:
        latest = sorted(prefs)[-1]
        ok = bool(prefs[latest])
        res.append(_r("ae_pref", "ok" if ok else "warn", f"After Effects {latest}: scripts may write files" if ok else f"After Effects {latest}: scripts are NOT allowed to write files",
                      "" if ok else "The connection report cannot be written, so generating from the app will not work.",
                      "" if ok else "In After Effects: Edit > Preferences > Scripting & Expressions > tick 'Allow Scripts to Write Files and Access Network'."))
    try:
        from . import ae_bridge
        st = ae_bridge.status()
        res.append(_r("ae_connection", "ok" if st["connected"] else "warn",
                      "After Effects is connected" if st["connected"] else ("After Effects is open but the connect script is not running" if st["ae_running"] else "After Effects is not running"),
                      f"version reported: {st['ae_version']}" if st["connected"] else "",
                      "" if st["connected"] else "In After Effects: File > Script > Run Script File… > adapters\\jsx-core\\fcg_connect.jsx (once per session)."))
    except Exception as e:
        res.append(_r("ae_connection", "warn", "Could not check the After Effects connection", str(e), ""))
    return res


def check_disk() -> dict:
    try:
        free = shutil.disk_usage(ROOT).free / 1e9
    except OSError as e:
        return _r("disk", "warn", "Could not read free disk space", str(e), "")
    try:
        os.makedirs(os.path.join(ROOT, "projects"), exist_ok=True)
        t = os.path.join(ROOT, "projects", ".write_test")
        open(t, "w").close(); os.remove(t)
    except OSError as e:
        return _r("disk", "fail", "The projects folder is not writable", str(e), "Move the tool to a folder you can write to (not Program Files).")
    if free < WARN_FREE_GB:
        return _r("disk", "warn", f"Only {free:.1f} GB free on the drive holding the tool", "Models need about 5 GB; projects are small.", "Free some space.")
    return _r("disk", "ok", f"{free:.0f} GB free; projects folder writable")


def check_port() -> dict:
    try:
        s = socket.socket(); s.bind(("127.0.0.1", 0)); s.close()
        return _r("network", "ok", "Local port available (the app is never reachable from other computers)")
    except OSError as e:
        return _r("network", "fail", "Cannot open a local port", str(e), "Check firewall / security software.")


def run_all() -> dict:
    checks: list[dict] = []
    for fn in (check_python, check_packages, check_gpu, check_models, check_fonts, check_after_effects, check_disk, check_port):
        try:
            r = fn()
            checks.extend(r if isinstance(r, list) else [r])
        except Exception as e:                       # a broken check must not hide the rest
            checks.append(_r(fn.__name__, "warn", f"{fn.__name__} crashed", f"{type(e).__name__}: {e}", ""))
    worst = "fail" if any(c["status"] == "fail" for c in checks) else ("warn" if any(c["status"] == "warn" for c in checks) else "ok")
    return {"overall": worst, "checks": checks}


def format_report(rep: dict) -> str:
    sym = {"ok": "[ OK ]", "warn": "[WARN]", "fail": "[FAIL]"}
    lines = []
    for c in rep["checks"]:
        lines.append(f"{sym[c['status']]} {c['title']}")
        if c["detail"]:
            lines.append(f"       {c['detail']}")
        if c["fix"] and c["status"] != "ok":
            lines.append(f"       -> {c['fix']}")
    lines.append("")
    lines.append({"ok": "Everything is ready.", "warn": "Ready, with the notes above.", "fail": "Not ready: fix the [FAIL] items above."}[rep["overall"]])
    return "\n".join(lines)
