"""Background jobs so a long transcription never blocks the UI (or After Effects)."""
from __future__ import annotations

import threading
import time
import traceback
import uuid
from typing import Any, Callable, Optional


class Job:
    def __init__(self, kind: str):
        self.id = uuid.uuid4().hex[:10]
        self.kind = kind
        self.state = "queued"       # queued | running | done | error | cancelled
        self.progress = 0.0
        self.message = ""
        self.result: Any = None
        self.error: Optional[str] = None
        self.started = None
        self.finished = None
        self.cancel_requested = False

    def set(self, progress: Optional[float] = None, message: Optional[str] = None) -> None:
        if progress is not None:
            self.progress = max(0.0, min(1.0, float(progress)))
        if message is not None:
            self.message = message

    def to_dict(self) -> dict:
        return {"id": self.id, "kind": self.kind, "state": self.state, "progress": round(self.progress, 3), "message": self.message,
                "result": self.result, "error": self.error, "seconds": round((self.finished or time.time()) - self.started, 1) if self.started else 0}


class JobManager:
    def __init__(self):
        self.jobs: dict[str, Job] = {}
        self._lock = threading.Lock()
        self.gpu_lock = threading.Lock()      # one transcription at a time (keeps VRAM use predictable)

    def start(self, kind: str, fn: Callable[[Job], Any]) -> Job:
        job = Job(kind)
        with self._lock:
            self.jobs[job.id] = job

        def run():
            job.state, job.started = "running", time.time()
            try:
                job.result = fn(job)
                job.state = "cancelled" if job.cancel_requested else "done"
                job.progress = 1.0 if job.state == "done" else job.progress
            except Exception as exc:                 # report, never crash the server
                job.state, job.error = "error", f"{type(exc).__name__}: {exc}"
                job.message = job.error
                traceback.print_exc()
            finally:
                job.finished = time.time()

        threading.Thread(target=run, daemon=True, name=f"job-{kind}-{job.id}").start()
        return job

    def get(self, jid: str) -> Optional[Job]:
        return self.jobs.get(jid)
