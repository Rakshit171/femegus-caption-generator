// Section 9: generate/update in After Effects.  Section 10: export & troubleshooting.
import { S, emit } from './store.js';
import { get, post, put, waitJob } from './api.js';
import { h, toast, setStatus } from './dom.js';

export function renderGenerate(root) {
  const ae = S.ae || {};
  const comp = h('input', { type: 'text', value: (S.meta && S.meta.ae && S.meta.ae.comp_name) || 'FCG Captions', style: { width: '180px' } });
  const addVideo = h('input', { type: 'checkbox', checked: true }), recreate = h('input', { type: 'checkbox' });
  const bar = h('div', { class: 'bar' }, h('i', {})), msg = h('div', { class: 'small' }), result = h('div', {});
  const go = h('button', { class: 'primary', disabled: !S.groups || !ae.connected }, 'Generate / update in After Effects');
  go.onclick = async () => {
    go.disabled = true; result.replaceChildren(); bar.firstChild.style.width = '3%'; msg.textContent = 'sending to After Effects…';
    try {
      const job = await post('/api/ae/generate', { comp_name: comp.value, add_video: addVideo.checked, recreate_comp: recreate.checked });
      const done = await waitJob(job, (j) => { bar.firstChild.style.width = Math.round(j.progress * 100) + '%'; msg.textContent = j.message || j.state; }, 700);
      if (done.state !== 'done') throw new Error(done.error || done.state);
      const r = done.result;
      bar.firstChild.style.width = '100%'; msg.textContent = '';
      result.append(h('div', { class: 'card' }, r.ok ? h('b', { class: 'ok' }, `✓ ${r.words} editable text layers in “${r.comp.name}” (${r.seconds}s)`) : h('b', { class: 'bad' }, '✗ After Effects reported errors'),
        r.verified === true ? h('div', { class: 'ok small' }, '✓ Verified inside After Effects: every layer starts at or after its word’s reveal time, no captions overlap, texts match.') : null,
        r.verified === false ? h('div', { class: 'bad small' }, '✗ Verification found problems:') : null, ...(r.verify_problems || []).map((p) => h('div', { class: 'bad small' }, '• ' + p)),
        ...(r.errors || []).map((p) => h('div', { class: 'bad small' }, '• ' + p)), ...(r.warnings || []).map((p) => h('div', { class: 'warn small' }, '• ' + p)),
        r.anim_stats ? h('div', { class: 'hint small' }, `animated ${r.anim_stats.animated} words` + (r.anim_stats.clamped ? `, ${r.anim_stats.clamped} shortened to fit` : '')) : null));
      toast(r.ok ? 'Captions are in After Effects' : 'After Effects reported errors', r.ok ? 'ok' : 'err');
    } catch (e) { msg.textContent = ''; result.append(h('div', { class: 'card bad' }, e.message)); toast(e.message, 'err', 8000); } finally { go.disabled = !ae.connected || !S.groups; }
  };
  const refresh = h('button', { class: 'small', onclick: async () => { S.ae = await get('/api/ae/status'); emit('ae'); emit('section', 'generate'); } }, 'check connection');
  const path = ae.connect_script || 'adapters\\jsx-core\\fcg_connect.jsx';
  root.replaceChildren(h('h2', {}, '9 · Generate in After Effects'),
    h('div', { class: 'hint small' }, 'Creates real, editable text layers (one per word) with effects and keyframes. Running it again replaces only the layers this tool made.'),
    h('div', { class: 'card' }, h('div', { class: 'row' }, h('b', {}, 'Connection'), h('span', { class: 'pill ' + (ae.connected ? 'on' : ae.ae_running ? 'warn' : 'off') }, ae.connected ? `connected · AE ${ae.ae_version || ''}` : ae.ae_running ? 'After Effects is open, not connected' : 'After Effects is not running'), refresh),
      ae.connected ? null : h('div', { class: 'small' }, 'In After Effects choose ', h('b', {}, 'File ▸ Script ▸ Run Script File…'), ' and pick:', h('pre', {}, path), 'Run it once per After Effects session. No installation, nothing in the After Effects folder is changed. If it is already running, wait ~10 s and check again.')),
    h('div', { class: 'row' }, h('label', { class: 'l' }, 'Composition name'), comp), h('div', { class: 'row' }, h('label', { class: 'l' }, 'Add the video'), addVideo, h('span', { class: 'hint small' }, 'as the bottom layer (first time only)')),
    h('div', { class: 'row' }, h('label', { class: 'l' }, 'Start fresh'), recreate, h('span', { class: 'hint small' }, 'delete and recreate the composition')),
    h('div', { class: 'row' }, go), bar, msg, result,
    S.groups ? null : h('div', { class: 'hint' }, 'Nothing to generate yet — transcribe first.'));
}

export function renderExport(root) {
  const d = S.diagnostics || {}, ae = S.ae || {};
  const link = (href, label) => h('a', { href, style: { color: 'var(--accent2)' } }, label);
  const rows = Object.entries(d).map(([k, v]) => h('tr', {}, h('td', { class: 'hint' }, k), h('td', {}, String(v))));
  root.replaceChildren(h('h2', {}, '10 · Export & troubleshooting'),
    h('div', { class: 'card' }, S.groups ? h('div', {}, h('div', { class: 'row' }, link('/api/export/srt', '⬇ SRT subtitles (one cue per caption)'), h('span', { class: 'hint small' }, 'plain interchange; the animated look exists only in After Effects')),
      h('div', { class: 'row' }, link('/api/export/groups', '⬇ groups.json (timed captions)'))) : h('div', { class: 'hint' }, 'Nothing to export yet.')),
    h('h3', {}, 'Project files'), h('div', { class: 'small' }, S.meta ? h('code', {}, 'projects\\' + S.meta.id) : '—', h('div', { class: 'hint small' }, 'transcript.json (engine output, never edited) · overrides.json (all your corrections) · groups.json · project.json (settings, style)')),
    h('h3', {}, 'Updates'), updatesCard(),
    h('h3', {}, 'System check'),
    h('div', { class: 'hint small' }, 'Checks Python, packages, GPU, speech models, fonts, After Effects and its script permission, and disk space. It only reads; it changes nothing.'),
    (() => {
      const out = h('div', {});
      const btn = h('button', { class: 'primary' }, 'Run system check');
      btn.onclick = async () => {
        btn.disabled = true; out.replaceChildren(h('div', { class: 'hint' }, 'checking…'));
        try {
          const rep = await get('/api/selfcheck');
          const col = { ok: 'ok', warn: 'warn', fail: 'bad' }, sym = { ok: '✓', warn: '!', fail: '✗' };
          out.replaceChildren(h('div', { class: 'card' }, ...rep.checks.map((c) => h('div', { class: 'row tight' }, h('b', { class: col[c.status] }, sym[c.status]), h('span', {}, c.title),
            c.detail ? h('span', { class: 'hint small' }, c.detail) : null, c.fix && c.status !== 'ok' ? h('div', { class: 'small', style: { width: '100%' } }, '→ ' + c.fix) : null)),
            h('b', { class: col[rep.overall] }, { ok: 'Everything is ready.', warn: 'Ready, with notes.', fail: 'Not ready — fix the ✗ items.' }[rep.overall])));
        } catch (e) { out.replaceChildren(h('div', { class: 'bad' }, e.message)); } finally { btn.disabled = false; }
      };
      return h('div', {}, btn, out);
    })(),
    h('h3', {}, 'System details'), h('table', {}, ...rows), h('div', { class: 'row' }, h('span', { class: 'pill ' + (ae.connected ? 'on' : 'off') }, ae.connected ? 'After Effects connected' : 'After Effects not connected')),
    h('h3', {}, 'Troubleshooting'),
    ...[['No After Effects connection', ' from File ▸ Script ▸ Run Script File once per session. Also tick Preferences ▸ Scripting & Expressions ▸ “Allow Scripts to Write Files and Access Network”.'],
        ['After Effects does nothing', 'A modal dialog (for example the disk-cache warning at startup) blocks scripts. Close it and try again.'],
        ['Transcription is slow or fails on the GPU', 'The app falls back to the CPU automatically. Check “cuda_devices” above; update the NVIDIA driver if it is 0.'],
        ['Words are wrong', 'Fix them in section 2; the timing stays. Flagged words (tags) are the least certain.'],
        ['Missing font in After Effects', 'The tool substitutes Arial and warns; install the font or pick another in section 5.'],
        ['Captions cover the speaker', 'Section 8 ▸ Vertical position.']].map(([q, a]) => h('details', {}, h('summary', {}, q), h('div', { class: 'small hint' }, a))));
}

// ---- updates: opt-in; contacts only the update site and only sends GET requests (nothing about you, your footage or your projects)
function updatesCard() {
  const box = h('div', { class: 'card' }), out = h('div', {});
  const stat = h('div', { class: 'small' }, `Installed version ${S.version || ''}`);
  const auto = h('input', { type: 'checkbox', checked: !!(S.settings && S.settings.update_check) });
  auto.onchange = async () => {
    try { await put('/api/update/setting', { enabled: auto.checked }); S.settings = { ...(S.settings || {}), update_check: auto.checked }; toast(auto.checked ? 'Automatic update checks on' : 'Automatic update checks off', 'ok'); } catch (e) { toast(e.message, 'err'); }
  };
  const btn = h('button', { class: 'primary' }, 'Check for updates');
  const render = (r) => {
    S.update = r; paintUpdateBadge();
    const kids = [];
    const news = (r.looks || []).filter((l) => l.status === 'new' || l.status === 'update');
    if (!r.app_update && !news.length) kids.push(h('div', { class: 'ok' }, `You are up to date (version ${r.current}).`));
    if (r.app_update) {
      const apply = h('button', { class: 'primary' }, `Update to version ${r.latest}`);
      apply.onclick = async () => {
        if (!confirm('Update the program to version ' + r.latest + '?\n\nYour projects, saved looks and downloaded models are not touched. A backup of the replaced files is kept so you can go back.')) return;
        apply.disabled = true; apply.textContent = 'Updating…';
        try {
          const res = await post('/api/update/apply', {});
          out.replaceChildren(h('div', { class: 'card' }, h('b', { class: 'ok' }, `Updated to version ${res.version}.`), h('div', {}, 'Close the app window and start it again to finish (Start-FemeGus.cmd).'),
            res.needs_setup ? h('div', { class: 'warn' }, 'This version needs new components: after restarting, run Install-FemeGus.cmd once more.') : null));
          S.update = null; paintUpdateBadge();
        } catch (e) { apply.disabled = false; apply.textContent = `Update to version ${r.latest}`; toast(e.message, 'err'); }
      };
      kids.push(h('div', { class: 'card' }, h('b', {}, `Version ${r.latest} is available`), r.released ? h('span', { class: 'hint small' }, '  released ' + r.released) : null,
        h('ul', { class: 'small' }, ...(r.notes || []).map((n) => h('li', {}, n))),
        r.needs_setup ? h('div', { class: 'warn small' }, 'Includes new components — you will be asked to run Install-FemeGus.cmd again afterwards.') : null, apply));
    }
    if (news.length) {
      const rows = news.map((l) => {
        const c = h('input', { type: 'checkbox', checked: true, 'data-name': l.name });
        return h('div', { class: 'row tight' }, c, h('span', {}, l.title), h('span', { class: 'pill ' + (l.status === 'new' ? 'on' : 'warn') + ' small' }, l.status === 'new' ? 'new look' : 'updated look'));
      });
      const inst = h('button', { class: 'primary small' }, 'Install selected looks');
      inst.onclick = async () => {
        const names = rows.map((b) => b.querySelector('input')).filter((c) => c.checked).map((c) => c.dataset.name);
        if (!names.length) return;
        inst.disabled = true;
        try { const res = await post('/api/update/looks', { names }); S.presets = res.presets; toast(`Installed: ${res.installed.join(', ')} — see section 4`, 'ok'); await check(); } catch (e) { inst.disabled = false; toast(e.message, 'err'); }
      };
      kids.push(h('div', { class: 'card' }, h('b', {}, 'Caption looks'), h('div', { class: 'hint small' }, 'Look packs are plain data files; installing one changes nothing about your projects.'), ...rows, inst));
    }
    out.replaceChildren(...kids);
  };
  async function check() {
    btn.disabled = true; out.replaceChildren(h('div', { class: 'hint' }, 'contacting the update site…'));
    try { render(await post('/api/update/check', {})); } catch (e) { out.replaceChildren(h('div', { class: 'bad' }, e.message)); } finally { btn.disabled = false; }
  }
  btn.onclick = check;
  const back = h('button', { class: 'small', title: 'put the files of the previous version back' }, 'Go back to the previous version');
  back.onclick = async () => {
    if (!confirm('Restore the previous version of the program files?')) return;
    try { const r = await post('/api/update/rollback', {}); toast(`Restored version ${r.version}. Restart the app.`, 'ok'); } catch (e) { toast(e.message, 'err'); }
  };
  get('/api/update/status').then((st) => {
    if (st.backups && st.backups.length) box.append(h('div', { class: 'row tight' }, back, h('span', { class: 'hint small' }, `previous version: ${st.backups[0].version}`)));
    if (st.cache) render(st.cache);
  }).catch(() => {});
  box.append(stat, h('div', { class: 'hint small' }, 'Updates come from a free public site (GitHub). Checking only downloads a small file; nothing about you, your footage or your projects is sent.'),
    h('div', { class: 'row tight' }, auto, h('label', {}, 'check automatically when the app starts (at most once a day)')), h('div', { class: 'row' }, btn), out);
  return box;
}
export function paintUpdateBadge() {
  const r = S.update, el = document.getElementById('updpill');
  if (!el) return;
  const n = r ? (r.app_update ? 1 : 0) + (r.looks || []).filter((l) => l.status === 'new' || l.status === 'update').length : 0;
  el.style.display = n ? '' : 'none';
  el.textContent = r && r.app_update ? `Update ${r.latest} available` : 'New caption looks available';
}
