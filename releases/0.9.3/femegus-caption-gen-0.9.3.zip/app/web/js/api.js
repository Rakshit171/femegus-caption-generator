// JSON API client. The session token travels in an HttpOnly cookie set when the page was opened.

// One clear banner (instead of a pile of identical errors) when the app behind this page has stopped.
function offline(on) {
  let el = document.getElementById('offlineBanner');
  if (!on) { if (el) el.remove(); return; }
  if (el) return;
  el = document.createElement('div');
  el.id = 'offlineBanner';
  el.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:99999;background:#5a1d1d;color:#fff;padding:10px 16px;font:14px system-ui,sans-serif;border-bottom:2px solid #d9534f';
  el.innerHTML = '<b>The caption app has stopped.</b> Look at its black window for a message (you can copy it to get help), then start it again with ' +
    '<code>Start-FemeGus.cmd</code> — it opens a NEW page; close this one. Your projects are saved.';
  document.body.appendChild(el);
}
export async function api(method, path, body) {
  const opt = { method, headers: {}, credentials: 'same-origin' };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  let res;
  try { res = await fetch(path, opt); } catch (e) { offline(true); throw new Error('The caption app is not reachable (is it still running?)'); }
  offline(false);
  let data = null;
  const ct = res.headers.get('Content-Type') || '';
  if (ct.includes('application/json')) data = await res.json();
  if (!res.ok) throw new Error((data && data.error) || `${res.status} ${res.statusText}`);
  return data;
}
export const get = (p) => api('GET', p);
export const post = (p, b = {}) => api('POST', p, b);
export const put = (p, b) => api('PUT', p, b);
export const del = (p) => api('DELETE', p);

// Poll a background job until it finishes; onTick gets the job object each time.
export async function waitJob(job, onTick, everyMs = 400) {
  let j = job;
  for (;;) {
    onTick && onTick(j);
    if (['done', 'error', 'cancelled'].includes(j.state)) return j;
    await new Promise((r) => setTimeout(r, everyMs));
    j = await get('/api/jobs/' + j.id);
  }
}
