"""transcript (+ overrides, config, optional loudness envelope) -> caption groups with reveal/exit times.

Pure function, no I/O. Data flow is one-directional: styling/animation code only ever READS this result.
"""
from __future__ import annotations

import bisect
from typing import Optional

from . import textnorm
from .audio_features import pause_after, refined_onsets, word_loudness
from .config import SegmenterConfig
from .edits import apply_overrides, apply_policy
from .emphasis import assign_roles
from .segmenter import segment
from .timing import reveal_times, schedule
from .verify import verify

SCHEMA = 1


def build(transcript: dict, overrides: Optional[dict] = None, cfg: Optional[SegmenterConfig] = None,
          envelope: Optional[dict] = None) -> dict:
    cfg = cfg or SegmenterConfig()
    ov = overrides or {}
    warns: list[str] = list(transcript.get("warnings", []))

    words, w = apply_overrides([dict(x) for x in transcript["words"]], ov)
    warns += w
    kept, excluded = apply_policy(words, cfg.exclude_flags)
    if excluded:
        warns.append(f"{len(excluded)} flagged word(s) excluded from captions (kept listed under 'excluded')")
    norm = textnorm.normalize(kept, ov.get("glossary"))
    if not norm:
        return {"schema": SCHEMA, "kind": "fcg.groups", "groups": [], "excluded": excluded, "warnings": warns + ["no words"],
                "config": cfg.to_dict(), "violations": [], "hard_boundaries_before": [], "source": transcript.get("source"),
                "language": transcript.get("language"), "stats": {}}

    starts = [x["start"] for x in norm]
    gap_break: set[int] = set()
    for e in excluded:
        i = bisect.bisect_right(starts, e["start"])
        if 0 < i < len(norm):
            gap_break.add(i)

    pauses = pause_after(norm, envelope, cfg.onset_speech_fraction)
    onsets = refined_onsets(norm, envelope, cfg.onset_mode, cfg.onset_max_shift_s, cfg.onset_speech_fraction)
    loud = word_loudness(norm, envelope)
    reveals_all = reveal_times(norm, onsets, cfg, warns)

    spans, hard, w = segment(norm, pauses, cfg, set(ov.get("break_before", [])), set(ov.get("join_before", [])), gap_break)
    warns += w

    gw = [norm[a:b] for a, b, _ in spans]
    gr = [reveals_all[a:b] for a, b, _ in spans]
    sched = schedule(gw, gr, cfg, warns)

    groups = []
    sentence_start = {i for i, r in hard.items() if r in ("sentence", "sentence_cue", "pause", "forced")} | {0}
    for gi, ((a, b, reason), ws, rv, (start, ex)) in enumerate(zip(spans, gw, gr, sched)):
        for k, x in enumerate(ws):
            x["first_in_sentence"] = (a + k) in sentence_start
        assign_roles(ws, loud[a:b], cfg)
        out_words = []
        for k, x in enumerate(ws):
            out_words.append({
                "id": x["id"], "ids": x["merged_ids"], "text": x["text"], "display": x["display"],
                "start": round(x["start"], 4), "end": round(x["end"], 4), "reveal": round(rv[k], 4),
                "onset_shift": round(max(0.0, onsets[a + k] - x["start"]), 4),
                "pause_after": round(pauses[a + k], 3), "role": x["role"], "role_source": x["role_source"],
                "confidence": x.get("confidence"), "flags": x.get("flags", []), "lang": x.get("lang"),
                "edited": bool(x.get("edited")), **({"style_override": x["style_override"]} if "style_override" in x else {}),
            })
        grp = {"id": f"g{gi + 1:04d}", "start": round(start, 4), "exit": round(ex, 4), "break_after": reason,
               "n_words": len(ws), "chars": sum(len(x["display"]) for x in ws) + len(ws) - 1, "words": out_words}
        # layout override chosen by the user for this caption: overrides["group_templates"] = {any word id in the group: "tiers"|"stack"|"flow"}
        gt = ov.get("group_templates") or {}
        for ow in out_words:
            if ow["id"] in gt and gt[ow["id"]] in ("tiers", "stack", "flow", "auto"):
                grp["template"] = gt[ow["id"]]
                break
        groups.append(grp)

    # exit values were computed from unrounded reveals; keep the contract exact after rounding
    for g in groups:
        g["exit"] = max(g["exit"], g["words"][-1]["reveal"] + 0.01, g["words"][-1]["end"])
    result = {
        "schema": SCHEMA, "kind": "fcg.groups", "source": transcript.get("source"), "language": transcript.get("language"),
        "config": cfg.to_dict(), "groups": groups, "excluded": [
            {"id": e["id"], "text": e["text"], "start": e["start"], "end": e["end"], "flags": e.get("flags", [])} for e in excluded],
        "hard_boundaries_before": [norm[i]["id"] for i in sorted(hard)],
        "warnings": warns,
    }
    result["violations"] = verify(result, [dict(x, id=x["id"]) for x in norm], cfg)
    ns = [g["n_words"] for g in groups]
    shifts = [x["onset_shift"] for g in groups for x in g["words"]]
    result["stats"] = {
        "groups": len(groups), "words": sum(ns), "avg_words_per_group": round(sum(ns) / len(ns), 2),
        "min_words": min(ns), "max_words": max(ns),
        "onset_shifted_words": sum(s > 0 for s in shifts), "mean_onset_shift_s": round(sum(shifts) / len(shifts), 4),
        "max_onset_shift_s": max(shifts), "used_envelope": envelope is not None,
        "break_reasons": {r: sum(g["break_after"] == r for g in groups) for r in sorted({g["break_after"] for g in groups})},
    }
    return result
