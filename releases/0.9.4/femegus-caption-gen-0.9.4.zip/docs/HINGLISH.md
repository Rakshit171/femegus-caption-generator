# English / Hinglish / Auto — design and test evidence

Status (2026-10-13): **hybrid route works well on the owner's real Hinglish clip (110 s, 353 words, 13 Hindi spans): 3.4 % WER vs 15–18 % for the
other strategies** against a provisional, owner-corrected reference. One speaker / one clip only, reference not fully audio-verified: promising, not proven.

## Stage 7 addendum (2026-10-14) — decoding robustness, more clips
Two further real clips (a 41 s Hinglish mp4, an 85 s nearly pure Hindi mp3) exposed failures that the reference clip never showed:
long-form (sequential) decoding **silently dropped ~70 % of the mp4**, made "market market market…" loops with the Hinglish model, and **lost the last ~11 s of the mp3**.
Forced English on the mp4 produced a fluent **translation** of the Hindi. The engine now (a) decodes sequentially (most accurate: 3.4 % WER on the reference clip),
(b) measures whether loud audio is left without words, and (c) only then runs the batched (independent chunk) decoder and fills the holes. Details and numbers: [TESTING.md](TESTING.md).
Accuracy of the two new clips is **not measured** (no reference text) — only completeness. Batched decoding is less reliable on digits (10.5 % vs 3.4 % WER on the reference clip), which is why it is the rescue pass, not the default.
Auto routing is still a heuristic validated on three clips; a pure-English clip with a strong Indian accent is untested.

## Modes
| Mode | What runs | Notes |
|---|---|---|
| English | stock large-v3-turbo, language forced `en` | ⚠️ forcing English makes Whisper **translate** any spoken Hindi into English. Only for English speech. |
| **Hinglish** | **hybrid** (below) | default strategy; `apex` and `stock_prompt` strategies kept as alternatives |
| Auto | skeleton pass (turbo, Hindi mode, no prompt); ≥3 words and ≥3 % Devanagari ⇒ Hinglish hybrid, else forced-English pass | per-file decision; thresholds configurable. Whisper's own language ID said "en" for the Hinglish clip, so it is NOT used. |

### The hybrid (`engine/fcg_engine/hybrid.py`)
1. **Skeleton**: stock turbo with `language=hi`, no prompt. English words come out in Latin script, Hindi words in Devanagari ⇒ **script = free word-level language ID**.
2. **Hinglish model**: Oriserve Whisper-Hindi2Hinglish-Apex (Apache-2.0, large-v3-turbo fine-tune, converted to CTranslate2) over the same audio.
3. **Merge**: each Devanagari run in the skeleton is replaced by the Hinglish model's Roman words whose time falls inside that run (±0.15 s).
   English words and their timings always come from the skeleton. Duplicates of an English word heard by both models are dropped.
   If the Hinglish model gave nothing for a span, the Devanagari words stay and are flagged `non_roman` — nothing is invented or silently removed.
4. Every output word keeps its own timestamp from the model that produced it ⇒ word-level timing across language switches.

## Measured accuracy (owner's corrected PROVISIONAL reference, 353 words, `tests/fixtures/hinglish_clip_reference.txt`)
The owner flagged that financial figures and some Hinglish phrases are still unverified against the audio, so treat the numbers as indicative.
Command: `.\scripts\fcg.ps1 evaluate <transcript.json> tests\fixtures\hinglish_clip_reference.txt --variants tests\fixtures\spelling_variants.json`

| Strategy | WER strict | WER (spelling variants equal) | sub / del / ins |
|---|---|---|---|
| English (forced `en`) | 17.6 % | 17.6 % | 50 / 7 / 5 |
| Hinglish — **hybrid** (default) | **5.1 %** | **3.4 %** | 8 / 3 / 1 |
| Hinglish — Apex only | 16.7 % | 15.0 % | 33 / 11 / 9 |
| Hinglish — stock + Roman prompt | 17.0 % | 16.7 % | 43 / 2 / 14 |
| Auto | 5.1 % | 3.4 % | (routes to hybrid) |

Hybrid's 12 remaining differences: number/currency **formatting** (`crore`→"CRR", `rupees`→"rs", `thousand`→",000" ×2), `funnel`→"funnels", `baith kar`→"baithakar",
"why **you should** choose me" vs reference "why **should you** choose me" (reference may be the doubtful one), and "thousand rupees" absent after "35 to 50" (owner flagged
figures as unverified — may be the reference rather than the recogniser). So the true recognition error is likely lower than 3.4 %; the formatting items are a
**display-text normaliser** job (Stage 3): join split tokens ("15 ,000"→"15,000", "one -on -one"→"one-on-one"), plus a user-editable glossary (crr→crore, rs→rupees).

## Evidence
### Real Hinglish clip (owner's, 1:50; Hindi phrases from 0:36 and heavily from 1:05)
| Strategy | Result |
|---|---|
| Forced English / Auto→English | English is excellent, but Hindi is **translated or dropped**: "Zyaadaatar coaches sell you theory" → "Most coaches sell you theory"; "To aap agar ek certified coach ho…" → "So if you are a certified coach…". Auto's language ID chose `en`. |
| Stock `hi` + Roman prompt | inconsistent: Roman on one half, **Devanagari** on the other; one Hindi sentence translated. |
| Apex alone | Hindi in nice casual Roman ("Tab mainne socha ki", "aapka funnel sudhaar ke de") but English errors/drops ("Nothing to flex…" missing, "business is stuck" → "fusion is stuck", "irregistable"), stray Devanagari junk, missing words. |
| **Hybrid** | English as good as stock; all 13 Hindi spans in Roman with Apex's wording; 0 Devanagari left; 11 low-confidence words flagged. Residual issues: a few spellings need editing (e.g. "1 CRR", "rs"), **punctuation is missing across Hindi spans** (e.g. "…comments down below India mein hazaaron…" is one run-on line) → the segmenter must not rely on punctuation alone (use pauses + capital-after-unpunctuated-word cue). |
Timings: the two models' word times agree within ≈0.1–0.15 s; hybrid word durations are sane (no ≤30 ms words). Output is **deterministic** (fixed seed; 3 runs identical).

### Earlier smoke tests (Hindi sample clips from the Apex repo, noisy call-centre audio)
Stock `hi` without prompt → Devanagari; stock + prompt → **prompt text repeated as speech** on noisy clips; Apex → Roman but junk/empty on very short noisy clips;
Apex on English speech → garbled intro (conf ≈ 0). These motivated the flags and the hybrid.

## Safeguards (`quality.py`)
Words are never deleted/rewritten by the engine — only flagged: `non_roman`, `repeat_run`, `low_confidence`, `prompt_leak`. The segmenter/editor (Stage 3/6)
applies a user-configurable policy. Degenerate timestamps are repaired only by moving words **later**. English-mode output with Devanagari/CJK is flagged.

## Open items
* Owner to audio-verify the reference (figures, Hinglish phrases) → re-score; add more clips (other speakers, pure Hindi, noisy audio).
* Pure/mostly-Hindi audio and different speakers/accents: untested.
* Casual-spelling dictionary (user-editable, non-destructive) if corrections show repeated patterns.
* Hindi spans where skeleton wrongly outputs Latin (Hindi words written phonetically in English letters) stay as the skeleton heard them — no detection possible by script.
* Roman Hinglish wrapping/readability is layout work (Stage 5); text path is shared with English.
