"""Hinglish hybrid route: stock Whisper as the skeleton, the Hinglish fine-tune only inside Hindi spans.

Why: on real creator Hinglish the stock model is far better on English words but writes Hindi in Devanagari; the Hinglish fine-tune writes
Hindi in Roman script well but garbles/drops English. Stock Whisper in ``language=hi`` mode (no prompt) writes Hindi words in Devanagari and
English words in Latin, so the *script* is a free word-level language ID. Every Devanagari run found in the skeleton is replaced by the
Roman words the Hinglish model produced for the SAME time window. Latin words (English) keep the skeleton's text and timing.

Nothing is invented: every output word comes from one of the two recognisers. If the Hinglish model produced nothing for a Hindi span,
the original Devanagari words are kept and flagged ``non_roman`` (the editor shows them; nothing disappears silently).
"""
from __future__ import annotations

import unicodedata
from typing import Callable, Optional

from .quality import _norm

WINDOW_PAD = 0.15     # seconds of tolerance when matching the two recognisers' word times
SAME_WORD_GAP = 0.30  # an identical word from both recognisers closer than this is one word, not two


def is_devanagari(text: str) -> bool:
    return any("DEVANAGARI" in unicodedata.name(c, "") for c in text)


def has_letters(text: str) -> bool:
    return any(c.isalpha() for c in text)


def _runs(words: list[dict]) -> list[tuple[int, int]]:
    """Index ranges [i, j] of consecutive words containing Devanagari (punctuation-only tokens are skipped over)."""
    runs, i, n = [], 0, len(words)
    while i < n:
        if is_devanagari(words[i]["text"]):
            j = i
            k = i + 1
            while k < n and (is_devanagari(words[k]["text"]) or not has_letters(words[k]["text"])):
                if is_devanagari(words[k]["text"]):
                    j = k
                k += 1
            runs.append((i, j))
            i = j + 1
        else:
            i += 1
    return runs


def _overlap(a0, a1, b0, b1) -> float:
    return max(0.0, min(a1, b1) - max(a0, b0))


def merge(skeleton: dict, hinglish: dict, pad: float = WINDOW_PAD) -> dict:
    """Return a transcript dict (same schema) combining ``skeleton`` (stock, language=hi) and ``hinglish`` (fine-tune)."""
    sk = [dict(w) for w in skeleton["words"]]
    hw = [dict(w) for w in hinglish["words"]]
    used: set[str] = set()
    out: list[dict] = []
    stats = {"hindi_runs": 0, "runs_replaced": 0, "runs_kept_devanagari": 0, "words_from_hinglish_model": 0}
    latin = [w for w in sk if not is_devanagari(w["text"])]

    runs = _runs(sk)
    run_of = {}
    for r, (i, j) in enumerate(runs):
        for k in range(i, j + 1):
            run_of[k] = r
    emitted_run: set[int] = set()

    for idx, w in enumerate(sk):
        if idx not in run_of:
            if is_devanagari(w["text"]):
                continue
            w["origin"] = "skeleton"
            out.append(w)
            continue
        r = run_of[idx]
        if r in emitted_run:
            continue
        emitted_run.add(r)
        i, j = runs[r]
        t0, t1 = sk[i]["start"], sk[j]["end"]
        stats["hindi_runs"] += 1
        cand = []
        for h in hw:
            if h["id"] in used or not has_letters(h["text"]):
                continue
            mid = (h["start"] + h["end"]) / 2
            if t0 - pad <= mid <= t1 + pad:
                # the skeleton owns every moment where it heard an English (Latin) word: drop a hinglish word that
                # overlaps one by more than half of its own duration (e.g. "funnel" vs "funnels")
                dur = max(h["end"] - h["start"], 1e-3)
                hn = _norm(h["text"])
                dup = any(_overlap(l["start"], l["end"], h["start"], h["end"]) > 0.5 * dur
                          or (hn and _norm(l["text"]) == hn and max(l["start"] - h["end"], h["start"] - l["end"]) < SAME_WORD_GAP)
                          for l in latin)
                if not dup:
                    cand.append(h)
        flags_junk = [h for h in cand if is_devanagari(h["text"]) or "repeat_run" in h.get("flags", [])]
        cand = [h for h in cand if h not in flags_junk]
        if cand:
            for h in cand:
                used.add(h["id"])
                h["origin"] = "hinglish_model"
                out.append(h)
            stats["runs_replaced"] += 1
            stats["words_from_hinglish_model"] += len(cand)
        else:
            for k in range(i, j + 1):
                x = sk[k]
                x["origin"] = "skeleton_devanagari"
                x.setdefault("flags", []).append("non_roman")
                out.append(x)
            stats["runs_kept_devanagari"] += 1

    out.sort(key=lambda w: (w["start"], w["end"]))
    # ids and segments
    segs = skeleton["segments"]
    for n, w in enumerate(out):
        w["id"] = f"w{n + 1:06d}"
    new_segments = []
    for s in segs:
        ids = [w["id"] for w in out if s["start"] - 1e-6 <= w["start"] < s["end"] + 1e-6]
        new_segments.append({"id": s["id"], "start": s["start"], "end": s["end"],
                             "text": " ".join(w["text"] for w in out if w["id"] in set(ids)), "word_ids": ids,
                             "lang": "hi"})
    seen: set[str] = set()
    for s in new_segments:                      # a word belongs to the first matching segment only
        s["word_ids"] = [i for i in s["word_ids"] if i not in seen]
        seen.update(s["word_ids"])
    by_id = {w["id"]: w for w in out}
    for s in new_segments:
        for i in s["word_ids"]:
            by_id[i]["segment"] = s["id"]
        s["text"] = " ".join(by_id[i]["text"] for i in s["word_ids"])
    orphan = [w for w in out if w["id"] not in seen]
    if orphan and new_segments:
        for w in orphan:
            seg = min(new_segments, key=lambda s: abs(s["start"] - w["start"]))
            seg["word_ids"].append(w["id"]); w["segment"] = seg["id"]
        for s in new_segments:
            s["word_ids"].sort(key=lambda i: by_id[i]["start"])
            s["text"] = " ".join(by_id[i]["text"] for i in s["word_ids"])

    res = dict(skeleton)
    res["words"], res["segments"] = out, new_segments
    res["engine"] = dict(skeleton["engine"], hybrid={"skeleton": skeleton["engine"]["model"],
                                                     "hinglish_model": hinglish["engine"]["model"]})
    res["language"] = dict(skeleton["language"], route="hinglish-hybrid")
    res["hybrid_stats"] = stats
    res["warnings"] = list(skeleton["warnings"]) + list(hinglish["warnings"])
    return res
