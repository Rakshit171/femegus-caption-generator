"""Flag suspicious recognition output. Words are NEVER deleted or rewritten here — only annotated with ``flags``
so the transcript editor can highlight them and the segmenter can apply a user-configurable policy.

Flags
  non_roman        alphabetic characters outside Latin script while English/Hinglish output was requested
  repeat_run       >= ``repeat_min`` consecutive identical tokens (typical Whisper loop/hallucination)
  low_confidence   word probability below ``low_conf``
  prompt_leak      segment text is (almost) a copy of the initial prompt, i.e. likely not real speech
"""
from __future__ import annotations

import re
import unicodedata

_WORD_RE = re.compile(r"[^\W_]+", re.UNICODE)


def _norm(text: str) -> str:
    return "".join(_WORD_RE.findall(text.lower()))


def _has_non_latin_letter(text: str) -> bool:
    for ch in text:
        if ch.isalpha() and not unicodedata.name(ch, "").startswith("LATIN"):
            return True
    return False


def add_flag(word: dict, flag: str) -> None:
    flags = word.setdefault("flags", [])
    if flag not in flags:
        flags.append(flag)


def flag_words(words: list[dict], segments: list[dict], language_mode: str, prompt: str | None = None,
               low_conf: float = 0.4, repeat_min: int = 4, leak_overlap: float = 0.8) -> dict:
    """Annotate in place. Returns counts per flag."""
    counts: dict[str, int] = {}

    def bump(w, f):
        add_flag(w, f)
        counts[f] = counts.get(f, 0) + 1

    if language_mode in ("english", "hinglish"):
        for w in words:
            if _has_non_latin_letter(w["text"]):
                bump(w, "non_roman")

    i = 0
    while i < len(words):
        j = i
        key = _norm(words[i]["text"])
        while j + 1 < len(words) and _norm(words[j + 1]["text"]) == key and key:
            j += 1
        if j - i + 1 >= repeat_min:
            for k in range(i, j + 1):
                bump(words[k], "repeat_run")
        i = j + 1

    for w in words:
        if w.get("confidence", 1.0) < low_conf:
            bump(w, "low_confidence")

    if prompt:
        ptoks = set(_WORD_RE.findall(prompt.lower()))
        by_id = {w["id"]: w for w in words}
        for seg in segments:
            stoks = _WORD_RE.findall(seg["text"].lower())
            if len(stoks) >= 3 and sum(t in ptoks for t in stoks) / len(stoks) >= leak_overlap:
                seg["flags"] = ["prompt_leak"]
                for wid in seg["word_ids"]:
                    bump(by_id[wid], "prompt_leak")
    return counts
