"""Project storage. One folder per video under ``projects/``; every file is plain JSON so it can be inspected, versioned and recovered.

projects/<id>/
  project.json     {id, video, language, created, config (segmenter overrides), style_preset, style (full style object), ae}
  transcript.json  engine output (never edited by the app)
  overrides.json   user corrections (see core/fcg_core/edits.py) — the ONLY place manual edits live
  envelope.json    loudness envelope (pauses / onsets)
  groups.json      latest built captions
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import threading
import time
from typing import Any, Optional

_lock = threading.RLock()


def _atomic_write(path: str, data: Any) -> None:
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def _read(path: str, default: Any = None) -> Any:
    if not os.path.isfile(path):
        return default
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


REPLACE_KEYS = ("template_styles",)       # a style that has these keys owns them completely (a look with no layout overrides must not inherit the default look's)


def deep_merge(base: Any, over: Any) -> Any:
    if isinstance(base, dict) and isinstance(over, dict):
        out = dict(base)
        for k, v in over.items():
            out[k] = v if k in REPLACE_KEYS else deep_merge(base[k], v) if k in base else v
        return out
    return over


def slug(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "-", name).strip("-")[:40] or "project"


class Project:
    FILES = ("transcript", "overrides", "envelope", "groups")

    def __init__(self, folder: str):
        self.folder = folder
        self.meta = _read(os.path.join(folder, "project.json"), {})

    @property
    def id(self) -> str:
        return self.meta["id"]

    def path(self, name: str) -> str:
        return os.path.join(self.folder, name + ".json")

    def get(self, name: str, default: Any = None) -> Any:
        with _lock:
            return _read(self.path(name), default)

    def put(self, name: str, data: Any) -> None:
        with _lock:
            _atomic_write(self.path(name), data)

    def save_meta(self) -> None:
        with _lock:
            _atomic_write(os.path.join(self.folder, "project.json"), self.meta)

    def summary(self) -> dict:
        t = self.get("transcript")
        return {"id": self.id, "video": self.meta.get("video"), "language": self.meta.get("language"),
                "created": self.meta.get("created"), "has_transcript": t is not None,
                "words": len(t["words"]) if t else 0, "has_groups": os.path.isfile(self.path("groups")),
                "style_preset": self.meta.get("style_preset")}


class ProjectStore:
    def __init__(self, base: str, default_style: dict, default_preset: str = "reference_style"):
        self.base = base
        self.default_style = default_style
        self.default_preset = default_preset
        os.makedirs(base, exist_ok=True)

    def _id_for(self, video: str) -> str:
        h = hashlib.sha1(os.path.abspath(video).lower().encode("utf-8")).hexdigest()[:6]
        return f"{slug(os.path.splitext(os.path.basename(video))[0])}-{h}"

    def open_video(self, video: str, language: str = "auto") -> Project:
        if not os.path.isfile(video):
            raise FileNotFoundError(f"video not found: {video}")
        pid = self._id_for(video)
        folder = os.path.join(self.base, pid)
        p = Project(folder)
        if not p.meta:
            p.meta = {"id": pid, "video": os.path.abspath(video), "language": language, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
                      "config": {}, "style_preset": self.default_preset, "style": self.default_style, "ae": {}}
            os.makedirs(folder, exist_ok=True)
            p.save_meta()
            p.put("overrides", {})
        return p

    def load(self, pid: str) -> Project:
        if not re.fullmatch(r"[A-Za-z0-9_-]+", pid):
            raise ValueError("bad project id")
        folder = os.path.join(self.base, pid)
        p = Project(folder)
        if not p.meta:
            raise FileNotFoundError(pid)
        return p

    def list(self) -> list[dict]:
        out = []
        for name in sorted(os.listdir(self.base)):
            f = os.path.join(self.base, name)
            if os.path.isfile(os.path.join(f, "project.json")):
                try:
                    out.append(Project(f).summary())
                except (OSError, ValueError):
                    pass
        return out
