// Central state + change events. Everything the panels and the preview share lives here.
import { get, put, post } from './api.js';
import { debounce, clone, deepMerge, toast, setStatus } from './dom.js';

export const S = {
  meta: null,            // project.json
  transcript: null,      // engine output (read-only)
  overrides: {},         // user corrections
  groups: null,          // built captions
  style: null,           // full style object (what gets sent to After Effects and drawn in the preview)
  defaults: null,        // {config, style}
  fonts: [], fontMap: {},
  presets: [],
  selection: new Set(), // selected word ids
  selectedGroup: null,
  time: 0, section: 'input', ae: null, busy: false,
};
const subs = {};
export function on(evt, fn) { (subs[evt] ||= []).push(fn); }
export function emit(evt, arg) { (subs[evt] || []).forEach((f) => f(arg)); }

export async function boot() {
  const [st, defs, fonts, presets] = await Promise.all([get('/api/state'), get('/api/defaults'), get('/api/fonts'), get('/api/presets')]);
  S.defaults = defs; S.fonts = fonts.fonts; S.presets = presets.presets;
  S.fontMap = Object.fromEntries(S.fonts.map((f) => [f.postscript, f]));
  S.ae = st.ae; S.diagnostics = st.diagnostics; S.version = st.version; S.settings = st.settings;
  S.style = clone(defs.style);
  return st;
}

export async function loadProject() {
  const p = await get('/api/project');
  S.meta = p.meta; S.transcript = p.transcript; S.overrides = p.overrides || {}; S.groups = p.groups;
  S.style = deepMerge(clone(S.defaults.style), p.meta.style || {});
  S.selection.clear(); S.selectedGroup = null;
  emit('project'); emit('groups');
}

// ---- overrides (manual corrections) -> server rebuilds the captions
let pendingOv = null;
const flushOv = debounce(async () => {
  try {
    const res = await put('/api/project/overrides', S.overrides);
    if (res && res.groups) { S.groups = res; emit('groups'); }
    setStatus('saved');
  } catch (e) { toast(e.message, 'err'); }
  pendingOv = null;
}, 350);
export function setOverrides(mutator) {
  mutator(S.overrides);
  pendingOv = true;
  setStatus('saving…');
  flushOv();
  emit('overrides');
}

export async function saveConfig(cfg) {
  S.meta.config = cfg;
  const res = await put('/api/project/config', cfg);
  if (res && res.groups) { S.groups = res; emit('groups'); }
}

const flushStyle = debounce(async () => {
  try {
    const res = await put('/api/project/style', { style: S.style, preset: S.meta && S.meta.style_preset });
    if (res && res.groups) { S.groups = res.groups; emit('groups'); }          // the look carries grouping rules and the captions were re-cut
    setStatus('saved');
  } catch (e) { toast(e.message, 'err'); }
}, 500);
export function styleChanged() { emit('style'); if (S.meta) { flushStyle(); setStatus('saving…'); } }

export function wordsFlat() { return S.groups ? S.groups.groups.flatMap((g) => g.words.map((w) => ({ g, w }))) : []; }
