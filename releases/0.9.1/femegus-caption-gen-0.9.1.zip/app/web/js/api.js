// JSON API client. The session token travels in an HttpOnly cookie set when the page was opened.
export async function api(method, path, body) {
  const opt = { method, headers: {}, credentials: 'same-origin' };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  let res;
  try { res = await fetch(path, opt); } catch (e) { throw new Error('The caption app is not reachable (is it still running?)'); }
  let data = null;
  const ct = res.headers.get('Content-Type') || '';
  if (ct.includes('application/json')) data = await res.json();
  if (!res.ok) throw new Error((data && data.error) || `${res.status} ${res.statusText}`);
  return data;
}
export const get = (p) => api('GET', p);
export const post = (p, b = {}) => api('POST', p, b);
export const put = (p, b) => api('PUT', p, b);
export const del = (p) => api('DELETE', p);

// Poll a background job until it finishes; onTick gets the job object each time.
export async function waitJob(job, onTick, everyMs = 400) {
  let j = job;
  for (;;) {
    onTick && onTick(j);
    if (['done', 'error', 'cancelled'].includes(j.state)) return j;
    await new Promise((r) => setTimeout(r, everyMs));
    j = await get('/api/jobs/' + j.id);
  }
}
