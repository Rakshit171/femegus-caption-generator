"""Start the caption editor:  python -m fcg_app [--port N] [--no-browser]"""
from __future__ import annotations

import argparse
import webbrowser

from .server import serve


def main() -> int:
    ap = argparse.ArgumentParser(prog="fcg_app")
    ap.add_argument("--port", type=int, default=0, help="0 = pick a free port")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--projects", default=None, help="folder for projects (default: <project>/projects)")
    ap.add_argument("--token", default=None, help="fixed session token (development only; default: random)")
    ap.add_argument("--check", action="store_true", help="run the system check and exit (exit code 1 if something is not ready)")
    args = ap.parse_args()
    if args.check:
        from . import selfcheck
        rep = selfcheck.run_all()
        print(selfcheck.format_report(rep))
        return 1 if rep["overall"] == "fail" else 0
    httpd, app = serve(args.port, args.projects, args.token)
    port = httpd.server_address[1]
    url = f"http://127.0.0.1:{port}/?token={app.token}"
    print("FemeGus Caption Generator is running (local only).")
    print(f"Open: {url}")
    print("Press Ctrl+C to stop.")
    if not args.no_browser:
        webbrowser.open(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("stopped")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
