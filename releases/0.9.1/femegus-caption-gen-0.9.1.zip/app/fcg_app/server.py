"""Local web server for the caption editor. Binds to 127.0.0.1 only; every request needs the per-session token (cookie or header) and a
local Host header (blocks DNS-rebinding). Pure standard library. Nothing leaves this machine.
"""
from __future__ import annotations

import http.cookies
import json
import mimetypes
import os
import re
import secrets
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Optional
from urllib.parse import parse_qs, unquote, urlparse

from . import ae_bridge, fontscan, ops, updater
from .jobs import JobManager
from .project import Project, ProjectStore, _atomic_write, deep_merge

ROOT = ops.ROOT
WEB = os.path.join(ROOT, "app", "web")
PRESETS = os.path.join(ROOT, "presets")
USER_PRESETS = os.path.join(PRESETS, "user")
DOWNLOADED_PRESETS = os.path.join(PRESETS, "downloaded")          # look packs installed by the updater
MAX_BODY = 64 * 1024 * 1024
def _read_version() -> str:
    """The installed version = the first line of the VERSION file in the project folder (the updater rewrites it)."""
    try:
        with open(os.path.join(ROOT, "VERSION"), "r", encoding="utf-8-sig") as f:
            v = f.readline().strip()
        if re.fullmatch(r"\d+(\.\d+){0,3}", v):
            return v
    except OSError:
        pass
    return "0.0.0"


VERSION = _read_version()



class ApiError(Exception):
    def __init__(self, status: int, msg: str):
        super().__init__(msg)
        self.status, self.msg = status, msg


def _load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def default_style() -> dict:
    st = _load_json(os.path.join(PRESETS, "reference_style.json"))
    st.pop("_comment", None)
    st.pop("_look", None)
    return st


class App:
    """Holds state shared by all requests."""

    def __init__(self, projects_dir: Optional[str] = None, token: Optional[str] = None):
        self.token = token or secrets.token_urlsafe(24)
        self.store = ProjectStore(projects_dir or os.path.join(ROOT, "projects"), default_style())
        self.jobs = JobManager()
        self.current: Optional[Project] = None
        self.fonts_cache = os.path.join(ROOT, "work", "fonts_cache.json")
        self._fonts: Optional[list] = None
        self.settings_path = os.path.join(self.store.base, "_settings.json")
        self.updater = updater.Updater(ROOT, version=VERSION)
        self.lock = threading.RLock()
        last = self.settings().get("last_project")                 # resume where the user left off
        if last:
            try:
                self.current = self.store.load(last)
            except (OSError, ValueError):
                self.current = None

    def settings(self) -> dict:
        try:
            return _load_json(self.settings_path)
        except (OSError, ValueError):
            return {}

    def save_settings(self, patch: dict) -> dict:
        s = {**self.settings(), **patch}
        _atomic_write(self.settings_path, s)
        return s

    def project(self) -> Project:
        if self.current is None:
            raise ApiError(409, "no project open")
        return self.current

    def fonts(self) -> list:
        if self._fonts is None:
            self._fonts = fontscan.scan(cache_path=self.fonts_cache)
        return self._fonts


def _preset_files() -> dict[str, tuple[str, bool]]:
    out: dict[str, tuple[str, bool]] = {}
    for d, builtin in ((PRESETS, True), (DOWNLOADED_PRESETS, False), (USER_PRESETS, False)):       # later folders win on the same name (an update, then your own)
        if os.path.isdir(d):
            for n in sorted(os.listdir(d)):
                if n.endswith(".json"):
                    out[n[:-5]] = (os.path.join(d, n), builtin)
    return out


def _look_meta(path: str) -> dict:
    """Title / description / tags of a preset ('_look' block). Presets without one get a title made from the file name."""
    try:
        look = (_load_json(path) or {}).get("_look") or {}
    except (OSError, ValueError):
        look = {}
    name = os.path.splitext(os.path.basename(path))[0]
    return {"title": look.get("title") or name.replace("_", " ").title(), "description": look.get("description", ""),
            "tags": look.get("tags", []), "toggle": look.get("toggle")}


def build_ae_options(app: App, project: Project, extra: dict) -> dict:
    style = deep_merge(default_style(), project.meta.get("style") or {})
    opts = {k: style[k] for k in ("layout", "roles", "template_styles") if k in style}
    opts["comp"] = {"name": extra.get("comp_name") or "FCG Captions"}
    opts["replace_existing"] = True
    opts["recreate_comp"] = bool(extra.get("recreate_comp"))
    if extra.get("add_video", True):
        opts["background"] = os.path.abspath(project.meta["video"])
    return opts


# ----------------------------------------------------------------------------------------------------------------------- routes
ROUTES: list[tuple[str, re.Pattern, Callable]] = []


def route(method: str, pattern: str):
    rx = re.compile("^" + re.sub(r"<(\w+)>", r"(?P<\1>[^/]+)", pattern) + "$")

    def deco(fn):
        ROUTES.append((method, rx, fn))
        return fn
    return deco


@route("GET", "/api/state")
def r_state(app: App, req, **kw):
    p = app.current
    return {"version": VERSION, "settings": app.settings(), "project": p.summary() if p else None, "ae": ae_bridge.status(),
            "diagnostics": ops.diagnostics()}


@route("GET", "/api/projects")
def r_projects(app: App, req, **kw):
    return {"projects": app.store.list()}


@route("POST", "/api/projects/open")
def r_open(app: App, req, **kw):
    b = req.json()
    video = b.get("video") or ""
    if not video:
        raise ApiError(400, "video path required")
    path = video.strip().strip('"')
    if os.path.isfile(path):                                  # refuse files that are neither video nor audio before creating a project
        pr = ops.probe(path)
        if not (pr.get("has_video") or pr.get("has_audio")):
            raise ApiError(415, f"'{os.path.basename(path)}' is not a video or audio file the app can read (supported: mp4, mov, mkv, avi, webm, m4v, wav, mp3, m4a).")
    try:
        app.current = app.store.open_video(path, b.get("language", "auto"))
    except FileNotFoundError as e:
        raise ApiError(404, str(e))
    if not app.current.meta.get("probe"):
        app.current.meta["probe"] = ops.probe(app.current.meta["video"])
        app.current.save_meta()
    app.save_settings({"last_project": app.current.id})
    return app.current.summary()


@route("POST", "/api/projects/load")
def r_load(app: App, req, **kw):
    try:
        app.current = app.store.load(req.json().get("id", ""))
    except (FileNotFoundError, ValueError) as e:
        raise ApiError(404, str(e))
    app.save_settings({"last_project": app.current.id})
    return app.current.summary()


@route("POST", "/api/pick-video")
def r_pick(app: App, req, **kw):
    """Native file dialog on the user's own machine (the browser cannot reveal a full path)."""
    try:
        import tkinter
        from tkinter import filedialog
        root = tkinter.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        path = filedialog.askopenfilename(title="Choose a video or audio file",
                                          filetypes=[("Video / audio", "*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.wav *.mp3 *.m4a"), ("All files", "*.*")])
        root.destroy()
    except Exception as e:
        raise ApiError(500, f"file dialog unavailable: {e}")
    return {"path": path or None}


@route("GET", "/api/project")
def r_project(app: App, req, **kw):
    p = app.project()
    return {"meta": p.meta, "transcript": p.get("transcript"), "overrides": p.get("overrides") or {}, "groups": p.get("groups"),
            "has_envelope": os.path.isfile(p.path("envelope"))}


@route("PUT", "/api/project/overrides")
def r_put_overrides(app: App, req, **kw):
    p = app.project()
    ov = req.json()
    if not isinstance(ov, dict):
        raise ApiError(400, "overrides must be an object")
    p.put("overrides", ov)
    return ops.build_groups(p) if p.get("transcript") else {"ok": True}


@route("PUT", "/api/project/config")
def r_put_config(app: App, req, **kw):
    p = app.project()
    from fcg_core import SegmenterConfig
    cfg = req.json()
    try:
        SegmenterConfig.from_dict(cfg)
    except (ValueError, TypeError) as e:
        raise ApiError(400, f"invalid grouping settings: {e}")
    p.meta["config"] = cfg
    p.save_meta()
    return ops.build_groups(p) if p.get("transcript") else {"ok": True}


@route("PUT", "/api/project/style")
def r_put_style(app: App, req, **kw):
    p = app.project()
    b = req.json()
    old_grouping = (p.meta.get("style") or {}).get("grouping") or {}
    p.meta["style"] = b.get("style", p.meta.get("style"))
    if "preset" in b:
        p.meta["style_preset"] = b["preset"]
    p.save_meta()
    if ((p.meta.get("style") or {}).get("grouping") or {}) != old_grouping and p.get("transcript"):
        try:
            return {"ok": True, "groups": ops.build_groups(p)}           # the look's grouping rules changed: captions are re-cut (reveal times unaffected)
        except ValueError as e:
            raise ApiError(400, f"invalid grouping settings in this look: {e}")
    return {"ok": True}


@route("GET", "/api/defaults")
def r_defaults(app: App, req, **kw):
    from fcg_core import SegmenterConfig
    return {"config": SegmenterConfig().to_dict(), "style": default_style()}


@route("POST", "/api/transcribe")
def r_transcribe(app: App, req, **kw):
    p = app.project()
    b = req.json()
    language = b.get("language", "auto")
    strategy = b.get("strategy", "hybrid")

    def run(job):
        with app.jobs.gpu_lock:
            return ops.transcribe(p, language, job, strategy)
    return app.jobs.start("transcribe", run).to_dict()


@route("POST", "/api/transcript/import")
def r_import(app: App, req, **kw):
    p = app.project()
    try:
        res = ops.import_transcript(p, req.json())
    except (ValueError, KeyError) as e:
        raise ApiError(400, str(e))
    return {"stats": res["stats"], "warnings": res["warnings"]}


@route("POST", "/api/groups/build")
def r_build(app: App, req, **kw):
    try:
        return ops.build_groups(app.project())
    except ValueError as e:
        raise ApiError(409, str(e))


@route("GET", "/api/jobs/<jid>")
def r_job(app: App, req, jid: str, **kw):
    j = app.jobs.get(jid)
    if not j:
        raise ApiError(404, "unknown job")
    return j.to_dict()


@route("POST", "/api/jobs/<jid>/cancel")
def r_job_cancel(app: App, req, jid: str, **kw):
    j = app.jobs.get(jid)
    if not j:
        raise ApiError(404, "unknown job")
    j.cancel_requested = True
    return {"ok": True}


@route("GET", "/api/envelope")
def r_envelope(app: App, req, **kw):
    """Downsampled loudness (max per bucket) for the timeline waveform."""
    env = app.project().get("envelope")
    if not env:
        return {"hop": 0.01, "db": []}
    step = max(1, int(req.query.get("step", ["5"])[0]))
    db = env["db"]
    return {"hop": env["hop"] * step, "db": [max(db[i:i + step]) for i in range(0, len(db), step)]}


@route("GET", "/api/fonts")
def r_fonts(app: App, req, **kw):
    return {"fonts": [{k: f[k] for k in ("postscript", "family", "style", "weight", "italic")} for f in app.fonts()]}


@route("GET", "/api/presets")
def r_presets(app: App, req, **kw):
    return {"presets": [{"name": n, "builtin": b, "look": _look_meta(p)} for n, (p, b) in _preset_files().items()]}


@route("GET", "/api/presets/<name>")
def r_preset(app: App, req, name: str, **kw):
    f = _preset_files().get(name)
    if not f:
        raise ApiError(404, "unknown preset")
    st = _load_json(f[0])
    st.pop("_comment", None)
    st.pop("_look", None)                         # metadata, not style
    return {"name": name, "builtin": f[1], "look": _look_meta(f[0]), "style": deep_merge(default_style(), st)}


@route("PUT", "/api/presets/<name>")
def r_put_preset(app: App, req, name: str, **kw):
    if not re.fullmatch(r"[A-Za-z0-9 _-]{1,40}", name):
        raise ApiError(400, "preset names: letters, digits, space, _ and - (max 40)")
    files = _preset_files()
    if name in files and files[name][1]:
        raise ApiError(409, "built-in presets are read-only; save under another name")
    os.makedirs(USER_PRESETS, exist_ok=True)
    _atomic_write(os.path.join(USER_PRESETS, name + ".json"), req.json())
    return {"ok": True}


@route("DELETE", "/api/presets/<name>")
def r_del_preset(app: App, req, name: str, **kw):
    files = _preset_files()
    if name not in files or files[name][1]:
        raise ApiError(404, "no such user preset")
    os.remove(files[name][0])
    return {"ok": True}


@route("GET", "/api/selfcheck")
def r_selfcheck(app: App, req, **kw):
    from . import selfcheck
    return selfcheck.run_all()


# ----------------------------------------------------------------------------------------------------------------------- updates (opt-in)
def _upd(fn, *a):
    try:
        return fn(*a)
    except updater.UpdateError as e:
        raise ApiError(502, str(e))


@route("GET", "/api/update/status")
def r_update_status(app: App, req, **kw):
    s = app.settings()
    return {"current": app.updater.current_version(), "enabled": bool(s.get("update_check")), "cache": s.get("update_cache"), "backups": app.updater.backups(),
            "site": app.updater.base}


@route("PUT", "/api/update/setting")
def r_update_setting(app: App, req, **kw):
    app.save_settings({"update_check": bool(req.json().get("enabled"))})
    return {"enabled": bool(app.settings().get("update_check"))}


@route("POST", "/api/update/check")
def r_update_check(app: App, req, **kw):
    """`auto: true` = the silent check at start-up: only when switched on, and at most once a day. A manual check always contacts the site."""
    auto = bool(req.json().get("auto"))
    s = app.settings()
    if auto:
        if not s.get("update_check"):
            return {"skipped": "automatic checks are off"}
        last = s.get("update_last_check") or 0
        if time.time() - last < updater.CHECK_INTERVAL_S and s.get("update_cache"):
            return {**s["update_cache"], "cached": True}
    try:
        res = app.updater.check()
    except updater.UpdateError as e:
        if auto:
            return {"skipped": str(e)}                                   # a silent check never shows an error
        raise ApiError(502, str(e))
    app.save_settings({"update_last_check": time.time(), "update_cache": res})
    return res


@route("POST", "/api/update/looks")
def r_update_looks(app: App, req, **kw):
    names = req.json().get("names") or []
    if not isinstance(names, list) or not all(isinstance(n, str) for n in names):
        raise ApiError(400, "names must be a list")
    done = _upd(app.updater.install_looks, names)
    s = app.settings()
    if s.get("update_cache"):                                           # the cached "new looks" notice is out of date now
        c = s["update_cache"]
        for e in c.get("looks", []):
            if e["name"] in done:
                e["status"] = "current"
        app.save_settings({"update_cache": c})
    return {"installed": done, "presets": r_presets(app, req)["presets"]}


@route("POST", "/api/update/apply")
def r_update_apply(app: App, req, **kw):
    res = _upd(app.updater.apply_app_update)
    app.save_settings({"update_cache": None})
    return res


@route("POST", "/api/update/rollback")
def r_update_rollback(app: App, req, **kw):
    res = _upd(app.updater.rollback)
    app.save_settings({"update_cache": None})
    return res


@route("GET", "/api/ae/status")
def r_ae_status(app: App, req, **kw):
    return ae_bridge.status()


@route("POST", "/api/ae/generate")
def r_ae_generate(app: App, req, **kw):
    p = app.project()
    b = req.json()
    if not os.path.isfile(p.path("groups")):
        ops.build_groups(p)
    opts = build_ae_options(app, p, b)

    def run(job):
        return ae_bridge.submit(p, opts, "build", job=job)
    return app.jobs.start("ae-generate", run).to_dict()


@route("POST", "/api/dev/save-json")
def r_dev_save(app: App, req, **kw):
    """Developer aid for parity tests: the browser can store a JSON dump under work/devdump/ (fixed folder, strict name).
    Disabled unless the app was started with the environment variable FCG_DEV=1 (it is not part of the end-user surface)."""
    if os.environ.get("FCG_DEV") != "1":
        raise ApiError(404, "not found")
    b = req.json()
    name = b.get("name", "")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", name):
        raise ApiError(400, "bad name")
    folder = os.path.join(ROOT, "work", "devdump")
    os.makedirs(folder, exist_ok=True)
    _atomic_write(os.path.join(folder, name + ".json"), b.get("data"))
    return {"ok": True}


@route("GET", "/api/export/srt")
def r_srt(app: App, req, **kw):
    g = app.project().get("groups")
    if not g:
        raise ApiError(409, "no captions yet")
    return ("text", ops.export_srt(g), "application/x-subrip", f"{app.project().id}.srt")


@route("GET", "/api/export/groups")
def r_export_groups(app: App, req, **kw):
    g = app.project().get("groups")
    if not g:
        raise ApiError(409, "no captions yet")
    return ("text", json.dumps(g, ensure_ascii=False, indent=1), "application/json", f"{app.project().id}.groups.json")


# ----------------------------------------------------------------------------------------------------------------------- HTTP
class Request:
    def __init__(self, handler: BaseHTTPRequestHandler, query: dict):
        self.h, self.query = handler, query
        self._body: Optional[bytes] = None

    def body(self) -> bytes:
        if self._body is None:
            n = int(self.h.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                raise ApiError(413, "request too large")
            self._body = self.h.rfile.read(n) if n else b""
        return self._body

    def json(self) -> Any:
        raw = self.body()
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except ValueError as e:
            raise ApiError(400, f"invalid JSON: {e}")


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        server_version = "FemeGusCaptions/" + VERSION
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):       # keep the console quiet; errors are printed explicitly
            pass

        # --- security
        def _host_ok(self) -> bool:
            host = (self.headers.get("Host") or "").split(":")[0].lower()
            return host in ("127.0.0.1", "localhost")

        def _authed(self, query: dict) -> bool:
            if self.headers.get("X-FCG-Token") == app.token:
                return True
            c = http.cookies.SimpleCookie(self.headers.get("Cookie") or "")
            return "fcg_token" in c and secrets.compare_digest(c["fcg_token"].value, app.token)

        def _send(self, status: int, body: bytes, ctype: str, extra: Optional[dict] = None):
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _json(self, status: int, obj: Any):
            self._send(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

        def _dispatch(self, method: str):
            try:
                u = urlparse(self.path)
                query = parse_qs(u.query)
                if not self._host_ok():
                    return self._json(403, {"error": "bad host"})
                path = unquote(u.path)
                extra: dict = {}
                if not path.startswith("/api/"):
                    # static UI: the first visit carries ?token=..., which becomes an HttpOnly cookie
                    tok = (query.get("token") or [""])[0]
                    if tok and secrets.compare_digest(tok, app.token):
                        extra["Set-Cookie"] = f"fcg_token={app.token}; Path=/; HttpOnly; SameSite=Strict"
                    elif not self._authed(query):
                        return self._send(401, b"Open the address printed by the app (it contains a one-time token).", "text/plain")
                    return self._static(path, extra)
                if not self._authed(query):
                    return self._json(401, {"error": "unauthorised"})
                if method == "GET" and path == "/api/video":
                    return self._video()
                for m, rx, fn in ROUTES:
                    if m != method:
                        continue
                    mt = rx.match(path)
                    if mt:
                        res = fn(app, Request(self, query), **mt.groupdict())
                        if isinstance(res, tuple) and res and res[0] == "text":
                            return self._send(200, res[1].encode("utf-8"), res[2] + "; charset=utf-8",
                                              {"Content-Disposition": f'attachment; filename="{res[3]}"'})
                        return self._json(200, res)
                return self._json(404, {"error": "not found"})
            except ApiError as e:
                self._json(e.status, {"error": e.msg})
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as e:                  # never leak a stack trace to the page, but print it for the developer
                traceback.print_exc()
                try:
                    self._json(500, {"error": f"{type(e).__name__}: {e}"})
                except Exception:
                    pass

        def _static(self, path: str, extra: dict):
            rel = "index.html" if path in ("/", "") else path.lstrip("/")
            full = os.path.normpath(os.path.join(WEB, rel))
            if not full.startswith(os.path.normpath(WEB) + os.sep) or not os.path.isfile(full):
                # shared, browser-loadable maths/geometry live outside app/web (single source of truth)
                shared = {"shared/anim.js": os.path.join(ROOT, "core", "anim", "anim.js"),
                          "shared/fcg_layout.js": os.path.join(ROOT, "adapters", "jsx-core", "lib", "fcg_layout.jsxinc")}
                full = shared.get(rel)
                if not full or not os.path.isfile(full):
                    return self._send(404, b"not found", "text/plain")
            ctype = "application/javascript" if full.endswith((".js", ".jsxinc")) else (mimetypes.guess_type(full)[0] or "application/octet-stream")
            with open(full, "rb") as f:
                data = f.read()
            self._send(200, data, ctype + ("; charset=utf-8" if ctype.startswith(("text/", "application/javascript")) else ""), extra)

        def _video(self):
            p = app.project()
            path = p.meta["video"]
            if not os.path.isfile(path):
                return self._json(404, {"error": "video file missing"})
            size = os.path.getsize(path)
            ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
            start, end = 0, size - 1
            rng = self.headers.get("Range")
            status = 200
            if rng:
                m = re.fullmatch(r"bytes=(\d*)-(\d*)", rng.strip())
                if not m:
                    return self._send(416, b"", "text/plain", {"Content-Range": f"bytes */{size}"})
                if m.group(1):
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else size - 1
                else:
                    start, end = max(0, size - int(m.group(2) or 0)), size - 1
                end = min(end, size - 1)
                if start > end:
                    return self._send(416, b"", "text/plain", {"Content-Range": f"bytes */{size}"})
                status = 206
            length = end - start + 1
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(length))
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                with open(path, "rb") as f:
                    f.seek(start)
                    left = length
                    while left > 0:
                        chunk = f.read(min(256 * 1024, left))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        left -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self): self._dispatch("GET")
        def do_POST(self): self._dispatch("POST")
        def do_PUT(self): self._dispatch("PUT")
        def do_DELETE(self): self._dispatch("DELETE")

    return Handler


def serve(port: int = 0, projects_dir: Optional[str] = None, token: Optional[str] = None) -> tuple[ThreadingHTTPServer, App]:
    app = App(projects_dir, token)
    httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(app))
    httpd.daemon_threads = True
    return httpd, app
