"""Operations the API exposes: transcribe, envelope, build groups, SRT export, diagnostics. Heavy imports are lazy so the server starts fast."""
from __future__ import annotations

import os
import sys
import threading
from typing import Optional

from .project import Project

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
for sub in ("core", "engine"):
    p = os.path.join(ROOT, sub)
    if p not in sys.path:
        sys.path.insert(0, p)

_engine = None
_engine_key = None
_engine_lock = threading.Lock()


def get_engine(strategy: str = "hybrid"):
    """One Engine per process: the Whisper models stay loaded between jobs."""
    global _engine, _engine_key
    with _engine_lock:
        if _engine is None or _engine_key != strategy:
            from fcg_engine.engine import Engine
            _engine = Engine("auto", os.path.join(ROOT, "engine", "models_local.json"), hinglish_strategy=strategy)
            _engine_key = strategy
        return _engine


def probe(video: str) -> dict:
    """Size / frame rate / duration of the video (PyAV ships with faster-whisper). Falls back to None fields on failure."""
    try:
        import av
        with av.open(video) as c:
            v = next((s for s in c.streams if s.type == "video"), None)
            has_audio = any(s.type == "audio" for s in c.streams)
            dur = float(c.duration / 1_000_000) if c.duration else None
            if v is None:
                return {"width": None, "height": None, "fps": None, "duration": dur, "has_video": False, "has_audio": has_audio}
            fps = float(v.average_rate) if v.average_rate else None
            vdur = float(v.duration * v.time_base) if v.duration and v.time_base else dur       # the container may be longer (audio tail)
            return {"width": v.codec_context.width, "height": v.codec_context.height, "fps": fps, "duration": vdur, "has_video": True,
                    "has_audio": has_audio}
    except Exception:
        return {"width": None, "height": None, "fps": None, "duration": None, "has_video": False, "has_audio": False}


def transcribe(project: Project, language: str, job=None, strategy: str = "hybrid") -> dict:
    if language not in ("english", "hinglish", "auto"):
        raise ValueError("language must be english, hinglish or auto")
    from fcg_engine.audio import compute_envelope
    video = project.meta["video"]
    if job:
        job.set(0.02, "loading models (first run only)…")
    eng = get_engine(strategy)
    if job:
        job.set(0.04, "measuring the audio…")
    env = compute_envelope(video)                              # used for pauses, onsets AND the speech-coverage safety net
    project.put("envelope", env)
    res = eng.transcribe(video, language, envelope=env,
                         progress=(lambda p: job.set(0.06 + 0.88 * p, "transcribing…")) if job else None)
    project.put("transcript", res)
    project.meta["language"] = language
    project.save_meta()
    if job:
        job.set(0.97, "grouping captions…")
    groups = build_groups(project)
    return {"words": len(res["words"]), "route": res["language"].get("route"), "warnings": res["warnings"], "groups": groups["stats"],
            "speech_gaps": (res.get("quality") or {}).get("speech_gaps", [])}


def import_transcript(project: Project, transcript: dict, with_envelope: bool = True) -> dict:
    if "words" not in transcript or not isinstance(transcript["words"], list):
        raise ValueError("transcript needs a 'words' list")
    for i, w in enumerate(transcript["words"]):
        for k in ("id", "text", "start", "end"):
            if k not in w:
                raise ValueError(f"word {i} is missing '{k}'")
    project.put("transcript", transcript)
    if with_envelope and project.get("envelope") is None and os.path.isfile(project.meta["video"]):
        try:
            from fcg_engine.audio import compute_envelope
            project.put("envelope", compute_envelope(project.meta["video"]))
        except Exception:                    # envelope is optional (pauses fall back to timestamps)
            pass
    return build_groups(project)


def build_groups(project: Project) -> dict:
    from fcg_core import SegmenterConfig, build
    t = project.get("transcript")
    if t is None:
        raise ValueError("no transcript yet")
    # the current LOOK may carry grouping rules (style.grouping, e.g. "four words per line"); they override the project's own settings while that look is
    # active, and vanish when another look replaces the style. Grouping never changes when a word is revealed.
    look_grouping = (project.meta.get("style") or {}).get("grouping") or {}
    cfg, warns = SegmenterConfig.from_dict({**(project.meta.get("config") or {}), **look_grouping})
    res = build(t, project.get("overrides") or {}, cfg, project.get("envelope"))
    res["look_grouping"] = look_grouping
    res["warnings"] = warns + res["warnings"]
    project.put("groups", res)
    return res


def _ts(sec: float, sep: str = ",") -> str:
    ms = int(round(sec * 1000))
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d}{sep}{ms % 1000:03d}"


def export_srt(groups: dict) -> str:
    """One cue per caption group: first reveal -> exit. (Word-by-word animation is After-Effects only; SRT is the simple interchange.)"""
    out = []
    for i, g in enumerate(groups["groups"], 1):
        out.append(f"{i}\n{_ts(g['start'])} --> {_ts(g['exit'])}\n{' '.join(w['display'] for w in g['words'])}\n")
    return "\n".join(out)


def diagnostics() -> dict:
    d: dict = {"python": sys.version.split()[0], "root": ROOT}
    try:
        import ctranslate2
        d["ctranslate2"] = ctranslate2.__version__
        d["cuda_devices"] = ctranslate2.get_cuda_device_count()
    except Exception as e:
        d["ctranslate2"] = f"unavailable: {e}"
    try:
        import faster_whisper
        d["faster_whisper"] = faster_whisper.__version__
    except Exception as e:
        d["faster_whisper"] = f"unavailable: {e}"
    d["hinglish_model_present"] = os.path.isdir(os.path.join(ROOT, "models", "ct2", "hinglish-apex-fp16"))
    d["models_local_json"] = os.path.isfile(os.path.join(ROOT, "engine", "models_local.json"))
    d["engine_loaded"] = _engine is not None
    return d
