# Changelog

Each release has a `## <version>` heading followed by bullet points; the bullets are what the app shows as "what's new" when an update is available.

## 0.9.1
- New look "Clean 4-Word": plain white text, at most four words per line, with a one-click smooth slide-up animation switch.
- New look "Soft Editorial": centred light-sans lines, key words in serif caps / bold glow / bold inline / warm bold / gold glow / serif italic, letter-by-letter reveals.
- Caption looks gallery (section 4): change the whole style in one click; save your own looks.
- Per-word and key-word styling: any installed font, solid or gradient fill, outline and glow, for one word or every occurrence.
- Updates: check for new versions and new looks from inside the app (opt-in).
- Fixes: fill colour hidden by a gradient, layout-specific overrides ignoring "all layouts" edits, After Effects reports for relative project folders.
