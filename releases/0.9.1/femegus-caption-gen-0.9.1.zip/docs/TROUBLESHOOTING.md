# Troubleshooting

First, run the **system check** (`.\scripts\fcgapp.ps1 --check`, PowerShell in the project folder — or section 10 in the app). It names the problem and the fix for most cases below.

## Setup and start
| Symptom | Cause / fix |
|---|---|
| `setup.ps1` says Python was not found | Install Python 3.10–3.12 from python.org with **Add python.exe to PATH**, open a *new* PowerShell, run again |
| "running scripts is disabled" | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, or run `powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1` |
| pip fails / hangs | Internet needed for the first install (several GB). Re-run `setup.ps1`; it resumes. Behind a proxy: set `HTTPS_PROXY` |
| `Start-FemeGus.cmd` says "not set up yet" | Run `.\scripts\setup.ps1` once |
| The browser shows "Open the address printed by the app" | The link needs its one-time token. Use the exact address the app printed (or restart the app) |
| Port/firewall message | The app only listens on `127.0.0.1` (this computer). Allow Python in the firewall prompt, or restart the app to pick another port |

## Transcription
| Symptom | Cause / fix |
|---|---|
| "The speech model … could not be loaded" | First use needs internet once (1.6 GB). Connect, retry. For the Hinglish model run `.\scripts\setup_hinglish.ps1` |
| Very slow transcription | The GPU is not used. System check → GPU row. Update the NVIDIA driver; `setup.ps1` (without `-CpuOnly`) installs the CUDA libraries |
| GPU "out of memory" | Close other GPU apps (After Effects uses VRAM too) and retry. If the model cannot be *loaded* on the GPU the app falls back to the CPU by itself; a failure in the middle of a run is not retried automatically |
| "could not be read as audio or video" | Unsupported/damaged file. Supported: mp4, mov, mkv, avi, webm, m4v, wav, mp3, m4a |
| Red "missing speech?" on the timeline | Loud audio with no recognised words. Click ▶ in section 1, listen, and add the words in section 2 ("Insert a missed word"). The engine already tried a second decoding pass |
| Hindi words came out in English | You used **English** mode: it translates Hindi. Use **Auto** or **Hinglish** and transcribe again |
| English speech came out as Roman Hindi | Auto chose Hinglish for a strongly accented English speaker. Choose **English** |
| Digits/numbers wrong or missing | Fix them in section 2; numbers are the least reliable part of the rescue pass |
| Wrong words | Edit them in section 2 — timing is untouched. Flagged words (tags) are the least certain |

## Captions and preview
| Symptom | Cause / fix |
|---|---|
| Captions cover the speaker's face | Section 8 ▸ **Vertical position** (default 0.60 = lower middle) |
| A caption stays too short / long | Section 3 ▸ hold times, min visible; very fast speech cannot stay longer without overlapping the next caption (the tool never overlaps) |
| A word appears a little late / early-looking | By design a word is shown **at or after** its recognised start, never before. Section 3 ▸ *Reveal delay* shifts every reveal later; there is deliberately no setting to show words earlier |
| Preview glow/blur looks different from After Effects | Those three are approximations in the preview; timing, layout and motion are exact |
| Font looks wrong in the preview | The font must be installed in Windows. Pick another in section 5 |
| A colour/font change in section 5/6 "does nothing" on some captions | Those captions use a layout (e.g. *stack*) with its own override of that property. Since v0.8.1 editing "all layouts" replaces it; in older versions switch "Editing" to that layout |
| The Fill colour has no effect | The role uses a gradient, which hides the solid fill. Section 6 ▸ **Fill type** → Solid colour (or edit the gradient top/bottom) |

## After Effects
| Symptom | Cause / fix |
|---|---|
| App shows "After Effects … not connected" | Run `adapters\jsx-core\fcg_connect.jsx` (File ▸ Script ▸ Run Script File…) once per After Effects session; wait ~10 s |
| The script alerts "not allowed to write files" | Edit ▸ Preferences ▸ Scripting & Expressions ▸ tick **Allow Scripts to Write Files and Access Network** |
| Nothing happens after "Generate" | A modal dialog in After Effects (e.g. the disk-cache warning at startup) blocks scripts — close it. The app times out after 15 minutes |
| "font … not installed; using ArialMT" | After Effects does not have that font. Install it or choose another; the layers still build |
| Generation is slow | Time grows with the word count: about 0.15 s per word with all effects and animation (measured: 1,520 words ≈ 4 minutes, 283 words ≈ 1 minute). After Effects is busy meanwhile but stays responsive |
| Verification shows problems | The message names them (premature start, overlap, style not applied). Please keep the `work\ae_test` folder and report it |
| I edited layers in After Effects and Update removed my edits | "Update" replaces every layer whose **Comment** starts with `FCG:` (that is how the tool recognises its own layers). To keep a hand-edited layer, clear its Comment field (Layer ▸ Comment column), or generate into a differently named composition (section 9) |
| After Effects shows **"Fatal Error — Error at hooking API 'NtProtectVirtualMemory'"** on its loading screen and closes | **Not caused by this tool** (it adds nothing to After Effects' startup; the connect script runs only when you run it). Diagnosed 2026-10-15 on the dev PC: the error box is titled with the DLL that raised it — `aejuice_utils.dll`, loaded while the splash said "AEJuice Pack Manager 4" — i.e. a third-party plug-in's hooking code failing (AE's own plug-in scan had finished). Fix: update/reinstall that plug-in or contact its vendor; to disable it, **move** (as Administrator) `C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore\AEJuice Pack Manager` out of the Plug-ins tree (e.g. to `C:\AEJuice_disabled_backup\`). **Renaming it is not enough** — After Effects scans plug-in sub-folders recursively and loads every `.aex`/DLL there whatever the folder is called (a `.disabled` rename still loaded `aejuice_utils.dll`; verified 2026-10-15), and an uninstall can leave this folder behind. The error title bar always names the module — read it first. Other plug-ins that hook APIs (overlays, anti-cheat, audio/voice tools) can produce the same box |
| After Effects 2024 / 2026 | **Not tested.** The tool warns when the version is not 25.x. See COMPATIBILITY.md |

## Cleaning up / freeing space
* `work\` is scratch space (test renders, variants). Safe to delete: `Remove-Item work\* -Recurse -Force` (PowerShell, project folder) — it is re-created when needed.
* `models\hf\` (original Hinglish weights, 1.5 GB) and `.venv-convert\` are only needed to convert the model: `.\scripts\setup_hinglish.ps1 -CleanUp`.
* Projects live in `projects\<name>\`. Deleting a folder there removes that project's transcript, corrections and settings.

## Reporting a problem
Run the system check, then send: its text, the project folder `projects\<name>` (no video inside; only small JSON files), and what you clicked.
