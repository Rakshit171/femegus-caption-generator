# Licences — what is free, and what is not

**No paid service, subscription, account, API key or cloud processing is required.** After the one-time downloads the tool works fully offline; footage and audio are
processed only on this computer. The only paid item you need is **Adobe After Effects itself** (your existing licence).

Licences below were read from the installed packages' own metadata (`pip`) and from the models' Hugging Face pages on 2026-10-14. This is not legal advice; check the upstream licences before redistributing.

## Speech models (downloaded once)
| Model | Used for | Licence | Size |
|---|---|---|---|
| OpenAI Whisper **large-v3-turbo**, CTranslate2 conversion (`mobiuslabsgmbh/faster-whisper-large-v3-turbo`) | English, Hindi-mode first pass | MIT | 1.6 GB |
| **Oriserve Whisper-Hindi2Hinglish-Apex** (fine-tune of large-v3-turbo; we convert it locally) | Hindi → Roman-script Hinglish | Apache-2.0 | 1.5 GB |
| Silero VAD (shipped inside faster-whisper) | finding speech in audio | MIT upstream (not re-verified here) | small |
Optional/unused by default: `Systran/faster-whisper-large-v3` (MIT) if you select it.

## Python packages (installed by `scripts\setup.ps1`)
| Package | Licence | Free? |
|---|---|---|
| faster-whisper, CTranslate2 | MIT | yes |
| PyAV (`av`; bundles FFmpeg libraries) | BSD-3-Clause (the bundled FFmpeg libraries have their own, LGPL-family licence — per PyAV's documentation, not re-verified here) | yes |
| numpy | BSD | yes |
| onnxruntime | MIT | yes |
| huggingface_hub, tokenizers, hf-xet, flatbuffers | Apache-2.0 | yes |
| tqdm | MPL-2.0 and MIT | yes |
| httpx2/httpcore2, anyio, h11, idna, click, colorama, protobuf, sympy, mpmath, coloredlogs, humanfriendly, pyreadline3, PyYAML, filelock, fsspec, packaging, typing_extensions, truststore, tomli, exceptiongroup | MIT / BSD / Apache-2.0 / PSF | yes |
| **nvidia-cublas-cu12, nvidia-cudnn-cu12, nvidia-cuda-nvrtc-cu12** | **NVIDIA proprietary licence** (free to download and use for this purpose; **not open source**) | free, not open source. Skip with `-CpuOnly` |
| pytest (tests only) | MIT | yes |
The browser app uses **no external scripts, fonts or images** (no CDN): all JavaScript is in `app/web` and the two shared files from `core/anim` and `adapters/jsx-core/lib`.

## Fonts
The tool uses fonts already installed on your computer (default: Arial, which ships with Windows). Fonts you select are subject to *their own* licences — in particular
"personal use only" or demo fonts must not be used in client work. The tool never copies or embeds fonts.

## Network use
Apart from the one-time downloads (pip packages, speech models), the only network use is the **optional** update check/download from the public GitHub update site (docs/UPDATES.md): plain GET requests, https only, nothing about you or your footage is sent; off unless you switch it on (or click "Check for updates").

## This project's own code
The project's own code is under the **FemeGus Free Use License** (file `LICENSE`, chosen 2026-10-20): free to use for personal and commercial work; no selling, no redistribution of the Software or of modified copies; what you create with it is yours. It is a plain-language custom licence, not legal advice; the copyright holder can change it for future versions (for example to MIT if wider sharing is wanted). `scripts\publish.ps1` refuses to publish without a `LICENSE` file.

## Summary table
| Component | Cost |
|---|---|
| Speech recognition, alignment, grouping, animation, app | free / open |
| NVIDIA CUDA runtime wheels | free, proprietary licence |
| Hugging Face downloads | free, no account needed for these (non-gated) models |
| Adobe After Effects | **paid (your existing licence)** |
