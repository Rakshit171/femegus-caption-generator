"""Speech-coverage check + fusion of two transcription passes.

Why: no single decoding mode is reliable on every clip. Sequential long-form decoding silently dropped ~70 % of one real clip and made
"market market…" loops with the Hinglish model; batched (independent VAD chunks) fixed that clip but dropped a 6.6 s stretch of another.
Both failures are the same observable thing: LOUD audio with NO words. That is measured here from the loudness envelope, and gaps in
one pass are filled from the other (never with junk: flagged / looping words are not imported).
"""
from __future__ import annotations

from typing import Optional

from .hybrid import has_letters, plausible_number
from .quality import _norm

SPEECH_FRACTION = 0.30      # speech threshold = noise floor + fraction * (loud speech - floor), same rule as the timing core
BIN_S = 0.05
MERGE_HOLE_S = 0.40         # silence shorter than this inside speech does not split it
MIN_SPAN_S = 0.60           # shorter loud bursts (coughs, clicks) are not speech
WORD_PAD_S = 0.35           # a word "covers" this much time around itself
MIN_GAP_S = 1.50            # REPORT uncovered speech at least this long (shown red on the timeline, warned about)
PATCH_GAP_S = 0.60          # TRY TO FILL uncovered speech this long from the other decoding pass. Lower than the report threshold on purpose: the sequential
                            # decoder sometimes skips just the first second or two of a clip that starts mid-speech (a cut clip), which a 1.5 s threshold missed
APEX_FILL_GAPS = True       # Hinglish hybrid: first fill long holes of the stock-model skeleton with the Hinglish model's own words
HEAD_RESCUE = True          # switch for the start-of-clip rescue below
HEAD_ATTEMPTS = ((0.0, 4.0), (0.0, 2.5), (1.0, 4.0), (2.0, 4.0))   # start-of-clip rescue: (seconds of silence put in front, seconds decoded after the hole).
                            # The first seconds are decoded again on their own and moved back to the real timeline. Measured on real clips: a window with NO run-in
                            # of silence is the most reliable (silence in front made the Hinglish model babble "stories stories stories"), but a short decode is
                            # fickle either way, so up to four windows are tried, stopping as soon as the hole is closed
WINDOW_ATTEMPTS = ((0.0, 2.0), (0.0, 3.0), (1.0, 1.0), (0.0, 1.0))   # Hindi stretch the Hinglish model skipped: it is asked again for just that stretch
                            # (seconds of silence in front, seconds of speech after the stretch). Up to four windows are tried and the answer closest in length to
                            # what the stock model heard there is used (loops and Devanagari are rejected)
LOOP_REPAIR = True          # switch for the loop repair below
LOOP_PAD_S = 0.5            # a looped stretch ("vah, vah, vah, …" from the Hinglish model, seen for 15+ seconds on a real clip, which then left ALL its Hindi unwritten)
LOOP_CHUNK_S = 8.0          # is decoded again in windows of at most this many seconds, starting a little before the loop
LOOP_ATTEMPTS = ((1.3, 3, 0.4), (1.15, 0, 0.4), (1.5, 3, 1.2), (1.0, 0, 1.2))   # per window (repetition_penalty, no_repeat_ngram_size, context seconds each side); see Engine._redecode
REDECODE_GOOD_AGREEMENT = 0.6   # a re-decode that reproduces this share of the stock model's words is accepted at once, otherwise the best of the attempts is used
LOOP_MIN_WORDS_PER_S = 0.5  # an answer sparser than this over a speech window is not an answer (the stretch would stay empty)
LOOP_MIN_SHARE = 0.6        # ... nor one with fewer than this share of the words the stock model heard in the same window (a decode that stops after one sentence)
APEX_WINDOWED = True        # the Hinglish model decodes the file in short windows cut at pauses instead of one long-form pass (see Engine._hinglish_pass)
WINDOW_PASS_S = 8.0         # window length; each border is moved to the quietest moment within +- WINDOW_PASS_SLACK_S so no word is cut
WINDOW_PASS_SLACK_S = 2.0
WINDOW_PASS_ATTEMPTS = ((0, 0, 0.4), (1.3, 3, 0.4), (1.15, 0, 1.2))   # first usable answer wins; later attempts only when one loops or is far too short
TIGHT_ATTEMPTS = ((0, 0, 0.0), (0, 0, 0.6), (1.3, 3, 0.3), (0, 0, 1.2))   # a Hindi stretch that replaces a translation is decoded on its own; () switches it off
SECOND_OPINION = True       # switch for the second opinion below
SECOND_OPINION_WINDOW_S = 8.0     # the Hinglish model's long-form words are compared with the stock model's in windows of this length ...
SECOND_OPINION_MIN_AGREE = 0.5    # ... and a window where fewer than this share of the stock model's English words are matched is decoded again by itself
SECOND_OPINION_ATTEMPTS = ((0, 0, 0.4), (0, 0, 1.2), (1.3, 3, 0.4), (1.15, 0, 1.2))   # (repetition_penalty, no_repeat_ngram_size, context seconds each side); 0 = off. Plain first
HEAD_HOLE_S = 0.60          # the first caption may start this long after the speech starts (the recogniser's first word usually starts within ~0.3 s)
HEAD_MIN_CONF = 0.20        # a word imported by the rescue must be at least this certain (noise at the very start must not become words)
SWITCH_MARGIN_S = 2.0      # the second (batched, less accurate on digits) pass becomes the MAIN pass only if it leaves this many seconds fewer uncovered;
                            # a smaller difference is just patched into the sequential result
MIN_DYNAMIC_RANGE_DB = 10.0  # loud-vs-quiet difference needed before anything counts as speech
MIN_PEAK_DB = -55.0          # a clip whose loudest part is quieter than this is treated as silent


def _percentile(sorted_vals, p):
    k = (len(sorted_vals) - 1) * p / 100.0
    lo = int(k); hi = min(lo + 1, len(sorted_vals) - 1)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (k - lo)


def speech_spans(env: dict, fraction: float = SPEECH_FRACTION) -> list[tuple[float, float]]:
    db, hop = env["db"], env["hop"]
    if not db:
        return []
    s = sorted(db)
    floor, peak = _percentile(s, 10), _percentile(s, 95)
    if peak - floor < MIN_DYNAMIC_RANGE_DB or peak < MIN_PEAK_DB:      # digital silence / constant hiss: there is no speech to cover
        return []
    thr = floor + fraction * (peak - floor)
    per = max(1, int(round(BIN_S / hop)))
    active = [max(db[i:i + per]) >= thr for i in range(0, len(db), per)]
    spans, start = [], None
    for k, a in enumerate(active + [False]):
        if a and start is None:
            start = k
        elif not a and start is not None:
            spans.append([start * BIN_S, k * BIN_S]); start = None
    merged: list[list[float]] = []
    for sp in spans:                                   # bridge short silences
        if merged and sp[0] - merged[-1][1] < MERGE_HOLE_S:
            merged[-1][1] = sp[1]
        else:
            merged.append(sp)
    return [(a, b) for a, b in merged if b - a >= MIN_SPAN_S]


def uncovered_gaps(words: list[dict], env: dict, min_gap: float = MIN_GAP_S) -> list[tuple[float, float]]:
    """Intervals of loud audio (>= min_gap seconds) that no USABLE word covers (junk-flagged words and loops cover nothing)."""
    from .quality import flag_words
    probe = [dict(w) for w in words if "flags" not in w]
    if probe:                                            # flag loops even if the caller has not yet (cheap, idempotent)
        flag_words(probe, [], "auto")
    flagged = {w["id"] for w in probe if "repeat_run" in w.get("flags", [])}
    usable = [w for w in words if not _junk(w) and w.get("id") not in flagged]
    cover = sorted((w["start"] - WORD_PAD_S, w["end"] + WORD_PAD_S) for w in usable)
    gaps = []
    for a, b in speech_spans(env):
        cur = a
        for c0, c1 in cover:
            if c1 <= cur:
                continue
            if c0 >= b:
                break
            if c0 > cur and c0 - cur >= min_gap:
                gaps.append((cur, c0))
            cur = max(cur, c1)
        if b - cur >= min_gap:
            gaps.append((cur, b))
    return gaps


def uncovered_seconds(words, env) -> float:
    return sum(b - a for a, b in uncovered_gaps(words, env))


def _junk(w: dict) -> bool:
    return bool(set(w.get("flags", [])) & {"non_roman", "repeat_run", "prompt_leak"})


def _debris(text: str) -> bool:
    """No letters and not a believable number (".7", "!1.", "..."): a decoder's noise in non-speech stretches, never something to import."""
    return not has_letters(text) and not plausible_number(text)


def head_hole(words: list[dict], env: dict, min_hole: Optional[float] = None) -> Optional[tuple[float, float]]:
    """The start of the clip: (where the speech starts, where the first usable word starts) when that is >= ``min_hole`` (default HEAD_HOLE_S) seconds.
    Measured WITHOUT the usual 0.35 s word padding: a clip cut mid-sentence loses its first words, and the padded test hid holes of up to ~1 s."""
    spans = speech_spans(env)
    if not spans:
        return None
    min_hole = HEAD_HOLE_S if min_hole is None else min_hole
    usable = [w["start"] for w in words if not _junk(w) and not _debris(w["text"])]
    first = min(usable) if usable else spans[0][1]
    return (spans[0][0], first) if first - spans[0][0] >= min_hole else None


def fuse(primary: dict, secondary: dict, env: dict, min_gap: Optional[float] = None, min_conf: Optional[float] = None,
         gaps: Optional[list] = None) -> dict:
    """Fill the coverage gaps of ``primary`` (>= ``min_gap`` seconds, default PATCH_GAP_S) with words from ``secondary`` (only inside the gaps, only clean
    words, no duplicates; with ``min_conf`` also only words the recogniser was at least that sure of; ``gaps`` replaces the measured gaps). Returns a copy of
    ``primary`` with ``fusion`` info; word ids/segments are renumbered in time order."""
    min_gap = PATCH_GAP_S if min_gap is None else min_gap
    gaps = uncovered_gaps(primary["words"], env, min_gap) if gaps is None else list(gaps)
    res = dict(primary)
    words = [dict(w) for w in primary["words"]]
    patched = 0
    for g0, g1 in gaps:
        cand = [dict(w) for w in secondary["words"] if g0 - 0.15 <= (w["start"] + w["end"]) / 2 <= g1 + 0.15 and not _junk(w) and not _debris(w["text"])
                and (min_conf is None or float(w.get("confidence", 1.0)) >= min_conf)]
        # drop loops ENTIRELY: a token repeated >= 4 times in a row is a decoding loop, none of its copies is real speech
        keep, i = [], 0
        while i < len(cand):
            j = i
            while j + 1 < len(cand) and _norm(cand[j + 1]["text"]) == _norm(cand[i]["text"]):
                j += 1
            if j - i + 1 < 4:
                keep.extend(cand[i:j + 1])
            i = j + 1
        for w in keep:
            if any(min(w["end"], o["end"]) - max(w["start"], o["start"]) > 0.5 * (w["end"] - w["start"]) for o in words):
                continue                                # already covered by a primary word
            w["origin"] = (w.get("origin") or "") + "|fused"
            w["fused"] = True
            words.append(w)
            patched += 1
    words.sort(key=lambda w: (w["start"], w["end"]))
    for n, w in enumerate(words):
        w["id"] = f"w{n + 1:06d}"
    segs = [dict(s) for s in primary["segments"]]
    for s in segs:
        s["word_ids"] = []
    for w in words:                                      # attach every word to the segment that contains its start, else the nearest
        if not segs:
            break
        s = next((s for s in segs if s["start"] - 1e-6 <= w["start"] < s["end"] + 1e-6), None) or min(segs, key=lambda s: abs(s["start"] - w["start"]))
        s["word_ids"].append(w["id"]); w["segment"] = s["id"]
    by = {w["id"]: w for w in words}
    for s in segs:
        s["text"] = " ".join(by[i]["text"] for i in s["word_ids"])
    res["words"], res["segments"] = words, segs
    res["fusion"] = {"gaps_before": [(round(a, 2), round(b, 2)) for a, b in gaps], "patched_words": patched,
                     "gaps_after": [(round(a, 2), round(b, 2)) for a, b in uncovered_gaps(words, env, min_gap)]}
    return res
