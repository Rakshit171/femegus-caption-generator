"""Local transcription with word-level timestamps (faster-whisper / CTranslate2).

The model is loaded once per ``Transcriber`` instance and reused. Output follows ``schema.py``.
"""
from __future__ import annotations

import json
import os
import time
from typing import Callable, Optional

from .cuda_setup import prepare_cuda_dlls
from .errors import MediaReadError, ModelLoadError, is_decode_error, media_error  # noqa: F401
from .models import HINGLISH_PROMPT, LANGUAGE_MODES, MODELS
from .schema import SCHEMA_VERSION, word_id

prepare_cuda_dlls()  # must precede ctranslate2 import

import ctranslate2  # noqa: E402
from faster_whisper import WhisperModel  # noqa: E402

MIN_WORD_DURATION = 0.02  # seconds; only used to repair degenerate timestamps
SEED = 1234               # fixed so repeated runs are reproducible


def resolve_model(name: str, models_local_path: Optional[str] = None) -> str:
    if models_local_path and os.path.isfile(models_local_path):
        with open(models_local_path, "r", encoding="utf-8-sig") as f:  # tolerate BOM written by Windows editors
            local = json.load(f)
        if name in local:
            return local[name]
    return MODELS.get(name, name)


def pick_device(requested: str = "auto") -> tuple[str, str]:
    """Return (device, compute_type)."""
    if requested in ("auto", "cuda"):
        try:
            if ctranslate2.get_cuda_device_count() > 0:
                return "cuda", "int8_float16"
        except Exception:
            pass
        if requested == "cuda":
            raise RuntimeError("CUDA requested but no CUDA device is available to CTranslate2")
    return "cpu", "int8"


def sanitize_words(words: list[dict], warnings: list[str]) -> list[dict]:
    """Repair degenerate timings WITHOUT ever moving a word earlier than recognised (premature-reveal safety)."""
    out: list[dict] = []
    prev_end = 0.0
    fixed = 0
    for w in words:
        if not w["text"]:
            warnings.append(f"dropped empty word at {w['start']:.2f}s")
            continue
        s, e = max(0.0, float(w["start"])), float(w["end"])
        if s < prev_end:
            s = prev_end  # overlap -> push LATER, never earlier
            fixed += 1
        if e < s + MIN_WORD_DURATION:
            e = s + MIN_WORD_DURATION
            fixed += 1
        w["start"], w["end"] = round(s, 3), round(e, 3)
        prev_end = e
        out.append(w)
    if fixed:
        warnings.append(f"repaired {fixed} overlapping/degenerate word timestamps")
    return out
class Transcriber:
    def __init__(self, model: str = "turbo", device: str = "auto", compute_type: Optional[str] = None,
                 models_local_path: Optional[str] = None):
        self.model_key = model
        self.model_ref = resolve_model(model, models_local_path)
        dev, ctype = pick_device(device)
        self.device, self.compute_type = dev, compute_type or ctype
        self.warnings: list[str] = []
        t0 = time.time()
        try:
            try:
                self.model = WhisperModel(self.model_ref, device=self.device, compute_type=self.compute_type)
            except Exception as exc:  # GPU failure -> CPU fallback (only when device was 'auto')
                if device != "auto" or self.device == "cpu":
                    raise
                self.warnings.append(f"GPU load failed ({exc!r}); fell back to CPU int8")
                self.device, self.compute_type = "cpu", "int8"
                self.model = WhisperModel(self.model_ref, device="cpu", compute_type="int8")
        except Exception as exc:
            raise ModelLoadError(model, self.model_ref, exc) from exc
        self.load_seconds = time.time() - t0

    # Batched decoding (independent VAD chunks) is the default: long-form sequential decoding dropped ~70 % of a real Hinglish clip and
    # produced "market market market…" loops with the Hinglish model; chunked decoding recovered all of it (see docs/TESTING.md).
    default_batched = True
    batch_size = 8

    GPU_ERROR_HINTS = ("cublas", "cudnn", "cudart", "nvrtc", "cuda", "is not found or cannot be loaded", "out of memory", "no kernel image")

    def transcribe(self, path: str, *args, **kwargs) -> dict:
        """Transcribe; if the GPU fails at run time (missing/old CUDA libraries, driver mismatch, out of GPU memory) continue on the CPU instead of failing.
        CTranslate2 only discovers such problems at the first real use, not when the model is loaded."""
        try:
            return self._transcribe_impl(path, *args, **kwargs)
        except Exception as exc:
            if self.device == "cuda" and any(h in str(exc).lower() for h in self.GPU_ERROR_HINTS):
                self._fall_back_to_cpu(exc)
                return self._transcribe_impl(path, *args, **kwargs)
            raise

    def _fall_back_to_cpu(self, exc: Exception) -> None:
        msg = f"GPU not usable ({type(exc).__name__}: {str(exc).splitlines()[0][:140]}); continuing on the CPU (slower)"
        print("[engine] " + msg, flush=True)
        self.warnings.append(msg)
        self.device, self.compute_type = "cpu", "int8"
        try:
            self.model = WhisperModel(self.model_ref, device="cpu", compute_type="int8")
        except Exception as exc2:
            raise ModelLoadError(self.model_key, self.model_ref, exc2) from exc2

    def _transcribe_impl(self, path: str, language_mode: str = "english", beam_size: int = 5,
                         vad: bool = True, vad_min_silence_ms: int = 300,
                         progress: Optional[Callable[[float], None]] = None,
                         initial_prompt: Optional[str] = None, batched: Optional[bool] = None,
                         repetition_penalty: Optional[float] = None, no_repeat_ngram_size: Optional[int] = None) -> dict:
        if language_mode not in LANGUAGE_MODES:
            raise ValueError(f"language_mode must be one of {LANGUAGE_MODES}")
        if not os.path.isfile(path):
            raise FileNotFoundError(path)
        warnings = list(self.warnings)
        ctranslate2.set_random_seed(SEED)  # temperature fallback samples randomly; same input must give same captions
        batched = self.default_batched if batched is None else batched

        kw: dict = dict(
            beam_size=beam_size,
            word_timestamps=True,
            condition_on_previous_text=False,   # avoids hallucination loops and timestamp drift
            vad_filter=vad,
            vad_parameters=dict(min_silence_duration_ms=vad_min_silence_ms),
        )
        if not batched:
            kw["hallucination_silence_threshold"] = 2.0
        if repetition_penalty:                      # only for re-decoding a stretch that looped ("vah, vah, vah, …"): it also discourages legitimate repeats
            kw["repetition_penalty"] = repetition_penalty
        if no_repeat_ngram_size:
            kw["no_repeat_ngram_size"] = no_repeat_ngram_size
        if language_mode == "english":
            kw["language"] = "en"
        elif language_mode == "hinglish":
            kw["language"] = "hi"
            kw["initial_prompt"] = initial_prompt if initial_prompt is not None else HINGLISH_PROMPT
        else:  # auto
            kw["language"] = None
            if not batched:
                kw["multilingual"] = True        # per-segment language detection (sequential decoding only)
        if initial_prompt is not None and language_mode != "hinglish":
            kw["initial_prompt"] = initial_prompt

        t0 = time.time()
        try:
            if batched:
                from faster_whisper import BatchedInferencePipeline
                from faster_whisper.audio import decode_audio
                audio = decode_audio(path, sampling_rate=16000)
                seg_iter, info = BatchedInferencePipeline(model=self.model).transcribe(audio, batch_size=self.batch_size, **kw)
                duration = len(audio) / 16000.0
            else:
                seg_iter, info = self.model.transcribe(path, **kw)
                duration = float(info.duration)
        except Exception as exc:
            if is_decode_error(exc):
                raise media_error(path) from exc
            raise
        words: list[dict] = []
        segments: list[dict] = []
        for seg in seg_iter:
            sid = len(segments)
            ids = []
            for w in (seg.words or []):
                txt = w.word.strip()
                wd = {"id": word_id(len(words)), "text": txt, "start": w.start, "end": w.end,
                      "confidence": round(float(w.probability), 3), "segment": sid,
                      "lang": getattr(seg, "language", None)}
                words.append(wd)
                ids.append(wd["id"])
            segments.append({"id": sid, "start": round(seg.start, 3), "end": round(seg.end, 3),
                             "text": seg.text.strip(), "word_ids": ids,
                             "lang": getattr(seg, "language", None),
                             "avg_logprob": round(float(seg.avg_logprob), 3),
                             "no_speech_prob": round(float(seg.no_speech_prob), 3)})
            if progress and duration > 0:
                progress(min(1.0, seg.end / duration))
        words = sanitize_words(words, warnings)
        if not words:
            warnings.append("no speech recognised")
        elapsed = time.time() - t0
        return {
            "schema": SCHEMA_VERSION,
            "source": {"file": os.path.abspath(path), "duration": round(duration, 3)},
            "engine": {"model": self.model_ref, "device": self.device, "compute_type": self.compute_type,
                       "language_mode": language_mode, "batched": batched,
                       "options": {k: v for k, v in kw.items() if k != "initial_prompt"},
                       "load_seconds": round(self.load_seconds, 2), "transcribe_seconds": round(elapsed, 2),
                       "realtime_factor": round(elapsed / duration, 3) if duration else None},
            "language": {"mode": language_mode, "detected": info.language,
                         "probability": round(float(info.language_probability), 3)},
            "words": words, "segments": segments, "warnings": warnings,
        }
