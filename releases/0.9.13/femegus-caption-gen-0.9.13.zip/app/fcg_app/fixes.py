"""One-click fixes for what the system check finds missing (see selfcheck.FIX_META for the list and the wording shown to the user).

Everything here only writes inside this project folder (models\\, engine\\models_local.json, the Hugging Face cache for the stock model) and never touches projects,
looks, After Effects or the registry. The long ones run as background jobs with a live message, can be cancelled, and report problems in plain words.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import socket
import subprocess
import tempfile
import threading
import time
from typing import Optional

from . import ops, selfcheck
from .jobs import UserMessage

ROOT = ops.ROOT
HINGLISH_NEEDS_FREE_GB = 7.0           # download (1.5 GB) + conversion tools + converted model; most of it is freed again by the clean-up at the end
HF_HOST = "huggingface.co"
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_STAGES = [("conversion tools", 0.05, 0.30), ("downloading the official model", 0.30, 0.62), ("converting", 0.62, 0.95), ("cleaning up", 0.95, 0.99)]


def online(host: str = HF_HOST, port: int = 443, timeout: float = 6.0) -> bool:
    try:
        socket.create_connection((host, port), timeout=timeout).close()
        return True
    except OSError:
        return False


def _need_internet(what: str) -> None:
    if not online():
        raise UserMessage(f"{what} needs the internet, and {HF_HOST} cannot be reached from this computer (internet off, firewall or proxy?). "
                          "Connect and press the Fix button again — everything already downloaded is kept.")


# ------------------------------------------------------------------------------------------------------------------------------ English model
def run_english_model(job) -> dict:
    if selfcheck.english_model_ready():
        job.set(1.0, "The English speech model is already downloaded.")
        return {"done": True, "already": True}
    job.set(0.01, "Checking the connection…")
    _need_internet("Downloading the speech model")
    try:
        ops.ensure_speech_model(job, selfcheck.ENGLISH_MODEL, span=(0.02, 0.97))
    except RuntimeError as e:
        raise UserMessage(str(e)) from e
    if not selfcheck.english_model_ready():
        raise UserMessage("The download finished but the model is not complete. Press the Fix button again (it continues where it stopped).")
    ops.reset_engine()
    job.set(1.0, "English speech model ready.")
    return {"done": True}


# ------------------------------------------------------------------------------------------------------------------------------ Hinglish model
def register_hinglish(root: Optional[str] = None) -> str:
    """Write the converted model's folder into engine/models_local.json (merging with whatever is there)."""
    root = root or ROOT
    out = selfcheck.hinglish_model_dir(root)
    path = os.path.join(root, "engine", "models_local.json")
    cfg: dict = {}
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            cfg = json.load(f) or {}
    except (OSError, ValueError):
        cfg = {}
    cfg["hinglish-apex"] = out.replace("\\", "/")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, path)
    return path


def run_register_hinglish(job, root: Optional[str] = None) -> dict:
    if selfcheck.hinglish_state(root) == "missing":
        raise UserMessage("The converted Hinglish model is not in the models folder, so there is nothing to connect. Use 'Set up the Hinglish model' instead.")
    from fcg_engine import model_check
    restored = model_check.restore_small_files(selfcheck.hinglish_model_dir(root))        # a lost tokenizer.json etc.: put back the exact bundled copies (offline)
    register_hinglish(root)
    ops.reset_engine()
    job.set(1.0, "Hinglish model connected." + (f" Restored: {', '.join(restored)}." if restored else ""))
    if selfcheck.hinglish_state(root) == "incomplete":
        raise UserMessage("The Hinglish model folder is still missing a file that cannot be restored from inside the app. Use 'Set up the Hinglish model' (download) or run scripts\\setup_hinglish.ps1.")
    return {"done": True, "restored": restored}


def hinglish_command(root: Optional[str] = None, force: bool = False) -> list[str]:
    root = root or ROOT
    return ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", os.path.join(root, "scripts", "setup_hinglish.ps1"), "-CleanUp"] + (["-Force"] if force else [])


def run_rebuild_hinglish(job, root: Optional[str] = None, command: Optional[list] = None, check_internet: bool = True, min_free_gb: float = HINGLISH_NEEDS_FREE_GB) -> dict:
    """Convert the Hinglish model again with the pinned (tested) tool versions, replacing a conversion made with other versions (setups before 0.9.13)."""
    import gc
    ops.reset_engine()                                    # the loaded model keeps model.bin open; Windows would refuse to overwrite it
    gc.collect()
    return run_hinglish_model(job, root, command or hinglish_command(root, force=True), check_internet, min_free_gb, force=True)


def _kill_tree(proc: subprocess.Popen) -> None:
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, timeout=30, creationflags=_NO_WINDOW)
        else:
            proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def run_hinglish_model(job, root: Optional[str] = None, command: Optional[list] = None, check_internet: bool = True, min_free_gb: float = HINGLISH_NEEDS_FREE_GB,
                       force: bool = False) -> dict:
    """Download + convert the Hinglish model by running scripts\\setup_hinglish.ps1 (the same script the installer uses) and mirror its output as progress.
    ``force`` = convert again even though a model is there (see ``run_rebuild_hinglish``)."""
    root = root or ROOT
    state = selfcheck.hinglish_state(root)
    if state == "ready" and not force:
        job.set(1.0, "The Hinglish model is already set up.")
        return {"done": True, "already": True}
    if state in ("unregistered", "incomplete") and not force:
        return run_register_hinglish(job, root)
    script = os.path.join(root, "scripts", "setup_hinglish.ps1")
    if command is None and not os.path.isfile(script):
        raise UserMessage("scripts\\setup_hinglish.ps1 is missing from this installation. Run Install-FemeGus.cmd again (or update the app).")
    if command is None and not os.path.isfile(os.path.join(root, ".venv", "Scripts", "python.exe")):
        raise UserMessage("The project's Python environment (.venv) is missing. Run Install-FemeGus.cmd first.")
    free = shutil.disk_usage(root).free / 1e9
    if free < min_free_gb:
        raise UserMessage(f"The Hinglish setup needs about {min_free_gb:.0f} GB of free disk space while it works (most of it is freed again at the end); this drive has {free:.1f} GB. "
                          "Free some space and press the Fix button again.")
    if check_internet:
        job.set(0.01, "Checking the connection…")
        _need_internet("Setting up the Hinglish model")
    job.set(0.03, "Starting the Hinglish setup (about 3 GB download; this takes several minutes)…")
    proc = subprocess.Popen(command or hinglish_command(root), cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, creationflags=_NO_WINDOW)
    state_lock = threading.Lock()
    shown = {"line": "", "stage": -1, "pct": 0.0}
    tail: list[str] = []

    def pump() -> None:
        buf = b""
        while True:
            chunk = proc.stdout.read1(256)                # returns what is there (read() would wait for a full block and show nothing for minutes)
            if not chunk:
                break
            buf += chunk
            parts = re.split(rb"[\r\n]+", buf)
            buf = parts.pop()
            for raw in parts:
                line = raw.decode("utf-8", "replace").strip()
                if not line:
                    continue
                with state_lock:
                    tail.append(line)
                    del tail[:-80]
                    low = line.lower()
                    if line.startswith("=="):
                        for i, (name, _a, _b) in enumerate(_STAGES):
                            if name.split()[0] in low:
                                shown["stage"], shown["pct"] = i, 0.0
                    m = re.search(r"(\d{1,3})\s*%", line)
                    if m and shown["stage"] >= 0:
                        shown["pct"] = min(1.0, int(m.group(1)) / 100.0)
                    if len(line) < 160:
                        shown["line"] = line
    t = threading.Thread(target=pump, daemon=True)
    t.start()
    t0 = time.time()
    try:
        while proc.poll() is None:
            if job.cancel_requested:
                _kill_tree(proc)
                raise UserMessage("Cancelled. Nothing is broken: press the Fix button again later (finished steps are kept).")
            with state_lock:
                st, pct, line = shown["stage"], shown["pct"], shown["line"]
            if st >= 0:
                _name, a, b = _STAGES[st]
                prog = a + (b - a) * pct
            else:
                prog = 0.03
            minutes = int((time.time() - t0) // 60)
            job.set(prog, (line or "working…") + f"   ({minutes} min)" if minutes else (line or "working…"))
            time.sleep(0.5)
    finally:
        if proc.poll() is None:
            _kill_tree(proc)
        t.join(timeout=5)
    if proc.returncode != 0:
        with state_lock:
            last = [x for x in tail if x][-4:]
        raise UserMessage("The Hinglish setup stopped before it finished"
                          + (" (the download needs a working internet connection)" if any(("download" in x.lower() or "internet" in x.lower()) for x in last) else "")
                          + ". Last messages: " + " | ".join(last) + ". Press the Fix button again to continue; finished steps are kept.")
    if selfcheck.hinglish_state(root) != "ready":
        raise UserMessage("The setup finished but the Hinglish model is not usable yet (model.bin missing or not registered). Press the Fix button again.")
    ops.reset_engine()
    job.set(1.0, "Hinglish model ready.")
    return {"done": True}


# ------------------------------------------------------------------------------------------------------------------------------ After Effects helper
def show_connect_script() -> dict:
    path = os.path.join(ROOT, "adapters", "jsx-core", "fcg_connect.jsx")
    if not os.path.isfile(path):
        raise OSError("adapters\\jsx-core\\fcg_connect.jsx is missing from this installation: update the app or run Install-FemeGus.cmd again.")
    if os.name == "nt":
        subprocess.Popen(["explorer.exe", f"/select,{path}"])
    return {"path": path}
