# Sets up the Hinglish speech model (Oriserve Whisper-Hindi2Hinglish-Apex, Apache-2.0): downloads the official weights from Hugging Face and
# converts them once to the CTranslate2 format the engine uses. Needs internet; about 3 GB download, a few minutes. Safe to run again (skips when done).
#
#     .\scripts\setup_hinglish.ps1              # set up
#     .\scripts\setup_hinglish.ps1 -CleanUp     # afterwards delete the conversion tools and the original weights (saves about 4 GB)
#     .\scripts\setup_hinglish.ps1 -Force       # redo everything
#
# Run from PowerShell in the project folder. It only writes inside the project folder (models\, .venv-convert\, engine\models_local.json).
param([switch]$CleanUp, [switch]$Force)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
function Step($m) { Write-Host "`n== $m" -ForegroundColor Cyan }

$venvPy = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPy)) { throw "Run scripts\setup.ps1 first (the project environment .venv is missing)." }
$src = Join-Path $root "models\hf\Whisper-Hindi2Hinglish-Apex"
$out = Join-Path $root "models\ct2\hinglish-apex-fp16"
$map = Join-Path $root "engine\models_local.json"
# The exact model revision and tool versions of the TESTED model (before 0.9.13 both were "whatever is newest", so other computers built a different model).
# With these the conversion is byte-identical: model.bin SHA-256 below (checked 2026-11-09).
$HINGLISH_REVISION = 'f3214eed20b4e4d4144e739982d911f87b9cb223'
$TORCH_VERSION = '2.14.1'
$EXPECTED_MODEL_SHA256 = '1a47e83dbb61709cb703159c4ca16dae4f2d33bffab1f21d7615c4d0b46786b2'

function Register-Model {
    $cfg = @{}
    if (Test-Path $map) { try { (Get-Content $map -Raw -Encoding UTF8 | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $cfg[$_.Name] = $_.Value } } catch { } }
    $cfg['hinglish-apex'] = $out.Replace('\', '/')
    $json = $cfg | ConvertTo-Json
    New-Item -ItemType Directory -Force (Split-Path $map) | Out-Null
    [IO.File]::WriteAllText($map, $json, (New-Object Text.UTF8Encoding($false)))
}

if ((Test-Path (Join-Path $out "model.bin")) -and -not $Force) {
    Write-Host "The Hinglish model is already converted: $out" -ForegroundColor Green
    if (-not (Test-Path $map) -or -not ((Get-Content $map -Raw) -match 'hinglish-apex')) { Register-Model; Write-Host "Registered in engine\models_local.json" -ForegroundColor Green }
} else {
    Step "Conversion tools (a separate throw-away environment, .venv-convert)"
    if (-not (Test-Path ".venv-convert\Scripts\python.exe")) { & $venvPy -m venv .venv-convert }
    $cp = Join-Path $root ".venv-convert\Scripts\python.exe"
    & $cp -m pip install --quiet --upgrade pip
    & $cp -m pip install --quiet "torch==$TORCH_VERSION" --index-url https://download.pytorch.org/whl/cpu
    if ($LASTEXITCODE -ne 0) { throw "could not install the conversion tools (torch $TORCH_VERSION, CPU build) - internet?" }
    & $cp -m pip install --quiet -r (Join-Path $root "scripts\requirements-convert.txt")
    if ($LASTEXITCODE -ne 0) { throw "could not install the conversion tools (scripts\requirements-convert.txt) - internet?" }

    Step "Downloading the official model (about 1.5 GB)"
    New-Item -ItemType Directory -Force (Split-Path $src) | Out-Null
    & $cp -c "from huggingface_hub import snapshot_download; snapshot_download('Oriserve/Whisper-Hindi2Hinglish-Apex', revision='$HINGLISH_REVISION', local_dir=r'$src', allow_patterns=['*.json','*.txt','*.safetensors'])"
    if ($LASTEXITCODE -ne 0) { throw "download failed (internet?)" }

    Step "Converting to CTranslate2 (float16)"
    New-Item -ItemType Directory -Force (Split-Path $out) | Out-Null
    & (Join-Path $root ".venv-convert\Scripts\ct2-transformers-converter.exe") --model $src --output_dir $out --copy_files tokenizer.json preprocessor_config.json --quantization float16 --force
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path (Join-Path $out "model.bin"))) { throw "conversion failed" }
    $got = (Get-FileHash (Join-Path $out "model.bin") -Algorithm SHA256).Hash.ToLower()
    if ($got -eq $EXPECTED_MODEL_SHA256) { Write-Host "Checked: identical to the tested Hinglish model." -ForegroundColor Green }
    else { Write-Host "Note: the converted model differs from the tested one (SHA-256 $got). It should still work; please mention this if Hinglish misbehaves." -ForegroundColor Yellow }
    Register-Model
    Write-Host "Hinglish model ready." -ForegroundColor Green
}

if ($CleanUp) {
    Step "Cleaning up"
    if (Test-Path ".venv-convert") { Remove-Item ".venv-convert" -Recurse -Force; Write-Host "removed .venv-convert" }
    if (Test-Path $src) { Remove-Item $src -Recurse -Force; Write-Host "removed the original weights" }
}
