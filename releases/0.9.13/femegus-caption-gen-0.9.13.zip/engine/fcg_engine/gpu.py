"""How much graphics-card memory is free, and whether the speech models must take turns on it.

Hinglish keeps TWO speech models (stock + Hinglish) on the GPU; English keeps one. Measured on the dev PC (RTX 3060 6 GB, 2026-11-09): English peaks at ~1.3 GB,
Hinglish at ~2.4 GB of GPU memory. On a card with less free memory, recent NVIDIA drivers on Windows do not fail but spill into normal RAM ("sysmem fallback"),
which is slower (measured with 1.86 GB free: Hinglish 267 s instead of 169 s, English unchanged) and gets much worse the less memory is free. When free memory is
short, the engine keeps only the model that is working on the GPU and parks the other in normal RAM (CTranslate2 ``unload_model(to_cpu=True)`` / ``load_model()``):
the same weights and settings, so the same words; only a second or two per switch. Never raises."""
from __future__ import annotations

import os
import subprocess
from typing import Optional

LOW_VRAM_FREE_MIB = 2800          # both models together peak at ~2.4 GB (measured) + room for the driver; less free than this -> the models take turns
ENV_SWITCH = "FCG_ONE_MODEL_ON_GPU"   # "1" = always take turns, "0" = never (support / tests); unset = decide by free memory


def free_vram_mib() -> Optional[int]:
    """Free memory of the first NVIDIA GPU in MiB (what CTranslate2 uses), or None when it cannot be read."""
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=memory.free", "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=10,
                             creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        first = out.stdout.strip().splitlines()[0]
        return int(first.strip())
    except Exception:
        return None


def models_must_take_turns(free_mib: Optional[int] = None) -> bool:
    env = os.environ.get(ENV_SWITCH, "").strip()
    if env in ("0", "1"):
        return env == "1"
    free = free_vram_mib() if free_mib is None else free_mib
    return free is not None and free < LOW_VRAM_FREE_MIB
