"""Is a local speech-model folder complete — and, if only its small text files are missing, restore them WITHOUT the internet.

Why: faster-whisper loads a model from a local folder, but when ``tokenizer.json`` is not in that folder it silently asks the Hugging Face website for a
tokenizer instead. On a computer without (or with a blocked / very slow) internet connection that request is retried for minutes while the CPU and the GPU sit
idle — the transcription looks frozen (measured here: with the file removed and a dead network the load did not finish in 150 s). The Hinglish model's folder is
made by ``scripts/setup_hinglish.ps1``; if that was interrupted or a file was cleaned away, only the small files may be missing. The exact copies of those files
(byte-identical to the ones the converter copies from the Oriserve repository, Apache-2.0, see docs/LICENSES.md) are kept in ``engine/hinglish_assets`` and are
put back after their SHA-256 has been checked. Nothing here changes the model or how it decodes."""
from __future__ import annotations

import hashlib
import os
import shutil
from typing import Optional

ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "hinglish_assets")
MIN_MODEL_BYTES = 300_000_000                       # the converted fp16 model.bin is about 1.6 GB
SMALL_FILES = {                                     # name -> SHA-256 of the copy in ASSETS_DIR
    "tokenizer.json": "5c1bf30c9e716e1477bedef846b01be0013daecb89e9e3ef7ab89b23c178df1b",
    "preprocessor_config.json": "654cf18d3e163b948ceaf9766da56ce0b52de265d58673cf61c9376f126bd499",
    "vocabulary.json": "697ee5a65726e46b4d294d1a243d98e1878f5d81caba17891b1c5ebab7a912a9",
}


def _sha(path: str) -> Optional[str]:
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read()).hexdigest()
    except OSError:
        return None


def problems(path: str) -> list[str]:
    """What is wrong with the model folder (empty list = complete)."""
    out: list[str] = []
    if not os.path.isdir(path):
        return [f"the folder {path} does not exist"]
    if not os.path.isfile(os.path.join(path, "config.json")):
        out.append("config.json is missing")
    try:
        size = os.path.getsize(os.path.join(path, "model.bin"))
        if size < MIN_MODEL_BYTES:
            out.append(f"model.bin is only {size / 1e6:.0f} MB (an interrupted conversion?)")
    except OSError:
        out.append("model.bin is missing")
    if not os.path.isfile(os.path.join(path, "tokenizer.json")):
        out.append("tokenizer.json is missing")
    if not os.path.isfile(os.path.join(path, "preprocessor_config.json")):
        out.append("preprocessor_config.json is missing")
    if not (os.path.isfile(os.path.join(path, "vocabulary.json")) or os.path.isfile(os.path.join(path, "vocabulary.txt"))):
        out.append("vocabulary.json is missing")
    return out


def restore_small_files(path: str, assets_dir: Optional[str] = None) -> list[str]:
    """Put back the missing small files from the bundled exact copies (checked by SHA-256 first). Returns the names restored. Never raises."""
    assets = assets_dir or ASSETS_DIR
    restored: list[str] = []
    for name, digest in SMALL_FILES.items():
        dst = os.path.join(path, name)
        if os.path.isfile(dst) or (name == "vocabulary.json" and os.path.isfile(os.path.join(path, "vocabulary.txt"))):
            continue
        src = os.path.join(assets, name)
        if _sha(src) != digest:                              # an altered or missing asset is never used
            continue
        try:
            tmp = dst + ".fcgnew"
            shutil.copyfile(src, tmp)
            os.replace(tmp, dst)
            restored.append(name)
        except OSError:
            pass
    return restored


# The tested Hinglish model (scripts/setup_hinglish.ps1 with its pinned revision and tools gives exactly this; checked 2026-11-09 by converting again).
# Before 0.9.13 the setup installed the newest conversion tools, so another computer may hold a DIFFERENT conversion; these let the app notice that.
TESTED_CONFIG_SHA256 = "6261e4e5c2bff7efa63884d7516da4521b83c25b1940dbdbe1dc04a4228a7d8f"
TESTED_MODEL_BYTES = 1617884929
TESTED_MODEL_SHA256 = "1a47e83dbb61709cb703159c4ca16dae4f2d33bffab1f21d7615c4d0b46786b2"
_FINGERPRINT_CACHE = ".fcg_fingerprint.json"


def matches_tested_build(path: str, full: bool = False) -> Optional[bool]:
    """Is this folder the tested Hinglish conversion? True / False / None (cannot tell). Quick check = config.json + model.bin size; ``full`` also hashes
    model.bin (1.6 GB, a few seconds; the answer is cached in the folder by size + modification time). Never raises."""
    try:
        if _sha(os.path.join(path, "config.json")) != TESTED_CONFIG_SHA256:
            return False
        st = os.stat(os.path.join(path, "model.bin"))
        if st.st_size != TESTED_MODEL_BYTES:
            return False
        if not full:
            return True
        import json
        key = f"{st.st_size}:{int(st.st_mtime)}"
        cache = os.path.join(path, _FINGERPRINT_CACHE)
        try:
            with open(cache, "r", encoding="utf-8") as f:
                c = json.load(f)
            if c.get("key") == key:
                return c.get("sha256") == TESTED_MODEL_SHA256
        except (OSError, ValueError):
            pass
        h = hashlib.sha256()
        with open(os.path.join(path, "model.bin"), "rb") as f:
            for block in iter(lambda: f.read(8 << 20), b""):
                h.update(block)
        digest = h.hexdigest()
        try:
            with open(cache, "w", encoding="utf-8") as f:
                json.dump({"key": key, "sha256": digest}, f)
        except OSError:
            pass
        return digest == TESTED_MODEL_SHA256
    except OSError:
        return None


def prepare_local_model(path: str, assets_dir: Optional[str] = None) -> tuple[list[str], list[str]]:
    """(restored files, problems left). A folder with problems left must NOT be handed to faster-whisper: it would go to the internet for the missing parts."""
    left = problems(path)
    restored: list[str] = []
    if left and os.path.isdir(path):
        restored = restore_small_files(path, assets_dir)
        left = problems(path)
    return restored, left
