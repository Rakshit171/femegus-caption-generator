"""All tunable segmentation/timing parameters in one serialisable object. Nothing in the algorithms is hard-coded outside this file."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields

# words a group should not END with (it would leave an awkward dangling fragment) — English + Roman Hindi
END_AVOID = [
    "the", "a", "an", "of", "to", "in", "on", "at", "for", "with", "by", "from", "and", "but", "or", "so", "if", "that",
    "is", "are", "was", "were", "be", "i", "my", "your", "our", "his", "her", "their", "its", "this", "these", "those",
    "as", "than", "then", "not", "just", "i'm", "i'll", "i've", "you", "we", "they", "it", "it's", "that's", "don't",
    "ka", "ke", "ki", "ko", "se", "mein", "me", "par", "pe", "jo", "ye", "yeh", "woh", "wo", "aur", "ya", "toh", "bhi",
    "ek", "aapka", "aapki", "aapke", "apna", "apni", "apne", "hum", "tum", "main", "mai",
    "let's", "who", "which", "what", "how", "why", "when", "where", "can", "will", "would", "could", "should", "have", "has",
    "had", "do", "does", "did", "am", "been", "being", "up", "about", "into", "over", "under", "ke", "wala", "wali",
]
# words that make a good START of a new group (soft break is welcome right before them)
START_PREFER = [
    "and", "but", "so", "because", "which", "when", "while", "if", "where", "then", "until", "right", "now", "also",
    "aur", "lekin", "par", "kyunki", "jo", "toh", "phir", "tab", "ki", "agar", "magar",
]
# only abbreviations that practically never end a sentence ("No." / "St." / "etc." can, so they are NOT listed)
ABBREVIATIONS = ["mr.", "mrs.", "ms.", "dr.", "vs.", "e.g.", "i.e.", "jr.", "sr."]
# words that must never be accented (emphasis suggestion)
STOP_WORDS = END_AVOID + [
    "have", "has", "had", "do", "does", "did", "will", "would", "can", "could", "should", "what", "how", "why", "who", "me",
    "him", "them", "us", "there", "here", "when", "where", "all", "any", "some", "into", "up", "down", "out", "about",
    "hai", "hain", "tha", "thi", "the", "kya", "nahi", "nahin", "mat", "sab", "kuch", "kar", "karke", "de", "do",
]
# Roman-Hindi grammar words / light verbs: frequent, rarely the word a viewer should see emphasised
STOP_WORDS += [
    "agar", "magar", "lekin", "kyonki", "kyunki", "kyon", "kyun", "kaise", "kaun", "kab", "kahan", "kaisa", "kitna", "koi", "kuchh", "yah", "yeh", "vah", "woh", "yahi",
    "vahi", "yahaan", "wahan", "yahan", "isliye", "isse", "usse", "unhen", "uski", "uska", "unka", "meri", "mera", "tumhaari", "tumhara", "tumhen", "aapko", "aapki", "aapka",
    "karo", "karna", "karne", "kare", "karoge", "karenge", "karega", "karti", "karta", "kiya", "kijiye", "rahe", "raha", "rahi", "rahega", "hota", "hoti", "hote", "hona", "hoga",
    "hogi", "honge", "ho", "jaega", "jaegi", "jaate", "jana", "jao", "jaao", "aa", "aaya", "aata", "aati", "aate", "padta", "padega", "padti", "chahiye", "chaahie", "sakte",
    "sakti", "sakta", "sakega", "milta", "milti", "liya", "lena", "dena", "diya", "kar", "tak", "hi", "toh", "to", "pe", "par", "mein", "men", "ko", "se", "ke", "ki", "ka", "lie",
    "liye", "saath", "bina", "baad", "pahle", "pehle", "phir", "abhi", "ab", "jab", "tab", "tak", "wala", "wali", "wale", "bhi", "na", "nahin", "nahi", "mat", "haan", "ji",
]


@dataclass
class SegmenterConfig:
    # ---- group size limits
    max_words: int = 7
    min_words: int = 2
    target_words: int = 4
    max_chars: int = 36            # characters in a group incl. spaces (display text)
    max_duration_s: float = 3.4    # spoken span of a group
    min_duration_s: float = 0.35
    # ---- boundaries
    hard_pause_s: float = 0.45          # acoustic (or timestamp) pause that always ends a group
    pause_full_credit_s: float = 0.20   # pause length that earns the full soft-break bonus
    sentence_cue_pause_s: float = 0.10  # capital-after-unpunctuated word + at least this pause => sentence boundary
    sentence_cue_enabled: bool = True
    sentence_end_chars: str = ".?!…।"
    abbreviations: list = field(default_factory=lambda: list(ABBREVIATIONS))
    end_avoid: list = field(default_factory=lambda: list(END_AVOID))
    start_prefer: list = field(default_factory=lambda: list(START_PREFER))
    # ---- cost weights (lower total cost wins)
    w_size: float = 1.0
    w_min_words: float = 6.0
    w_short_duration: float = 4.0
    w_pause: float = 5.0
    w_punct: float = 4.0
    w_segment: float = 1.5
    w_capital: float = 1.5
    w_start_prefer: float = 2.0
    w_end_avoid: float = 5.0
    w_number_end: float = 5.0      # penalty for ending a group on a bare number ("over 1 | crore")
    w_short_tail: float = 6.0      # penalty when the last word would be on screen < min_last_word_visible_s before the next group
    # ---- policy for flagged words coming from the engine
    exclude_flags: list = field(default_factory=lambda: ["non_roman", "repeat_run", "prompt_leak", "collapsed"])
    # "collapsed" = a run of words squeezed into a few hundredths of a second each (the speech model repeated a phrase or lost its timing there):
    # nobody speaks three words in 0.2 s, so such a run would only flash on screen. It is left out of the captions but listed and restorable.
    collapsed_max_word_s: float = 0.07  # a word this short or shorter counts as squeezed
    collapsed_min_run: int = 3          # consecutive squeezed words that make a run; 0 = never flag
    # ---- reveal / exit timing
    reveal_offset_s: float = 0.0       # added to every reveal; negative values (lead) are clamped to 0 unless allow_lead
    allow_lead: bool = False           # opt-in: let words appear before the recognised start (violates the no-early rule)
    onset_mode: str = "silence"        # off | silence | slope — audio-based correction of early Whisper word starts
    onset_max_shift_s: float = 0.12
    onset_speech_fraction: float = 0.30  # speech threshold = floor + fraction * (peak - floor)
    hold_min_s: float = 0.15
    hold_max_s: float = 0.80
    hold_factor: float = 0.8           # hold ~ factor * average word duration of the group (slower speech => longer hold)
    min_read_per_word_s: float = 0.22
    min_group_visible_s: float = 0.60
    exit_gap_s: float = 0.04           # empty time before the next group starts (about one frame); 0 = hard cut at the same instant
    min_last_word_visible_s: float = 0.20  # below this a warning is emitted (overlap-avoidance wins over visibility)
    # ---- Hinglish text polish (display text only; never timing; see docs/HINGLISH_STYLE.md)
    text_polish: str = "auto"          # auto: on for Hinglish transcripts | on | off
    polish_spelling: bool = True       # one preferred spelling per word: voh, toh, nahin, tumhaare, theek, yeh ...
    polish_numbers: bool = True        # "paanch laakh" -> "5 lakh", 40000 -> 40,000, magnitude/currency spellings
    polish_homophones: bool = True     # sells/cells, sale/sail — only with sales context and a not-quite-sure word
    polish_punctuation: bool = True    # "?" only for real questions, sentence-start capitals, final full stop
    number_grouping: str = "indian"    # indian (5,00,000) | international (500,000) | none
    # ---- emphasis suggestion
    accent_stop_words: list = field(default_factory=list)   # extra words that must never be suggested as accents (added to the built-in list)
    accent_max_per_group: int = 2
    accent_min_group_words: int = 2
    accent_min_score: float = 0.9

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict | None) -> tuple["SegmenterConfig", list[str]]:
        names = {f.name for f in fields(cls)}
        unknown = [k for k in (d or {}) if k not in names]
        cfg = cls(**{k: v for k, v in (d or {}).items() if k in names})
        cfg.validate()
        return cfg, [f"unknown config key ignored: {k}" for k in unknown]

    def validate(self) -> None:
        if self.max_words < 1 or self.min_words < 1 or self.min_words > self.max_words:
            raise ValueError("require 1 <= min_words <= max_words")
        if not (self.min_words <= self.target_words <= self.max_words):
            raise ValueError("target_words must lie within [min_words, max_words]")
        if self.onset_mode not in ("off", "silence", "slope"):
            raise ValueError("onset_mode must be off|silence|slope")
        if self.text_polish not in ("auto", "on", "off"):
            raise ValueError("text_polish must be auto|on|off")
        if self.number_grouping not in ("indian", "international", "none"):
            raise ValueError("number_grouping must be indian|international|none")
        if self.collapsed_max_word_s < 0 or self.collapsed_min_run < 0:
            raise ValueError("collapsed_max_word_s and collapsed_min_run must not be negative")
        if self.hold_min_s > self.hold_max_s:
            raise ValueError("hold_min_s must be <= hold_max_s")
        if self.exit_gap_s < 0 or self.max_chars < 4 or self.max_duration_s <= 0:
            raise ValueError("invalid limits")
