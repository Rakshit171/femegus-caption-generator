"""Verify a layer dump written by the After Effects adapter against the groups.json it was built from. Pure Python; used by the app after every
generation (so the user sees proof, not just 'done') and by the tests.

Checks: one layer per word with the right text; in-point >= reveal (never early) and < reveal + 1 frame; out-point <= group exit;
no group still visible when the next one starts.
"""
from __future__ import annotations

EPS = 1e-4


def _merge(base, over):
    if isinstance(base, dict) and isinstance(over, dict):
        out = dict(base)
        for k, v in over.items():
            out[k] = _merge(base[k], v) if k in base else v
        return out
    return over


def word_style(st: dict, ov: dict | None) -> dict:
    """Per-word style on top of a role style (mirrors fcgWordStyle in the adapter and wordStyle in the preview):
    a solid ``fill`` without a ``gradient`` key switches the gradient off, otherwise it would hide the chosen colour."""
    if not ov:
        return st
    out = _merge(st, ov)
    if "fill" in ov and "gradient" not in ov and isinstance(out.get("gradient"), dict):
        out["gradient"] = {**out["gradient"], "enabled": False}
    return out


def verify_style(report: dict, options: dict, groups: dict | None = None) -> list[str]:
    """Check that the layers carry the style that was ASKED for (font size, fill, caps, effects) — timing checks alone would miss a style that
    silently failed to apply. `options` = the style sent to After Effects (roles / template_styles). Missing fonts may differ (reported by AE as a warning)."""
    problems: list[str] = []
    if not report.get("ok"):
        return problems
    font_warned = any("not installed" in w for w in report.get("warnings", []))
    roles, tstyles = options.get("roles", {}), options.get("template_styles", {})
    bad = {"size": 0, "fill": 0, "font": 0, "fx": 0, "animator": 0}
    overrides = {w["id"]: w["style_override"] for g in (groups or {}).get("groups", []) for w in g["words"] if w.get("style_override")}
    for L in report["layers"]:
        m = L["meta"]
        st = roles.get(m["role"]) or roles.get("support") or {}
        ts = (tstyles.get(m.get("tpl")) or {}).get(m["role"])
        if ts:
            st = _merge(st, ts)
        if not st:
            continue
        v = m.get("v")                                                        # accent variant of this word (see fcgAssignVariants)
        if v is not None and st.get("variants") and 0 <= v < len(st["variants"]):
            st = _merge(st, st["variants"][v])
        st = word_style(st, overrides.get(m.get("w")))
        if abs(L["font_size"] - st["size"]) > 0.01:
            bad["size"] += 1
        want = st.get("fill", "#FFFFFF").lstrip("#")
        rgb = [int(want[i:i + 2], 16) / 255 for i in (0, 2, 4)]
        if any(abs(a - b) > 0.01 for a, b in zip(L["fill"][:3], rgb)):
            bad["fill"] += 1
        if L["font"] not in [st["font"], *st.get("font_fallbacks", [])] and not font_warned:        # the first INSTALLED candidate is used
            bad["font"] += 1
        fx = L.get("effects", [])
        if bool((st.get("gradient") or {}).get("enabled")) != ("FCG Gradient" in fx) or bool((st.get("glow") or {}).get("enabled")) != ("FCG Glow" in fx) \
                or bool((st.get("shadow") or {}).get("enabled")) != ("FCG Shadow" in fx):
            bad["fx"] += 1
        anim = st.get("anim") or {}                                           # per-letter reveal = text animators on the layer (and no layer blur)
        wanted = (["FCG Letters"] + (["FCG Tint"] if (anim.get("letters") or {}).get("tint") else [])) if anim.get("unit") == "letter" else []
        if L.get("animators", []) != wanted or (anim.get("unit") == "letter" and "FCG Blur" in fx):
            bad["animator"] += 1
    for k, n in bad.items():
        if n:
            problems.append(f"STYLE NOT APPLIED: {n} layer(s) have the wrong {k}")
    return problems


def reveal_mode(options: dict | None) -> str:
    """style.reveal.mode: 'word' (every word at its own reveal time, the default) or 'line' (the whole caption together with its FIRST word)."""
    mode = ((options or {}).get("reveal") or {}).get("mode", "word")
    return mode if mode in ("word", "line") else "word"


def expected_reveal(g: dict, w: dict, mode: str) -> float:
    """The time a word's layer must start: its own reveal, or in 'line' mode the caption's first reveal (the only way a word is shown before it is spoken,
    and only because the user switched it on)."""
    return g["words"][0]["reveal"] if mode == "line" else w["reveal"]


def verify_boxes(report: dict, groups: dict, options: dict | None) -> list[str]:
    """Solid box behind the text (style.box): one rectangle per line, timed with the caption, covering its words, with the colour/opacity asked for."""
    box = (options or {}).get("box") or {}
    boxes = report.get("boxes") or []
    if not box.get("enabled"):
        return [f"{len(boxes)} box layer(s) exist although the box is switched off"] if boxes else []
    v: list[str] = []
    fd = report["comp"]["frameDuration"]
    mode = reveal_mode(options)
    want = box.get("color", "#000000").lstrip("#")
    rgb = [int(want[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    layers = {l["meta"]["w"]: l for l in report["layers"]}
    by_group: dict[str, list[dict]] = {}
    for b in boxes:
        by_group.setdefault(b["meta"]["g"], []).append(b)
    for g in groups["groups"]:
        bs = by_group.get(g["id"], [])
        ls = [layers[w["id"]] for w in g["words"] if w["id"] in layers]
        if not bs:
            v.append(f"{g['id']}: no box layer behind the text")
            continue
        first_in = expected_reveal(g, g["words"][0], mode)
        out = max((l["out_point"] for l in ls), default=None)
        lo = min((l["position"][0] - l["rect"]["width"] * l["scale"][0] / 200 for l in ls), default=None)
        hi = max((l["position"][0] + l["rect"]["width"] * l["scale"][0] / 200 for l in ls), default=None)
        for b in bs:
            if b["in_point"] < first_in - EPS or b["in_point"] >= first_in + fd + EPS:
                v.append(f"{g['id']}: box starts at {b['in_point']:.4f}, the caption at {first_in:.4f}")
            if out is not None and abs(b["out_point"] - out) > EPS:
                v.append(f"{g['id']}: box ends at {b['out_point']:.4f}, the words at {out:.4f}")
            if any(abs(a - c) > 0.01 for a, c in zip(b["color"][:3], rgb)) or abs(b["opacity"] - box.get("opacity", 1.0)) > 0.01:
                v.append(f"{g['id']}: box colour/opacity is not what was asked for")
            left = b["position"][0] - b["size"][0] / 2
            right = b["position"][0] + b["size"][0] / 2
            if lo is not None and (left > lo + 1.0 or right < hi - 1.0) and len(bs) == 1:
                v.append(f"{g['id']}: the box does not cover its words")
    return v


def verify(report: dict, groups: dict, options: dict | None = None) -> list[str]:
    """`options` = the style sent to After Effects; only `reveal` (mode) and `box` matter here. Without it every word is judged against its own reveal."""
    v: list[str] = []
    if not report.get("ok"):
        return ["report not ok: " + "; ".join(report.get("errors", []))]
    fd = report["comp"]["frameDuration"]
    mode = reveal_mode(options)
    layers = {l["meta"]["w"]: l for l in report["layers"]}
    words = [(g, w) for g in groups["groups"] for w in g["words"]]
    if len(layers) != len(report["layers"]):
        v.append("duplicate word ids in layers")
    exp = {w["id"] for _, w in words}
    if set(layers) != exp:
        v.append(f"layer/word mismatch: missing={sorted(exp - set(layers))[:5]} extra={sorted(set(layers) - exp)[:5]}")
    for g, w in words:
        L = layers.get(w["id"])
        if not L:
            continue
        want = w["display"].upper() if L["meta"].get("caps") else w["display"]     # caps are typed into the layer when the style asks for them
        if L["text"] != want:
            v.append(f"{w['id']}: text {L['text']!r} != {want!r}")
        due = expected_reveal(g, w, mode)                                       # == w["reveal"] unless the user chose "whole line at once"
        if L["in_point"] < due - EPS:
            v.append(f"PREMATURE in AE: {w['id']} {w['display']!r} in={L['in_point']:.4f} < reveal={due:.4f}")
        if L["in_point"] >= due + fd + EPS:
            v.append(f"{w['id']}: in-point {L['in_point']:.4f} later than reveal+1 frame ({due + fd:.4f})")
        if L["out_point"] <= L["in_point"] + EPS:
            v.append(f"{w['id']}: out<=in")
        # a layer needs at least one frame: when the LAST word of a caption is revealed less than a frame before the caption's exit, the whole caption
        # keeps (last in-point + 1 frame) as its shared out-point (the overlap check below still guarantees it never runs into the next caption)
        last_in = max((layers[x["id"]]["in_point"] for x in g["words"] if x["id"] in layers), default=L["in_point"])
        if L["out_point"] > max(g["exit"], last_in + fd) + EPS:
            v.append(f"{w['id']}: out {L['out_point']:.4f} > group exit {g['exit']:.4f}")
    gl = groups["groups"]
    for a, b in zip(gl, gl[1:]):
        outs = [layers[w["id"]]["out_point"] for w in a["words"] if w["id"] in layers]
        ins = [layers[w["id"]]["in_point"] for w in b["words"] if w["id"] in layers]
        if not outs or not ins:
            continue                                   # missing layers are already reported by the coverage check
        if max(outs) > min(ins) + EPS:
            v.append(f"OVERLAP in AE: {a['id']} visible until {max(outs):.4f} but {b['id']} starts {min(ins):.4f}")
    return v + verify_boxes(report, groups, options)
