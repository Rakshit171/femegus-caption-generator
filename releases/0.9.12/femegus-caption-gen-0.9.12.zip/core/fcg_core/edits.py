"""User overrides applied ON TOP of engine output (the transcript file is never modified).

overrides.json
{
  "words":   {"w000012": {"text": "theek", "start": 3.1, "end": 3.4, "deleted": true, "keep": true,
                          "role": "accent|support", "style": {...free-form, passed to the AE adapter...}}},
  "inserts": [{"id": "u000001", "after": "w000010", "text": "word", "start": 2.0, "end": 2.3}],
  "break_before": ["w000020"],      # force a new caption group before this word
  "join_before":  ["w000030"],      # forbid a group break before this word (ignored if limits make it impossible)
  "glossary": {"crr": "crore"}
}
Correcting ``text`` NEVER changes timing. ``start``/``end`` overrides are the user's explicit decision (reveal >= edited start).
``keep`` rescues a word the junk policy would exclude.
"""
from __future__ import annotations


def apply_overrides(words: list[dict], overrides: dict | None) -> tuple[list[dict], list[str]]:
    warns: list[str] = []
    ov = overrides or {}
    per = ov.get("words", {})
    out: list[dict] = []
    seen = set()
    for w in words:
        w = dict(w)
        o = per.get(w["id"])
        if o:
            seen.add(w["id"])
            if o.get("deleted"):
                continue
            if "text" in o and o["text"] != w["text"]:
                w["orig_text"] = w["text"]
                w["text"] = o["text"]
                w["edited"] = True
            for k in ("start", "end"):
                if k in o:
                    w.setdefault("orig_" + k, w[k])
                    w[k] = float(o[k])
                    w["edited"] = True
            if o.get("keep"):
                w["keep"] = True
            if "role" in o:
                w["role_override"] = o["role"]
            if "style" in o:
                w["style_override"] = o["style"]
        out.append(w)
    for wid in per:
        if wid not in seen:
            warns.append(f"override for unknown word id {wid} ignored")
    ids = {w["id"] for w in out}
    for ins in ov.get("inserts", []):
        after = ins.get("after")
        if after is not None and after not in ids:
            warns.append(f"insert {ins.get('id')} refers to unknown/deleted word {after}; placed by time")
        if not ins.get("text") or "start" not in ins or "end" not in ins:
            warns.append(f"insert {ins.get('id')} needs text, start and end; skipped")
            continue
        out.append({"id": ins["id"], "text": ins["text"], "start": float(ins["start"]), "end": float(ins["end"]),
                    "confidence": 1.0, "segment": None, "inserted": True, "edited": True})
    out.sort(key=lambda w: (w["start"], w["end"]))
    for w in out:
        if w["end"] <= w["start"]:
            warns.append(f"word {w['id']} has end<=start after edits; end set to start+0.02")
            w["end"] = w["start"] + 0.02
    for a, b in zip(out, out[1:]):
        if b["start"] < a["end"] - 1e-9:
            warns.append(f"words {a['id']} and {b['id']} overlap after edits; later word starts moved to {a['end']:.3f}")
            b["end"] = max(b["end"], a["end"] + 0.02)
            b["start"] = a["end"]
    return out, warns


def flag_collapsed(words: list[dict], max_word_s: float, min_run: int) -> int:
    """Flag runs of ``min_run`` or more consecutive words that each last ``max_word_s`` or less as ``collapsed`` (in place; returns how many words).
    Such a run is not speech: the recogniser squeezed a repeated or invented phrase into a few hundredths of a second, so it would only flash on screen.
    Words whose timing the user set (edited / inserted) are never flagged. The flag only marks; whether flagged words leave the captions is the
    ``exclude_flags`` policy (and ``keep`` rescues a single word)."""
    if min_run <= 0:
        return 0

    def squeezed(w: dict) -> bool:
        return not (w.get("edited") or w.get("inserted")) and (w["end"] - w["start"]) <= max_word_s + 1e-9

    n, i = 0, 0
    while i < len(words):
        if not squeezed(words[i]):
            i += 1
            continue
        j = i
        while j + 1 < len(words) and squeezed(words[j + 1]):
            j += 1
        if j - i + 1 >= min_run:
            for w in words[i:j + 1]:
                flags = w.setdefault("flags", [])
                if "collapsed" not in flags:
                    flags.append("collapsed")
                n += 1
        i = j + 1
    return n


def apply_policy(words: list[dict], exclude_flags: list[str]) -> tuple[list[dict], list[dict]]:
    """Split into (kept, excluded). Flagged junk is excluded from captions but returned so nothing disappears silently."""
    kept, excl = [], []
    bad = set(exclude_flags)
    for w in words:
        if bad & set(w.get("flags", [])) and not w.get("keep"):
            excl.append(w)
        else:
            kept.append(w)
    return kept, excl
