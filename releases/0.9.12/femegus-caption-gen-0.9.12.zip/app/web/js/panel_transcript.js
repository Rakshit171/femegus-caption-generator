// Section 2: editable transcript + timing; section 3: caption grouping settings.
import { S, on, emit, setOverrides, saveConfig } from './store.js';
import { h, fmtTime, toast, clone, deepMerge } from './dom.js';
import { fontPair, colorInput } from './widgets.js';

const TEMPLATES = ['auto', 'tiers', 'stack', 'flow'];
let video = null;
export function bindVideo(v) { video = v; }

function ensureWord(ov, id) { ov.words = ov.words || {}; return (ov.words[id] = ov.words[id] || {}); }
function cleanWord(ov, id) { if (ov.words && ov.words[id] && !Object.keys(ov.words[id]).length) delete ov.words[id]; }
const r3 = (x) => Math.round(x * 1000) / 1000;

// Hinglish text polish (spelling, numbers, punctuation): every change it made is listed, and it can be switched off. Timing is never touched by it.
function polishCard() {
  const tp = S.groups.text_polish || { enabled: false, changes: [], counts: {}, problems: [] };
  const cur = (S.meta.config && S.meta.config.text_polish) || (S.defaults.config && S.defaults.config.text_polish) || 'auto';
  const mode = h('select', {}, [['auto', 'Automatic (for Hinglish transcripts)'], ['on', 'Always on'], ['off', 'Off — captions show the text exactly as recognised']]
    .map(([v, l]) => h('option', { value: v, selected: cur === v }, l)));
  mode.onchange = () => saveConfig({ ...(S.meta.config || {}), text_polish: mode.value }).then(() => emit('section', 'transcript')).catch((e) => toast(e.message, 'err'));
  const n = tp.changes.length;
  const playAt = (t) => { if (video) { video.currentTime = Math.max(0, t - 0.4); video.play(); } };
  const probs = tp.problems.map((p) => h('div', { class: 'row tight' }, p.t != null ? h('button', { class: 'small', onclick: () => playAt(p.t) }, '▶') : null, h('span', { class: 'warn small' }, p.text)));
  const list = tp.changes.map((c) => h('div', { class: 'small' }, h('span', { class: 'hint' }, `${fmtTime(c.t)} · ${c.rule.replace(/_/g, ' ')}  `), h('code', {}, c.before), ' → ', h('code', {}, c.after)));
  return h('div', {},
    h('h3', {}, 'Hinglish text polish'),
    h('div', { class: 'hint small' }, 'One spelling per word (voh, toh, nahin, tumhaare, theek…), spoken amounts as numbers (paanch laakh → 5 lakh), sells/cells with sales context, question marks only for real questions, sentence capitals. Only the caption text changes — never the words, their order or timing. Words you edited yourself are never touched.'),
    h('div', { class: 'row' }, mode, tp.enabled ? h('span', { class: 'ok small' }, `${n} change${n === 1 ? '' : 's'}`) : h('span', { class: 'hint small' }, 'not active for this transcript')),
    probs.length ? h('div', {}, h('b', { class: 'warn small' }, 'Please check'), ...probs) : null,
    n ? h('details', { class: 'small' }, h('summary', {}, `What was changed (${n})`), ...list) : null);
}

export function renderTranscript(root) {
  if (!S.groups) { root.replaceChildren(h('h2', {}, '2 · Transcript & timing'), h('div', { class: 'hint' }, 'Transcribe or import a transcript first (section 1).')); return; }
  const ov = S.overrides, src = Object.fromEntries((S.transcript ? S.transcript.words : []).map((w) => [w.id, w]));
  const flagOnly = h('input', { type: 'checkbox', id: 'flagOnly' });
  const rows = [];
  S.groups.groups.forEach((g, gi) => {
    const firstId = g.words[0].id, gt = (ov.group_templates || {});
    const cur = g.words.map((w) => gt[w.id]).find(Boolean) || 'auto';
    const sel = h('select', { class: 'small', title: 'Layout for this caption' }, TEMPLATES.map((t) => h('option', { value: t, selected: t === cur }, t)));
    sel.onchange = () => setOverrides((o) => { o.group_templates = o.group_templates || {}; g.words.forEach((w) => delete o.group_templates[w.id]); if (sel.value !== 'auto') o.group_templates[firstId] = sel.value; });
    rows.push(h('tr', { class: 'gstart', 'data-g': g.id }, h('td', { colspan: 8 }, h('b', {}, g.id), ' ', h('span', { class: 'hint small' }, `${fmtTime(g.start)} → ${fmtTime(g.exit)} · ends: ${g.break_after}`), '  ', sel,
      g.template ? h('span', { class: 'tag edit' }, 'layout: ' + g.template) : null)));
    g.words.forEach((w, k) => {
      const e = (ov.words || {})[w.id] || {}, s = src[w.id];
      const mark = S.selection.has(w.id);
      const chk = h('input', { type: 'checkbox', checked: mark, onchange: (ev) => { ev.target.checked ? S.selection.add(w.id) : S.selection.delete(w.id); emit('selection'); } });
      const text = h('input', { type: 'text', value: w.text, 'aria-label': 'word text' });
      text.onchange = () => setOverrides((o) => { const x = ensureWord(o, w.id); if (s && text.value === s.text) delete x.text; else x.text = text.value; cleanWord(o, w.id); });
      const timeIn = (key, val) => {
        const i = h('input', { type: 'number', step: 0.01, value: r3(val), 'aria-label': key });
        i.onchange = () => setOverrides((o) => { const x = ensureWord(o, w.id); const v = parseFloat(i.value); if (s && Math.abs(v - s[key]) < 1e-6) delete x[key]; else x[key] = v; cleanWord(o, w.id); });
        return i;
      };
      const role = h('button', { class: 'role small ' + (w.role === 'accent' ? 'accent' : ''), title: `${w.role} (${w.role_source}) — click to toggle`, onclick: () => setOverrides((o) => {
        const x = ensureWord(o, w.id); x.role = w.role === 'accent' ? 'support' : 'accent'; })}, w.role === 'accent' ? 'A' : 's');
      const brk = (ov.break_before || []).includes(w.id), join = (ov.join_before || []).includes(w.id);
      const brkBtn = h('button', { class: 'small', title: k === 0 ? 'force a new caption before this word' : 'split the caption before this word', onclick: () => setOverrides((o) => {
        o.break_before = (o.break_before || []).filter((i) => i !== w.id); if (!brk) o.break_before.push(w.id); if (!o.break_before.length) delete o.break_before; }) }, brk ? '⏎✓' : '⏎');
      const del = h('button', { class: 'small danger', title: 'delete this word from the captions', onclick: () => setOverrides((o) => { ensureWord(o, w.id).deleted = true; }) }, '✕');
      const play = h('button', { class: 'small', title: 'play from here', onclick: () => { if (video) { video.currentTime = Math.max(0, w.reveal - 0.3); video.play(); } } }, '▶');
      const tags = [];
      (w.flags || []).forEach((f) => tags.push(h('span', { class: 'tag', title: 'engine flag' }, f.replace('_', ' '))));
      if (w.edited) tags.push(h('span', { class: 'tag edit' }, 'edited')); if (w.ids && w.ids.length > 1) tags.push(h('span', { class: 'tag edit', title: 'merged: ' + w.ids.join(' + ') }, 'merged'));
      if (w.display !== w.text) tags.push(h('span', { class: 'hint small', title: 'text shown in the caption' }, '→ ' + w.display));
      rows.push(h('tr', { 'data-w': w.id, class: mark ? 'sel' : '' }, h('td', {}, chk), h('td', {}, play), h('td', {}, timeIn('start', w.start)), h('td', {}, timeIn('end', w.end)),
        h('td', { style: { width: '100%' } }, text, tags), h('td', {}, role), h('td', {}, brkBtn), h('td', {}, del)));
    });
  });

  // excluded (engine-flagged junk) and deleted words: nothing disappears silently
  const excluded = (S.groups.excluded || []).map((x) => h('div', { class: 'row tight' }, h('span', { class: 'tag', title: x.flags.includes('collapsed') ? 'Squeezed into a few hundredths of a second together with its neighbours — the speech model repeated a phrase or lost its timing here, so showing it would only flash on screen. If it was really spoken, press "keep in captions".' : 'engine flag' }, x.flags.join(', ')), h('span', {}, `"${x.text}" @ ${fmtTime(x.start)}`),
    h('button', { class: 'small', onclick: () => setOverrides((o) => { ensureWord(o, x.id).keep = true; }) }, 'keep in captions')));
  const deleted = Object.entries(ov.words || {}).filter(([, v]) => v.deleted).map(([id]) => h('div', { class: 'row tight' }, h('span', {}, `"${(src[id] || {}).text || id}" @ ${fmtTime((src[id] || {}).start || 0)}`),
    h('button', { class: 'small', onclick: () => setOverrides((o) => { delete o.words[id].deleted; cleanWord(o, id); }) }, 'restore')));

  // glossary
  const gl = ov.glossary || {};
  const glRows = Object.entries(gl).map(([k, v]) => h('div', { class: 'row tight' }, h('code', {}, k), '→', h('code', {}, v), h('button', { class: 'small', onclick: () => setOverrides((o) => { delete o.glossary[k]; }) }, '✕')));
  const gk = h('input', { type: 'text', placeholder: 'crr', style: { width: '90px' } }), gv = h('input', { type: 'text', placeholder: 'crore', style: { width: '110px' } });
  const gadd = h('button', { class: 'small', onclick: () => gk.value && gv.value && setOverrides((o) => { o.glossary = o.glossary || {}; o.glossary[gk.value.toLowerCase()] = gv.value; }) }, 'add');

  // add a missing word
  const aw = { t: h('input', { type: 'text', placeholder: 'word', style: { width: '120px' } }), s: h('input', { type: 'number', step: 0.01, placeholder: 'start' }), e: h('input', { type: 'number', step: 0.01, placeholder: 'end' }) };
  const ins = h('button', { class: 'small', onclick: () => { if (!aw.t.value || aw.s.value === '' || aw.e.value === '') return toast('word, start and end are needed', 'err');
    setOverrides((o) => { o.inserts = o.inserts || []; o.inserts.push({ id: 'u' + String(o.inserts.length + 1).padStart(6, '0') + '-' + Date.now() % 100000, text: aw.t.value, start: +aw.s.value, end: +aw.e.value }); }); aw.t.value = ''; } }, 'insert word');

  root.replaceChildren(h('h2', {}, '2 · Transcript & timing'),
    h('div', { class: 'hint small' }, 'Edits change text/timing only on the captions; the original recognition is never overwritten. ▶ plays from just before the word. A/s = accent/support emphasis. ⏎ = start a new caption here. Words are never revealed before their start time.'),
    h('div', { class: 'row small' }, `${S.groups.stats.groups} captions · ${S.groups.stats.words} words`, S.groups.violations.length ? h('span', { class: 'bad' }, ` · ${S.groups.violations.length} timing violation(s)!`) : h('span', { class: 'ok' }, ' · timing checks pass'),
      h('button', { class: 'small', onclick: () => { S.selection.clear(); emit('selection'); emit('section', 'transcript'); } }, 'clear selection')),
    h('table', { class: 'words' }, h('thead', {}, h('tr', {}, ['', '', 'start', 'end', 'text', 'role', 'break', ''].map((x) => h('th', {}, x)))), h('tbody', {}, rows)),
    excluded.length ? h('div', {}, h('h3', {}, 'Excluded by the junk filter'), ...excluded) : '',      // (replaceChildren prints a literal "null" for null)
    deleted.length ? h('div', {}, h('h3', {}, 'Deleted by you'), ...deleted) : '',
    h('h3', {}, 'Insert a missed word'), h('div', { class: 'row' }, aw.t, aw.s, aw.e, ins),
    h('h3', {}, 'Display glossary'), h('div', { class: 'hint small' }, 'Replaces a recognised spelling in the caption only (e.g. crr → crore). Timing and the transcript are untouched.'), ...glRows, h('div', { class: 'row' }, gk, '→', gv, gadd),
    polishCard(),
    selectionPanel());
  // highlight the row being spoken
  highlightNow();
}

// ---- selection: apply a style change to just these words/captions
function selectionPanel() {
  const ids = [...S.selection];
  if (!ids.length) return h('div', { class: 'hint small' }, 'Tick words (left column) to style just those words differently.');
  const opt = (items) => items.map(([v, t]) => h('option', { value: v }, t));
  const fillKind = h('select', {}, opt([['', '(colour unchanged)'], ['solid', 'Solid colour'], ['gradient', 'Gradient']]));
  const fill = colorInput('#ff7a00'), gTop = colorInput('#ffd24a'), gBot = colorInput('#ff6a00');
  const font = fontPair('', null, { unchanged: true });
  const size = h('input', { type: 'number', step: 2, placeholder: 'px', style: { width: '70px' } });
  const caps = h('select', {}, opt([['', '(caps unchanged)'], ['upper', 'ALL CAPS'], ['none', 'as spoken']]));
  const strokeW = h('input', { type: 'number', min: 0, max: 40, step: 0.5, placeholder: 'width', style: { width: '70px' } }), strokeC = colorInput('#000000');
  const glowKind = h('select', {}, opt([['', '(glow unchanged)'], ['on', 'Glow on'], ['off', 'Glow off']])), glowC = colorInput('#ff7a00');
  const every = h('input', { type: 'checkbox' });
  const variants = (S.style && S.style.roles.accent && S.style.roles.accent.variants) || [];     // key-word treatments of the current look (if it has any)
  const treat = h('select', {}, h('option', { value: '' }, '(treatment unchanged)'), ...variants.map((v, i) => h('option', { value: String(i) }, v.name || 'Treatment ' + (i + 1))));
  const row = (label, ...kids) => h('div', { class: 'row tight' }, h('label', { class: 'l' }, label), ...kids);

  // only what is filled in is written, so words keep everything else from their role (the style of a word = role style + this patch)
  const patch = () => {
    const p = {};
    if (fillKind.value === 'solid') { p.fill = fill.getValue(); p.gradient = { enabled: false }; }
    if (fillKind.value === 'gradient') { p.fill = gTop.getValue(); p.gradient = { enabled: true, top: gTop.getValue(), bottom: gBot.getValue() }; }
    if (font.getFont()) p.font = font.getFont();
    if (size.value) p.size = +size.value;
    if (caps.value) p.caps = caps.value;
    if (strokeW.value !== '') p.stroke = { width: +strokeW.value, color: strokeC.getValue() };
    if (glowKind.value === 'on') p.glow = { enabled: true, color_a: glowC.getValue(), color_b: glowC.getValue(), radius: 24, intensity: 0.8 };
    if (glowKind.value === 'off') p.glow = { enabled: false };
    if (treat.value !== '') p.variant = +treat.value;                        // a key-word treatment (only meaningful on accent words)
    return p;
  };
  const targetIds = () => {
    if (!every.checked) return ids;
    const spoken = new Set(); const norm = (s) => String(s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
    S.groups.groups.forEach((g) => g.words.forEach((w) => { if (ids.includes(w.id)) spoken.add(norm(w.display)); }));
    const all = []; S.groups.groups.forEach((g) => g.words.forEach((w) => { if (spoken.has(norm(w.display))) all.push(w.id); }));
    return all;
  };
  const apply = h('button', { class: 'primary small', onclick: () => {
    const p = patch(); if (!Object.keys(p).length) return toast('Nothing to apply — choose a colour, font, size… first', 'err');
    const t = targetIds();
    setOverrides((o) => t.forEach((id) => { const x = ensureWord(o, id); x.style = deepMerge(x.style || {}, p); }));
    toast(`Style applied to ${t.length} word(s)`, 'ok');
  } }, 'Apply to selected');
  const role = (r) => h('button', { class: 'small', onclick: () => setOverrides((o) => targetIds().forEach((id) => { ensureWord(o, id).role = r; })) }, 'make ' + r);
  const clear = h('button', { class: 'small', onclick: () => setOverrides((o) => targetIds().forEach((id) => { if (o.words && o.words[id]) { delete o.words[id].style; delete o.words[id].role; cleanWord(o, id); } })) }, 'clear style & role');
  return h('div', { class: 'card' }, h('b', {}, `Style the selected words — ${ids.length} selected`),
    h('div', { class: 'hint small' }, 'Fill in only what should differ from the word’s role (key word / support). Timing is never affected.'),
    row('Colour', fillKind, fill, 'or gradient', gTop, gBot),
    row('Font', font, 'size', size, caps),
    row('Outline', strokeW, strokeC, glowKind, glowC),
    variants.length ? row('Key-word treatment', treat, h('span', { class: 'hint small' }, 'applies to key words (make accent first)')) : null,
    h('div', { class: 'row tight' }, every, h('label', {}, 'also every other occurrence of the selected word(s) in this video')),
    h('div', { class: 'row' }, apply, role('accent'), role('support'), clear));
}

function highlightNow() {
  const t = video ? video.currentTime : 0;
  document.querySelectorAll('table.words tr.now').forEach((r) => r.classList.remove('now'));
  if (!S.groups) return;
  let hit = null;
  for (const g of S.groups.groups) for (const w of g.words) if (t >= w.reveal && t < w.end + 0.05) hit = w.id;
  const tr = hit && document.querySelector(`tr[data-w="${hit}"]`); if (tr) tr.classList.add('now');
}
setInterval(highlightNow, 150);

// ---------------------------------------------------------------------------------------------------- grouping settings
const FIELDS = [
  ['Caption size', [['max_words', 'Max words', 1, 12, 1, 'Never more words than this in one caption'], ['min_words', 'Min words', 1, 6, 1, 'Avoids one-word fragments'], ['target_words', 'Preferred words', 1, 10, 1, ''],
    ['max_chars', 'Max characters', 8, 80, 1, 'Caption text length incl. spaces'], ['max_duration_s', 'Max seconds', 0.5, 8, 0.1, 'Spoken length of one caption']]],
  ['Where captions split', [['hard_pause_s', 'Hard pause (s)', 0.1, 2, 0.05, 'A pause this long ALWAYS ends a caption'], ['sentence_cue_pause_s', 'Sentence-start pause (s)', 0.02, 0.5, 0.01, 'Capital letter after an unpunctuated word + this pause = new sentence'],
    ['pause_full_credit_s', 'Soft-pause strength (s)', 0.05, 0.6, 0.01, 'Pause length that earns the full preference for splitting here']]],
  ['Reveal timing', [['reveal_offset_s', 'Reveal delay (s)', 0, 0.3, 0.01, 'Shift every reveal later (negative values are not allowed: words never appear before they are spoken)'], ['onset_max_shift_s', 'Max onset correction (s)', 0, 0.3, 0.01, 'How far the audio check may delay a word that Whisper started early']]],
  ['How long captions stay', [['hold_min_s', 'Min hold (s)', 0, 1, 0.05, ''], ['hold_max_s', 'Max hold (s)', 0.2, 3, 0.05, ''], ['min_group_visible_s', 'Min visible (s)', 0.2, 3, 0.05, ''], ['exit_gap_s', 'Gap to next caption (s)', 0, 0.3, 0.01, '0 = hard cut at the same instant']]],
  ['Emphasis', [['accent_max_per_group', 'Max accent words', 0, 4, 1, 'How many words per caption are suggested as big accent words']]],
];
export function renderGrouping(root) {
  if (!S.groups) { root.replaceChildren(h('h2', {}, '3 · Caption grouping'), h('div', { class: 'hint' }, 'Transcribe or import a transcript first.')); return; }
  const cfg = { ...S.defaults.config, ...(S.meta.config || {}) };
  const apply = () => saveConfig(cfg).catch((e) => toast(e.message, 'err'));
  const blocks = FIELDS.map(([title, fs]) => h('div', {}, h('h3', {}, title), ...fs.map(([k, label, mn, mx, st, tip]) => {
    const num = h('input', { type: 'number', min: mn, max: mx, step: st, value: cfg[k] }), rng = h('input', { type: 'range', min: mn, max: mx, step: st, value: cfg[k] });
    const set = (v) => { cfg[k] = +v; num.value = v; rng.value = v; apply(); };
    num.onchange = () => set(num.value); rng.oninput = () => { num.value = rng.value; }; rng.onchange = () => set(rng.value);
    return h('div', { class: 'row tight', title: tip }, h('label', { class: 'l' }, label), rng, num);
  })));
  const onset = h('select', {}, ['off', 'silence', 'slope'].map((v) => h('option', { value: v, selected: cfg.onset_mode === v }, v)));
  onset.onchange = () => { cfg.onset_mode = onset.value; apply(); };
  const reset = h('button', { onclick: () => { Object.keys(cfg).forEach((k) => delete cfg[k]); Object.assign(cfg, S.defaults.config); S.meta.config = {}; saveConfig({}).then(() => emit('section', 'grouping')); } }, 'Reset to defaults');
  const st = S.groups.stats;
  const lg = S.style && S.style.grouping && Object.keys(S.style.grouping).length ? S.style.grouping : null;
  const lookNote = lg ? h('div', { class: 'card small' }, h('b', {}, 'The current look sets the grouping: '), Object.entries(lg).map(([k, v]) => `${k} = ${v}`).join(', '),
    h('div', { class: 'hint small' }, 'These values override the ones below while this look is active (the other rules still apply). Pick another look in section 4 to release them. Sentence ends and long pauses still end a caption early — words are never added to fill a line.')) : null;
  root.replaceChildren(h('h2', {}, '3 · Caption grouping'), h('div', { class: 'hint small' }, 'These rules decide which words share a caption and when it leaves. They never change when a word first appears.'), lookNote,
    h('div', { class: 'card small' }, `${st.groups} captions · ${st.avg_words_per_group} words each on average · breaks: ` + Object.entries(st.break_reasons).map(([k, v]) => `${k} ${v}`).join(', ')),
    ...blocks, h('h3', {}, 'Audio onset correction'), h('div', { class: 'row' }, h('label', { class: 'l' }, 'Mode'), onset, h('span', { class: 'hint small' }, 'off · silence (default, safe) · slope (also corrects early starts in fast speech)')),
    h('div', { class: 'row' }, reset));
}
