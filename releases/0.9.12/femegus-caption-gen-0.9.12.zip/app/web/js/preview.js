// Caption preview: draws the generated captions over the video using the SAME layout geometry (fcg_layout) and animation maths (anim.js)
// that the After Effects adapter uses. Timing/layout/motion are exact; glow, blur and drop shadow are canvas approximations.
import { S, on } from './store.js';
import { deepMerge, wordStyle } from './dom.js';

const snapUp = (t, fd) => Math.ceil(t / fd - 1e-6) * fd;
const snapDown = (t, fd) => Math.floor(t / fd + 1e-6) * fd;

export class Preview {
  constructor(video, canvas) {
    this.video = video; this.canvas = canvas; this.ctx = canvas.getContext('2d');
    this.layouts = null; this.show = true; this.rafId = 0; this.lastKey = '';
    const redraw = () => { this.invalidate(); this.draw(); };
    on('groups', redraw); on('style', redraw); on('project', redraw);
    new ResizeObserver(() => this.resize()).observe(video.parentElement);
    window.addEventListener('resize', () => this.resize());
    video.addEventListener('loadedmetadata', () => { this.resize(); this.invalidate(); this.draw(); });
    video.addEventListener('seeked', () => this.draw());
    const loop = () => { this.draw(); this.rafId = requestAnimationFrame(loop); };
    loop();
  }
  hasVideo() { return !(S.meta && S.meta.probe && S.meta.probe.has_video === false); }
  get comp() {
    const p = (S.meta && S.meta.probe) || {};
    return { w: p.width || this.video.videoWidth || 1080, h: p.height || this.video.videoHeight || 1920, fps: p.fps || 30 };
  }
  resize() {
    const v = this.video;
    let r = v.getBoundingClientRect();
    if (!this.hasVideo()) {                       // audio only: a black 9:16 stage (the comp's default size) carries the captions
      const box = v.parentElement.getBoundingClientRect(), h = Math.min(box.height, box.width * 16 / 9), w = h * 9 / 16;
      r = { width: w, height: h };
      this.canvas.style.left = (box.width - w) / 2 + 'px'; this.canvas.style.top = (box.height - h) / 2 + 'px'; this.canvas.style.background = '#000';
    } else { this.canvas.style.left = v.offsetLeft + 'px'; this.canvas.style.top = v.offsetTop + 'px'; this.canvas.style.background = 'transparent'; }
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = Math.max(1, Math.round(r.width * dpr)); this.canvas.height = Math.max(1, Math.round(r.height * dpr));
    this.canvas.style.width = r.width + 'px'; this.canvas.style.height = r.height + 'px';
    this.dpr = dpr; this.draw();
  }
  invalidate() { this.layouts = null; }

  // ---- style helpers (mirror fcgRoleStyle in the adapter)
  // role style -> layout-specific override -> accent variant -> the word's own override (same order as fcgRoleStyle in the adapter)
  roleStyle(role, tpl, word, variant) {
    const st = S.style;
    let s = st.roles[role] || st.roles.support;
    const ts = st.template_styles && st.template_styles[tpl] && st.template_styles[tpl][role];
    if (ts) s = deepMerge(s, ts);
    if (variant != null && s.variants && s.variants[variant]) s = deepMerge(s, s.variants[variant]);
    if (word && word.style_override) s = wordStyle(s, word.style_override);
    return s;
  }
  // text treatment key for the centred layout: running text (support words and inline accents) shares one line, other accents get their own
  lineKey(st, role, variant) { return role !== 'accent' || st.line === 'inline' ? 'text' : 'v' + (variant == null ? 'x' : variant); }
  // first installed font of [font, ...font_fallbacks] (mirrors the adapter)
  fontOf(st) { return [st.font, ...(st.font_fallbacks || [])].find((f) => S.fontMap[f]) || st.font; }
  cssFont(st) {
    const f = S.fontMap[this.fontOf(st)];
    const fam = f ? f.family : st.font;
    return `${f && f.italic ? 'italic ' : ''}${f ? f.weight : 400} ${st.size}px "${fam}", Arial, sans-serif`;
  }
  measure(text, st) {
    const c = this.ctx; c.save(); c.font = this.cssFont(st); c.letterSpacing = ((st.tracking || 0) / 1000 * st.size) + 'px';
    const t = st.caps === 'upper' ? text.toUpperCase() : text;
    const m = c.measureText(t); c.restore();
    const left = -m.actualBoundingBoxLeft, right = m.actualBoundingBoxRight;
    return { w: right - left, h: m.actualBoundingBoxAscent + m.actualBoundingBoxDescent, top: -m.actualBoundingBoxAscent, left, size: st.size };
  }
  prepare() {
    const { w: W, h: H, fps } = this.comp, fd = 1 / fps;
    this.layouts = [];
    if (!S.groups) return;
    const vars = fcgAssignVariants(S.groups.groups, S.style.roles.accent);
    S.groups.groups.forEach((g, gi) => {
      const tpl = fcgChooseTemplate(g, gi, S.style.layout);
      const sts = g.words.map((w, k) => this.roleStyle(w.role, tpl, w, vars[gi][k]));
      const items = g.words.map((w, k) => ({ ...this.measure(w.display, sts[k]), role: w.role, line: this.lineKey(sts[k], w.role, vars[gi][k]), cap: sts[k].fit_width > 0 ? sts[k].fit_width * W : 0 }));
      const res = fcgLayoutGroup(items, W, H, S.style.layout, tpl);
      const mode = (S.style.reveal && S.style.reveal.mode) || 'word';          // "line": the whole caption appears with its first word (see fcgRevealOf)
      const lastIn = snapUp(fcgRevealOf(g, g.words.length - 1, mode), fd);
      const outT = Math.max(snapDown(g.exit, fd), lastIn + fd);
      const ins = g.words.map((w, k) => snapUp(fcgRevealOf(g, k, mode), fd));
      const box = S.style.box && S.style.box.enabled ? S.style.box : null;
      const boxes = box ? fcgBoxRects(items, res, box) : null;
      // per-letter reveal plans (letters fit into the time before the caption leaves)
      const plans = g.words.map((w, k) => {
        const a = sts[k].anim;
        if (!a || a.unit !== 'letter') return null;
        const n = Array.from(sts[k].caps === 'upper' ? w.display.toUpperCase() : w.display).length;
        return FCGAnim.letterPlan(a.letters || {}, n, outT - ins[k], fd);
      });
      this.layouts.push({ g, tpl, items, res, sts, outT, ins, plans, boxes, box });
    });
    // sorted start times for a fast "which group is visible now" lookup
    this.starts = this.layouts.map((L) => L.ins[0]);
  }

  draw() {
    const c = this.ctx, cv = this.canvas;
    c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, cv.width, cv.height);
    if (!this.show || !S.groups || (this.hasVideo() && !this.video.videoWidth)) return;
    if (!this.layouts) this.prepare();
    const t = this.video.currentTime, { w: W, fps } = this.comp, fd = 1 / fps;
    const s = (cv.width / (this.dpr || 1)) / W * (this.dpr || 1);
    for (const L of this.layouts) {
      if (t < L.ins[0] - 1e-6 || t >= L.outT) continue;
      if (L.boxes) this.drawBoxes(L.boxes, L.box, s);
      L.g.words.forEach((w, k) => {
        if (t < L.ins[k] - 1e-6) return;                  // never before its in-point
        const st = L.sts[k], p = L.res.placements[k], it = L.items[k];
        const base = { x: p.cx, y: p.cy, scale: p.f * 100 };
        let state = { opacity: 100, x: base.x, y: base.y, scale: base.scale, blur: 0 };
        const a = st.anim, plan = L.plans && L.plans[k];
        if (plan) { this.drawWord(w, st, it, state, s, { plan, tRel: t - L.ins[k] }); return; }       // per-letter reveal (anim.unit = "letter")
        if (a && a.duration > 0) {
          const cl = FCGAnim.clampDuration(a.duration, L.outT - L.ins[k], fd);
          const t1 = snapUp(L.ins[k] + cl.duration, fd);
          if (t1 - L.ins[k] >= 2 * fd - 1e-6) state = FCGAnim.entranceAt({ ...a, duration: t1 - L.ins[k] }, base, t - L.ins[k]);
        }
        this.drawWord(w, st, it, state, s);
      });
    }
  }

  // the solid box behind each line (style.box): a plain filled rounded rectangle, drawn under the words
  drawBoxes(rects, box, s) {
    const c = this.ctx;
    c.save(); c.globalAlpha = Math.max(0, Math.min(1, box.opacity === undefined ? 1 : box.opacity)); c.fillStyle = box.color || '#000000';
    for (const r of rects) {
      c.beginPath();
      if (c.roundRect) c.roundRect(r.x * s, r.y * s, r.w * s, r.h * s, r.r * s); else c.rect(r.x * s, r.y * s, r.w * s, r.h * s);
      c.fill();
    }
    c.restore();
  }

  // lt = { plan, tRel } draws the word letter by letter (anim.unit = "letter"): each letter has its own opacity, blur, rise and tint colour
  drawWord(w, st, it, state, s, lt) {
    const c = this.ctx, text = st.caps === 'upper' ? w.display.toUpperCase() : w.display;
    c.save();
    c.translate(state.x * s, state.y * s); c.scale(state.scale / 100 * s, state.scale / 100 * s);
    c.globalAlpha = Math.max(0, Math.min(1, state.opacity / 100));
    c.font = this.cssFont(st); c.letterSpacing = ((st.tracking || 0) / 1000 * st.size) + 'px'; c.textBaseline = 'alphabetic'; c.textAlign = 'left';
    const ox = -(it.left + it.w / 2), oy = -(it.top + it.h / 2);         // origin (baseline-left) relative to the box centre
    const gradient = !!(st.gradient && st.gradient.enabled);
    let fill = st.fill;
    if (gradient) {
      const g = c.createLinearGradient(0, -it.h / 2, 0, it.h / 2); g.addColorStop(0, st.gradient.top); g.addColorStop(1, st.gradient.bottom); fill = g;
    }
    const glow = st.glow && st.glow.enabled, sh = st.shadow && st.shadow.enabled;
    const L = (st.anim && st.anim.letters) || {};
    let pieces = [{ ch: text, x: 0, dy: 0, alpha: 1, blur: state.blur, tint: 0 }];
    if (lt) {
      const chars = Array.from(text);
      pieces = chars.map((ch, i) => {
        const a = FCGAnim.letterAt(L, lt.plan, lt.tRel, i);
        return { ch, x: i ? c.measureText(chars.slice(0, i).join('')).width : 0, dy: a.dy, alpha: a.opacity / 100, blur: a.blur, tint: a.tint };
      });
    }
    for (const p of pieces) {
      if (p.alpha <= 0.002) continue;
      c.save();
      c.globalAlpha *= p.alpha;
      // blur value -> Gaussian sigma: AE's Gaussian Blur effect ~0.5 x blurriness, AE's text-animator Blur ~0.40 x value (both measured in AE 25.2)
      if (p.blur > 0.2) c.filter = `blur(${(p.blur * (lt ? 0.4 : 0.5) * state.scale / 100 * s).toFixed(2)}px)`;
      const x = ox + p.x, y = oy + p.dy;
      if (glow) {                                                         // approximate AE Glow: coloured halo
        c.save(); c.shadowColor = st.glow.color_a; c.shadowBlur = st.glow.radius * 1.2 * s; c.globalAlpha *= Math.min(1, 0.55 * st.glow.intensity + 0.2);
        c.fillStyle = st.glow.color_b; c.fillText(p.ch, x, y); c.fillText(p.ch, x, y); c.restore();
      }
      if (sh) {                                                           // approximate AE Drop Shadow (direction 135 = down-right)
        const ang = (st.shadow.direction || 135) * Math.PI / 180, d = st.shadow.distance;
        c.shadowColor = this.rgba(st.shadow.color, st.shadow.opacity); c.shadowBlur = st.shadow.softness * 0.8 * s;
        c.shadowOffsetX = Math.sin(ang) * d * s; c.shadowOffsetY = -Math.cos(ang) * d * s;
      }
      c.fillStyle = p.tint > 0 && !gradient && L.tint ? this.mix(st.fill, L.tint, p.tint) : fill;      // a gradient fill hides the tint (same in AE)
      c.fillText(p.ch, x, y);
      if (st.stroke && st.stroke.width > 0) { c.shadowColor = 'transparent'; c.lineWidth = st.stroke.width; c.strokeStyle = st.stroke.color; c.strokeText(p.ch, x, y); }
      c.restore();
    }
    c.restore();
  }
  mix(a, b, k) {
    const p = (h) => { const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(h || '#000000') || [0, '00', '00', '00']; return [1, 2, 3].map((i) => parseInt(m[i], 16)); };
    const A = p(a), B = p(b);
    return `rgb(${A.map((v, i) => Math.round(v + (B[i] - v) * k)).join(',')})`;
  }
  rgba(hex, a) {
    const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '#000000') || [0, '00', '00', '00'];
    return `rgba(${parseInt(m[1], 16)},${parseInt(m[2], 16)},${parseInt(m[3], 16)},${a})`;
  }
}
