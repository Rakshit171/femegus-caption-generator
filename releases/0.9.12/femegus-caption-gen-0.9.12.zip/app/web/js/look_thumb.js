// Thumbnail of a look: the same sample caption laid out and painted with the preview's own code (fcg_layout + Preview.drawWord), in its final state.
import { S } from './store.js';
import { Preview } from './preview.js';

const SAMPLE = [['that', 'support'], ['transcribes', 'support'], ['an', 'accent'], ['hour', 'accent'], ['of', 'support'], ['audio', 'support']];

export function drawLookThumb(canvas, style) {
  const ctx = canvas.getContext('2d'), W = 1080, H = 1920, s = canvas.width / W;
  const old = S.style;
  S.style = style;                                   // Preview's helpers read S.style; restored below
  try {
    const P = Object.create(Preview.prototype);      // helpers only (no video, no listeners)
    P.ctx = ctx; P.canvas = canvas; P.dpr = 1;
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, canvas.width, canvas.height);
    const bg = ctx.createLinearGradient(0, 0, 0, canvas.height); bg.addColorStop(0, '#4a3a31'); bg.addColorStop(0.5, '#241b17'); bg.addColorStop(1, '#0f0c0b');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, canvas.width, canvas.height);
    const n = style.grouping && style.grouping.max_words > 0 ? style.grouping.max_words : SAMPLE.length;      // a look with "N words per line" shows N words
    const g = { words: SAMPLE.slice(0, n).map(([display, role]) => ({ display, role })) };
    const vars = fcgAssignVariants([g], style.roles.accent);
    const tpl = fcgChooseTemplate(g, 0, style.layout);
    const sts = g.words.map((w, k) => P.roleStyle(w.role, tpl, w, vars[0][k]));
    const items = g.words.map((w, k) => ({ ...P.measure(w.display, sts[k]), role: w.role, line: P.lineKey(sts[k], w.role, vars[0][k]), cap: sts[k].fit_width > 0 ? sts[k].fit_width * W : 0 }));
    const res = fcgLayoutGroup(items, W, H, style.layout, tpl);
    if (style.box && style.box.enabled) P.drawBoxes(fcgBoxRects(items, res, style.box), style.box, s);
    g.words.forEach((w, k) => {
      const p = res.placements[k], st = sts[k], a = st.anim;
      let lt = null;
      if (a && a.unit === 'letter') {
        const n = Array.from(st.caps === 'upper' ? w.display.toUpperCase() : w.display).length;
        lt = { plan: FCGAnim.letterPlan(a.letters || {}, n, 10, 1 / 30), tRel: 10 };          // long after the reveal: final state
      }
      P.drawWord(w, st, items[k], { opacity: 100, x: p.cx, y: p.cy, scale: p.f * 100, blur: 0 }, s, lt);
    });
  } finally { S.style = old; }
}
