"""Bridge to After Effects. The user runs the connect script (adapters/jsx-core/fcg_connect.jsx) once per AE session; it polls an inbox folder.
This module writes a job there, waits for the report, and verifies the layers AE created against the groups we sent.
"""
from __future__ import annotations

import json
import os
import subprocess
import time
import uuid
from typing import Optional

from .ops import ROOT

INBOX = os.path.join(ROOT, "work", "ae_inbox")
HEARTBEAT = os.path.join(INBOX, "heartbeat_connect.txt")        # written by adapters/jsx-core/fcg_connect.jsx
JOB = os.path.join(INBOX, "job_connect.json")
CONNECT_SCRIPT = os.path.join(ROOT, "adapters", "jsx-core", "fcg_connect.jsx")
HEARTBEAT_MAX_AGE = 20.0


def ae_process_running() -> bool:
    try:
        out = subprocess.run(["tasklist", "/FI", "IMAGENAME eq AfterFX.exe", "/NH"], capture_output=True, text=True, timeout=10).stdout
        return "AfterFX.exe" in out
    except Exception:
        return False


def status() -> dict:
    age: Optional[float] = None
    if os.path.isfile(HEARTBEAT):
        age = time.time() - os.path.getmtime(HEARTBEAT)
    running = ae_process_running()
    ver = None
    try:
        with open(HEARTBEAT, "r", encoding="utf-8-sig") as f:
            lines = f.read().split("\n")
            ver = lines[1] if len(lines) > 1 else None
    except OSError:
        pass
    connected = age is not None and age < HEARTBEAT_MAX_AGE and running
    return {"ae_running": running, "connected": connected, "ae_version": ver if connected else None,
            "heartbeat_age_s": round(age, 1) if age is not None else None, "connect_script": CONNECT_SCRIPT}


def submit(project, options: dict, action: str = "build", timeout: float = 900.0, job=None) -> dict:
    """Send a build job to After Effects and wait for the verified report. Raises on timeout / not connected."""
    st = status()
    if not st["connected"]:
        raise RuntimeError("After Effects is not connected. In After Effects: File > Script > Run Script File… > " + CONNECT_SCRIPT)
    os.makedirs(INBOX, exist_ok=True)
    groups_path = os.path.abspath(project.path("groups"))            # After Effects resolves relative paths against ITS working folder, not ours
    if not os.path.isfile(groups_path):
        raise RuntimeError("no captions built yet")
    report_path = os.path.abspath(os.path.join(project.folder, f"ae_report_{uuid.uuid4().hex[:6]}.json"))
    payload = {"action": action, "groups": groups_path.replace("\\", "/"), "options": options, "report": report_path.replace("\\", "/")}
    tmp = JOB + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp, JOB)
    t0 = time.time()
    while not os.path.isfile(report_path):
        if job is not None and job.cancel_requested:
            raise RuntimeError("cancelled")
        if time.time() - t0 > timeout:
            raise TimeoutError("no answer from After Effects (is a dialog open?)")
        if job is not None:
            job.set(min(0.9, (time.time() - t0) / 60.0), "After Effects is building the layers…")
        time.sleep(1.0)
    time.sleep(0.5)
    with open(report_path, "r", encoding="utf-8-sig") as f:
        report = json.load(f)
    result = {"ok": bool(report.get("ok")), "errors": report.get("errors", []), "warnings": report.get("warnings", []),
              "words": report.get("words"), "seconds": report.get("seconds"), "anim_stats": report.get("anim_stats"),
              "comp": report.get("comp"), "host": (report.get("host") or {}).get("raw")}
    if report.get("ok") and action == "build":
        from fcg_core.ae_verify import verify, verify_style
        with open(groups_path, "r", encoding="utf-8-sig") as f:
            groups = json.load(f)
        problems = verify(report, groups, options) + verify_style(report, options, groups)
        result["verified"] = not problems
        result["verify_problems"] = problems[:20]
    try:
        os.remove(report_path)           # the dump can be large; the summary above is what the UI needs
    except OSError:
        pass
    return result
