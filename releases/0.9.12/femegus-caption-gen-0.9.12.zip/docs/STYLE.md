# Style, layout and animation (Stage 5)

Everything visual is **data**: a JSON preset merged over the built-in defaults (`FCG_DEFAULT_OPTIONS` in `adapters/jsx-core/lib/fcg_build.jsxinc`).
You never edit code. Presets / looks (section 4 of the app): `presets/reference_style.json` (the reference look), `presets/soft_editorial.json` (look 2, see below) and `presets/clean_poppins.json` (a deliberately different example).
Use one with the dev harness: `.\scripts\ae_run.ps1 -Groups work\clip.groups.json -OptionsJson presets\reference_style.json -SaveProject work\ae_test\x.aep`
(the end-user panel in Stage 6 will pick the preset from a menu). **Style can never change timing** — see "Guarantees".

## Roles
Every word is `support` (default) or `accent` (suggested automatically, overridable per word — see SEGMENTER.md). Each role has:

| Key | Meaning |
|---|---|
| `font` | PostScript name, e.g. `ArialMT`, `Arial-BoldMT`, `Arial-BoldItalicMT`, `Poppins-Bold`, `Montserrat-ExtraBold`. A missing font falls back to `fallback_font` with a warning |
| `size`, `tracking`, `caps` (`none`/`upper`) | pixels in the comp, tracking units, all-caps via AE's own caps option (AE ≥ 24) |
| `fill` | solid colour (hex). **Ignored while `gradient.enabled` is true** (the gradient is drawn over it) — the app's "Fill type" menu shows only the controls that apply |
| `gradient` `{enabled, top, bottom}` | vertical gradient inside the letters — an AE **Gradient Ramp** effect on the same text layer (see Technique notes) |
| `stroke` `{width, color}` | text stroke (code path present, untested visually) |
| `shadow` `{enabled, color, opacity 0–1, distance, softness, direction}` | AE **Drop Shadow** effect |
| `glow` `{enabled, color_a, color_b, radius, intensity}` | AE **Glow** effect (alpha-based, two-colour) |
| `label` | AE layer label colour index |
| `anim` | entrance animation (below) |

`template_styles.<template>.<role>` overrides any of the above for one layout (the reference's second look = bold italic all-caps).
A single word can carry `style_override` (from overrides.json) that is merged on top.

### Per-word and key-word styling
* **All key words** = the `accent` role (Typography / Colours sections: font, size, fill type solid/gradient, outline, shadow, glow). **Some words** = tick them in section 2 → "Style the selected words": colour or gradient, **any installed font**, size, caps, outline, glow; optionally every other occurrence of the same word. Only the fields you fill in are stored (`style_override`); the rest comes from the word's role.
* Merge rule (same in the AE builder `fcgWordStyle`, the preview `wordStyle` and the verifier `word_style`): a solid `fill` in a word override that does not mention `gradient` **switches the role's gradient off**, otherwise the gradient would hide the chosen colour. An explicit `gradient` in the override always wins.
* Editing the **"all layouts"** target replaces a layout-specific value of the same property (e.g. the stack layout's own accent colour/font); before this, such an override silently won and the edit seemed to "do nothing" on those captions. Editing a single layout still writes only that layout's override.
* After Effects read-back verification (`verify_style`) now applies word overrides when checking size, fill, font and effects.

## Layout templates (`layout.*`)
Geometry is computed for the **whole group at once**, so nothing moves when later words appear.
* `tiers` — consecutive words of one role form a line; accent lines centred and large; support lines above hug the accent's left edge, below hug its right edge (`tiers.support_inset_px`, `gap_px`, `baseline_step_px`).
* `stack` — every word on its own centred line, tight leading (`stack.gap_em`), horizontal jitter cycle (`stack.x_offsets`).
* `flow` — plain centred wrapping.
* `template`: `auto` (default) picks per group: no accent or no support ⇒ `stack`; otherwise cycles `auto_cycle` (default tiers, tiers, stack); or force one name. A group may carry its own `template`.
* `anchor_x/anchor_y` (fractions of the comp), `max_width`, `safe_margin`: text is **shrunk to fit**, never clipped, and kept inside the safe margins.
* **Placement depends on the speaker's framing.** The default `anchor_y: 0.60` suits a talking head whose face is in the upper half. Set it per video (the reference clip's face is higher, so it used ≈0.46).

## Animation (`anim`, relative to each word's in-point)
`duration` s · `ease` (preset name or `[x1,y1,x2,y2]` cubic-bezier) · `slide [dx,dy]` px · `scale_from` · `opacity_from` · `blur_from` px.
Presets: `linear`, `easeOut`, `easeOutSoft`, `easeInOut`, `easeIn`, `overshoot`. Exit = hard cut at the group exit (like the reference).
* The animation starts **at** the word's in-point and can never be earlier; duration is clamped to the time left before the group exits (reported as a warning, e.g. "13 word animation(s) shortened"); an entrance that would be shorter than 2 frames is skipped (reported).
* Overshoot works on **scale** (bounce); position uses the same curve with its y-handles limited to [0,1] (After Effects cannot overshoot along a spatial path), opacity/blur are clamped by their ranges. The shared evaluator mirrors this exactly.

## Look 2 — "Soft Editorial" (`presets/soft_editorial.json`)
Modelled on `reference/look2/Video-34323.mp4` (analysis: REFERENCE_ANALYSIS.md, "Reference 2"). It is a **second look next to the reference look** — switch in section 4, nothing of the original changed.
What it adds to the data model (all optional; the reference look uses none of it):

| Where | Key | Meaning |
|---|---|---|
| `layout.template` | `"centered"` | centred lines; a new line starts when the text treatment changes; `layout.centered {gap_em, gap_px}` = line gap |
| role / variant | `line` | `"own"` (key words on their own line) or `"inline"` (a bold word inside the running text) |
| role / variant | `fit_width` | shrink this line to at most this fraction of the frame width (stops long serif-caps words overflowing) |
| role / variant | `font_fallbacks` | PostScript names tried in order when `font` is not installed (preview and After Effects pick the same one) |
| `roles.accent` | `variants[]`, `variant_pool[]`, `variant_mode` | several key-word treatments (partial styles merged over the accent role). Each accent **phrase** (consecutive accent words in a caption) takes the next treatment of the pool (`rotate`) or always the first (`fixed`); a word can force one with `style_override.variant` |
| `anim` | `unit: "letter"` + `letters {stagger, duration, ease, blur_from, opacity_from, rise, tint, tint_duration, max_total}` | per-letter reveal instead of the word-level slide/scale/blur |
| layout-specific | `template_styles` | **replaces** the default's when a style has the key (a look without layout overrides must not inherit the reference look's italic "stack") |

**Letter reveal** (`core/anim/anim.js` `letterPlan` / `letterAt`): letter *i* starts `i × stagger` after the word's in-point, so the first letter starts exactly at the reveal and no letter can be visible earlier; each letter runs the same eased opacity / un-blur / rise over `duration`; its **tint** colour (newly shown letters are pink-ish in the reference) fades over `tint_duration`. The whole reveal is compressed into `max_total` and into the time before the caption leaves.
In After Effects it is two **text animators with Expression Selectors** (`FCG Letters`: Opacity, Blur, Position; `FCG Tint`: Fill Colour). The selector expression is generated by `FCGAnim.letterExpression` and tested to give the same numbers as `letterAt`. Measured in AE 25.2: rendered opacity equals the shared evaluator to ≤ 0.1 % (linear and ease-out), the text-animator blur is a Gaussian of σ ≈ 0.40 × the blur value, and a gradient fill hides the tint (the Gradient Ramp effect is applied after the animators).

**What the look does *not* copy** (honest list): the reference shows several words *at once* before they are spoken — that would break the "never before it is spoken" rule, so words appear one by one at their spoken time; graphic assets (logo pill, UI cards, tan highlight box behind a word, phone frame, background, light leaks, zoom/blur transitions) are not captions; the reference's typefaces are not identified — Satoshi (sans) and Playfair Display (serif) are used, both already installed here; the "which phrase gets which treatment" choice is made by rotation instead of an editor's judgement (set per word or reduce the pool in section 4); the tan / gold / pink colours were sampled by eye from video frames and may differ a little.

## Look 3 — "Clean 4-Word" (`presets/clean_four_words.json`)
Plain white bold sans (Satoshi Bold; fallbacks Poppins SemiBold / Neue Montreal / Arial), **at most four words per line, always on ONE line**, every word appearing exactly when it is spoken (reveal times are the same as in every other look). **Animation is OFF in the saved look** (plain text); a one-click switch turns on a smooth slide-up.
New, optional data (STYLE data model):

| Where | Key | Meaning |
|---|---|---|
| style | `grouping {…}` | caption-grouping settings (any `SegmenterConfig` field, see SEGMENTER.md) that apply **while this look is active**, on top of the project's own settings. Here `max_words 4, target_words 4, min_words 2, max_chars 60, max_duration_s 5, w_size 6`. Changing the style re-cuts the captions; choosing another look releases them. Sentence ends, long pauses and punctuation still end a caption early, so ≈ 70 % of the captions have exactly four words, the rest three (measured on an English and a Hinglish clip) — words are **never padded** to fill a line. |
| `_look` (metadata, not style) | `toggle {label, hint, on, off}` | a one-click switch: `on` / `off` are style patches merged over the style. The app shows ON / OFF (or CUSTOM if you changed those values yourself) in section 4. |
| `layout.centered` | `wrap: false` | never break a line of running text: shrink it to fit instead (four long words stay on one line). |

**Slide-up (switch ON):** every word, support and accent alike, moves **vertically only** from 42 px below into its place while fading in, over 0.45 s with the curve `cubic-bezier(0.22, 1, 0.36, 1)` (fast start, long soft landing, **no overshoot, no blur, no scale**). It starts exactly at the word's reveal frame, so it follows the speaker; the layout of the whole line is fixed beforehand, so nothing else moves when a word arrives. Tested (`tests/anim/test_look2.js`): starts invisible/below, ends exactly in place, y only decreases, opacity only rises, never above its place, largest step at 30 fps ≤ 45 % of the slide. Words that appear just before their caption leaves get a shortened slide (reported as a warning, never a late start).
**Switch OFF:** `duration 0` → no keyframes at all in After Effects (the layer simply starts at its reveal frame).

### More options of this look (unreleased, built 2026-11-06)
Two more one-click switches in section 4, both OFF by default (nothing changes for anyone who does not use them), independent of each other and of the slide-up:

| Where | Key | Meaning |
|---|---|---|
| style | `reveal {mode}` | `"word"` (default): every word at its own reveal time. `"line"` (**Whole line at once**): the whole caption appears together with its FIRST word and stays as it is. **This is the one deliberate exception to "never show a word before it is spoken"** — the later words of a line are on screen up to about a second before they are said; the owner asked for it explicitly (2026-11-06) and it only applies when the switch is ON. The first word is still never early, `reveal` times in `groups.json` never change, and the checks in `ae_verify` judge each word against the caption's first reveal in this mode (and flag anything earlier than that). Shared function `fcgRevealOf` (fcg_layout.jsxinc), used by the preview and the After Effects builder. |
| style | `box {enabled, color, opacity, pad_x, pad_y, radius, ascent_em, descent_em}` | **Solid box behind the text**: one filled rectangle per line (a separate shape layer per line in After Effects, named `gNNNN_boxK`, comment `FCGBOX:{…}`, directly beneath the caption's lowest word layer, in/out points = the caption's, rebuilds replace them). Colour, opacity, padding and corner roundness are editable in section 4. Width = the words of the line as placed; height comes from the baseline and font size (`ascent_em`/`descent_em`), so every caption's box has the same height. In word-by-word mode the box is there from the first word on (it is sized for the whole line, so its width hints at the words still to come). Shared function `fcgBoxRects`. |
| `_look` (metadata) | `options [{id, label, hint, on, off, controls}]` | the generic form of the switches above (a patch pair like `toggle`, plus optional editable `controls`). The page only lets a look's controls touch `box.*` / `reveal.*`; update look packs may contain `reveal` and `box`. |

## Guarantees (tested)
| Claim | Evidence |
|---|---|
| Layout/font/colour/effect/animation changes never move a reveal | two real builds (reference vs Poppins preset) and two layouts (anchor 0.46 vs 0.60): in/out points of all 345 words identical (`tests/ae/test_stage5_fixtures.py`) |
| Preview maths ≡ After Effects keyframes | 1,725 values sampled from real AE layers vs `core/anim/anim.js`: max difference 0.014 px / 2e-7 % (`tests/ae/verify_anim.js`) |
| Layout stays inside safe margins and frame | 900 random groups × 3 templates (`tests/anim/test_layout.js`) |
| All layers are real, editable text with `startTime 0` | dump checks |

## Technique notes (what was tried in AE 25.2)
* Gradient: **Gradient Ramp effect on the text layer** respects letter shapes (verified by rendering); start/end colours stay editable in Effect Controls. Layer styles (Gradient Overlay) cannot be added by script; alpha-matte needs two layers per word (rejected).
* Glow, Drop Shadow, Gaussian Blur exist and are scriptable (ranges: shadow opacity 0–255, glow threshold/intensity 0–255).
* Duplicating a styled template layer is ~7× faster than styling each layer: 345 words with effects + keyframes build in ≈19–40 s.

## Not done yet / honest gaps vs the reference
* The reference look has no per-letter reveal/wipe on accent words, no sparkle glints, no "tinted-red first frames" — its entrance is approximated by slide + scale + blur + fade. (Look 2, "Soft Editorial", does have a per-letter reveal with a tint.)
* Font is Arial (closest installed to the reference's Helvetica-style grotesque); Poppins/Montserrat/Roboto are installed and selectable.
* Colours were **measured** from reference frames (median of saturated orange pixels): look A accent ≈ `#F2750C` (almost flat, slight lightening), look B accent ≈ `#F8AE2D → #F49C28` / `#F28A13 → #EF6F13`. The glow strength/radius and shadow softness are still matched by eye.
* No automatic face avoidance (set `anchor_y`); no restyle-only "update" (a rebuild replaces generated layers); no exit animation other than a hard cut.
* Performance of glow-heavy projects with ≈1,500 words not measured.
