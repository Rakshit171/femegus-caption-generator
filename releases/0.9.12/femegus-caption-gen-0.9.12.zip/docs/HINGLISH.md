# English / Hinglish / Auto — design and test evidence

Status (2026-10-13): **hybrid route works well on the owner's real Hinglish clip (110 s, 353 words, 13 Hindi spans): 3.4 % WER vs 15–18 % for the
other strategies** against a provisional, owner-corrected reference. One speaker / one clip only, reference not fully audio-verified: promising, not proven.

## Stage 7 addendum (2026-10-14) — decoding robustness, more clips
Two further real clips (a 41 s Hinglish mp4, an 85 s nearly pure Hindi mp3) exposed failures that the reference clip never showed:
long-form (sequential) decoding **silently dropped ~70 % of the mp4**, made "market market market…" loops with the Hinglish model, and **lost the last ~11 s of the mp3**.
Forced English on the mp4 produced a fluent **translation** of the Hindi. The engine now (a) decodes sequentially (most accurate: 3.4 % WER on the reference clip),
(b) measures whether loud audio is left without words, and (c) only then runs the batched (independent chunk) decoder and fills the holes. Details and numbers: [TESTING.md](TESTING.md).
Accuracy of the two new clips is **not measured** (no reference text) — only completeness. Batched decoding is less reliable on digits (10.5 % vs 3.4 % WER on the reference clip), which is why it is the rescue pass, not the default.
Auto routing is still a heuristic validated on three clips; a pure-English clip with a strong Indian accent is untested.

## Text polish, numbers and the 2026-10-24 recognition fixes
Spelling convention (voh, toh, nahin, tumhaare, theek …), number/amount format, punctuation rules, the root causes of lost amounts ("agar ya rupees"), "cells" for "sells" and the missing
first words, the regression suite and its measurements: **[HINGLISH_STYLE.md](HINGLISH_STYLE.md)** (not yet released — see CHANGELOG "Unreleased").

## Modes
| Mode | What runs | Notes |
|---|---|---|
| English | stock large-v3-turbo, language forced `en` | ⚠️ forcing English makes Whisper **translate** any spoken Hindi into English. Only for English speech. |
| **Hinglish** | **hybrid** (below) | default strategy; `apex` and `stock_prompt` strategies kept as alternatives |
| Auto | skeleton pass (turbo, Hindi mode, no prompt); ≥3 words and ≥3 % Devanagari ⇒ Hinglish hybrid, else forced-English pass | per-file decision; thresholds configurable. Whisper's own language ID said "en" for the Hinglish clip, so it is NOT used. |

### The hybrid (`engine/fcg_engine/hybrid.py`)
1. **Skeleton**: stock turbo with `language=hi`, no prompt. English words come out in Latin script, Hindi words in Devanagari ⇒ **script = free word-level language ID**.
2. **Hinglish model**: Oriserve Whisper-Hindi2Hinglish-Apex (Apache-2.0, large-v3-turbo fine-tune, converted to CTranslate2) over the same audio.
3. **Merge**: each Devanagari run in the skeleton is replaced by the Hinglish model's Roman words whose time falls inside that run (±0.15 s).
   English words and their timings always come from the skeleton. Duplicates of an English word heard by both models are dropped.
   If the Hinglish model gave nothing for a span, the Devanagari words stay and are flagged `non_roman` — nothing is invented or silently removed.
4. Every output word keeps its own timestamp from the model that produced it ⇒ word-level timing across language switches.

## Measured accuracy (owner's corrected PROVISIONAL reference, 353 words, `tests/fixtures/hinglish_clip_reference.txt`)
The owner flagged that financial figures and some Hinglish phrases are still unverified against the audio, so treat the numbers as indicative.
Command: `.\scripts\fcg.ps1 evaluate <transcript.json> tests\fixtures\hinglish_clip_reference.txt --variants tests\fixtures\spelling_variants.json`

| Strategy | WER strict | WER (spelling variants equal) | sub / del / ins |
|---|---|---|---|
| English (forced `en`) | 17.6 % | 17.6 % | 50 / 7 / 5 |
| Hinglish — **hybrid** (default) | **5.1 %** | **3.4 %** | 8 / 3 / 1 |
| Hinglish — Apex only | 16.7 % | 15.0 % | 33 / 11 / 9 |
| Hinglish — stock + Roman prompt | 17.0 % | 16.7 % | 43 / 2 / 14 |
| Auto | 5.1 % | 3.4 % | (routes to hybrid) |

Hybrid's 12 remaining differences: number/currency **formatting** (`crore`→"CRR", `rupees`→"rs", `thousand`→",000" ×2), `funnel`→"funnels", `baith kar`→"baithakar",
"why **you should** choose me" vs reference "why **should you** choose me" (reference may be the doubtful one), and "thousand rupees" absent after "35 to 50" (owner flagged
figures as unverified — may be the reference rather than the recogniser). So the true recognition error is likely lower than 3.4 %; the formatting items are a
**display-text normaliser** job (Stage 3): join split tokens ("15 ,000"→"15,000", "one -on -one"→"one-on-one"), plus a user-editable glossary (crr→crore, rs→rupees).

## Evidence
### Real Hinglish clip (owner's, 1:50; Hindi phrases from 0:36 and heavily from 1:05)
| Strategy | Result |
|---|---|
| Forced English / Auto→English | English is excellent, but Hindi is **translated or dropped**: "Zyaadaatar coaches sell you theory" → "Most coaches sell you theory"; "To aap agar ek certified coach ho…" → "So if you are a certified coach…". Auto's language ID chose `en`. |
| Stock `hi` + Roman prompt | inconsistent: Roman on one half, **Devanagari** on the other; one Hindi sentence translated. |
| Apex alone | Hindi in nice casual Roman ("Tab mainne socha ki", "aapka funnel sudhaar ke de") but English errors/drops ("Nothing to flex…" missing, "business is stuck" → "fusion is stuck", "irregistable"), stray Devanagari junk, missing words. |
| **Hybrid** | English as good as stock; all 13 Hindi spans in Roman with Apex's wording; 0 Devanagari left; 11 low-confidence words flagged. Residual issues: a few spellings need editing (e.g. "1 CRR", "rs"), **punctuation is missing across Hindi spans** (e.g. "…comments down below India mein hazaaron…" is one run-on line) → the segmenter must not rely on punctuation alone (use pauses + capital-after-unpunctuated-word cue). |
Timings: the two models' word times agree within ≈0.1–0.15 s; hybrid word durations are sane (no ≤30 ms words). Output is **deterministic** (fixed seed; 3 runs identical).

### Earlier smoke tests (Hindi sample clips from the Apex repo, noisy call-centre audio)
Stock `hi` without prompt → Devanagari; stock + prompt → **prompt text repeated as speech** on noisy clips; Apex → Roman but junk/empty on very short noisy clips;
Apex on English speech → garbled intro (conf ≈ 0). These motivated the flags and the hybrid.

## Safeguards (`quality.py`)
Words are never deleted/rewritten by the engine — only flagged: `non_roman`, `repeat_run`, `low_confidence`, `prompt_leak` (and, in the core, `collapsed` = a run of words squeezed into a few hundredths of a second, see SEGMENTER.md). The segmenter/editor (Stage 3/6)
applies a user-configurable policy. Degenerate timestamps are repaired only by moving words **later**. English-mode output with Devanagari/CJK is flagged.

## Two more ways Hindi was lost (field report 2026-11-08: "after transcribing no Hinglish words are coming")
Both were found on the owner's own clips, reproduced, fixed and tested. Details and numbers: [TESTING.md](TESTING.md) "Hinglish: translated Hindi and decoder loops".

1. **The stock model TRANSLATED Hindi into English.** In Hindi mode it normally writes Hindi in Devanagari, and the hybrid finds Hindi stretches by that script. On
   "Learn this one skill" it wrote the spoken "Tumhen koi bhi is kal ko master karna hai, tumhen sirph is cycle ko chalaana hai" as fluent English ("you have to master
   any of this skill you have to start this cycle", with squeezed timestamps). No Devanagari, so no Hindi stretch, so the Hinglish model's correct words were thrown
   away and the clip came out all English. **Fix:** `hybrid.translated_spans` uses the Hinglish model's OWN words as evidence (several words of
   `hindi_words.HINDI_WORDS` close together that the stock model did not write in Latin at the same moment; the stretch grows until the two recognisers agree again,
   is dropped if they mostly agree, and ignored where the stock model wrote Devanagari). `merge(..., translated=spans)` replaces those stock words by the Hinglish
   model's words (including words after the stock model's mistimed ones). **Auto mode** had the same blind spot (no Devanagari → "English" → the forced-English pass
   translates Hindi too); it now also asks the Hinglish model when the stock model wrote no Devanagari (`Engine.auto_check_translated`, one extra decoding pass).
   Confirmed independently: stock large-v3 in Hindi mode writes "तो आप अगर एक certified coach हो बट आपका business stuck है तो" for the 105 s stretch of the reference clip where
   the older output (and the owner's provisional reference text) had the English translation "so if you are a coach but your business is stuck then".
2. **The Hinglish model looped.** "ki vah, vah, vah, vah, …" for 15+ seconds, or one "word" such as "dekhekhekhekhekhe…" that swallowed the next sentence. Looped words
   are junk and are never imported, so every Hindi stretch inside stayed in Devanagari, was flagged `non_roman` and was left out of the captions. It happens run to
   run and depends on what was transcribed before in the same session (the app keeps the models loaded): on one test sequence PC 5 lost 44 words, the podcast clip 37.
   **Fix:** `quality.is_stutter` flags such single-word loops (`repeat_run`); `Engine._repair_hinglish_loops` decodes each looped stretch again in windows of at most
   8 s with a repetition penalty (`coverage.LOOP_*`), accepting the first answer that does not loop and is about as long as what the stock model heard there
   (a decode that stops after one sentence is rejected). If every attempt fails the junk stays out and the Devanagari stays flagged, exactly as before.

### 2026-11-08, second report: "bahut zyada overcrowded hai" captioned as "is a lot of overcrowded"
After the first two fixes the owner sent a screenshot of the same clip: the Hindi "bahut zyada overcrowded hai" was still captioned in English. The Hindi proof is
the Hinglish model's own Hindi words, and here its LONG-FORM pass had failed too: sometimes it garbled the stretch ("starts USB Or artists but you know"), sometimes
it wrote the same English translation as the stock model (the two then agree, so nothing betrays the Hindi). Decoded alone in an 8 s window the same audio gives
"Coaching business bahut zyaada over crowded hai" every time. Fixes (all in `engine.py`, constants in `coverage.py`):
* **Second opinion** (`Engine._second_opinion`): every 8 s window where the two recognisers agree on fewer than half of the stock model's English words (garbled
  or looped long pass) is decoded again by the Hinglish model alone. A single short decode is fickle too (the same window came out right twice and as "Coachinging
  business bahuthings. I am content." once), so `_redecode` makes up to four attempts (plain, more context, repetition penalty) and takes the first that reproduces
  at least 60 % of the stock model's words, otherwise the best-agreeing one; looped or far-too-short answers are never used.
* **Window evidence** (`Engine._windowed_pass`, `_add_window_evidence`): the whole file is also decoded by the Hinglish model in short windows cut at pauses, and
  where THOSE show a Hindi stretch the stock model translated (and the long pass does not), the long-pass words of the stretch are replaced by the windowed ones.
  Everything else stays the long pass's text, because as the MAIN pass the windows were measured to be less accurate (whoami reference: 6.2 % → 11.1 % word error:
  words cut at window borders and invented ones), so that variant was rejected. Cost: one more Hinglish-model pass (`coverage.APEX_WINDOWED = False` switches it
  off). Auto mode now uses this windowed pass as its evidence of hidden Hindi.
* Measured: the Learn clip decoded 5 times in the real engine: "bahut zyaada over crowded hai" 5 of 5 (was: English caption in 1 of 5 after the first fix and in the
  owner's app run); the Hindi sentence after it ("Tumhen koi bhi is skill ko master karna hai, tumhen sirph is cycle ko chalaana hai") is found every time but its words
  vary from run to run ("school", "iskil"…): that is the Hinglish model's own accuracy, not detection.

### 2026-11-09, field report on 0.9.10: "stuck at a certain percentage" on another PC (Hinglish, 35 s clip, bar at 35 % after 464 s)
Not a hang: the two base passes (stock skeleton + Hinglish long-form) are only a small part of the work. Timed on the dev PC (RTX 3060, 40 s clip, `stage_times.py`
in the session scratchpad): skeleton 15 s + Hinglish 9 s = 24 s, then the extra accuracy passes of 0.9.9/0.9.10 = 145 s (second opinion 54 s, windowed evidence 68 s,
tight re-decode 17 s; ~1 decode of 5–17 s per attempt, 4 attempts per bad window), and the progress bar stood still at 52 % of the Hinglish stage the whole time.
A slower GPU or a CPU-only PC multiplies this (and the fixed bar looks frozen). Fix, models and their settings untouched (`coverage.Budget`, `Engine._expired`):
* the extras get a wall-clock limit = 8 × the time the base passes took, at most max(60 s, 5 × clip length), at least 20 s; each pass has its own share (loops 25 %,
  second opinion 50 %, windowed 75 %, tight 90 %, rescue 100 % of the limit, auto's decision pass 100 % of its own), checked before every decode attempt;
* what does not fit is skipped: the words stay as the base passes wrote them, `hybrid_stats.extras_skipped` lists the passes and a plain warning says so;
* the bar now moves from 65 % to 99 % of the Hinglish stage in step with the limit being used up (time-based, never backwards).
Measured: dev PC, full budget (192 s): nothing skipped, same text as before; simulated slow PC (limit 1 × base): 55 s instead of 170–220 s, complete transcript,
warning shown. NOT verified: the other PC itself (cause assumed from the symptoms; ask for the black-window text, `work\app.log` and the System check if it persists).

### 2026-11-09, second report on the other PC: "GPU and CPU both not used, English works, Hinglish does not"
Idle GPU and CPU mean the program was WAITING, not computing (so the extra-pass time limit above was not the (whole) cause). The one thing the Hinglish route does
that English never does is load a model from a LOCAL folder: when `tokenizer.json` is not in that folder, faster-whisper silently asks huggingface.co for a tokenizer.
Reproduced here: copy of the Hinglish folder without `tokenizer.json`, cold Hugging Face cache, dead network (proxy to an unroutable address) → the load had not
finished after 150 s (5 retries with back-off), CPU/GPU idle. With a working network it just downloads the file (so it never shows here). The cause on that PC is NOT
confirmed (a lost tokenizer file, a slow disk / OneDrive placeholder / antivirus scan of the 1.6 GB `model.bin`, or low RAM would all look the same), so the fix covers
the reproduced case AND makes any other wait visible. Models, decoding settings and results are untouched:
* `model_check.py`: before faster-whisper sees a local model folder it is checked (config, model.bin ≥ 300 MB, tokenizer.json, preprocessor_config.json, vocabulary);
  missing small files are put back from `engine/hinglish_assets/` (byte-identical to the converter's copies, SHA-256 verified, Apache-2.0, see LICENSES.md); a folder
  that still has problems is refused with a plain message and `Engine.hinglish_model_available()` is False (the fallback route + a warning that says why) — no
  network wait. Replay of the hang with the fix: loaded in 6 s.
* `Transcriber._load`: a stock model already in the Hugging Face cache is loaded with `local_files_only=True` first (no "is there a newer revision?" request, so
  a blocked / slow connection costs nothing); a model that is not cached still downloads exactly as before.
* `status.py`: the engine says each step ("Loading the speech model … from disk", "Pass 1", "Pass 2", "Extra check 1–3") and the job text shows it instead of a bare
  "transcribing…" (`ops._TranscribeWatch`). After 90 s without progress or a new step the text names the step and says so; after 120 s the stack of every thread is
  written to `work\stall_trace.txt`, which 'Copy support info' includes (with the Hinglish model's file list/state). If it stalls again, that file names the call.
* System check: a model folder with a lost small file is now "Hinglish model incomplete" with a no-download Fix button (restores the files and reconnects).
NOT verified: the other PC itself.

## Open items
* Owner to audio-verify the reference (figures, Hinglish phrases) → re-score; add more clips (other speakers, pure Hindi, noisy audio).
* Pure/mostly-Hindi audio and different speakers/accents: untested.
* Casual-spelling dictionary (user-editable, non-destructive) if corrections show repeated patterns.
* Hindi spans where skeleton wrongly outputs Latin (Hindi words written phonetically in English letters) stay as the skeleton heard them, unless the Hinglish model's own Hindi words give them away (`translated_spans`, 2026-11-08; needs at least two Hindi words from `hindi_words.py` close together, so a single Hindi word inside English speech is still not detected).
* Roman Hinglish wrapping/readability is layout work (Stage 5); text path is shared with English.
