# After Effects adapter (`adapters/jsx-core`) — Stage 4

ExtendScript (ES3) that turns `groups.json` into **editable text layers**. No installation, no changes to the After Effects folder or registry:
run it with **File ▸ Script ▸ Run Script File…**. Host-version knowledge lives only in `lib/fcg_profile.jsxinc`.

## Use (end user)
1. Build `groups.json` (see [SEGMENTER.md](SEGMENTER.md)).
2. In After Effects (needs Preferences ▸ Scripting & Expressions ▸ **Allow Scripts to Write Files and Access Network** only for report/dev files; plain generation needs file *read* only — untested without the setting):
   File ▸ Script ▸ Run Script File… ▸ `adapters\jsx-core\fcg_run.jsx` → pick `groups.json`.
3. Result: composition **FCG Captions**, one text layer per word, in the layer stack top = first caption.

Options (defaults in `FCG_DEFAULT_OPTIONS`, merged from `fcg_job.json` → `options`): comp name/size/fps, background footage, layout (`flow`: anchor, max width,
line gap, space width), per-role style (`support`/`accent`: font PostScript name, size, colour, tracking, stroke), `recreate_comp`, `replace_existing`.
A word's `style_override` (from overrides.json) is merged over its role style.

## What each layer is
* Name `g0012_w000345_edits`, comment `FCG:{"g":..,"w":..,"role":..,"reveal":..,"spoken":..}` (used to find/replace generated layers and to verify).
* **In-point = reveal time snapped UP to the next frame** (a word can never appear before it is spoken); **out-point = group exit snapped DOWN** (no overlap with the next group).
* `startTime = 0` for every layer (so future keyframes in comp time stay valid). Colour label by role.
* Generated layers are found by their comment prefix; re-running replaces them (`replace_existing`), nothing else in the comp is touched.

## Verified in After Effects 25.2 (2026-10-13, this machine)
| Check | Result |
|---|---|
| Script runs; host profile reports `25.2x131` | ✅ |
| Hinglish clip, 345 words → 345 layers + source video, comp 1080×1920 @ 30 fps (taken from the footage) | ✅ built in **32 s** |
| Layer in-point ≥ reveal and < reveal + 1 frame for all 345 layers; out ≤ group exit; no group overlap; text == display; `startTime == 0` | ✅ 0 problems (`tests/ae/verify_dump.py`) |
| Visual check: frames rendered with `aerender` at 4 times — correct word groups, Hindi in Roman, accent words larger/orange | ✅ (images in `work/ae_test/frames`, not kept in git) |
| Missing font → falls back to ArialMT + warning | ✅ |
| Invalid / missing groups file → clean error report, no hang | ✅ |
| Re-run replaces generated layers (35 → 35), no duplicates | ✅ |
| Missing-font check through `app.fonts` (24.0+) | ✅ used on 25.2; **older versions: untested** |
| Running without "write files" preference | ⚠️ untested (the report file needs it; layer generation itself should not) |

## API facts learned (important, easy to get wrong)
* Setting `layer.inPoint` **after** `outPoint` shifts the out-point by the same amount (observed: out became `in + exit`). Always set **in first, then out**. (Found by the offline verifier, not by inspection.)
* Styling a layer from scratch (assign `font` etc.) costs ≈0.7 s per layer; the builder styles one **template** per role and `duplicate()`s it (changing only `text`): 331 s → 32 s for 345 words.
* `CompItem` has **no still-frame export**; use `aerender` (shipped with AE, run read-only) for visual checks. Output module template `TIFF Sequence with Alpha` works.
* `AfterFX.exe -r script.jsx` / `-s "code"` did **not** execute anything in the already-running 2025 instance here (documented as supported; reason unknown — possibly the blocked startup dialog below). Not relied on.
* After Effects showed a modal **"disk cache folder … not enough available space"** warning at startup; while it is open nothing can run. It is a setting on this PC (Preferences ▸ Media & Disk Cache), unrelated to the tool.
* `app.fonts` / `Font` objects exist from 24.0, `TextDocument.leading` from 14.2 (Adobe scripting guide); the adapter checks `fcgHostProfile()` flags instead of assuming.
* The preference key behind "Allow Scripts to Write Files…" is undocumented; the code tests by actually writing a file.

## Developer harness (not for end users)
`adapters/jsx-core/fcg_connect.jsx` (this was `fcg_dev_watch.jsx` until Stage 8; the old file no longer exists) — run once per AE session; it polls `work/ae_inbox/job_connect.json` every second
(`app.scheduleTask`), writes `heartbeat_connect.txt`, and runs jobs through `lib/fcg_connect_run.jsxinc`. It is a fixed stub that re-evaluates the `lib/*.jsxinc` files per job,
so edits apply immediately. `scripts/ae_run.ps1` sends a job and waits for `work/ae_test/report.json`. Lesson: AE keeps scripts' functions alive in a **persistent engine**
(`#targetengine`), so re-running a changed watcher did not replace the old polling code — hence the stub design (and, historically, renaming the channel B → C → `job_connect.json`).
The same connect script is what the caption app uses (section 9 "Generate in AE"), so it is no longer only a developer tool.

## Stage 5 additions (2026-10-14) — see STYLE.md for the options
* New modules: `lib/fcg_layout.jsxinc` (pure geometry: tiers / stack / flow, unit-tested in Node), `core/anim/anim.js` (shared easing + entrance maths, ES3), per-role effects (Gradient Ramp, Glow, Drop Shadow, Gaussian Blur) on the template layer, keyframes relative to each word's in-point.
* Layer anchor = centre of the word's box, position = centre, scale = fit factor ⇒ scale/slide animate about the word's centre; word layers carry `a:{t0,d,spec,base}` in their comment.
* **A regression the offline verifier caught:** in the first Stage 5 build every word of a group got the group's *first* in-point (words appeared before being spoken). Fixed (each word keeps its own in-point); the same verifier now guards it on real dumps.
* **Preview ≡ After Effects:** keyframes use influence/speed derived from the cubic-bezier (`FCGAnim.easeToKeyframe`); sampled AE values equal the evaluator within 0.014 px (1,725 samples, two presets). Position overshoot is not reproducible in AE, so position uses the curve with y-handles clamped to [0,1] in both places.
* Effect parameter facts (AE 25.2): Gradient Ramp params = Start of Ramp, Start Color, End of Ramp, End Color (matchNames `ADBE Ramp-0001..0004`); Drop Shadow opacity 0–255, Glow threshold/intensity 0–255, Glow "based on" 1 = colour / 2 = alpha; effect references go stale after adding another effect — always re-fetch by name.
* Timing of a full build: 345 words with all effects and keyframes = 19–40 s.
* Dev action `eval` + `probes/` hold throw-away experiments (not shipped).

## Stage 7 additions (2026-10-14)
* **Audio-only footage** (`hasVideo === false`): comp size stays at the configured/default 1080×1920 @ 30; the sound is added as "Source audio". Verified with an 85 s mp3 (283 layers).
* **All-caps is typed, not formatted** (see APP.md); layer meta carries `caps:true` so the verifier compares `display.upper()`.
* **Stress results:** 1,520 layers / 9-minute comp built in 226 s with all effects and keyframes, After Effects stayed responsive (≈4 GB). Words wider than the safe area are shrunk to fit (down to 25 % for a 45-letter word) and reported.

## Limitations / next
(Written at Stage 4–5; the UI exists since Stage 6 — see APP.md.) Remaining: restyle-only "update" (today a rebuild replaces the generated layers, keeping nothing the user hand-edited inside them); no exit animation other than a hard cut; AE 2024/2026 untested. See STYLE.md for the visual gaps against the reference.
