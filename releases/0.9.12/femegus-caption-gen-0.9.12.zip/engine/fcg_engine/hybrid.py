"""Hinglish hybrid route: stock Whisper as the skeleton, the Hinglish fine-tune only inside Hindi spans.

Why: on real creator Hinglish the stock model is far better on English words but writes Hindi in Devanagari; the Hinglish fine-tune writes
Hindi in Roman script well but garbles/drops English. Stock Whisper in ``language=hi`` mode (no prompt) writes Hindi words in Devanagari and
English words in Latin, so the *script* is a free word-level language ID. Every Devanagari run found in the skeleton is replaced by the
Roman words the Hinglish model produced for the SAME time window. Latin words (English) keep the skeleton's text and timing.

Nothing is invented: every output word comes from one of the two recognisers. If the Hinglish model produced nothing for a Hindi span,
the original Devanagari words are kept and flagged ``non_roman`` (the editor shows them; nothing disappears silently).
"""
from __future__ import annotations

import bisect
import re
import unicodedata
from difflib import SequenceMatcher
from typing import Callable, Optional

from .quality import NUMBER_WORDS, _norm

WINDOW_PAD = 0.15     # seconds of tolerance when matching the two recognisers' word times
SAME_WORD_GAP = 0.30  # an identical word from both recognisers closer than this is one word, not two


def is_devanagari(text: str) -> bool:
    return any("DEVANAGARI" in unicodedata.name(c, "") for c in text)


def has_letters(text: str) -> bool:
    return any(c.isalpha() for c in text)


def has_content(text: str) -> bool:
    """A word that carries speech: letters OR digits. Only pure punctuation is "no content" — a number such as 40,000 must never be treated like a comma."""
    return any(c.isalnum() for c in text)


_PLAUSIBLE_NUMBER = re.compile(r"\d[\d,]*(\.\d+)?")


def plausible_number(text: str) -> bool:
    """Digit tokens a recogniser really produces for spoken amounts ("40000", "5", ",000"). Debris such as ".7" or "!1." is not a number."""
    t = text.strip().rstrip(".,?!")
    return _PLAUSIBLE_NUMBER.fullmatch(t) is not None or (t.startswith(",") and t[1:].isdigit())


def _runs(words: list[dict]) -> list[tuple[int, int]]:
    """Index ranges [i, j] of consecutive words containing Devanagari (punctuation-only tokens are skipped over)."""
    runs, i, n = [], 0, len(words)
    while i < n:
        if is_devanagari(words[i]["text"]):
            j = i
            k = i + 1
            # punctuation and NUMBERS between Hindi words belong to the Hindi stretch ("agar 40 ,000 ya 50 ,000 rupees"): the numbers are part of that spoken
            # sentence and are read by the Hinglish model with the rest of it
            while k < n and (is_devanagari(words[k]["text"]) or not has_content(words[k]["text"]) or plausible_number(words[k]["text"])):
                if is_devanagari(words[k]["text"]):
                    j = k
                k += 1
            runs.append((i, j))
            i = j + 1
        else:
            i += 1
    return runs


def _overlap(a0, a1, b0, b1) -> float:
    return max(0.0, min(a1, b1) - max(a0, b0))


# ---- Hindi the stock model TRANSLATED (no Devanagari to find it by) ---------------------------------------------------------------------------------
TRANSLATED_MIN_HITS = 2        # Hindi words of the Hinglish model, not matched by the stock model, that make a Hindi stretch
TRANSLATED_HIT_GAP_S = 2.0     # hits closer than this belong to one stretch
TRANSLATED_MAX_EXTEND_S = 2.0  # how far a stretch may grow beyond its first/last Hindi-word hit (to take its English loanwords and unmarked words)
TRANSLATED_PAUSE_S = 1.0       # a pause this long ends the extension (another sentence)
TRANSLATED_MAX_AGREE = 0.6     # a stretch where the stock model agrees with the Hinglish model on more than this share of words is not "translated"
TRANSLATED_MIN_SHARE = 0.6     # the Hinglish model's words in a stretch must be at least this share of the stock model's (no stretch may lose words)
ANCHOR_TOL_S = 0.45           # two recognisers' identical word this close in time = they agree on it


def _same_word(a: str, b: str) -> bool:
    if not a or not b:
        return False
    if a == b:
        return True
    return min(len(a), len(b)) >= 5 and SequenceMatcher(None, a, b).ratio() >= 0.8       # "underrated" vs "underrateded"


def agreement(skeleton_words: list[dict], hinglish_words: list[dict], t0: float, t1: float) -> tuple[int, int, int]:
    """How well do the two recognisers agree on [t0, t1)? Returns (words of the Hinglish model, Latin words of the stock model, Hinglish words the stock model also
    wrote at the same moment). English speech: high. A stretch the stock model translated, or one the Hinglish model garbled or looped on: low."""
    mid = lambda w: (w["start"] + w["end"]) / 2
    sk = [s for s in skeleton_words if has_letters(s["text"]) and not is_devanagari(s["text"]) and t0 - ANCHOR_TOL_S <= mid(s) < t1 + ANCHOR_TOL_S]
    hw = [h for h in hinglish_words if has_letters(h["text"]) and not is_devanagari(h["text"]) and t0 <= mid(h) < t1]
    sk_norm = [(mid(s), _norm(s["text"])) for s in sk]
    agree = sum(1 for h in hw if any(abs(mid(h) - m) <= ANCHOR_TOL_S and _same_word(_norm(h["text"]), n) for m, n in sk_norm))
    return len(hw), sum(1 for s in sk if t0 <= mid(s) < t1), agree


def translated_spans(skeleton_words: list[dict], hinglish_words: list[dict]) -> list[tuple[float, float]]:
    """Time spans where the Hinglish model heard Hindi but the stock model wrote none of it in Devanagari — it TRANSLATED the sentence into English.

    Seen on a real clip: "Tumhen koi bhi is kal ko master karna hai, tumhen sirph is cycle ko chalaana hai" came back from the stock model as
    "you have to master any of this skill you have to start this cycle". With no Devanagari in the skeleton the merge found no Hindi run, the Hinglish
    model's correct words were dropped, and the captions had no Hinglish at all.

    Evidence of Hindi = several words of hindi_words.HINDI_WORDS in the Hinglish model's own output that the stock model did NOT write in Latin at the same
    moment, close together. The stretch grows outwards over its neighbours until the two recognisers agree again (two matching words in a row), at most
    TRANSLATED_MAX_EXTEND_S, and is dropped if the recognisers mostly agree after all. Pure function; nothing is invented (the words come from the Hinglish model)."""
    from .hindi_words import HINDI_WORDS, WEAK_HINDI_WORDS
    hw = sorted((h for h in hinglish_words if has_letters(h["text"]) and not is_devanagari(h["text"])), key=lambda w: (w["start"], w["end"]))
    if not hw:
        return []
    sk = sorted((w for w in skeleton_words if has_letters(w["text"]) and not is_devanagari(w["text"])), key=lambda w: w["start"])
    sk_starts = [w["start"] for w in sk]
    dev = [(w["start"], w["end"]) for w in skeleton_words if is_devanagari(w["text"])]
    norm = [_norm(h["text"]) for h in hw]

    def anchored(k: int) -> bool:
        h = hw[k]
        mid = (h["start"] + h["end"]) / 2
        lo = bisect.bisect_left(sk_starts, mid - ANCHOR_TOL_S - 1.0)
        for s in sk[lo:]:
            if s["start"] > mid + ANCHOR_TOL_S + 1.0:
                break
            if abs((s["start"] + s["end"]) / 2 - mid) <= ANCHOR_TOL_S and _same_word(norm[k], _norm(s["text"])):
                return True
        return False

    anch = [anchored(k) for k in range(len(hw))]
    hits = [k for k in range(len(hw)) if norm[k] in HINDI_WORDS and not anch[k]
            and not any(a - 0.1 <= (hw[k]["start"] + hw[k]["end"]) / 2 <= b + 0.1 for a, b in dev)]       # a Devanagari run is handled by the normal merge
    groups: list[list[int]] = []
    for k in hits:
        if groups and hw[k]["start"] - hw[groups[-1][-1]]["end"] <= TRANSLATED_HIT_GAP_S:
            groups[-1].append(k)
        else:
            groups.append([k])
    spans: list[tuple[float, float]] = []
    for g in groups:
        if len(g) < TRANSLATED_MIN_HITS or all(norm[k] in WEAK_HINDI_WORDS for k in g):
            continue                                           # too few hits, or only weak ones ("jo", "ko", "ki"): garbled English can contain those
        a, b = g[0], g[-1]
        t_first, t_last = hw[a]["start"], hw[b]["end"]
        while a > 0:                                           # grow to the left until the recognisers agree again (two matching words in a row), a pause, or the limit
            p = a - 1
            if t_first - hw[p]["start"] > TRANSLATED_MAX_EXTEND_S or hw[a]["start"] - hw[p]["end"] > TRANSLATED_PAUSE_S or (anch[p] and p > 0 and anch[p - 1]):
                break
            a = p
        while b + 1 < len(hw):
            n = b + 1
            if hw[n]["end"] - t_last > TRANSLATED_MAX_EXTEND_S or hw[n]["start"] - hw[b]["end"] > TRANSLATED_PAUSE_S or (anch[n] and n + 1 < len(hw) and anch[n + 1]):
                break
            b = n
        while a < b and anch[a]:                               # an agreed word at an edge belongs to the English around it
            a += 1
        while b > a and anch[b]:
            b -= 1
        if sum(anch[a:b + 1]) / (b - a + 1) > TRANSLATED_MAX_AGREE:
            continue
        span = (hw[a]["start"], hw[b]["end"])
        inside = [w for w in skeleton_words if span[0] - 0.05 <= (w["start"] + w["end"]) / 2 <= span[1] + 0.05]
        if inside and sum(is_devanagari(w["text"]) for w in inside) / len(inside) >= 0.5:
            continue                                           # the stock model wrote this stretch in Devanagari: the normal merge handles it, nothing was translated
        n_stock = sum(1 for w in inside if has_letters(w["text"]) and not is_devanagari(w["text"]))
        if n_stock >= 3 and (b - a + 1) < TRANSLATED_MIN_SHARE * n_stock:
            continue                                           # the Hinglish model wrote far fewer words than the stock model heard: replacing would LOSE words (a garbled stretch)
        if spans and span[0] <= spans[-1][1] + 0.05:
            spans[-1] = (spans[-1][0], max(spans[-1][1], span[1]))
        else:
            spans.append(span)
    return spans


def _add_spans(sk: list[dict], runs: list[tuple[int, int]], spans: list[tuple[float, float]]) -> tuple[list[tuple[int, int]], dict[tuple[int, int], tuple[float, float]]]:
    """Turn time spans into skeleton word ranges and add them to the Devanagari runs (overlapping ranges are united).
    Returns (runs, {synthetic range: the time span it stands for}) — the span, not only the stock model's (often mistimed) words, is the window the
    Hinglish model's words are taken from."""
    synthetic: dict[tuple[int, int], tuple[float, float]] = {}
    for t0, t1 in spans:
        idx = [k for k, w in enumerate(sk) if t0 - 0.05 <= (w["start"] + w["end"]) / 2 <= t1 + 0.05]
        if not idx:
            continue
        i, j = min(idx), max(idx)
        keep = []
        for r in runs:
            if r[0] <= j and i <= r[1]:                        # overlaps a run already there: unite
                i, j = min(i, r[0]), max(j, r[1])
                a, b = synthetic.pop(r, (t0, t1))
                t0, t1 = min(t0, a), max(t1, b)
            else:
                keep.append(r)
        runs = keep + [(i, j)]
        synthetic[(i, j)] = (t0, t1)
    return sorted(runs), synthetic


def merge(skeleton: dict, hinglish: dict, pad: float = WINDOW_PAD, translated: Optional[list[tuple[float, float]]] = None) -> dict:
    """Return a transcript dict (same schema) combining ``skeleton`` (stock, language=hi) and ``hinglish`` (fine-tune).
    ``translated`` = spans from translated_spans(): Hindi the stock model wrote as English; they are replaced like Devanagari runs."""
    sk = [dict(w) for w in skeleton["words"]]
    hw = [dict(w) for w in hinglish["words"]]
    used: set[str] = set()
    out: list[dict] = []
    stats = {"hindi_runs": 0, "runs_replaced": 0, "runs_kept_devanagari": 0, "words_from_hinglish_model": 0}
    runs = _runs(sk)
    synthetic: dict[tuple[int, int], tuple[float, float]] = {}
    if translated:
        runs, synthetic = _add_spans(sk, runs, translated)
        stats["translated_runs"] = len(synthetic)
    run_of = {}
    for r, (i, j) in enumerate(runs):
        for k in range(i, j + 1):
            run_of[k] = r
    # English words the skeleton owns. Tokens INSIDE a Hindi run are not owners: the run is being replaced, and a skeleton "5" there used to make the Hinglish
    # model's "paanch" look like a duplicate and be dropped (both then vanished: the spoken amount was lost)
    latin = [w for k, w in enumerate(sk) if not is_devanagari(w["text"]) and k not in run_of]
    emitted_run: set[int] = set()

    for idx, w in enumerate(sk):
        if idx not in run_of:
            if is_devanagari(w["text"]):
                continue
            w["origin"] = "skeleton"
            out.append(w)
            continue
        r = run_of[idx]
        if r in emitted_run:
            continue
        emitted_run.add(r)
        i, j = runs[r]
        t0, t1 = sk[i]["start"], sk[j]["end"]
        if (i, j) in synthetic:                              # a translated stretch: the whole span the Hinglish model heard Hindi in
            t0, t1 = min(t0, synthetic[(i, j)][0]), max(t1, synthetic[(i, j)][1])
        stats["hindi_runs"] += 1
        cand = []
        for h in hw:
            if h["id"] in used or not has_content(h["text"]):
                continue
            if not has_letters(h["text"]) and not plausible_number(h["text"]):
                continue                                   # digit debris (".7", "!1.") is not an amount
            mid = (h["start"] + h["end"]) / 2
            if t0 - pad <= mid <= t1 + pad:
                # the skeleton owns every moment where it heard an English (Latin) word: drop a hinglish word that
                # overlaps one by more than half of its own duration (e.g. "funnel" vs "funnels")
                dur = max(h["end"] - h["start"], 1e-3)
                hn = _norm(h["text"])
                dup = any(_overlap(l["start"], l["end"], h["start"], h["end"]) > 0.5 * dur
                          or (hn and _norm(l["text"]) == hn and max(l["start"] - h["end"], h["start"] - l["end"]) < SAME_WORD_GAP)
                          for l in latin)
                if not dup:
                    cand.append(h)
        flags_junk = [h for h in cand if is_devanagari(h["text"]) or "repeat_run" in h.get("flags", [])]
        cand = [h for h in cand if h not in flags_junk]
        # numbers the skeleton heard inside this Hindi run ("40", ",000" = one cluster): kept only when the Hinglish model has NO word anywhere in that
        # stretch (its reading wins: "paanch laakh" over the skeleton's "5 ,000"), so an amount spoken in a Hindi sentence is never silently dropped and
        # never doubled either
        k = i
        while k <= j:
            if is_devanagari(sk[k]["text"]) or not has_content(sk[k]["text"]) or not plausible_number(sk[k]["text"]):
                k += 1
                continue
            e = k
            while e + 1 <= j and not is_devanagari(sk[e + 1]["text"]) and plausible_number(sk[e + 1]["text"]):
                e += 1
            a0, a1 = sk[k]["start"] - 0.05, sk[e]["end"] + 0.05
            if not any(_overlap(a0, a1, h["start"], h["end"]) > 0 and (plausible_number(h["text"]) or h["text"].strip(".,?!").lower() in NUMBER_WORDS) for h in cand):
                for x in sk[k:e + 1]:
                    x["origin"] = "skeleton_number"
                    out.append(x)
                    stats["numbers_kept_from_skeleton"] = stats.get("numbers_kept_from_skeleton", 0) + 1
            k = e + 1
        if cand:
            for h in cand:
                used.add(h["id"])
                h["origin"] = "hinglish_model"
                out.append(h)
            stats["runs_replaced"] += 1
            stats["words_from_hinglish_model"] += len(cand)
        elif (i, j) in synthetic:                          # a translated stretch the Hinglish model gave nothing for: the stock model's words stay as they were
            already = {id(x) for x in out}                  # (skeleton numbers of the stretch were already emitted above)
            for k in range(i, j + 1):
                if id(sk[k]) not in already:
                    sk[k]["origin"] = "skeleton"
                    out.append(sk[k])
        else:
            for k in range(i, j + 1):
                x = sk[k]
                x["origin"] = "skeleton_devanagari"
                x.setdefault("flags", []).append("non_roman")
                out.append(x)
            stats["runs_kept_devanagari"] += 1

    out.sort(key=lambda w: (w["start"], w["end"]))
    # ids and segments
    segs = skeleton["segments"]
    for n, w in enumerate(out):
        w["id"] = f"w{n + 1:06d}"
    new_segments = []
    for s in segs:
        ids = [w["id"] for w in out if s["start"] - 1e-6 <= w["start"] < s["end"] + 1e-6]
        new_segments.append({"id": s["id"], "start": s["start"], "end": s["end"],
                             "text": " ".join(w["text"] for w in out if w["id"] in set(ids)), "word_ids": ids,
                             "lang": "hi"})
    seen: set[str] = set()
    for s in new_segments:                      # a word belongs to the first matching segment only
        s["word_ids"] = [i for i in s["word_ids"] if i not in seen]
        seen.update(s["word_ids"])
    by_id = {w["id"]: w for w in out}
    for s in new_segments:
        for i in s["word_ids"]:
            by_id[i]["segment"] = s["id"]
        s["text"] = " ".join(by_id[i]["text"] for i in s["word_ids"])
    orphan = [w for w in out if w["id"] not in seen]
    if orphan and new_segments:
        for w in orphan:
            seg = min(new_segments, key=lambda s: abs(s["start"] - w["start"]))
            seg["word_ids"].append(w["id"]); w["segment"] = seg["id"]
        for s in new_segments:
            s["word_ids"].sort(key=lambda i: by_id[i]["start"])
            s["text"] = " ".join(by_id[i]["text"] for i in s["word_ids"])

    res = dict(skeleton)
    res["words"], res["segments"] = out, new_segments
    res["engine"] = dict(skeleton["engine"], hybrid={"skeleton": skeleton["engine"]["model"],
                                                     "hinglish_model": hinglish["engine"]["model"]})
    res["language"] = dict(skeleton["language"], route="hinglish-hybrid")
    res["hybrid_stats"] = stats
    res["warnings"] = list(skeleton["warnings"]) + list(hinglish["warnings"])
    return res
