"""What the engine is doing right now, in plain words.

A transcription has long stretches without any progress number (loading a 1.6 GB model from disk, a second model, the extra accuracy passes). The app used to show
only "transcribing…" there, so a stall could not be told from slow work (field report on 0.9.10/0.9.11: Hinglish "stuck" with GPU and CPU idle). The engine now
says each step here; the app shows the latest text and the black window / work\\app.log keep the history. Never raises, never changes any result."""
from __future__ import annotations

import time
from typing import Callable, Optional

_listener: Optional[Callable[[str], None]] = None
_last: tuple[float, str] = (0.0, "")


def set_listener(fn: Optional[Callable[[str], None]]) -> None:
    global _listener
    _listener = fn


def say(msg: str) -> None:
    global _last
    _last = (time.time(), msg)
    try:
        print(f"[engine] {msg}", flush=True)
    except Exception:
        pass
    fn = _listener
    if fn is not None:
        try:
            fn(msg)
        except Exception:
            pass


def last() -> tuple[float, str]:
    """(when, what) of the latest message."""
    return _last
