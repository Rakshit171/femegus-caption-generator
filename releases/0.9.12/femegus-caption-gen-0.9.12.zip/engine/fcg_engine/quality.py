"""Flag suspicious recognition output. Words are NEVER deleted or rewritten here — only annotated with ``flags``
so the transcript editor can highlight them and the segmenter can apply a user-configurable policy.

Flags
  non_roman        alphabetic characters outside Latin script while English/Hinglish output was requested
  repeat_run       >= ``repeat_min`` consecutive identical tokens (typical Whisper loop/hallucination)
  repeat_phrase    a phrase of 2-6 words said >= 3 times in a row (the 2nd and later copies are flagged; speakers do repeat themselves, loops do too: listen)
  low_confidence   word probability below ``low_conf``
  prompt_leak      segment text is (almost) a copy of the initial prompt, i.e. likely not real speech
"""
from __future__ import annotations

import re
import unicodedata

_WORD_RE = re.compile(r"[^\W_]+", re.UNICODE)


def _norm(text: str) -> str:
    return "".join(_WORD_RE.findall(text.lower()))


def _has_non_latin_letter(text: str) -> bool:
    for ch in text:
        if ch.isalpha() and not unicodedata.name(ch, "").startswith("LATIN"):
            return True
    return False


_STUTTER_RE = re.compile(r"(.{2,8}?)\1{3,}")
STUTTER_MAX_LEN = 30                                    # no real word is longer


def is_stutter(text: str) -> bool:
    """A single recognised "word" that repeats a piece of itself four times ("dekhekhekhekhe") or is absurdly long: the decoder looped inside one token."""
    t = text.strip().lower()
    return len(t) > STUTTER_MAX_LEN or _STUTTER_RE.search(t) is not None


def add_flag(word: dict, flag: str) -> None:
    flags = word.setdefault("flags", [])
    if flag not in flags:
        flags.append(flag)


def flag_words(words: list[dict], segments: list[dict], language_mode: str, prompt: str | None = None,
               low_conf: float = 0.4, repeat_min: int = 4, leak_overlap: float = 0.8) -> dict:
    """Annotate in place. Returns counts per flag."""
    counts: dict[str, int] = {}

    def bump(w, f):
        add_flag(w, f)
        counts[f] = counts.get(f, 0) + 1

    if language_mode in ("english", "hinglish"):
        for w in words:
            if _has_non_latin_letter(w["text"]):
                bump(w, "non_roman")

    i = 0
    while i < len(words):
        j = i
        key = _norm(words[i]["text"])
        while j + 1 < len(words) and _norm(words[j + 1]["text"]) == key and key:
            j += 1
        if j - i + 1 >= repeat_min:
            for k in range(i, j + 1):
                bump(words[k], "repeat_run")
        i = j + 1

    for w in words:                      # one word that is really a loop inside itself: "dekhekhekhekhekhe…" (seen on a real clip; it swallowed the following sentence)
        if is_stutter(w["text"]):
            bump(w, "repeat_run")

    toks = [_norm(w["text"]) for w in words]
    i = 0
    while i < len(toks):
        hit = False
        for n in range(2, 7):
            if i + n * 3 > len(toks):
                break
            block = toks[i:i + n]
            if not all(block):
                continue
            reps = 1
            while toks[i + reps * n:i + (reps + 1) * n] == block:
                reps += 1
            if reps >= 3:
                for k in range(i + n, i + reps * n):
                    bump(words[k], "repeat_phrase")
                i += reps * n
                hit = True
                break
        if not hit:
            i += 1

    for w in words:
        if w.get("confidence", 1.0) < low_conf:
            bump(w, "low_confidence")

    if prompt:
        ptoks = set(_WORD_RE.findall(prompt.lower()))
        by_id = {w["id"]: w for w in words}
        for seg in segments:
            stoks = _WORD_RE.findall(seg["text"].lower())
            if len(stoks) >= 3 and sum(t in ptoks for t in stoks) / len(stoks) >= leak_overlap:
                seg["flags"] = ["prompt_leak"]
                for wid in seg["word_ids"]:
                    bump(by_id[wid], "prompt_leak")
    return counts


NUMBER_WORDS = frozenset("""
ek do teen chaar char paanch panch chhah chhe saat aath nau das dus gyaarah baarah terah chaudah pandrah solah satrah atharah unnis bees pachchis tees chaalees
pachaas saath sattar assi nabbe sau hazaar hazar lakh laakh lakhs lac crore crores karod one two three four five six seven eight nine ten twenty thirty forty
fifty sixty seventy eighty ninety hundred thousand million billion
""".split())


def _numberish(text: str) -> bool:
    t = text.strip().rstrip(".,?!").lower()
    return (any(c.isdigit() for c in t) and all(c.isdigit() or c == "," for c in t)) or t in NUMBER_WORDS


def _devanagari(text: str) -> bool:
    return any("ऀ" <= c <= "ॿ" for c in text)


def audit_numbers(final_words: list[dict], passes: dict[str, list[dict]], window: float = 0.35) -> list[dict]:
    """Spoken amounts are the one thing a caption must never silently lose. A number-like token (digits, or a Hindi/English number word) that a decoding
    pass heard must have a number-like word of the FINAL result within ``window`` seconds. To keep one pass's own hallucinations ("5 lakhs hundred." in the
    middle of English speech) from raising false alarms, a token only counts when ANOTHER pass corroborates it: a number-like word, or a Devanagari
    (= Hindi) word, at the same moment. Returns what is missing — to be reported and listened to, never to be invented."""
    mids = [(w["start"] + w["end"]) / 2 for w in final_words if _numberish(w["text"])]
    missing: dict[tuple[float, str], dict] = {}
    for name, ws in passes.items():
        others = [x for n, xs in passes.items() if n != name for x in xs]
        for w in ws:
            if not _numberish(w["text"]):
                continue
            mid = (w["start"] + w["end"]) / 2
            if any(abs(mid - m) <= window for m in mids):
                continue
            if any(abs(w["start"] - x["start"]) < 0.001 and x["text"] == w["text"] for x in final_words):
                continue
            if not any(abs((x["start"] + x["end"]) / 2 - mid) <= window and (_numberish(x["text"]) or _devanagari(x["text"])) for x in others):
                continue
            key = (round(w["start"], 1), w["text"].lower())
            missing.setdefault(key, {"text": w["text"], "t": round(w["start"], 2), "passes": []})["passes"].append(name)
    return sorted(missing.values(), key=lambda d: d["t"])
