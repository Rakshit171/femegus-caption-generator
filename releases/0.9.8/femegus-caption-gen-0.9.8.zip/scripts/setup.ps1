# FemeGus Caption Generator — one-time setup (Windows, PowerShell).
#
# Run from PowerShell, in the project folder (e.g. C:\Claude\AE caption Gen):
#     .\scripts\setup.ps1                      # standard install (NVIDIA GPU libraries included)
#     .\scripts\setup.ps1 -CpuOnly             # no NVIDIA libraries (about 1.5 GB smaller; transcription runs on the CPU)
#     .\scripts\setup.ps1 -PreloadModels       # also download the English speech model now (about 1.6 GB) instead of on first use
#     .\scripts\setup.ps1 -WithHinglish        # also set up the Hinglish model (about 3 GB download + conversion, a few minutes)
#     .\scripts\setup.ps1 -Dev                 # also install the test tools (pytest)
#
# It is safe to run again: finished steps are skipped. It only creates the folder  .venv  inside the project and downloads packages/models;
# it does not touch After Effects, the registry, or anything outside the project folder (pip and Hugging Face keep their usual caches).
param([switch]$CpuOnly, [switch]$PreloadModels, [switch]$WithHinglish, [switch]$Dev)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
function Step($m) { Write-Host "`n== $m" -ForegroundColor Cyan }
function Ok($m) { Write-Host "   $m" -ForegroundColor Green }
function Warn($m) { Write-Host "   $m" -ForegroundColor Yellow }

# ---- 1. Python 3.10+ ----------------------------------------------------------------------------------------------------------------
Step "Looking for Python 3.10 or newer"
$candidates = @(@('py', '-3.12'), @('py', '-3.11'), @('py', '-3.10'), @('python'), @('python3'))
$python = $null
foreach ($c in $candidates) {
    try {
        $exe = $c[0]; $rest = @(); if ($c.Count -gt 1) { $rest = $c[1..($c.Count - 1)] }
        $v = & $exe @rest -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
        if ($LASTEXITCODE -eq 0 -and $v -and ([version]$v -ge [version]'3.10')) { $python = @{ exe = $exe; args = $rest; version = $v }; break }
    } catch { }
}
if (-not $python) {
    Write-Host "Python 3.10 or newer was not found." -ForegroundColor Red
    Write-Host "Install Python 3.10-3.12 from https://www.python.org/downloads/ (tick 'Add python.exe to PATH'), then run this script again." -ForegroundColor Red
    exit 1
}
Ok "Python $($python.version) found"
if ([version]$python.version -ge [version]'3.13') { Warn "Python 3.13+ has not been tested with this tool; 3.10-3.12 is recommended." }

# ---- 2. virtual environment ---------------------------------------------------------------------------------------------------------
Step "Creating the project's private Python environment (.venv)"
$venvPy = Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $venvPy)) { & $python.exe @($python.args) -m venv .venv; if ($LASTEXITCODE -ne 0) { throw "could not create .venv" }; Ok "created" } else { Ok "already exists" }

# ---- 3. packages --------------------------------------------------------------------------------------------------------------------
Step "Installing packages (the first time this downloads several GB; later runs are quick)"
& $venvPy -m pip install --quiet --disable-pip-version-check --upgrade pip
# The tested versions of EVERY package are listed in requirements.lock.txt and used as constraints, so another computer gets the same library versions the
# tool was tested with (an untested newer library once broke transcription on a friend's PC). If a pin cannot be met on this Python version, install without it.
function Install-Pinned($files) {
    $a = @(); foreach ($f in $files) { $a += @('-r', $f) }
    & $venvPy -m pip install --quiet --disable-pip-version-check @a -c requirements.lock.txt
    if ($LASTEXITCODE -ne 0) {
        Warn "the tested versions could not be installed on this Python; trying the newest compatible versions instead (some things may behave differently)"
        & $venvPy -m pip install --quiet --disable-pip-version-check @a
    }
    return $LASTEXITCODE
}
Write-Host "   installing the speech engine (this can take several minutes the first time)..."
if ((Install-Pinned @('requirements.txt')) -ne 0) { throw "pip could not install requirements.txt (check your internet connection)" }
if (-not $CpuOnly) {
    Write-Host "   installing the NVIDIA GPU libraries (about 1.5 GB the first time)..."
    if ((Install-Pinned @('requirements-gpu.txt')) -ne 0) { Warn "GPU libraries could not be installed; transcription will use the CPU. You can retry later." }
}
if ($Dev) { & $venvPy -m pip install --quiet --disable-pip-version-check -r requirements-dev.txt }
# remember which requirements were installed, so the launcher (scripts\fcgapp.ps1) can tell later when an update needs other component versions
try {
    $parts = foreach ($f in @('requirements.txt', 'requirements-gpu.txt', 'requirements.lock.txt')) { $p = Join-Path $root $f; if (Test-Path $p) { (Get-FileHash $p -Algorithm SHA256).Hash } }
    [IO.File]::WriteAllText((Join-Path $root '.venv\.fcg_requirements.sha'), ($parts -join '-'))
} catch { }
Ok "packages ready"

# ---- 4. models ----------------------------------------------------------------------------------------------------------------------
if ($PreloadModels) {
    Step "Downloading the English speech model (about 1.6 GB, once)"
    & $venvPy -c "from faster_whisper import WhisperModel; WhisperModel('large-v3-turbo', device='cpu', compute_type='int8'); print('model ready')"
    if ($LASTEXITCODE -ne 0) { Warn "model download failed (offline?). It will be downloaded on first use instead." }
}
if ($WithHinglish) { Step "Setting up the Hinglish model"; & (Join-Path $PSScriptRoot "setup_hinglish.ps1") }

# ---- 5. check -----------------------------------------------------------------------------------------------------------------------
Step "System check"
$env:PYTHONPATH = (Join-Path $root "app"); $env:PYTHONIOENCODING = "utf-8"
& $venvPy -m fcg_app --check
$code = $LASTEXITCODE

Write-Host "`n== Next steps" -ForegroundColor Cyan
Write-Host "   1. Start the app:   double-click  Start-FemeGus.cmd   (or run  .\scripts\fcgapp.ps1 )"
Write-Host "   2. In After Effects (once per session):  File > Script > Run Script File...  >  $root\adapters\jsx-core\fcg_connect.jsx"
Write-Host "      and make sure Preferences > Scripting & Expressions > 'Allow Scripts to Write Files and Access Network' is ticked."
Write-Host "   Full guide: docs\INSTALL.md   Problems: docs\TROUBLESHOOTING.md"
exit $code
