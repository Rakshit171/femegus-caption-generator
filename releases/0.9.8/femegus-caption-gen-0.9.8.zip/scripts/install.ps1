# FemeGus Caption Generator - guided installer (Windows, PowerShell 5.1 or newer).
#
# Normal use: double-click  Install-FemeGus.cmd  in the folder you unzipped. It checks the computer, asks a few questions with recommended answers,
# installs everything INSIDE this folder (plus the usual pip / Hugging Face caches) and finishes with a system check. Safe to run again (repair / re-check).
# It does not touch After Effects, the registry or anything outside this folder, except the optional desktop shortcut and (only if you agree) installing Python.
#
#   .\scripts\install.ps1                 guided
#   .\scripts\install.ps1 -Preflight      only check this computer and stop (installs nothing)
#   .\scripts\install.ps1 -Yes            accept the recommended answers without asking (add -WithHinglish / -CpuOnly / -AutoUpdates to change them)
param(
    [switch]$Yes, [switch]$Preflight, [switch]$CpuOnly, [switch]$WithHinglish, [switch]$NoModelPreload,
    [switch]$AutoUpdates, [switch]$NoShortcut, [switch]$NoPythonInstall
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
# everything this window shows is also saved to work\install.log: if something fails, send that file (it contains no videos or personal data)
try { New-Item -ItemType Directory -Force (Join-Path $root 'work') | Out-Null; Start-Transcript -Path (Join-Path $root 'work\install.log') -Append | Out-Null } catch { }
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }

function Say($m, $c = 'White') { Write-Host $m -ForegroundColor $c }
function Head($m) { Write-Host ""; Write-Host "== $m" -ForegroundColor Cyan }
function Good($m) { Write-Host "   [ok]   $m" -ForegroundColor Green }
function Note($m) { Write-Host "   [note] $m" -ForegroundColor Yellow }
function Bad($m)  { Write-Host "   [FAIL] $m" -ForegroundColor Red }
function Ask($question, [bool]$default) {
    if ($Yes) { return $default }
    $hint = if ($default) { 'Y/n' } else { 'y/N' }
    while ($true) {
        $a = (Read-Host "   $question [$hint]").Trim().ToLower()
        if ($a -eq '') { return $default }
        if ($a -in @('y', 'yes')) { return $true }
        if ($a -in @('n', 'no')) { return $false }
    }
}

Say "FemeGus Caption Generator - installer" 'Cyan'
Say "Folder: $root"
$version = ''; if (Test-Path (Join-Path $root 'VERSION')) { $version = (Get-Content (Join-Path $root 'VERSION') -TotalCount 1).Trim(); Say "Version: $version" }
# files extracted from a downloaded zip carry a "downloaded from the internet" mark; remove it from this folder's own files so scripts run without warnings
try {
    foreach ($d in @('app', 'core', 'engine', 'adapters', 'scripts', 'docs', 'presets')) { if (Test-Path (Join-Path $root $d)) { Get-ChildItem -Path (Join-Path $root $d) -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue } }
    Get-ChildItem -Path $root -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
} catch { }

# ---------------------------------------------------------------------------------------------------------------------- 1. look at this computer
Head "1. Checking this computer"
$problems = 0
if ([Environment]::OSVersion.Version.Major -ge 10) { Good "Windows $([Environment]::OSVersion.Version)" } else { Bad "Windows 10 or 11 is required"; $problems++ }
if ($root -match '[^\x00-\x7F]') { Note "The folder path contains non-English characters. If anything fails later, move the folder to a plain path such as C:\FemeGus." }
if ($root.Length -gt 120) { Note "The folder path is long; a shorter one (C:\FemeGus) avoids Windows path-length problems." }

function Find-Python {
    foreach ($c in @(@('py', '-3.12'), @('py', '-3.11'), @('py', '-3.10'), @('python'), @('python3'))) {
        try {
            $exe = $c[0]; $rest = @(); if ($c.Count -gt 1) { $rest = $c[1..($c.Count - 1)] }
            $v = & $exe @rest -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
            if ($LASTEXITCODE -eq 0 -and $v -and ([version]$v -ge [version]'3.10')) { return @{ exe = $exe; args = $rest; version = $v } }
        } catch { }
    }
    foreach ($p in @("$env:LOCALAPPDATA\Programs\Python\Python312\python.exe", "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe", "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe")) {
        if (Test-Path $p) { return @{ exe = $p; args = @(); version = (& $p -c "import sys; print('%d.%d' % sys.version_info[:2])") } }
    }
    return $null
}
$python = Find-Python
if ($python) { Good "Python $($python.version) found" } else { Note "Python 3.10 or newer was not found (it will be offered below)." }

$gpu = $null
try { $gpu = (Get-CimInstance Win32_VideoController -ErrorAction Stop | Where-Object { $_.Name -match 'NVIDIA' } | Select-Object -First 1).Name } catch { }
if ($gpu) { Good "NVIDIA graphics card: $gpu (fast transcription)" } else { Note "No NVIDIA graphics card found: transcription will use the processor, about 7x slower. Everything else works the same." }

$drive = (Split-Path -Qualifier $root).TrimEnd(':')
try {
    $freeGb = [math]::Round((Get-PSDrive $drive).Free / 1GB, 1)
    if ($freeGb -ge 12) { Good "$freeGb GB free on drive $drive" } elseif ($freeGb -ge 7) { Note "$freeGb GB free on drive $drive (enough for English; Hinglish needs about 5 GB more)" } else { Bad "only $freeGb GB free on drive $drive - about 7 GB are needed"; $problems++ }
} catch { }

$online = $true
foreach ($u in @('https://pypi.org', 'https://huggingface.co', 'https://raw.githubusercontent.com')) {
    try { Invoke-WebRequest -Uri $u -UseBasicParsing -Method Head -TimeoutSec 10 | Out-Null; Good "can reach $($u -replace 'https://', '')" }
    catch { Note "cannot reach $($u -replace 'https://', '') (internet, firewall or proxy). The downloads need pypi.org and huggingface.co."; if ($u -notmatch 'raw.githubusercontent') { $online = $false } }
}
$ae = @(Get-ChildItem 'C:\Program Files\Adobe' -Directory -Filter 'Adobe After Effects*' -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
if ($ae.Count -gt 0) { Good ("After Effects found: " + ($ae -join ', ')); if (-not ($ae -match '2025')) { Note "Only After Effects 2025 (25.2) has been tested. Other versions show a warning and are not supported yet." } }
else { Note "After Effects was not found in the usual place. The app still installs; you need After Effects 2025 to use the captions." }
if (Test-Path (Join-Path $root '.venv\Scripts\python.exe')) { Note "A previous installation was found here: this run will repair / complete it (your projects and models are kept)." }

if ($Preflight) {
    Head "Preflight finished (nothing was installed)"
    if ($problems -gt 0) { Bad "$problems problem(s) need attention first"; exit 1 }
    Good "This computer looks ready."; exit 0
}
if ($problems -gt 0) { Bad "Please fix the problem(s) above and run the installer again."; exit 1 }
if (-not $online) { if (-not (Ask "Some download sites could not be reached. Continue anyway?" $false)) { exit 1 } }

# ---------------------------------------------------------------------------------------------------------------------- 2. Python
if (-not $python) {
    Head "2. Python"
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget -and -not $NoPythonInstall -and (Ask "Install Python 3.12 now with Windows' own installer (winget, free, for your user only)?" $true)) {
        & winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
        $python = Find-Python
    }
    if (-not $python) {
        Bad "Python 3.10-3.12 is needed. Install it from https://www.python.org/downloads/ (tick 'Add python.exe to PATH'), then run Install-FemeGus.cmd again."
        exit 1
    }
    Good "Python $($python.version) ready"
}

# ---------------------------------------------------------------------------------------------------------------------- 3. questions
Head "3. A few questions (Enter = the recommended answer)"
$useCpu = [bool]$CpuOnly
if (-not $useCpu -and -not $gpu) { $useCpu = $true; Note "No NVIDIA card: the GPU libraries (about 1.5 GB) will be skipped." }
$hing = [bool]$WithHinglish
if (-not $hing) { $hing = Ask "Also set up the Hinglish (Hindi in Roman letters) model? About 3 GB extra and a few minutes. English works without it." $false }
$preload = -not $NoModelPreload
if ($preload) { $preload = Ask "Download the English speech model now (about 1.6 GB) so the first transcription is not delayed?" $true }
$upd = [bool]$AutoUpdates
if (-not $upd) { $upd = Ask "Let the app check for updates and new caption looks when it starts? (It only downloads a small information file from GitHub; nothing about you or your videos is sent. You can change this later.)" $false }
$short = -not $NoShortcut
if ($short) { $short = Ask "Create a desktop shortcut?" $true }

# ---------------------------------------------------------------------------------------------------------------------- 4. install
Head "4. Installing (this can take a while; downloads are several GB the first time)"
$setupArgs = @()
if ($useCpu) { $setupArgs += '-CpuOnly' }
if ($preload) { $setupArgs += '-PreloadModels' }
if ($hing) { $setupArgs += '-WithHinglish' }
& (Join-Path $PSScriptRoot 'setup.ps1') @setupArgs
$setupCode = $LASTEXITCODE

# ---------------------------------------------------------------------------------------------------------------------- 5. settings, shortcut
Head "5. Finishing"
try {
    $proj = Join-Path $root 'projects'; New-Item -ItemType Directory -Force $proj | Out-Null
    $sp = Join-Path $proj '_settings.json'; $s = $null
    if (Test-Path $sp) { try { $s = Get-Content $sp -Raw | ConvertFrom-Json } catch { $s = $null } }
    if (-not $s) { $s = New-Object psobject }
    $s | Add-Member -NotePropertyName update_check -NotePropertyValue ([bool]$upd) -Force
    [IO.File]::WriteAllText($sp, ($s | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding($false)))
    Good ("automatic update checks: " + $(if ($upd) { 'on' } else { 'off' }))
} catch { Note "could not save the update setting ($_). You can set it in the app: section 10 > Updates." }
if ($short) {
    try {
        $lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) 'FemeGus Captions.lnk'
        $sh = New-Object -ComObject WScript.Shell; $l = $sh.CreateShortcut($lnk)
        $l.TargetPath = Join-Path $root 'Start-FemeGus.cmd'; $l.WorkingDirectory = $root; $l.Description = 'FemeGus Caption Generator'; $l.Save()
        Good "desktop shortcut created"
    } catch { Note "could not create the shortcut: $_" }
}

Head "Done"
if ($setupCode -ne 0) { Note "The system check above reported something to fix; the app may still work. See docs\TROUBLESHOOTING.md." }
Say "Next:" 'Cyan'
Say "  1. In After Effects, once: Edit > Preferences > Scripting & Expressions > tick 'Allow Scripts to Write Files and Access Network'."
Say "  2. Each After Effects session: File > Scripts > Run Script File...  >  $root\adapters\jsx-core\fcg_connect.jsx"
Say "  3. Start the app: double-click 'FemeGus Captions' on the desktop, or Start-FemeGus.cmd in this folder."
Say "  Step-by-step guide: docs\FIRST_RUN.md"
if (-not $Yes -and (Ask "Start the app now?" $true)) { Start-Process -FilePath (Join-Path $root 'Start-FemeGus.cmd') -WorkingDirectory $root }
exit $setupCode
