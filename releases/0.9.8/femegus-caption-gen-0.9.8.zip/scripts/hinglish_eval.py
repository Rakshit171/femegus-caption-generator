r"""Hinglish regression suite + measurements.   (PowerShell, project root)

    .\.venv\Scripts\python.exe scripts\hinglish_eval.py run                 # every case in tests/fixtures/hinglish/cases.json + the metrics below
    .\.venv\Scripts\python.exe scripts\hinglish_eval.py run --json out.json # same, machine readable
    .\.venv\Scripts\python.exe scripts\hinglish_eval.py add-case --transcript work\hinglish_test\pc3.transcript.json --from 39.5 --to 47.5 \
            --id pc3_my_case --category numbers --clip "CUT - PC 3.mp4" --expect "agar 40,000 ya 50,000 rupees" --evidence "heard by 3 recognisers"
    .\.venv\Scripts\python.exe scripts\hinglish_eval.py audio --clips "D:\clips\a.mp4,D:\clips\b.mp4"   # re-transcribe real clips with the CURRENT engine and measure (slow, needs the models)

A case holds the RAW words a recogniser produced for a stretch of a real clip, what the caption text must (and must not) contain, and where the expectation comes
from. The cases do not need audio or models: they test everything after recognition (merge output -> captions -> .srt). The ``audio`` command tests the recognition
itself on the real clips. Honest limits are written into every case (``verified``): expectations are NOT ground truth from a human listening, they are what
independent recognisers agree on plus sentence context; the owner's own corrected reference (hinglish_clip_reference.txt) is the strongest evidence we have.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
for sub in ("core", "engine", "app"):
    sys.path.insert(0, os.path.join(ROOT, sub))

from fcg_core import SegmenterConfig, build, hinglish  # noqa: E402

CASES = os.path.join(ROOT, "tests", "fixtures", "hinglish", "cases.json")
REFERENCE = os.path.join(ROOT, "tests", "fixtures", "hinglish_clip_reference.txt")
REF_TRANSCRIPT = os.path.join(ROOT, "tests", "fixtures", "hinglish_clip.transcript.json")
VARIANTS = os.path.join(ROOT, "tests", "fixtures", "spelling_variants.json")
FAMILIES = {"voh": ["vah", "woh", "wo", "vo", "voh"], "yeh": ["yah", "ye", "yeh"], "nahin": ["nahi", "nahee", "nahin"], "theek": ["thik", "theek"],
            "tumhaare": ["tumhare", "tumhaare"], "maine": ["mainne", "maine", "mene"], "lakh": ["laakh", "lakhs", "lac", "lakh"], "crore": ["crr", "crores", "karod", "crore"]}


# ------------------------------------------------------------------------------------------------------------------------------ cases
def load_cases(path: str = CASES) -> dict:
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def final_text(groups: dict) -> str:
    return " ".join(w["display"] for g in groups["groups"] for w in g["words"])


def run_case(case: dict) -> dict:
    tr = {"words": [dict(w) for w in case["raw_words"]], "segments": [], "warnings": [], "language": case.get("language") or {"route": "hinglish-hybrid"}}
    from fcg_engine.quality import flag_words
    flag_words(tr["words"], [], "hinglish")                           # the engine's own flags (idempotent): cases saved by an older engine get the newer flags too
    cfg, _ = SegmenterConfig.from_dict(case.get("config"))
    g = build(tr, case.get("overrides") or {}, cfg, None)
    text = final_text(g)
    failures: list[str] = []
    for s in case.get("expect_text", []):
        if s not in text:
            failures.append(f"missing in captions: {s!r}")
    for s in case.get("forbid_text", []):
        if s in text:
            failures.append(f"must not appear: {s!r}")
    flags = {(w["text"], f) for gr in g["groups"] for w in gr["words"] for f in w.get("flags", [])}
    for t, f in case.get("expect_flags", []):
        if (t, f) not in flags:
            failures.append(f"expected flag {f!r} on {t!r}")
    for t, f in case.get("forbid_flags", []):
        if (t, f) in flags:
            failures.append(f"unexpected flag {f!r} on {t!r}")
    words = [w for gr in g["groups"] for w in gr["words"]]
    if "first_reveal_max" in case and (not words or words[0]["reveal"] > case["first_reveal_max"]):
        failures.append(f"first caption appears at {words[0]['reveal'] if words else None}, expected <= {case['first_reveal_max']}")
    raw = {w["id"]: w for w in case["raw_words"]}
    for w in words:                                                    # the one invariant that must hold for everything: nothing is revealed before it is spoken
        r = raw[w["id"]]
        if w["reveal"] + 1e-6 < r["start"] or abs(w["start"] - r["start"]) > 1e-3:
            failures.append(f"timing changed or word revealed early: {w['id']} {w['text']!r}")
            break
    if g["violations"]:
        failures.append(f"{len(g['violations'])} timing violation(s)")
    return {"id": case["id"], "category": case["category"], "ok": not failures, "failures": failures, "text": text, "polish": g["text_polish"]["counts"],
            "problems": [p["kind"] for p in g["text_polish"]["problems"]]}


# ------------------------------------------------------------------------------------------------------------------------------ metrics
def _lev(a, b) -> int:
    prev = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        cur = [i]
        for j, y in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (x != y)))
        prev = cur
    return prev[-1]


def cer(ref_tokens: list[str], hyp_tokens: list[str]) -> float:
    r, h = " ".join(ref_tokens), " ".join(hyp_tokens)
    return _lev(r, h) / max(1, len(r))


def reference_tokens() -> list[str]:
    from fcg_engine.evaluate import load_reference
    return load_reference(REFERENCE)


def metrics(results: list[dict]) -> dict:
    from fcg_engine.evaluate import canon_map, hyp_tokens, tokenize, wer
    m: dict = {}
    by: dict[str, list[bool]] = {}
    for r in results:
        by.setdefault(r["category"], []).append(r["ok"])
    m["cases"] = {k: f"{sum(v)}/{len(v)}" for k, v in sorted(by.items())}
    m["cases_total"] = f"{sum(r['ok'] for r in results)}/{len(results)}"
    # 1. false corrections: the owner's corrected reference text is already in the preferred style
    toks = open(REFERENCE, encoding="utf-8-sig").read()
    lines = [re.sub(r"^\s*\[\d+:\d+(?:\.\d+)?\]\s*", "", l) for l in toks.splitlines() if l.strip() and not l.lstrip().startswith("#")]
    ws = [{"id": f"w{i}", "text": t, "display": t, "start": i * 0.3, "end": i * 0.3 + 0.25, "confidence": 0.95} for i, t in enumerate(" ".join(lines).split())]
    _, rep = hinglish.polish(ws)
    fc = [c for c in rep["changes"] if c["rule"] != "final_full_stop"]
    m["false_corrections_on_reference"] = {"words": len(ws), "changes": len(fc), "examples": [f"{c['before']}->{c['after']}" for c in fc[:5]]}
    # 2. WER / CER of the reference clip, raw recogniser text vs final caption text
    if os.path.isfile(REF_TRANSCRIPT):
        tr = json.load(open(REF_TRANSCRIPT, encoding="utf-8-sig"))
        tr.setdefault("language", {})["route"] = "hinglish-hybrid"
        g = build(tr, {}, SegmenterConfig(), None)
        ref = reference_tokens()
        canon = canon_map(json.load(open(VARIANTS, encoding="utf-8-sig")))
        raw_t, fin_t = hyp_tokens(tr), tokenize(final_text(g))
        nop_t = tokenize(final_text(build(tr, {}, SegmenterConfig(text_polish="off"), None)))       # captions without the Hinglish polish (number joining etc. only)
        for name, h in (("raw", raw_t), ("captions_without_polish", nop_t), ("final", fin_t)):
            a, b = wer(ref, h), wer(ref, h, canon)
            m[f"reference_clip_{name}"] = {"wer_strict": a["wer"], "wer_spelling_variants_equal": b["wer"], "cer": round(cer(ref, h), 4), "sub/del/ins": f"{a['sub']}/{a['del']}/{a['ins']}",
                                           "missing_word_rate": round(a["del"] / max(1, a["ref_words"]), 4)}
        m["reference_clip_polish_changes"] = g["text_polish"]["counts"]
    # 3. numbers: every expectation that contains a digit must be present in the final text
    nums = [(r, s) for r, c in zip(results, load_cases()["cases"]) for s in c.get("expect_text", []) if any(ch.isdigit() for ch in s)]
    m["number_expectations_met"] = f"{sum(s in r['text'] for r, s in nums)}/{len(nums)}"
    # 4. spelling consistency: variants of one word must not coexist in the final text of a case
    mixed = []
    for r in results:
        toks_ = set(re.findall(r"[\w']+", r["text"].lower()))
        for fam, vs in FAMILIES.items():
            used = [v for v in vs if v in toks_]
            if len(used) > 1:
                mixed.append((r["id"], used))
    m["mixed_spellings"] = mixed
    # 5. punctuation: "?" removed from fully English statements across all cases (each one is a mistake the old output had)
    m["question_marks_removed_from_statements"] = sum(r["polish"].get("question_mark_removed", 0) for r in results)
    # 6. .srt completeness: every caption word is in the .srt, in both modes, nothing added or lost
    from fcg_app import ops
    lost = []
    for c in load_cases()["cases"]:
        tr = {"words": [dict(w) for w in c["raw_words"]], "segments": [], "warnings": [], "language": c.get("language") or {"route": "hinglish-hybrid"}}
        g = build(tr, c.get("overrides") or {}, SegmenterConfig.from_dict(c.get("config"))[0], None)
        want = final_text(g).split()
        group_texts = [" ".join(w["display"] for w in gr["words"] if w["display"].strip()) for gr in g["groups"]]
        caption = ops.srt_cues(g, "caption")
        if " ".join(t for _, _, t in caption).split() != want:                    # standard mode: every word exactly once, in order
            lost.append((c["id"], "caption"))
        word_cues = {t for _, _, t in ops.srt_cues(g, "word")}
        if not all(gt in word_cues for gt in group_texts if gt):                  # build-up mode: the last cue of each caption holds the whole caption
            lost.append((c["id"], "word"))
        if ops.export_srt(g, "caption").count("-->") != len(caption):
            lost.append((c["id"], "format"))
    m["srt_cases_with_lost_words"] = lost
    # 7. amounts flagged for review (honest signal instead of invented numbers)
    m["amount_flags"] = sum(r["problems"].count("missing_amount") for r in results)
    return m


def add_case(a) -> None:
    tr = json.load(open(a.transcript, encoding="utf-8-sig"))
    words = [w for w in tr["words"] if a.start <= w["start"] < a.end]
    if not words:
        sys.exit("no words in that window")
    keep = ("id", "text", "start", "end", "confidence", "origin", "flags", "lang", "segment")
    case = {"id": a.id, "category": a.category, "clip": a.clip, "window": [a.start, a.end], "evidence": a.evidence, "verified": "NOT listened to by a human",
            "language": {"route": (tr.get("language") or {}).get("route", "hinglish-hybrid")}, "raw_words": [{k: w[k] for k in keep if k in w} for w in words],
            "expect_text": a.expect or [], "forbid_text": a.forbid or []}
    data = load_cases() if os.path.isfile(CASES) else {"schema": 1, "cases": []}
    data["cases"] = [c for c in data["cases"] if c["id"] != a.id] + [case]
    os.makedirs(os.path.dirname(CASES), exist_ok=True)
    json.dump(data, open(CASES, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"case {a.id} saved ({len(words)} raw words); edit {CASES} to add flags/first_reveal_max etc.")


def audio_run(clips: list[str]) -> None:
    """Re-transcribe real clips with the CURRENT engine and measure start coverage, numbers, flags. Slow; needs the models and the clips."""
    from fcg_engine.audio import compute_envelope
    from fcg_engine.coverage import speech_spans, uncovered_gaps
    from fcg_engine.engine import Engine
    from fcg_app import ops
    # clip names -> files: give paths directly, or list your own clips once in work\hinglish_clips.json  {"pc3": "D:\clips\a.mp4", ...}  (kept out of the repository)
    reg = os.path.join(ROOT, "work", "hinglish_clips.json")
    known = json.load(open(reg, encoding="utf-8-sig")) if os.path.isfile(reg) else {}
    eng = Engine("auto", os.path.join(ROOT, "engine", "models_local.json"))
    for k in clips:
        path = known.get(k, k)
        if not os.path.isfile(path):
            print(f"{k}: clip not found, skipped")
            continue
        env = compute_envelope(path)
        tr = eng.transcribe(path, "hinglish", envelope=env)
        g = build(tr, {}, SegmenterConfig(), env)
        sp = speech_spans(env)
        first = g["groups"][0]["words"][0]["reveal"] if g["groups"] else None
        print(f"{k}: speech starts {sp[0][0] if sp else None}, first caption {first}, words {len(tr['words'])}, uncovered>=0.6s "
              f"{sum(b - a for a, b in uncovered_gaps(tr['words'], env, 0.6)):.1f}s, numbers missing {(tr.get('quality') or {}).get('numbers_missing')}, "
              f"polish {g['text_polish']['counts']}, review flags {[p['kind'] for p in g['text_polish']['problems']]}")
        open(os.path.join(ROOT, "work", f"{k}.eval.srt"), "w", encoding="utf-8", newline="").write(ops.export_srt(g))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--json")
    r.add_argument("--verbose", action="store_true")
    c = sub.add_parser("add-case")
    c.add_argument("--transcript", required=True)
    c.add_argument("--from", dest="start", type=float, required=True)
    c.add_argument("--to", dest="end", type=float, required=True)
    c.add_argument("--id", required=True)
    c.add_argument("--category", required=True)
    c.add_argument("--clip", default="")
    c.add_argument("--evidence", default="")
    c.add_argument("--expect", action="append")
    c.add_argument("--forbid", action="append")
    au = sub.add_parser("audio")
    au.add_argument("--clips", required=True, help="comma separated: names from work/hinglish_clips.json or full paths")
    a = ap.parse_args()
    if a.cmd == "add-case":
        add_case(a)
        return 0
    if a.cmd == "audio":
        audio_run(a.clips.split(","))
        return 0
    results = [run_case(c) for c in load_cases()["cases"]]
    m = metrics(results)
    for res in results:
        print(("PASS " if res["ok"] else "FAIL ") + f"{res['category']:14s} {res['id']}")
        for f in res["failures"]:
            print("       -", f)
        if a.verbose:
            print("       ", res["text"][:200])
    print("\nMETRICS")
    for k, v in m.items():
        print(f"  {k}: {json.dumps(v, ensure_ascii=False)}")
    if a.json:
        json.dump({"results": results, "metrics": m}, open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return 0 if all(r["ok"] for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
