# Run the timing/segmentation core CLI:   .\scripts\fcgcore.ps1 build work\det_1.json --envelope work\hing_env.json --show
$root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = (Join-Path $root "core")
$env:PYTHONIOENCODING = "utf-8"
& (Join-Path $root ".venv\Scripts\python.exe") -m fcg_core @args
