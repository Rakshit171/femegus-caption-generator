# Run the engine CLI from anywhere:   .\scripts\fcg.ps1 transcribe "C:\path\video.mp4" --language english --show
# Run from PowerShell. Uses the project venv (.venv) — no global Python packages needed.
$root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = Join-Path $root "engine"
$env:PYTHONIOENCODING = "utf-8"
& (Join-Path $root ".venv\Scripts\python.exe") -m fcg_engine @args
