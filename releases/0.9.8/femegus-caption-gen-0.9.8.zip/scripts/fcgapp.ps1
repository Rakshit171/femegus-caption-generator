# Start the caption editor (local web app). Run from PowerShell:   .\scripts\fcgapp.ps1
# It prints an address with a one-time token and opens it in your browser. Nothing leaves this computer.
#
# This launcher also lets the app restart itself (after an update) and repair its components:
#   * the app exits with code 75  -> it is started again (same address, so the open browser page just reconnects);
#   * work\repair.flag exists     -> BEFORE the app starts, the tested versions of the components are installed again (pip; needs internet).
$root = Split-Path -Parent $PSScriptRoot
$env:PYTHONPATH = (Join-Path $root "app")
$env:PYTHONIOENCODING = "utf-8"
$env:FCG_LAUNCHER = "loop"
$py = Join-Path $root ".venv\Scripts\python.exe"
$flag = Join-Path $root "work\repair.flag"
Set-Location $root

# The component versions this copy of the tool needs are described by requirements*.txt. A marker inside .venv remembers which description was installed;
# when it is missing or different (first start after an update, or an installation made before the marker existed) the tested versions are installed
# again before the app starts. When everything is already in place pip only checks and finishes in a few seconds; offline, it just starts the app.
$marker = Join-Path $root ".venv\.fcg_requirements.sha"
function Get-WantedHash {
    $parts = foreach ($f in @('requirements.txt', 'requirements-gpu.txt', 'requirements.lock.txt')) { $p = Join-Path $root $f; if (Test-Path $p) { (Get-FileHash $p -Algorithm SHA256).Hash } }
    return ($parts -join '-')
}

do {
    $repair = Test-Path $flag
    $gpu = Test-Path (Join-Path $root ".venv\Lib\site-packages\nvidia\cublas")
    if ($repair) {
        try { $gpu = [bool]((Get-Content $flag -Raw | ConvertFrom-Json).gpu) } catch { }
        Remove-Item $flag -Force -ErrorAction SilentlyContinue
    }
    $wanted = Get-WantedHash
    $installed = ''; if (Test-Path $marker) { try { $installed = (Get-Content $marker -Raw).Trim() } catch { } }
    if ($repair -or $installed -ne $wanted) {
        Write-Host ""
        if ($repair) { Write-Host "== Repairing components (installing the tested versions; needs internet; a few minutes) ==" -ForegroundColor Cyan }
        else { Write-Host "== Checking the components (once after an update; a few seconds, longer if something must be installed) ==" -ForegroundColor Cyan }
        $files = @('-r', 'requirements.txt'); if ($gpu) { $files += @('-r', 'requirements-gpu.txt') }
        $net = @(); if (-not $repair) { $net = @('--retries', '1', '--timeout', '8') }       # the automatic check must not delay the start for long when offline
        & $py -m pip install --disable-pip-version-check @net @files -c requirements.lock.txt | Where-Object { $_ -notmatch '^Requirement already satisfied' }
        if ($LASTEXITCODE -ne 0 -and $repair) {
            Write-Host "   pinned install failed; trying without the version constraints..." -ForegroundColor Yellow
            & $py -m pip install --disable-pip-version-check @files | Where-Object { $_ -notmatch '^Requirement already satisfied' }
        }
        if ($LASTEXITCODE -eq 0) {
            try { [IO.File]::WriteAllText($marker, $wanted) } catch { }
            Write-Host "== Components are ready ==" -ForegroundColor Green
        } else { Write-Host "== The components could not be checked/installed (offline?) - starting the app anyway; section 10 has 'Repair components' ==" -ForegroundColor Yellow }
    }
    & $py -m fcg_app @args
    $code = $LASTEXITCODE
} while ($code -eq 75)
exit $code
