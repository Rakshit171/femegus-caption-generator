# Hinglish writing style, text polish and how it is tested

Everything here applies to the **caption text** (`display`) of Hinglish transcripts. The words the recogniser heard (`text`) are never changed, no word is added,
removed, merged or moved in time, and a word you edited by hand is never touched. Code: `core/fcg_core/hinglish.py` (rules), `engine/fcg_engine/hybrid.py` +
`engine/fcg_engine/engine.py` (recognition). Switch: section 2 ▸ *Hinglish text polish* (Automatic / Always on / Off). Every change is listed there and in
`groups.json` (`text_polish.changes`), and a word that was changed shows `→ new text` in the transcript table.

## 1. Spelling convention (one spelling per word)
Chosen from the owner's own corrected transcript (`tests/fixtures/hinglish_clip_reference.txt`) and the spellings requested for this project.

| Written | Not written | Note |
|---|---|---|
| **voh** | vah, woh, wo, vo | |
| **yeh** | yah, ye | the owner's reference uses *yeh* |
| **toh** | to | only when a Hindi word is next to it (`agar nahin liya to consequences` → *toh*); English *to* (`want to pay`, `option to that prospect`) is never changed; `<Hindi word> to pay…` stays *to* |
| **nahin** | nahi, nahee | |
| **tumhaare / tumhaara / tumhaari** | tumhare … | same for hamaare/hamaara/hamaari |
| **theek** | thik | |
| **maine** | mainne, mene | |
| **mujhe** | mujhay | |
| **kuch**, **zyaadatar**, **hazaaron**, **aisa**, **sirf** | kuchh/kuchch, zyadatar/jyadatar, hazaaro/hazaron, aesa, sirph | |
| **hai**, **hum** | hay, ham | only with a Hindi word next to them (*hay* and *ham* are English words) |
| **lakh**, **crore**, **hazaar** | laakh/lakhs/lac, crores/karod/CRR, hazar/hajar | |
| **rupees** (as spoken) / **rupaye** | rupeez, rupis; rupe, rupay, rupaiye | `5 lakh rs` → `5 lakh rupees`; a prefix `Rs 500` is left alone |

Rules of the game: whole words only (never inside another word: *wonderful*, *yesterday* stay), the case of the original is carried over, punctuation is kept,
English words / names / acronyms / brands are not touched, Hindi is never translated or made formal, grammar mistakes of the speaker are kept.
**Add your own** variants without touching code: in the project's `overrides.json` add `"spelling": {"chaahie": "chahiye"}` (applied before the display glossary),
or use the *Display glossary* in section 2 (a glossary replacement always wins and is never polished again).

## 2. Numbers and amounts
* A spoken number word **directly before** lakh / crore / hazaar / thousand / million becomes digits: `paanch laakh` → `5 lakh`, `ek lakh` → `1 lakh`,
  `pachaas hazaar` → `50 hazaar`, `five lakh` → `5 lakh`. Number words without such a unit are never converted (`do you want`, `ek aisa partner`, `one hundred percent`).
* Bare 5–7 digit amounts get separators: `40000` → `40,000`, `500000` → `5,00,000` (Indian grouping; setting `number_grouping` = `indian` | `international` | `none`).
  Years and long numbers (`2021`, `9876543210`) and numbers that already have commas are left alone.
* A lone `1` between two words is the word *one* (`that 1 problem` → `that one problem`); `1 crore`, `number 1`, `1 lakh` stay digits.
* Format policy in one line: **digits + unit word as spoken** — `5 lakh rupees`, `50,000 rupees`, `1 crore`, `10 to 15,000 rupees`. No alternating `five lakh / 5 Lakhs / 500000`.
* **Nothing is invented.** If a unit or currency word has no number in front of it where one is likely (`agar ya rupees`, a pause before `rupees`) the word gets the flag
  `missing_amount` (tag in the transcript, listed under *Please check*) so you can listen and add the number. The recognition itself also reports amounts that one
  decoding pass heard and the result lacks (`quality.numbers_missing`). A built-in check proves every recognised digit still exists after the polish.

## 3. Homophones
`cells → sells`, `cell → sell`, `sail(s) → sale(s)` only when (a) the word's confidence is below 0.90 (clear audio is never overridden), (b) there is sales context within
six words (sales, story, prospect, price, close, call, tells …) and (c) no biology/boat context (blood, brain, white, phone, boat, sea …). `white blood cells`,
`the cells in the body`, `my cell phone` and any confidently recognised *cells* stay. Because the recogniser now keeps its own English words (see §6) `story sells` usually
arrives correct; this rule is the safety net.

## 4. Punctuation (sentence level, never per caption)
* A `?` is kept for any sentence with Hindi in it (the Hinglish model's mark is trusted; *kya/kaise/kyun/kaun…* and `…hai?` questions stay) and for English questions
  (wh-word + auxiliary, auxiliary + pronoun, tag questions, one-to-three-word echoes like `Right?`). A **fully English statement ending in `?`** gets `.`
  (`Tell them that problem, how that problem is affecting all the areas of your life?` → `…of your life.`). A `.` becomes `?` only for an unmistakable English question
  (`How is your health affecting your finances.`).
* A comma followed by a capitalised sentence starter (*Tumhaare, Now, We, Koi, Agar …*) becomes a full stop — the recogniser's own capital letter is the evidence;
  `Hey, I'm Raj` and lower-case continuations are left alone.
* Sentence starts are capitalised; a stray capital on a function word in mid-sentence is lowered (`ki My god` → `ki my god`, `bhi Apni` → `bhi apni`); `i` → `I`.
  Names, brands and acronyms keep their capitals.
* The last sentence of the clip gets a full stop when it has at least three words.
* No punctuation is invented otherwise (e.g. a missing full stop between two sentences stays missing).

## 5. What is measured, how to add and re-run tests
`.\.venv\Scripts\python.exe scripts\hinglish_eval.py run` (PowerShell, project root) runs `tests/fixtures/hinglish/cases.json` — raw recogniser output of real clips, the text
that must / must not appear, flags, and the first-caption time — and prints: cases per category, false corrections on the owner's corrected reference (must be 0),
WER / CER / missing-word rate of the reference clip (raw recogniser text, captions without the polish, final captions), number expectations met, mixed spellings,
`?` removed from statements, `.srt` completeness, amounts flagged. The same checks run in `pytest tests/core/test_hinglish_regression.py`.
* **Add a case** from any transcript: `scripts\hinglish_eval.py add-case --transcript <transcript.json> --from 39.5 --to 47.5 --id my_case --category numbers --clip "name.mp4" --expect "text that must appear" --evidence "why"` then edit `cases.json` if you want flags or `first_reveal_max`.
* **Re-test recognition on real clips** (slow, needs the models): `scripts\hinglish_eval.py audio --clips "D:\clips.mp4,D:\clips.mp4"` (or list your clips once in `work\hinglish_clips.json` as `{"name": "path"}` and pass the names).
* **Compare a model / setting change**: run the `audio` command before and after, then `run` on the new transcripts (`add-case`). Judge by the numbers, never by one clip; the GPU decoder is not bit-reproducible, so repeat a run before believing a difference of one or two words.
* Honest limit: the expectations are **not** listened-to ground truth. They are what independent recognisers agree on (stock turbo, stock large-v3, the Hinglish model) plus context; the owner's reference is the best evidence available and is itself marked provisional.

## 6. Why words were missing, and what changed (root causes)
| Symptom (owner's PC 3 clip) | Root cause | Fix |
|---|---|---|
| `agar ya rupees pay nahin karta to kal mujhe rupe pay` — both amounts gone | In the hybrid merge a Hindi stretch is replaced by the Hinglish model's words, but digits were treated like punctuation: the stock model's `40 ,000` was swallowed inside the stretch, the Hinglish model's `40000`/`50000` were skipped (`has_letters`), and `paanch laakh` was dropped as a "duplicate" of the stock model's `5`. Three models heard the amounts; the merge lost them. | `hybrid.merge`: numbers between Hindi words belong to the Hindi stretch, digits count as content, debris like `.7` does not, a stock-model number is kept only when the Hinglish model has no number there (never doubled), digits no longer make Hinglish words look like duplicates. |
| `that problem` for `that one problem` (twice) | same: the Hinglish model's `1` was skipped | same fix + `1` → *one* rule |
| `Tells story cells.`, first words `Stories batao` missing | The sequential stock decode skipped the first seconds; the hole was filled from the **Hinglish** model, which is weak on English. When that model also skipped a stretch, the Devanagari words stayed unconverted and were left out of the captions. | The hole in the stock pass is first filled from the stock model's own batched pass (`Engine._patch_skeleton`), so English words stay the stock model's (`tells, story sells`). A Hindi stretch the Hinglish model skipped is asked again for just that stretch (`_rescue_hindi_runs`, several windows, loops and wrong lengths rejected). |
| `vah`, `yah`, `to`, `thik`, `mainne`, `sirph`, `CRR`, `rs`… | spelling of the Hinglish model | §1 |
| `…of your life?`, `My god`, `gather` after `?` | punctuation / capitals of the recognisers | §4 |

Experiments that did **not** help (kept out of the code): padding the main decode with silence (made the first English word disappear), loudness-normalising the audio,
`temperature=0`, `no_speech_threshold`, VAD thresholds, `condition_on_previous_text` — each fixed one clip and broke another; the sequential stock decoder is simply unstable on
these clips (one run kept 36 words of a clip another run kept 270 of), so the coverage safety net (second decoding passes, window re-decodes, number audit) is the fix, not a setting.
Windows for the re-decodes start **without** silence in front: silence made the Hinglish model babble (`stories stories stories`).

## 7. Known limits
* The exact first ~0.7 s of PC 5 (`… tum jaa rahe ho`) is still recovered only partly (`call jab` instead of `sales call jab tum ja rahe ho`); low-confidence words are flagged.
* A missing full stop between two sentences is not restored; a Hindi `?` without a question word is trusted.
* Hindi number words are converted only before a unit word; compound Hindi numbers beyond the built-in table are left as spoken (add digits in the editor).
* Mixed-up word order from the two recognisers (`ke desperation saath`) cannot be detected from text.
* English route: the same recovery code runs, but the polish (spelling, punctuation) is off unless you choose *Always on*.
