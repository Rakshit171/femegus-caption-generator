# After Effects compatibility matrix

Rule: a version is "supported" only after the full test list passes **on that version**. One version at a time, in this order:
**2025 (25.x, primary) → 2024 (24.x) → 2026 (26.x)**. Fixes for a later version must not break an earlier one (regression-test every
supported version before marking the matrix). Version differences are isolated in adapter compatibility profiles; the engine, segmenter,
style and animation logic never see the host version.

| AE version | Status | Tested build | Adapter profile | Notes |
|---|---|---|---|---|
| **2025 (25.2)** | Primary target — Stage 4 (text layers + timing) **verified**; animation/styling/UI not yet built | 25.2x131 on dev PC | `ae25` | see AE_ADAPTER.md; Stage 5+ pending |
| 2024 (24.x) | Not started — begins only after 2025 is verified end-to-end | — | `ae24` (planned) | needs a 2024 install to test |
| 2026 (26.x) | Not started — after 2024 | — | `ae26` (planned) | UXP beta timing per Adobe: Nov 2026; ExtendScript unaffected |
| ≤ 2023, ≥ 2027 | Not claimed | — | — | |

## Per-version test checklist (copy for each version)
- [ ] Panel / script launches without error
- [ ] Reads project file; builds `Captions` comp with real text layers
- [ ] No layer in-point earlier than its word's reveal time (scripted inspection)
- [ ] Font family/weight/size/tracking/leading, fill colour, stroke, shadow applied
- [ ] Per-word keyframes (position/scale/opacity) + blur effect; easing curves match preview
- [ ] "Update" re-applies a changed style without touching timing or manual overrides
- [ ] Missing-font fallback message
- [ ] Long project (≈1500 words) opens/plays acceptably
- [ ] Hinglish (Roman) text editable and wraps
- Results: see the per-version tables below.

## AE 2025 (25.2x131) — results so far (2026-10-13)
| Checklist item | Result |
|---|---|
| Script launches without error | ✅ (Run Script File / dev watcher) |
| Reads project file; builds comp with real text layers | ✅ 345 words, 32 s |
| No layer in-point earlier than its word's reveal (scripted inspection) | ✅ 0 violations / 345 layers |
| Font family/size/colour/tracking/caps/gradient/glow/shadow applied | ✅ verified in dumps and renders (Arial, Poppins); **stroke untested** |
| Per-word keyframes (position/scale/opacity) + blur effect; easing matches preview | ✅ 1,725 sampled values vs shared evaluator: ≤ 0.014 px (2 presets) |
| "Update" re-applies a changed style without touching timing/overrides | ⚠️ replace-all works (35→35 layers); restyle-only update is Stage 5/6 |
| Missing-font fallback message | ✅ |
| Generate from the editor app, verified by read-back (timing + style) | ✅ 345 words (2026-10-14) |
| Release connect script `fcg_connect.jsx` (renamed from the dev stub): heartbeat seen as "connected 25.2x131"; 345 layers generated from the app and verified (2026-10-14) | ✅ |
| Audio-only footage (mp3): comp 1080×1920 + sound layer, 283 layers verified | ✅ (2026-10-14) |
| Long project: 1,520 layers, 9-min comp, all effects + keyframes — build 226 s, AE responsive, 7,600 animation samples verified | ✅ build; playback speed not measured |
| Words wider than the frame (45-letter word): shrunk to fit inside the safe area, never clipped | ✅ |
| All-caps styles: caps typed into the layer (AE "All Caps" option measured ~5 % wider, 24.0+ only) | ✅ |
| Long project (≈1500 words) | ⚠️ not yet; 345 words = 32 s (≈ linear → ~2.5 min expected, unmeasured) |
| Hinglish (Roman) text editable and wraps | ✅ editable text layers; wrapping is flow-layout only |

## Feature / limitation log
* 25.2: inPoint must be set before outPoint (setting it after shifts the out-point).
* 25.2: `AfterFX.exe -r/-s` had no effect on the running instance in this environment (documented as supported) — not relied on.
* 24.x / 26.x: not tested. API flags needed: `app.fonts` & `fontObject` need ≥ 24.0 (we guard with `fcgHostProfile`); `TextDocument.leading` ≥ 14.2.

## Look 2 "Soft Editorial" (AE 25.2x131, 2026-10-15)
| Item | Result |
|---|---|
| Text animators + Expression Selector created by script (`ADBE Text Animator`, `ADBE Text Expressible Selector`, `ADBE Text Opacity / Blur / Position 3D / Fill Color`) | ✅ match names confirmed on 25.2 (`probes/probe_text_animator.jsx`) |
| 78 layers (reference clip, all 6 key-word treatments) generated and verified by read-back (timing, text, size, fill, font incl. fallbacks, effects, animators) | ✅ 5.7 s |
| Per-letter opacity timing in AE vs the shared evaluator (rendered with aerender, linear and ease-out) | ✅ ≤ 0.1 % difference |
| Text-animator blur strength | ✅ measured: Gaussian σ ≈ 0.40 × value (preview uses the same factor) |
| Reference look rebuilt with the same code | ✅ verified, unchanged |
| AE 2024 / 2026 | ❌ not tested — text animators / expression selectors must be re-checked there |

## Look 3 "Clean 4-Word" (2026-10-17)
| Item | Result |
|---|---|
| Build in AE 25.2 with the slide-up ON and OFF (English 78 layers), and ON on the Hinglish clip (345 layers), read-back verification | ✅ all verified; keyframes ≡ shared maths (y ≤ 0.0033 px); rendered frames show the intended ease-out (TESTING.md) |
| New pieces exercised there: `duration 0` (no keyframes), `layout.centered.wrap:false` (one line), custom ease array `[0.22,1,0.36,1]`, look-carried grouping | ✅ |
| Honest limit | when the next caption starts < 0.48 s after a word, its slide is shortened to fit (15 % of the English clip's words, 31 % of the Hinglish clip's — fast speech); it never starts late |
