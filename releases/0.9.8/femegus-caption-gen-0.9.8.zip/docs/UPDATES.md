# Distribution and updates (for the owner)

Everything here is free: two GitHub repositories and the scripts in `scripts\`.

| Repository | Visibility | Holds |
|---|---|---|
| `femegus-caption-gen-private` | **private** | the full source (this project folder, minus what `.gitignore` excludes) |
| `femegus-caption-generator` | **public** | only the finished release files: `latest.json`, `releases\<version>\*.zip`, `looks\*.json`, `README.md`, `LICENSE` |

The app reads `https://raw.githubusercontent.com/Rakshit171/femegus-caption-generator/main/latest.json`. Nobody needs a GitHub account to download or update.

## Send the tool to someone
Send them the zip `releases\<version>\femegus-caption-gen-<version>.zip` (from the public repository, or from `dist\public\releases\...` after building). They unzip it, double-click **`Install-FemeGus.cmd`**, and follow `docs\FIRST_RUN.md`.

## Publish a new version or a new look
Everything is run in **PowerShell, in the project folder** (`C:\Claude\AE caption Gen`).

1. **Change something** (e.g. save a new look as `presets\my_new_look.json`, add `_look {title, description, tags}` to it).
2. **Bump the version:** edit `VERSION` (e.g. `0.9.1` → `0.9.2`) and add a `## 0.9.2` section with `- ` bullet points to `CHANGELOG.md` (the bullets are what users see as "what's new").
3. **Build:** `.\.venv\Scripts\python.exe scripts\make_release.py` — creates `dist\public`. It refuses to build if a file would not be accepted by the updater or if private details (your user name, e-mail, home folder) are found in files that ship.
4. **Test the tests:** `.\scripts\test.ps1`.
5. **Publish:** `.\scripts\publish.ps1` — shows what changes, asks you to type `PUBLISH`, then commits and pushes to the public repository.
6. **Back up the source (optional but recommended):** `.\scripts\push_source.ps1` — shows the files, asks you to type `PUSH`, uploads to the private repository.

A *look only* release is the same steps; users then see "New caption looks available" and install them with one click, without touching the program.
Users who already have your look under the same name get it as an **updated look**; their own saved looks are never changed.

## What an update changes on a user's computer
* **Look packs** → one `.json` file in `presets\downloaded\` (validated: allowed keys only, size limit, checksum). No restart.
* **App update** → the program files (`app`, `core`, `engine`, `adapters`, `scripts`, `docs`, built-in `presets\*.json`, a few top-level files) are replaced after a checksum check; the replaced files are first copied to `backup\<old-version>-<time>\`, and the update is undone automatically if anything fails. The user restarts the app. They can go back with **Go back to the previous version**.
* **Never touched:** `projects\`, `models\`, `.venv`, `work\`, `presets\user\`, `presets\downloaded\`, `engine\models_local.json`, settings.
* After an app update the Updates card says **"Update installed: version X — restart to finish"** with a **Restart now** button (the launcher `Start-FemeGus.cmd` / `scriptscgapp.ps1` starts the new copy on the same address and the page reloads by itself). The card compares the *installed files* with the published version, so after the restart **Check for updates** says "You have the latest version (X)". Before 0.9.4 the running program remembered its old version, which is why the Update button kept reappearing; people still on 0.9.3 must close the black window and start the app again once after updating.
* If `requirements*.txt` changed, the restart first installs the tested component versions (pip, needs internet, a few minutes; the card says so). Nothing is installed silently without the user pressing the restart button. **Repair components** (section 10) does the same on demand; **Copy support info** gives the versions and the end of the log for a bug report (no footage, transcripts or session token).
* Every library is pinned (`requirements.txt`) and installed against the full tested list (`requirements.lock.txt`); the System check warns when an installed version differs.
* **Release checklist for every change:** edit `VERSION` + `CHANGELOG.md` (the bullets are the in-app "what's new"), `python scripts\make_release.py`, `.\scripts	est.ps1`, `.\scripts\publish.ps1`, `.\scripts\push_source.ps1`. If you add or change a library, also update `requirements.txt` **and** `requirements.lock.txt` (a test fails if they disagree).

## Privacy and security
* Checking for updates is **off by default**. The installer asks; the user can change it in **10 · Export & help ▸ Updates**. A check makes plain GET requests for `latest.json` (and, when the user clicks Update/Install, for the zip/look files). The only thing sent is the app name and version in the request header, like any browser. No footage, transcripts, projects or file names are ever sent.
* Downloads must be `https`, must come from the update site's address, and must match the SHA-256 in `latest.json`. That protects against damaged downloads, not against someone who controls your GitHub account: **protect the account with two-factor sign-in** and a strong password. A look pack cannot run code (it is validated as data only); an app update contains code, so only publish what you trust.
* The public repository is readable by everyone, so the program code in the zip is readable too. Add a `LICENSE` file that says what others may do with it **before** the first publish (`publish.ps1` refuses without one).

## Testing an update on this computer without GitHub
Set the environment variable `FCG_UPDATE_BASE` to a local address that serves a `dist\public` folder (e.g. run `python -m http.server 8080 --directory dist\public`, then `$env:FCG_UPDATE_BASE="http://127.0.0.1:8080/"` before starting the app). Plain `http` is accepted only for `127.0.0.1`/`localhost`.
