# Installation guide (Windows 11, After Effects 2025)

Everything below runs in **PowerShell**, in the project folder (the folder that contains `README.md`; on the developer machine `C:\Claude\AE caption Gen`).
To open it: in File Explorer open the folder, click the address bar, type `powershell`, press Enter.

## The easy way (recommended): the guided installer
Unzip the release to a folder you will keep (e.g. `C:\FemeGus`) and double-click **`Install-FemeGus.cmd`**. It checks the computer (Python, graphics card, disk space,
internet, After Effects), offers to install Python if it is missing, asks a few questions with recommended answers (Hinglish model? update checks? desktop shortcut?),
runs the setup below, and ends with the system check. Run it again at any time to repair. Then follow [FIRST_RUN.md](FIRST_RUN.md).
In PowerShell: `.\scripts\install.ps1 -Preflight` only checks the computer and installs nothing; `.\scripts\install.ps1 -Yes` accepts the recommended answers.
The manual steps below do the same thing in separate steps.

## What you need
| | |
|---|---|
| Windows 10/11 | tested on Windows 11 |
| Python **3.10, 3.11 or 3.12** | from https://www.python.org/downloads/ — tick **"Add python.exe to PATH"** in the installer. 3.13+ is untested |
| Adobe After Effects | **2025 (25.2) is the only tested version**; 2024 and 2026 are planned and **not claimed** |
| NVIDIA GPU (optional) | recommended. Tested: RTX 3060 Laptop 6 GB. Without one, transcription runs on the CPU (about 7× slower) |
| Free disk space | about **5 GB** (packages ≈ 3 GB incl. GPU libraries, English model 1.6 GB, Hinglish model 1.5 GB) |
| Internet | **only for the one-time downloads**. Afterwards everything works offline; your footage never leaves the computer |
No account, subscription, API key or paid service is needed anywhere (see [LICENSES.md](LICENSES.md)).

## Step 1 — set up (once)
```powershell
.\scripts\setup.ps1                 # creates .venv, installs the speech engine and the NVIDIA GPU libraries, then runs a system check
```
Options: `-CpuOnly` (skip the GPU libraries), `-PreloadModels` (download the English speech model now instead of on first use), `-WithHinglish`, `-Dev` (test tools).
If PowerShell says scripts are disabled, run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, or start it with
`powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1`.

## Step 2 — Hinglish model (once, only if you will caption Hindi/Hinglish)
```powershell
.\scripts\setup_hinglish.ps1        # downloads the official Oriserve model and converts it (about 3 GB, a few minutes)
.\scripts\setup_hinglish.ps1 -CleanUp   # optional, afterwards: removes the conversion tools and original weights (saves ~4 GB)
```
Without it, English works fully; Hinglish/Auto fall back to a lower-quality method and say so.

## Step 3 — After Effects (once)
1. Open **After Effects ▸ Edit ▸ Preferences ▸ Scripting & Expressions** and tick **"Allow Scripts to Write Files and Access Network"** (needed so After Effects can send its report back).
2. Each time you start After Effects (once per session): **File ▸ Script ▸ Run Script File…** and choose  
   `<project folder>\adapters\jsx-core\fcg_connect.jsx`. No window appears. Nothing is installed and nothing in the After Effects folder is changed.
   If a startup warning dialog is open in After Effects, close it first — a modal dialog blocks all scripts.

## Step 4 — start the app
Double-click **`Start-FemeGus.cmd`** (or `.\scripts\fcgapp.ps1`). It prints an address with a one-time token and opens it in your browser. The page says
*"After Effects … connected"* in the top right when step 3 worked. Stop the app with Ctrl+C in its window.

## Check everything at any time
```powershell
.\scripts\fcgapp.ps1 --check        # or: the "Run system check" button in section 10 of the app
```
It lists what is ready, and for anything that is not, exactly what to do.

## Updating / moving / uninstalling
* **Move**: copy the whole folder anywhere you can write to (not `C:\Program Files`), then run `.\scripts\setup.ps1` again there. The Hinglish model path is re-registered by `setup_hinglish.ps1`.
* **Uninstall**: delete the folder. Models cached by Hugging Face live in `%USERPROFILE%\.cache\huggingface` (delete the `models--mobiuslabsgmbh--faster-whisper-large-v3-turbo` folder to reclaim 1.6 GB). Nothing else is outside the folder.
* **Reproduce the exact tested packages**: `.\.venv\Scripts\python.exe -m pip install -r requirements.lock.txt`.

## What the installer verified, and what it did not
* Verified on the developer machine: a clean-environment dependency resolution (`pip install --dry-run`) of `requirements.txt` + `requirements-gpu.txt` gives the same package set that was tested; a re-run of
  `setup.ps1` on the existing environment is idempotent; the system check reports correctly; `setup_hinglish.ps1` skips correctly when the model exists.
* **Not run end-to-end in this release:** a from-scratch install on a second, clean computer, and the full download-and-convert path of `setup_hinglish.ps1` (its individual commands were run by hand in Stage 2, the wrapper's skip path was tested).
