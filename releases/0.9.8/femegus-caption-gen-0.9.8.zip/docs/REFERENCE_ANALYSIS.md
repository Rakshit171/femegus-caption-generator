# Reference Video Analysis

Source: `reference/Video-44837.mp4` — 720×1280 (9:16), 23.976 fps, 23.1 s.
Only the **opening ~6 s** was inspected (as instructed). Frames were extracted with OpenCV
(already installed on this machine): every 0.25 s for 0–6 s, plus frame-by-frame (≈42 ms) sequences around
three moments (entrance of "You're edits", entrance of "Quality", exit of the first group at ≈1.8–2.1 s).
Images are in `reference/analysis/`. Everything below is **observed**, except items marked *(guess)*.

Non-caption editing in the clip (blur-zoom transitions at 0.0 and 4.0 s, light leak at 3.75 s) is video
editing, not captions, and is out of scope.

## 1. Structure: "groups" of words, shown cumulatively

| Group | Time (approx.) | Words (as shown) | Layout variant |
|---|---|---|---|
| 1 | 0.25 → 1.8 s | The reason / You're edits / Don't feel pro | **A** – mixed case, 3 tiers |
| 2 | 2.0 → ~2.9 s | Isn't the camera / Quality | **A** (2 tiers) |
| 3 | 3.0 → 3.9 s | ITS / YOU'RE / TEXT | **B** – italic caps stack |
| 4 | 4.0 → 4.9 s | That's / Exactly / How I | **A′** – all white, bold, stacked |
| 5 | 5.0 → 5.6 s | CAUGHT / YOU'R(E) / ATTENTION | **B** |

* Words appear **one at a time**, in speech order, and **stay visible** while later words of the same group
  appear (cumulative build-up). A group is therefore 2–7 words, driven by phrase, not a fixed count.
* At the end of a group everything **disappears at once** (hard cut: present at 1.800 s, gone at 1.842 s —
  at most ~1 frame, no visible fade-out). The next group starts a few frames later.
* The reference's own text has errors ("You're edits" for "Your edits", "ITS", "Was…"). The tool must therefore
  not copy the text — and this confirms the editable-transcript requirement.

## 2. Typography

* Typeface family: a **neo-grotesque sans** (Helvetica Neue / Neue Haas / Arial-like proportions) *(guess —
  not identified with certainty; to be matched against fonts installed on the user's PC in Stage 5)*.
* **Support words**: white, regular→medium/bold weight, small. Soft dark drop shadow for legibility.
* **Accent words**: ≈ **2×** the size of support words, **bold**, filled with a **vertical orange gradient**
  (lighter orange top → deeper red-orange bottom), with a soft **orange outer glow** and a subtle drop shadow.
  Variant B accent also reaches a yellow-orange.
* Variant B: **bold italic ALL-CAPS**, very tight leading (≈0.8–0.9, lines nearly touching), stacked
  3 words; one word orange, the others white (the white one can sit slightly right-shifted).
* Variant A′ (group 4): white bold mixed-case words stacked at different sizes, slight overlap.
* Tracking: slightly tight on accent words.
* Small **4-point sparkle glints** (✦) appear briefly beside emphasised words (≈0.75–1.25 s) — decorative, optional.

## 3. Layout

* Block is **horizontally centred**, vertically around **mid-frame (≈ 40–55 % of height)** — over the chest,
  not the usual bottom-third.
* Variant A is deliberately **scattered**: small white words top-left → giant orange in the middle →
  small white words lower-right, with slightly different baselines ("Don't" vs "feel" vs "pro" step downward).
  Placement is *consistent per template*, not random: the same slots recur from group to group.
* Everything stays inside the safe area; no clipping.

## 4. Animation (frame-level observations)

* **Support words** (e.g. "The reason", "Isn't the camera"): fade in **from heavy blur to sharp** over ≈ 3–5 frames
  (~0.12–0.2 s) with slight upward/lateral drift.
* **Accent words** (e.g. "You're", "edits", "Quality"): reveal over ≈ 5 frames (~0.2 s) with
  **ease-out slide from the left (≈ one word-width at the start) + opacity ramp + scale settle (starts larger/softer)**;
  the first visible frames are tinted more red and semi-transparent, then settle to full orange.
  During the move the next word briefly overlaps the previous one ("You'reedits" at 0.50–0.54 s) and then
  slides apart to its final position — i.e. **overlap during the move is acceptable; final layout is clean**.
* No overshoot/bounce was visible (restrained ease-out); *(guess)* a very small overshoot may exist but is not discernible at 24 fps.
* Between words of one group nothing else moves — the layout is **stable**; only the new word animates.
* Each word's reveal appears **locked to its onset** (e.g. "Quality" first visible at ≈ 2.33 s while the mouth is
  forming the word). Caveat: only video frames were inspected, not the audio, so exact sync is judged from the
  speaker's mouth and is unverified. Stage 2 will transcribe this clip and compare onsets numerically.
* Exit: hard cut (see §1).

## 5. Emphasis logic

* Accent words are content words (the *what*): "You're edits", "Quality", "You're" (B), "ATTENTION" is white while "YOU'RE" is orange —
  so emphasis is **not strictly a fixed position in the stack**; it is chosen per word *(editor judgement)*.
* Therefore: emphasis = suggested automatically (content word + duration + loudness), **overridable per word**.

## 6. What this means for the tool

1. Layout is **template-driven slots** (tier/offset/size/colour per *role*), with roles `support` / `accent`.
2. A word's visible time = its spoken onset; the group's exit = last word end + hold (configurable), hard cut by default.
3. Animation parameters per role: duration, easing, blur-in amount, slide offset, scale-from, opacity ramp, optional glow & sparkle.
4. All of the above must be **data**, not code, so the user can edit them.

---

# Reference 2 — `reference/look2/Video-34323.mp4` (look "Soft Editorial")

720×1280, 30 fps, 30.1 s, English, one speaker. Analysed 2026-10-15 from contact sheets every 0.5 s and frame-by-frame strips (30 fps) around ten moments;
the clip was transcribed with the engine (78 words, `work/look2/ref.transcript.json`) to compare caption onsets with speech. Observed unless marked *(guess)*.
Out of scope (not captions): the phone-frame / pixel-block background and "Made by" label, logo pill ("Whisper"), UI cards ("Any Audio file", "Analyzing", price cards),
the tan highlight box behind "parakeet TDT", light-leak/zoom/blur transitions at 0–2 s and 4 s. Text inside such assets was ignored.

## Structure and layout
* Captions are **short phrases (2–6 words) in centred lines**, over the chest (block centre ≈ 60 % of the frame height, the same default as look 1). Lines change with the *treatment* of the words: running text line → key-word line (bigger, other font) → running text line, e.g. `that transcribes` / `AN HOUR` / `of audio`; or one line with an inline bold word (`save **money**?`, `the **simple** setup guide.`).
* Line pitch is tight: ink boxes of neighbouring lines are ~0.1 × the smaller font size apart.
* **Exit = hard cut** (visible at 12.50 s, gone at 12.53 s). The next phrase starts a few frames later.
* The editor often shows a *whole phrase at once* ("The days of", "Ready to save money?") before the later words are spoken; elsewhere words come one by one with speech ("that" → "that transcribes"). Our tool must never show a word before it is spoken, so it always goes word by word.

## Typography (sizes relative to a 1080-wide comp, measured from widths and cap heights)
| Role | Look | Size | Notes |
|---|---|---|---|
| running text | light/regular grotesque (Google-Sans-like), white, tracking ≈ −2 % | ≈ 58 px | soft shadow; lower-case as spoken |
| key word A | **high-contrast serif, ALL CAPS**, white | ≈ 115 px (cap height ≈ 84 px) | "AN HOUR"; letter-by-letter reveal |
| key word B | serif italic, mixed case | ≈ 110 px | "Nvidia"; letter reveal |
| key word C | bold grotesque, white, soft white glow, tracking ≈ −3 % | ≈ 92 px | "completely free" |
| key word D | bold grotesque, warm tan (≈ #DDB08C) | ≈ 92 px | "paid options" |
| key word E | bold inline, same size as running text | ≈ 58 px | "money", "simple" |
| key word F | medium grotesque, pale yellow (≈ #FFF1B0) with a strong warm-yellow glow (≈ #FFC93C) | ≈ 86 px | `Comment "speech"`; letter reveal |

## Animation (frame-level)
* **Running-text words**: sharpen out of a blur while fading in and **rising ≈ 1 em** (e.g. "that": 64 → 46 px in 8 frames, mostly in the first 4); total ≈ 0.25 s, ease-out.
* **Serif / glow key words**: **letter by letter, ≈ 1 letter per frame (33 ms)**; each letter fades in over ≈ 5 frames (≈ 0.17 s) from blurred and slightly lower, and **newly shown letters are tinted pale pink (≈ #DCBBC2) that settles to the fill colour** over ≈ 0.3 s ("1 second": "second" still pink 4 frames after it appeared).
* **Bold key words**: whole-word fade + un-blur over ≈ 0.3 s (no letter stagger); "completely free" also gains its glow while sharpening.
* No overshoot/bounce seen. Whole captions never scale; the zoom visible in some frames is the video's own camera move.
* Onsets: the reference appears 0–0.25 s after the recognised word start (hand-timed); our reveals follow the same rule as look 1 (at or after the spoken onset).

## How this maps to the tool
New style capabilities (STYLE.md "Look 2"): `centered` layout, `line` own/inline, accent `variants` (rotation), per-letter `anim.unit = "letter"` with tint, `fit_width`, `font_fallbacks`. Verified in After Effects 25.2 (opacity timing ≤ 0.1 % vs the shared maths).
