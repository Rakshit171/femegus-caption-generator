# FemeGus Caption Generator — Architecture

## As built (v0.8, 2026-10-14) — and where it differs from the original proposal below
The four-module idea held: **engine** (speech) → **core** (timing, style data, shared animation maths) → **adapter** (After Effects) → plus a **local app**. What changed while building it:

| Proposal (Stage 1) | As built | Why |
|---|---|---|
| UI in a CEP or ScriptUI panel inside After Effects | **local web app** (`app/`, browser, 127.0.0.1) + a tiny connect script in After Effects | full transcript editor, waveform timeline and live preview are not possible in ScriptUI; CEP would need a registry debug flag. No After Effects installation or registry change is needed |
| Panel talks to After Effects with `evalScript` / command line | **file inbox** (`work/ae_inbox`): the connect script polls it with `app.scheduleTask`, runs jobs, writes reports | `AfterFX.exe -r/-s` did not reach the running instance on 25.2 (tested) |
| Whisper word timestamps, optional forced alignment | Whisper timestamps + **acoustic pauses/onsets from the loudness envelope**; no forced aligner | measured: sufficient, never earlier than the recognised start; the aligner was not needed |
| One transcription model | **English** = large-v3-turbo; **Hinglish** = turbo skeleton + Oriserve model merged by script; **coverage check** with a second decoding pass | single passes lost speech or translated Hindi (see TESTING.md) |
| Animation preview vs After Effects "should match" | **one shared ES3 file** (`core/anim`) and **one shared layout file** run in After Effects, the browser and Node; parity measured and tested | removes duplicate logic; exact by construction |
| CEP/UXP adapters per version | **ExtendScript only** (Adobe: unaffected by the CEP→UXP transition); version differences isolated in `fcg_profile.jsxinc` | simplest, most stable; UXP stub never needed on 25.2 |
| Support range "as wide as practical" | **25.2 only is tested**; 2024 → 2026 are planned ([AE_API_VERSIONS.md](AE_API_VERSIONS.md)) | rule: never claim an untested version |
Data flow: `transcript.json` → (`overrides.json`, grouping config, loudness envelope) → `groups.json` (timed captions) → style/layout/animation data → After Effects layers.
Style data can never write a reveal time (verified: identical in/out points across layouts and presets); user corrections live only in `overrides.json`.
Security of the app: local only, per-session token, Host check, no external resources ([APP.md](APP.md)).
File map: [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md). The rest of this file is the **original Stage 1 proposal**, kept for the reasoning behind the choices.

---

# Original Stage 1 proposal

Status legend: ✅ verified from official docs/this machine · ⚠️ not yet verified · ❌ known limitation

## 0. Facts established

| Item | Finding |
|---|---|
| Host | After Effects **25.2** (2025) at `C:\Program Files\Adobe\Adobe After Effects 2025` ✅ (read from `AfterFX.exe`) |
| GPU | RTX 3060 Laptop, 6 GB VRAM, driver 616.92 ✅ |
| Python | 3.10.6 installed ✅; `cv2`, `imageio_ffmpeg`, `numpy`, `PIL`, `torch 2.13 (CPU)` present; **no** `faster_whisper`, no `ffmpeg` on PATH |
| Node | installed ✅ (used for tests of shared JS) |
| ExtendScript | Adobe states "ExtendScripts are not affected by this transition" ✅ ([Adobe dev blog, Sept 2026](https://blog.developer.adobe.com/en/publish/2026/09/investing-in-the-future-of-creative-cloud-extensibility-uxp-comes-to-our-flagship-applications)) |
| CEP | Still works in AE 2025. After Effects stops accepting new CEP submissions and goes CEP-disabled-by-default in **Dec 2028**, removal after Dec 2029 ✅ (same source) |
| UXP for AE | **Public beta planned by Nov 2026** ✅ ([UXP for After Effects](https://developer.adobe.com/after-effects/uxp/)); docs list application / project item / layer / property / font APIs. ⚠️ Not confirmed: which AE builds run UXP (probably newer than 25.2), and whether text-document styling, keyframes and expressions are exposed. ⚠️ **Not a target for 25.2.** |
| faster-whisper | MIT license, CTranslate2 backend, `word_timestamps=True`, VAD filter, `int8_float16`; GPU needs CUDA 12 cuBLAS + cuDNN 9 ✅ ([repo](https://github.com/SYSTRAN/faster-whisper)). Models: large-v3, distil-large-v3, turbo. |

Not yet verified (to be done before any claim is made): the oldest AE version that supports every ExtendScript text/keyframe
property we use (per-property "since version" in the scripting guide); the CSXS version / debug-mode requirement for unsigned CEP
panels on AE 25.2; `afterfx.exe -r` command-line script execution.

## 1. Architecture

Four independent modules. Only the data files between them are shared.

```
┌──────────────────────── local machine only (127.0.0.1) ─────────────────────────┐
│                                                                                 │
│  [A] Transcription engine (Python, long-lived process)                          │
│        video → audio → faster-whisper (GPU, CPU fallback) → words+times         │
│                         └→ optional forced-alignment refine                     │
│                                  │ transcript.json                              │
│                                  ▼                                              │
│  [B] Timing & segmentation engine (pure Python, no I/O, unit-tested)            │
│        words + rules → groups (phrases) → reveal/exit times     → groups.json   │
│                                  │                                              │
│  [C] Style + animation spec (JSON data + one shared ES3 JS evaluator)           │
│        presets, templates, roles, easing curves                  → style.json   │
│                                  │                                              │
│  project file  <video>.fcg.json = transcript + edits + overrides + style        │
│                                  │                                              │
│  [D] After Effects adapter(s)  ── reads project file ──► builds editable comp    │
└──────────────────────────────────────────────────────────────────────────────────┘
```

### [A] Transcription engine (`engine/`)
* Long-lived local Python process; the Whisper model is loaded **once** and kept warm (no reload per request).
* Interface: CLI (`fcg transcribe video.mp4 → transcript.json`) and a localhost-only HTTP/JSON API with a job queue and
  progress, so the panel never blocks AE.
* Audio decode via PyAV (installed with faster-whisper) — no separate FFmpeg install needed; `imageio_ffmpeg` is a fallback.
* Model plan for 6 GB VRAM (to be benchmarked on this laptop, numbers are not claimed yet):
  default **large-v3-turbo, int8_float16 on GPU**; alternatives `distil-large-v3` (English, fastest), `large-v3` int8_float16,
  and CPU `int8` fallback (i9 + 64 GB makes this viable). Not "largest = best".
* Word timing: Whisper word timestamps first; measure drift on real clips (the reference video is the first fixture); add forced
  alignment (wav2vec2-style) only if measured error justifies the extra dependency.
* Output keeps raw recognised text; **no silent rewriting**. Each word keeps `confidence`; low-confidence words get flagged in the editor.

### [B] Timing & segmentation engine (`core/segmenter/`)
Pure functions: `words[] + rules → groups[]`. Fully unit-tested, independent of AE and of Whisper.

### [C] Style, templates, animation spec (`core/style/`, `core/anim/`)
All visual decisions are **data** (JSON): fonts, sizes per role, colours/gradient, glow, stroke, shadow, layout template slots,
per-role animation (duration, easing, slide offset, blur, scale-from, overshoot, stagger), group exit behaviour.
One animation evaluator written in **ES3-compatible JavaScript** is used by *both* the in-panel preview *and* the ExtendScript
keyframe generator, so preview and final output cannot diverge (verified by a Node test that samples both).

### [D] After Effects adapters (`adapters/`)
| Adapter | Tech | Purpose | Target |
|---|---|---|---|
| `jsx-core` | ExtendScript (ES3) | builds comp, text layers, keyframes from the project file; idempotent *update* | **AE 25.2 (tested)**; other versions only after testing |
| `scriptui-panel` | ScriptUI + `jsx-core` | minimal UI, no registry/AE-install changes (run via File ▸ Script ▸ Run Script File) | AE 25.2 |
| `cep-panel` | CEP (HTML/JS) hosting the full UI, calls `jsx-core` through `CSInterface.evalScript` | rich UI: transcript editor, timing, live preview, style editor | AE 25.2 (⚠️ may need debug-mode registry flag; asked before touching) |
| `uxp-panel` | UXP | future | **stub only until a UXP build is available to test** |
At start-up the adapter reads `app.version`, selects a compatibility profile (feature flags such as `textDocument.tracking`),
and refuses unsupported operations with a clear message instead of calling missing APIs.

### Communication
* Engine ⇄ UI: HTTP on `127.0.0.1:<port>` with a random per-session token; nothing is exposed beyond localhost; footage never leaves the machine.
* UI → AE: `evalScript("buildCaptions('<path to project file>')")` (CEP) or direct call (ScriptUI). Large data goes by **file**, not by string.
* ScriptUI-only mode can launch the engine via `system.callSystem` (requires AE pref *Allow Scripts to Write Files and Access Network*).

## 2. Widest practical version range
* **Baseline** = ExtendScript + ES3 (ExtendScript is explicitly not part of the CEP→UXP removal). Core logic is not coupled to AE, so
  a compatibility change touches only the adapter.
* **Claim:** AE 2025 (25.2) only, at first. Older versions get claimed one-by-one *only when tested on that version*.
  A follow-up task (Stage 1b) tabulates, from Adobe's scripting guide, the "since version" of every API we use to find the oldest
  *plausible* version; testing still needs a copy of that version.
* Known limitation: features that exist only in newer AE (e.g. some text animator / font APIs) get a fallback path or are disabled per profile — never silently dropped.

## 3. Project structure
```
AE caption Gen/
  README.md  CLAUDE.md
  docs/            ARCHITECTURE.md  REFERENCE_ANALYSIS.md  (+ TROUBLESHOOTING.md later)
  reference/       Video-44837.mp4  analysis/*.jpg
  engine/          transcription service, model mgmt, audio extraction, CLI, HTTP API
  core/
    segmenter/     grouping + timing rules (pure, tested)
    style/         schema, presets, layout templates (JSON) 
    anim/          easing + evaluator (ES3 JS, shared)
  adapters/
    jsx-core/      ExtendScript comp builder / updater
    scriptui-panel/  cep-panel/  uxp-panel/
  presets/         user-editable style & animation presets (JSON)
  tests/           unit tests, golden JSON fixtures, Node tests for ES3 JS, AE inspection scripts
  scripts/         Windows setup / run helpers (.ps1)
```

## 4. How premature reveal is made impossible (timing engine)
Single invariant, enforced in code and by tests:

> `reveal_time(word) ≥ word.start` and `layer.inPoint(word) = reveal_time(word)` — for every word, always.

1. Reveal time comes **only** from the word's spoken onset (+ a user offset that is clamped ≥ 0 by default; a deliberate negative "lead" is an explicit opt-in, off by default).
2. Grouping decides *which words share an exit time and a layout* — it never changes when a word becomes visible. Layout of the full group may be pre-computed (so positions don't jump when later words arrive), but unspoken words **do not exist on screen**: each word is its own text layer whose in-point is its reveal time and whose opacity animation starts at that time.
3. **Hard boundaries** the segmenter will never merge across: sentence-ending punctuation (`. ? !`), a pause longer than `hard_pause_ms`, and a speaker/segment break. Soft preferences: commas, conjunctions, a pause > `soft_pause_ms`, balanced length. Optimised by dynamic programming over candidate break points, with `max_words`, `max_chars_per_line`, `max_lines`, `min_words` (all configurable).
4. Exit = last word end + `hold` (adapts to speaking speed: min readable duration per word count), **capped just before the next group's first reveal** → no overlap with the following phrase; fast speech shortens holds, slow speech lengthens them up to a max.
5. Invalid input (zero/negative durations, overlapping words, `end<start`, empty text) is sanitised with a recorded warning, never invented.
6. Tests: property tests (random word streams) asserting the invariant; fixtures for slow/fast speech, pauses, long sentences, 1-word phrases, speed changes; plus checking the *generated AE comp* (in-points) by script.

## 5. Why style/animation can be changed without touching timing
Data flow is one-directional and layered:

`transcript (words+times) → groups (times) → [style+template+animation spec] → AE layers`

* The style/animation spec has **no write access** to word start/end/reveal times — it only maps *roles* (`support`, `accent`, per-word overrides) to visuals and defines animation *relative* to the reveal time (e.g. "ease-out slide over 0.2 s starting at reveal").
* Changing font/colour/preset/easing therefore never invalidates transcription or grouping; regeneration re-runs only stage D (the "Update" command). Re-grouping re-runs only B+D. Re-transcribing is only ever triggered explicitly.
* Manual overrides (per word/group: emphasis, colour, position, text correction, time nudge) are stored **separately** in the project file and re-applied on top of automatic results, so regeneration doesn't wipe them.
* Animation duration is clamped to the available window (e.g. ≤ next word's gap in fast speech) so a style choice cannot cause overlap or unreadable motion; the clamp is reported, not hidden.

## 6. AE output design
* One comp (`Captions`), one **text layer per word** (named `g012·w03·edits`, colour-labelled by role), in/out points set from timing; one controller null for global offset/scale. Per-word layers are required by the reference (each word has its own size, colour, position and entrance). Keyframes only on properties that animate (≈ 4–6 per word). Optional: precompose per group (decision after testing 10-minute projects).
* Blur-in via Gaussian Blur effect, gradient/glow via layer styles or an effect — ⚠️ gradient fill on live text is not available through the plain text API; Stage 5 verifies options (layer style, Gradient Ramp + track matte, or solid fill fallback) before promising it.
* Text stays real, editable AE text; "Update" is idempotent (keyed by word id stored in layer comment).

## 7. Free / paid classification
All free & open-source: Python, faster-whisper (MIT), CTranslate2 (MIT), Whisper weights (MIT), NVIDIA cuBLAS/cuDNN redistributable wheels (free, NVIDIA licence — not open source, free to use), ExtendScript/CEP (included with AE). Your After Effects licence itself is the only paid component. No cloud APIs. Internet is needed only once to download packages and model weights.

## 8. Staged plan
1. ✅ Architecture + reference analysis (this document).
1b. Per-API version table → proposed support range.
2. Venv, faster-whisper, model benchmark, `transcribe` CLI → `transcript.json`; compare against reference video.
3. Segmenter + tests; transcript/timing editing data model.
4. `jsx-core`: build comp from a hand-written fixture; inspect in AE 25.2.
5. Reference-style templates + animation; gradient/glow solution.
6. UI (CEP/ScriptUI), live preview, preset manager.
7. Test matrix, bug fixing, perf on a long video.
8. Installer scripts, README, troubleshooting.
