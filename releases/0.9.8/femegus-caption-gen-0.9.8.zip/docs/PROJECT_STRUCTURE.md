# Project structure — what each part is for

```
AE caption Gen/
├─ README.md  CLAUDE.md                 user guide · development rules + progress log (for the developer/AI sessions)
├─ Start-FemeGus.cmd                    double-click launcher for the app
├─ requirements*.txt                    runtime / GPU / dev dependencies · requirements.lock.txt = exact tested set
├─ scripts/
│   ├─ setup.ps1  setup_hinglish.ps1    one-time installation (packages · Hinglish model conversion)
│   ├─ fcgapp.ps1                       start the app (also: --check = system check)
│   ├─ fcg.ps1                          engine CLI: transcribe · envelope · evaluate (word error rate)
│   ├─ fcgcore.ps1                      timing core CLI: build captions from a transcript
│   ├─ test.ps1                         run the tests (fast / -Full)
│   └─ ae_run.ps1  ping.jsx             developer harness: send a job to After Effects through the connect script
├─ engine/        (speech recognition — no After Effects code)
│   └─ fcg_engine/   transcribe.py (faster-whisper wrapper, batched/sequential) · engine.py (routing, coverage fusion) · hybrid.py (Hinglish merge)
│                    coverage.py (speech-coverage check + gap fusion + start/Hindi-window rescue) · quality.py (flags) · audio.py (loudness envelope) · evaluate.py (WER)
│                    errors.py (plain-language errors) · cuda_setup.py · models.py · schema.py
├─ core/          (shared caption brain — pure Python, no models, no After Effects)
│   ├─ fcg_core/     segmenter.py (phrase grouping) · timing.py (reveal/exit) · audio_features.py (acoustic pauses/onsets) · edits.py (your corrections)
│   │                textnorm.py (15 ,000 → 15,000; glossary) · hinglish.py (spelling / numbers / punctuation text polish) · emphasis.py (accent suggestions) · verify.py / ae_verify.py (invariant + After Effects read-back checks)
│   └─ anim/anim.js  animation maths shared by the preview AND After Effects (ES3)
├─ adapters/jsx-core/   (the only code that touches After Effects — ExtendScript ES3)
│   ├─ fcg_connect.jsx                  the connect script you run once per After Effects session
│   ├─ fcg_run.jsx                      manual entry (File ▸ Script ▸ Run Script File → pick groups.json)
│   ├─ lib/   fcg_build (comp, layers, effects, keyframes) · fcg_layout (tiers/stack/flow geometry) · fcg_profile (version profile) · fcg_json · fcg_util · fcg_job · fcg_connect_run
│   └─ probes/   throw-away experiments (not used at run time)
├─ app/           (the local web app)
│   ├─ fcg_app/   server.py (API, security) · ops.py · project.py · jobs.py · ae_bridge.py · selfcheck.py · fontscan.py
│   └─ web/       index.html · style.css · js/ (panels incl. panel_look.js = the looks gallery, look_thumb.js, widgets.js, preview, timeline)
├─ presets/       reference_style.json (the reference look) · soft_editorial.json (look 2) · clean_poppins.json · user/ (yours)
├─ projects/      one folder per video: transcript.json · overrides.json (all your corrections) · groups.json · envelope.json · project.json
├─ models/        ct2/hinglish-apex-fp16 (converted Hinglish model) · hf/ (original weights; deletable after conversion)
├─ reference/     the reference video and the frames analysed for the look · look2/ = the second reference clip (look "Soft Editorial")
├─ tests/         engine · core · anim · ae (real After Effects dumps) · app · fixtures
├─ docs/          this documentation
└─ work/          scratch: test renders, variants, After Effects inbox/reports (safe to delete)
```
Dependency direction (never reversed): `app` → `core`, `engine`; `core` and `engine` know nothing of each other or of After Effects; only `adapters` touches After Effects objects.
The same two shared source files are used in three places on purpose: `core/anim/anim.js` and `adapters/jsx-core/lib/fcg_layout.jsxinc` run in After Effects, in the browser preview, and in Node tests.
