# Caption timing & segmentation core (`core/fcg_core`) — Stage 3

Pure Python (stdlib only). No After Effects code, no speech-model code. Input: engine `transcript.json` (+ optional `overrides.json`, config, loudness envelope).
Output: `groups.json` — caption groups with a **reveal time per word** and an **exit time per group**.

```powershell
.\scripts\fcg.ps1 envelope "C:\path\video.mp4" --out work\clip.envelope.json            # loudness envelope (10 ms), once per video
.\scripts\fcgcore.ps1 build work\clip.transcript.json --envelope work\clip.envelope.json --out work\clip.groups.json --show
.\scripts\fcgcore.ps1 defaults                                                           # every tunable parameter with its default
```
`build` exits with code 2 and prints `[VIOLATION]` lines if any invariant below is broken.

## Pipeline
1. **Overrides** (`edits.py`): text correction, time edits, delete, insert, forced break / join, role & style pass-through. Engine output is never modified.
2. **Junk policy**: words flagged `non_roman`, `repeat_run`, `prompt_leak` are excluded from captions (configurable; `keep:true` rescues one). They are listed under `excluded` and force a group boundary.
3. **Display text** (`textnorm.py`): `15 ,000`→`15,000`, `one -on -one`→`one-on-one`, user glossary (`crr`→`crore`, `rs`→`rupees`). Raw `text` stays; the caption uses `display`.
4. **Audio cues** (`audio_features.py`, optional): real silence between words (Whisper timestamps abut, hiding pauses) and acoustic onset.
5. **Segmenter** (`segmenter.py`): hard boundaries, then an optimal split (dynamic programming) of every stretch between them.
6. **Timing** (`timing.py`): reveal and exit times. 7. **Emphasis** (`emphasis.py`): suggested accent/support roles. 8. **Verify** (`verify.py`).

## Guarantees (enforced by `verify.py` at runtime and by 35 core tests)
| Guarantee | How |
|---|---|
| A word is never revealed before it is spoken | `reveal = max(recognised start, acoustic onset) + offset`; negative offsets are ignored unless `allow_lead` is set; onset refinement can only move **later** |
| A group never contains words from the next sentence | hard boundaries (below) can never be crossed |
| No overlap between consecutive groups; the last word is never cut | `exit ≤ next first reveal − exit_gap`, `exit ≥ last word end` |
| Every word appears exactly once, in order | coverage check |
| Style / animation choices cannot move a reveal | style data is only passed through (`style_override`); animation is defined relative to `reveal` |
| Text corrections keep timing | edits replace `text` only |
Overlap-avoidance wins over visibility: when speech is so fast that the next group starts immediately, the last word is on screen only briefly and a warning is emitted.

## Hard boundaries (a group can never span them)
`sentence` (`. ? ! … ।`, not Mr./Dr./vs.…) · `pause` (≥ `hard_pause_s` = 0.45 s, measured in the audio when an envelope is given) ·
`sentence_cue` (next word Capitalised + previous word unpunctuated + real pause ≥ `sentence_cue_pause_s` = 0.10 s; recovers sentence starts where the recogniser
dropped punctuation, e.g. "…comments down below | India mein hazaaron…") · `excluded` (junk word between) · `forced` (user).
Why audio pauses: on the real Hinglish clip the timestamp gap at "below | India" was 0.00 s but the audio pause 0.14 s; real sentence breaks measured 0.13–0.56 s versus
~0.04 s inside phrases. A fixed "0.6 s pause" would never have fired for this speaker.

## Soft cues (decide where a long stretch is cut; weights are config)
Bonus: pause length, comma/colon/dash, recogniser segment end, capital after unpunctuated word, conjunction starting the next group. Penalty: ending a group on a function
word (the, of, and, ka, ke, ki…), ending on a bare number ("over 1 | crore"), a last word that would be on screen < 0.2 s, groups below `min_words`, distance from `target_words`.
Size limits: `max_words` 7, `max_chars` 36, `max_duration_s` 3.4.

## Reveal & exit
`exit = max(last end + hold, first reveal + readable)` where `hold = clamp(0.8 × average word duration, 0.15, 0.8 s)` (slower speech ⇒ longer hold),
`readable = max(0.6 s, 0.22 s × words)`, then capped just before the next group (default gap 0.04 s ≈ 1 frame; set `exit_gap_s: 0` for a same-instant hard cut like the reference).
Frame snapping is done only by the After Effects adapter.

## Onset refinement (`onset_mode`)
Whisper starts words 0–160 ms early relative to the audio. `off` · `silence` (default; if the recognised start lies in quiet audio, wait for the sound, ≤ 0.12 s)
· `slope` (also in continuous speech move to the steepest energy rise). Measured on the two clips: `silence` touches 12–14 % of words (mean 6–7 ms);
`slope` touches ~half (mean 31–40 ms). Not yet judged by eye in After Effects — decide with the live preview (Stage 6).

## Real-data results (2026-10-13)
Hinglish clip (353 words): 91 groups, 3.8 words/group, all 7 unpunctuated sentence starts found (`sentence_cue`), 0 violations, 4 short-visibility warnings.
English reference (97 words): 24 groups, 0 violations. Random streams (slow / fast / speed-changing, 360 seeds): 0 violations.

## Emphasis stop-words (Stage 7)
The default accent suggestion ignores English *and* common Roman-Hindi grammar words (agar, karo, rahe, hai, ko, se, phir, …). Add your own with the grouping setting
`accent_stop_words` (a list). Manual A/s toggles always win.

## Known limitations / next
* Pause thresholds are fixed (configurable) rather than speaker-adaptive; a calibration helper is a possible later addition.
* Emphasis is a heuristic suggestion (length, duration, loudness, numbers/capitals, stop-word list); always overridable per word.
* Group weights were tuned by eye on two clips — expect tweaks once captions can be viewed in After Effects (Stage 4/5).
* Layout (which line/slot each word takes) is Stage 5; the segmenter only decides grouping and timing.
* Hinglish function-word lists are small and hand-written.
