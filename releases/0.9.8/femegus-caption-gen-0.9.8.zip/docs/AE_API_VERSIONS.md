# After Effects API versions (the "Stage 1b" table)

Purpose: before testing After Effects 2024 (24.x) and 2026 (26.x), list every host API the adapter uses, what Adobe's scripting guide says about *when it appeared*, and what is verified.
Source: the After Effects Scripting Guide ([ae-scripting.docsforadobe.dev](https://ae-scripting.docsforadobe.dev/)), pages read 2026-10-13/14. **"Not stated" means the guide gives no "since" note; it does NOT prove the API exists in an older version.**
Nothing here is a support claim: only **25.2 is tested** (see COMPATIBILITY.md).

| API (used for) | Guide says | Verified |
|---|---|---|
| `app.version` (profile / warning when not 25.x) | since 12.0 | 25.2 |
| `app.fonts.getFontsByPostScriptName` (missing-font check) | **24.0** | 25.2. The adapter **skips this check** below 24 (`profile.hasAppFonts`) |
| `TextDocument`: `font, fontSize, fillColor, applyFill, strokeColor, strokeWidth, strokeOverFill, applyStroke, tracking, justification, text, resetCharStyle` | no "since" note (long-standing) | 25.2 |
| `TextDocument.fontCapsOption`, `autoKernType`, `fontObject` | 24.0 | **no longer used** (caps are typed; see AE_ADAPTER.md) |
| `TextDocument.leading` | 14.2 | not used |
| `LayerCollection.addText / add`, `Layer.duplicate / moveToBeginning / remove`, `Layer.comment / inPoint / outPoint / startTime / label` | not stated | 25.2 (in/out order gotcha found) |
| `AVLayer.sourceRectAtTime` (word boxes for layout) | not stated | 25.2; returns ink bounds |
| `Property.setValueAtTime / valueAtTime / setTemporalEaseAtKey / isSpatial`, `KeyframeEase` | not stated (valueAtTime waits for expressions since 13.6) | 25.2; exact vs the shared maths |
| Effects by match name: `ADBE Ramp`, `ADBE Glo2`, `ADBE Drop Shadow`, `ADBE Gaussian Blur 2` and their parameter match names | not in the guide (effect catalogue) | 25.2 only — **must be re-checked on 2024 and 2026** |
| Text animators (look 2): `Layer.property("ADBE Text Properties").property("ADBE Text Animators").addProperty("ADBE Text Animator")`, `ADBE Text Expressible Selector` → `ADBE Text Expressible Amount` (expression set via `Property.expression`), animator properties `ADBE Text Opacity`, `ADBE Text Blur`, `ADBE Text Position 3D`, `ADBE Text Fill Color`; expression variables `textIndex`, `time`, `thisLayer.inPoint` | not in the guide (match names) | 25.2 only — **must be re-checked on 2024 and 2026** |
| `AVItem.hasVideo / width / height / frameRate / duration`, `FootageItem.mainSource.file`, `app.project.importFile`, `items.addComp` | not stated | 25.2 |
| `app.scheduleTask / cancelTask`, `app.beginUndoGroup`, `#targetengine` (connect script) | not stated | 25.2 |
| `File`/`Folder` read, write, `$.evalFile` | ExtendScript core | 25.2; writing needs the "Allow Scripts to Write Files" preference |
| Newer APIs seen in the guide (not used): `LayerCollection.addVerticalText` 24.2, `addParametricMesh` 26.3 | | shows 26.x exists |
| UXP / CEP | not used. Adobe: ExtendScript is "not affected" by the CEP→UXP transition; UXP public beta announced for Nov 2026 | n/a |

## What the 2024 and 2026 passes must test (one version at a time, 2025 first — already done)
1. The three effects + their parameters by match name; Gradient Ramp on text respecting letter shapes; Glow/Drop Shadow ranges (shadow opacity 0–255, glow threshold/intensity 0–255).
2. `sourceRectAtTime` ink-box numbers (layout parity vs the browser preview: ≤ 1 px mean).
3. Keyframe influence/speed mapping (parity with `core/anim/anim.js` ≤ 0.02 px).
4. in-point-before-out-point behaviour, `startTime` stays 0, template duplication speed.
5. Missing-font fallback, audio-only footage, `app.scheduleTask` connect script, "Allow Scripts to Write Files" preference location and name.
6. The complete read-back verification (`ae_verify`) on a 300-word clip, then a 1,500-word clip.
7. Look 2: text animators + Expression Selector present and behaving (opacity/blur/position/fill-colour per letter), expression engine (JavaScript) available, rendered opacity vs `FCGAnim.letterAt` (≤ 0.1 %), blur σ factor (0.40 on 25.2).
Record each result in COMPATIBILITY.md; version differences go into `lib/fcg_profile.jsxinc` flags, never into core/engine code.
