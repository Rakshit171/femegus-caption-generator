# Stage 7 — test matrix and results (2026-10-14)

All results are from real runs on this machine (RTX 3060 6 GB, After Effects 25.2x131). "Reference clip" = the owner's Hinglish video with a provisional
word-level reference (353 words). Nothing here is claimed beyond what is listed; open items are at the end.

## Automated suite
`.\.venv\Scripts\python.exe -m pytest tests -q` — **113 tests, ≈18 minutes** (it really transcribes several clips). Last full run: 113 passed (2026-10-14).
Fast subset (≈10 s, no models): `.\.venv\Scripts\python.exe -m pytest tests/core tests/anim tests/ae tests/engine/test_coverage.py tests/engine/test_hybrid.py tests/engine/test_quality_and_sanitize.py -q`
(PowerShell, in `C:\Claude\AE caption Gen`). Layers: engine (flags, hybrid, coverage, bad input, real-clip regressions),
core (segmenter / timing / edits / emphasis, property tests on 360 random streams), animation + layout maths (Node), After Effects fixtures (real dumps), app API.
Clip-dependent tests skip themselves when the owner's files are absent.

## Real-speech robustness (reference clip, full pipeline: transcribe → group → invariants)
The reference clip was time-stretched / edited with ffmpeg to create the conditions on your QA list. WER is against the provisional reference.

| Condition | Words | WER | Captions | Timing violations | Notes |
|---|---|---|---|---|---|
| Normal speech (control) | 351 | **3.4 %** | 91 | 0 | |
| **Fast** speech (1.4×, 4.2 words/s) | 334 | 14.4 % | 86 | 0 | 17 captions end on a very short last word (reported as warnings; fast speech leaves no room without overlapping the next caption) |
| **Slow** speech (0.75×) | 353 | 7.4 % | 92 | 0 | |
| **Long pause** (2.5 s silence inserted mid-speech) | 351 | 4.5 % | 89 | 0 | the pause became a caption boundary |
| **Speed change** (0.8× then 1.35×) | 344 | 16.4 % | 88 | 0 | |
Honest reading: accuracy falls with speech rate (a 1.4× rate is unusually fast), but **timing guarantees never broke** and no speech went missing.

## Second and third clips (owner's files, Stage 7) — and the failures they exposed
| Clip | Result |
|---|---|
| `Cutted version if you selling.mp4` (41 s, Hinglish: Hindi sentences around English business terms) | **first run silently lost ~70 % of the speech** (36 words; "market market market…" loops from the Hinglish model; forced-English route produced a fluent *translation* instead of what was said). Now 166 words, no uncovered speech |
| `60 seconds audio.mp3` (actually 85 s, nearly pure Hindi, audio only) | first run lost the **last ~11 s** (233 words). Now 276–284 words, complete |
| American-accent English reference (23 s) | unchanged, 97 words |
No reference transcripts exist for the two new clips, so **their accuracy is not measured** — only completeness (no loud audio without words) and sanity of the text. Please correct them
if you want them added as numeric regression fixtures.

### What was wrong and how it is handled now
1. **Long-form decoding can drop whole stretches or loop** — measured on two clips. Batched decoding (independent VAD chunks) is robust but **less accurate on digits** (reference clip 10.5 % WER vs 3.4 %).
2. Therefore the engine is *sequential-first* and **verifies its own coverage**: it compares the words against the loudness of the audio, finds loud stretches with no usable words (looping or junk words do not count),
   and only then runs the batched decoder and fills the holes from whichever pass has the words (`engine/fcg_engine/coverage.py`). Remaining holes are shown in the UI (red on the timeline, a card in section 1) and warned about.
3. The same check fills holes inside the Hinglish hybrid from the Hinglish model's own words.
4. Forced **English mode translates Hindi** (shown again here). Use Auto or Hinglish for mixed speech.

## QA checklist from the master prompt
| Item | Evidence | Status |
|---|---|---|
| Slow / fast speech, pauses, speed changes | table above (real audio) | ✅ |
| Sentence boundaries, long sentences, very short phrases | `tests/core` + real clips; 7 unpunctuated sentence starts recovered on the reference clip | ✅ |
| Incorrect transcription corrected manually | API + UI (edited "CRR"→"crore": reveal unchanged, 0 violations) | ✅ |
| Words that overflow the layout | After Effects run with 45- and 34-letter words: all 15 words inside the safe area, long ones shrunk to 25 % / 36 % (reported) | ✅ (a 25 % word is small but readable; it is never clipped) |
| Font and colour changes, preset changes | two real presets built in After Effects: all in/out points identical, style verified on every layer | ✅ |
| Different caption durations | 360 random streams (slow/fast/mixed) property-tested; invariants never broken | ✅ |
| Preview ≡ final output | position error 0.56 / 0.33 px mean, identical fit factors; animation ≤ 0.014 px | ✅ |
| Missing fonts | After Effects substitutes Arial and warns | ✅ |
| Missing model files | Hinglish model missing → stock fallback + warning; any model missing → plain-language message (internet needed once) | ✅ |
| Bad input | non-media file refused (HTTP 415, no project created); silent audio → "no speech", no false alarm | ✅ |
| Installation and launch in After Effects | connect script via File ▸ Script ▸ Run Script File; no installer, nothing in the After Effects folder; works on **25.2 only** | ✅ for 25.2 |
| Audio-only input | mp3 → preview on a black 9:16 stage; 283 layers built in After Effects with the sound as a layer; verified | ✅ |
| Long project | **1,520 layers** (9 min comp, all effects + keyframes) built in 226 s; After Effects stayed responsive (4 GB); timing/text/style/7,600 animation samples verified | ✅ build; playback speed with 1,520 glow layers **not measured** |

## Bugs found by Stage 7 and fixed
1. Sequential decoding drops/loops (see above) → coverage check + fusion.
2. Auto routed the new mp4 to Hinglish (correct), but its first-pass Hindi-mode skeleton was Devanagari *garbage* for much of the clip — the decode failure above, not the routing, was the fault. It does show the routing rule is only a heuristic (see limitations).
3. False "missing speech" alarm on silent audio → needs dynamic range + a minimum loudness before anything counts as speech.
4. Raw library errors for missing models / unreadable files → plain-language messages (`engine/fcg_engine/errors.py`).
5. Audio-only files broke the After Effects builder (footage without a picture has no size) and the preview.
6. Emphasis picked Hindi grammar words ("karo", "rahe", "agar") as accents → Hindi stop-word list + a per-project `accent_stop_words` setting.
7. A loop-filter flaw found by its own test: the first 3 copies of a repeated word leaked through → whole loops are now dropped.
8. Test-harness mistakes of mine (ffmpeg `-t` placement made a bad "mixed speed" clip) — the pipeline was right; corrected and re-run.

## Known limitations / open items
* **Auto language routing is a heuristic** (share of Devanagari in a Hindi-mode first pass) and is validated on three clips only. A *pure-English clip with a strong Indian accent* has not been tested and could be misrouted; if captions look like Roman Hindi for English speech, choose English.
* Accuracy numbers exist for **one speaker** (reference clip). Fast speech (1.4×) degrades to 14 % WER.
* Digits and numerals are less reliable in the batched rescue pass.
* Playback performance in After Effects of a 1,500-word glow-heavy composition is untested.
* The browser UI has no automated browser test; it was driven by hand.
* After Effects 2024 / 2026 are untested.

## v0.8.1 / v0.9.0 additions (2026-10-15)
| What | How | Result |
|---|---|---|
| Per-word colour/gradient rule (a solid word fill switches the gradient off) in Python, preview and the AE adapter | `tests/core/test_word_style.py` (Node runs the real ES3 file and compares with Python) | ✅ |
| Letter-reveal maths (never visible before its start, left-to-right, clamping to the time available, max total) | `tests/anim/test_look2.js` (2,300+ checks) | ✅ |
| AE expression text == preview evaluator | same file, runs the generated expression for 3 specs × 8 letters × 25 times | ✅ ≤ 1e-4 |
| Centred layout, accent-variant assignment (rotation, fixed, pool, override, determinism), width cap | same file + random groups inside the safe area | ✅ |
| Look metadata API, `template_styles` replacement, defaults unchanged | `tests/app/test_server.py::test_looks_gallery_metadata_and_look2_replaces_layout_overrides` | ✅ |
| Read-back check with variants, font fallbacks and letter animators (and catching a missing animator / wrong treatment) | `tests/core/test_look2.py` | ✅ |
| **Real After Effects 25.2**: Soft Editorial on the reference clip (78 layers), on the Hinglish clip (345 layers, 25 s), reference look rebuilt; all verified by read-back; frames rendered with aerender and compared with the shared maths | manual run, see COMPATIBILITY.md | ✅ |
| Browser UI (looks gallery, treatment editing, per-word panel, thumbnails) | exercised by hand in the built-in browser; **no automated browser tests** | ⚠️ manual only |

## v0.9.1 — look 3 "Clean 4-Word" (2026-10-17)
| What | How | Result |
|---|---|---|
| Plain by default, switch patches only touch `anim`, on→off→on lossless, grouping valid, one-line layout | `tests/core/test_look2.py` | ✅ |
| Slide-up quality: vertical only, no overshoot/blur/scale, monotone, ends exactly in place, per-frame step bound at 30 fps | `tests/anim/test_look2.js` | ✅ |
| `wrap:false` keeps one line (shrinks) | same file | ✅ |
| The look's grouping re-cuts captions to ≤ 4 words (same words, same order, never before spoken, reveal times unchanged), animation-only edits do NOT re-cut, another look releases the rule | `tests/app/test_server.py::test_look3_…` (real server + frozen English transcript) | ✅ |
| Preview in the built-in browser: look applied, switch OFF→ON, grouping re-cut, slide-up frames at 0/33/100/133/200 ms | manual | ✅ |
| **After Effects 25.2 build, animation ON** (English clip, 78 layers; run on 2026-10-17 in a fresh empty project after the owner closed theirs) | through the app (Generate, read-back verification) + `tests/ae/verify_anim.js` on the dump | ✅ verified; 78 animated; keyframes vs shared maths over 390 samples: opacity ≤ 7e-8, y ≤ 0.0033 px, x ≤ 3e-5 px; 0 timing/text/style problems; 0 lines scaled down at size 60 |
| **After Effects build, animation OFF** | same | ✅ verified; 0 words animated (no keyframes), no warnings |
| **After Effects build, Hinglish clip** (345 layers, 4-word captions, animation ON, 47 s) | same | ✅ verified; 107 slides shortened (fast speech: the caption changes < 0.48 s after the word), 3 skipped (< 2 frames); one real edge case found and fixed in the checker (below) |
| **Rendered frames (aerender)** of the slide: first frame at the reveal is invisible, then per-frame steps 9.9 → 7.1 → 4.7 → 3.0 → 1.9 → 1.2 → 0.7 → 0.4 → 0.25 px, never moves backwards, settled (≤ 0.5 px) 9 frames (0.3 s) after the reveal, opacity 0.30 → 1.00 | measured from the TIFF frames | ✅ smooth ease-out exactly as designed |
| Regression: last caption whose last word is revealed < 1 frame before the exit keeps its one-frame minimum (out-point = last in-point + 1 frame) — the read-back check used to call that a fault | `tests/ae/test_verify_dump.py` | ✅ |

## v0.9.1 — release builder, installer, updater (2026-10-20)
| What | How | Result |
|---|---|---|
| Release zip contains only allowed files (no tests, .venv, work, projects, reference, user presets, CLAUDE.md, machine-specific files); every member passes the updater's path rules; version inside matches; checksums; every look pack validates; deterministic; private details block a build | `tests/app/test_updater.py` | ✅ |
| Check: new version / new / updated / current looks, "needs setup" when requirements changed, friendly errors (unreachable, nothing published), https-only + update-site-only URLs | same | ✅ |
| Look packs: validation rejects code/unknown keys/bad names/oversize, checksum mismatch refused, only `presets/downloaded/` is written | same | ✅ |
| App update: replaces program files, keeps projects/models/.venv/own+downloaded looks/machine file untouched, backup, rollback; failure halfway restores byte-for-byte; tampered zip refused before anything changes; 16 forms of forbidden zip members (`..`, absolute, drive, backslash, protected folders, `tests/`…) abort the whole update; incomplete/mislabelled zip refused | same | ✅ (found and fixed 2 real bugs: leftover `.fcgnew` file after a failed write; "needs setup" computed after the requirements file was already replaced) |
| Opt-in: automatic check off by default (no network), at most once a day, a manual check always asks, failure of a silent check shows nothing | same, through the real HTTP server | ✅ |
| Release extracted into an empty folder: `install.ps1 -Preflight` passes; the app starts from it, serves the UI and API, lists the 4 looks, system check runs; Hinglish correctly reports "not set up" (machine file is not shipped) | manual, 2026-10-20 | ✅ |
| Full update in the real UI (sandbox copy + local update site): badge, check, install a look, update to a newer version, rollback; VERSION and files verified on disk | manual in the built-in browser | ✅ |
| **NOT tested:** the full download path of `install.ps1`/`setup.ps1` on a computer without this project's `.venv`/models (several GB); winget Python install; the real GitHub update site (nothing published yet); Windows SmartScreen behaviour on a downloaded zip | needs a second computer / a first publish | ⚠️ open |

## Hinglish accuracy work (2026-10-24, not released yet)
Full write-up, root causes and measurements: [HINGLISH_STYLE.md](HINGLISH_STYLE.md). Evidence is in `tests/fixtures/hinglish/cases.json` (17 real-clip cases),
`tests/core/test_hinglish_polish.py` (33 rule tests), `tests/core/test_hinglish_regression.py` (cases + measured quality), `tests/engine/test_hinglish_pipeline.py` (merge, audit, window re-decode, no models).

## v0.9.6 — start of the clip + .srt export (2026-10-24)
Field report: with Hinglish, no captions for the first few seconds although the speaker is talking. Reproduced on the owner's four real cut clips (kept outside the project; cut mid-sentence, so no lead-in) through the real engine (`Engine.transcribe`, GPU, turbo + Hinglish model):

| Clip | Speech starts | First caption BEFORE | AFTER (what was recovered) |
|---|---|---|---|
| PC 3 Storytelling Sales call | 0.10 s | 1.34 s (and the first words were a garbled guess) | 0.00 s — "Stories batao. presentation" (second decoding pass) |
| PC 4 3 gate method | 0.00 s | 1.00 s | 0.00 s — "set the frame," |
| PC 5 Sales call fear | 0.05 s | 1.12 s | 0.00 s — "sales calls" (start-of-clip rescue, 3 windows tried) |
| Podcast clip 1 | 0.05 s | 1.00 s | 0.00 s — "Ek mistake" |
| Who am I (reference, WER clip) | 0.00 s | 0.00 s | unchanged: no second pass needed, WER 5.1 % strict (5.1–5.7 % between runs: the GPU decoder is not bit-reproducible) |
| English reference clips (2) | 0.00–0.15 s | 0.00 s | unchanged, no second pass |

**Cause:** the sequential (most accurate) decoder skips the first second or two of a clip that starts mid-speech. The coverage safety net only looked for holes of 1.5 s or more, so a 0.6–1.3 s start hole was invisible. **Fix:** uncovered speech of 0.6 s or more is now filled from the batched pass (which becomes the main pass only if the sequential one lost 2 s or more more than it); if the very start is still empty, the first seconds are decoded again on their own behind 1–2 s of silence (up to three windows, same language route, words must be ≥ 0.20 certain, moved back onto the real timeline) and used only to fill that hole; a start hole that nothing could fill is reported (red on the timeline) from 0.6 s on. Applies to English and Hinglish alike (same code path); the English clips needed no rescue, the logic is covered by unit tests with both routes.
Findings worth knowing: padding the start with silence for the MAIN decode is NOT a fix (it made another clip lose its first word "The"); the sequential decoder differs from run to run on the same file (one run lost 9 s of PC 4, another nothing) — that is exactly what the coverage net is for; "tum jaa" (≈ 0.7 s) at the start of PC 5 is still not recovered.

| What | How | Result |
|---|---|---|
| Hole detection at 0.6 s, fill from the other pass, head-hole rescue (route, attempts, confidence filter, silence-zone words dropped, failures never break a transcription, switch-off), switch-to-batched margin, unfillable short start hole reported, short middle hole not | `tests/engine/test_coverage.py` (22 tests, no models needed) | ✅ |
| All engine tests incl. the real-model integration tests | `pytest tests/engine` | ✅ 54 passed, 3 skipped (clips not present) |
| .srt: valid SubRip syntax, CRLF, UTF-8, no overlaps, positive lengths, long cue split in two lines, word-by-word mode never shows a word before its reveal time, same-instant words/captions, empty/odd input, Devanagari text, real caption fixture, API (download headers, info, 400/409) | `tests/app/test_srt.py` | ✅ |
| Section 10 in the built-in browser (real project copy in a throw-away folder): card shows cue count/length/first cues for both modes; the button downloads `<project>.srt` (application/x-subrip, CRLF) | manual | ✅ |
| **NOT tested:** import of the .srt into YouTube / Premiere / DaVinci / CapCut (standard SubRip, but not tried in them); English clip with a really missing start (none of the English test clips failed) | | |
