# First run — 5 minutes

You have already run **`Install-FemeGus.cmd`** (if not, do that first; it asks a few questions and sets everything up).

## 1. Allow After Effects to talk to the app (once)
In After Effects: **Edit ▸ Preferences ▸ Scripting & Expressions** → tick **Allow Scripts to Write Files and Access Network** → OK.
This is how After Effects sends its "done" report back to the app. Nothing is installed into After Effects.

## 2. Connect After Effects (every time you start After Effects)
**File ▸ Scripts ▸ Run Script File…** → choose  
`<install folder>\adapters\jsx-core\fcg_connect.jsx`  
Nothing appears on screen. After about 10 seconds the app shows **"After Effects … connected"** in its top-right corner.
If After Effects shows a warning window at start-up (for example about the disk cache), close it first — an open dialog blocks scripts.

## 3. Start the app
Double-click **FemeGus Captions** on the desktop (or `Start-FemeGus.cmd` in the install folder). It opens in your browser. It runs only on your computer.

## 4. Make captions
1. **1 · Video & input** → choose your video, pick the language (English / Hinglish / Auto), press **Transcribe**.
2. **2 · Transcript & timing** → fix any wrong word (the timing is kept).
3. **4 · Caption look** → click the look you like (one click changes everything). Some looks have a switch, e.g. *Smooth slide-up animation*.
4. **9 · Generate in AE** → the captions appear in After Effects as normal, editable text layers, and the app checks them.

## If something does not work
**10 · Export & help ▸ Run system check** tells you what is missing. More: `docs\TROUBLESHOOTING.md`.
Tested with **After Effects 2025 (25.2)** on Windows only.

## Updates
**10 · Export & help ▸ Updates ▸ Check for updates** shows new versions and new caption looks. New looks install with one click and never change your projects.
