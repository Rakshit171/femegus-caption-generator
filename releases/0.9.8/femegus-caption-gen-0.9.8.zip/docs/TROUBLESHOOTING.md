# Troubleshooting

First, run the **system check** (`.\scripts\fcgapp.ps1 --check`, PowerShell in the project folder — or section 10 in the app). It names the problem and the fix for most cases below.

## Setup and start
| Symptom | Cause / fix |
|---|---|
| `setup.ps1` says Python was not found | Install Python 3.10–3.12 from python.org with **Add python.exe to PATH**, open a *new* PowerShell, run again |
| "running scripts is disabled" | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, or run `powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1` |
| pip fails / hangs | Internet needed for the first install (several GB). Re-run `setup.ps1`; it resumes. Behind a proxy: set `HTTPS_PROXY` |
| `Start-FemeGus.cmd` says "not set up yet" | Run `.\scripts\setup.ps1` once |
| The browser shows "Open the address printed by the app" | The link needs its one-time token. Use the exact address the app printed (or restart the app) |
| Port/firewall message | The app only listens on `127.0.0.1` (this computer). Allow Python in the firewall prompt, or restart the app to pick another port |

## The app stops by itself
| Symptom | Cause / fix |
|---|---|
| The page stays open but every action says **"The caption app is not reachable"** (a red banner says the app has stopped) | The app's black window is gone or stopped. Start it again with `Start-FemeGus.cmd` (it opens a NEW page; close the old one). Your projects are saved. If it keeps happening, look at the black window for a message and send it, together with `work\app_crash.log` if that file exists. Version 0.9.1 could stop on **Browse…** on some computers; 0.9.2 fixes this (Updates ▸ Check for updates, or paste the video path instead of using Browse) |

## System check and one-click fixes
Section 10 ▸ **Run system check**. Every problem that can be repaired from inside the app has a **Fix** button next to it, and **Fix everything** runs them in a sensible order (downloads first, the repair that restarts the app last; you confirm once and see what will happen and how big it is).
| Problem the check reports | What the button does |
|---|---|
| English speech model not downloaded (or an interrupted download) | downloads `large-v3-turbo` (about 1.6 GB) with a progress bar |
| Hinglish model not set up | runs `scripts\setup_hinglish.ps1` (about 3 GB download, then a few minutes of conversion) and removes the conversion tools afterwards; needs about 7 GB free while it works |
| Hinglish model found but not connected (folder moved) | writes the model's location into `engine\models_local.json`, no download |
| Missing / differing Python components, PyAV problem | **Repair components**: re-installs the tested versions and restarts the app (needs the launcher `Start-FemeGus.cmd`) |
| NVIDIA card found but the CUDA libraries are missing | installs them (about 1.5 GB) and restarts the app |
| After Effects not connected | opens the folder with `fcg_connect.jsx` (you still run it from After Effects) |
Not fixable by a button (the message says what to do): Python missing/too old, projects folder not writable, no free disk space, After Effects script permission. If a fix fails the message says why (usually: no internet, no disk space) and **nothing already downloaded is lost** — press the button again to continue. Fixes only write inside this folder (and the Hugging Face cache for the English model).

## Updates, repair and asking for help
| Symptom | Cause / fix |
|---|---|
| After pressing **Update** the card shows the update button again | Fixed in 0.9.4: the card now says "Update installed — restart to finish" with a **Restart now** button, and **Check for updates** always ends with "You have the latest version (X)" or "Version Y is available". If you are still on 0.9.3 or older, close the black window after updating and start the app again once (`Start-FemeGus.cmd`) |
| Transcribe fails with `TypeError: open() got an unexpected keyword argument 'metadata_errors'` (or another `unexpected keyword argument` / `has no attribute` / `cannot import name` error) | A component (PyAV) has a different version than the tested one. 0.9.4 works around this automatically and installs only the tested versions. Update to 0.9.4, then section 10 ▸ **Repair components** (needs internet, a few minutes, keeps projects and models) |
| The System check shows "Some components differ from the tested versions" | Press **Repair components** in section 10 |
| Anything else that fails on your computer | Section 10 ▸ **Copy support info**, paste it in a message. It holds versions, your computer type and the last lines of the black window (`work\app.log`) — never footage, transcripts or the session token. Installer problems: send `work\install.log` |

## The video picture is black but the sound plays
The browser cannot decode the picture of that file (typical for phone and screen-recorder videos in HEVC/H.265, or 10-bit video). Since 0.9.3 the app detects this and makes a small preview copy by itself (a message with progress appears where the picture should be; a few seconds to a minute). If it did not start, press **Picture black or choppy? Make a preview copy** in section 1. The copy is only for the preview — After Effects and the transcription use your original file, and the timing is identical. Not yet tested: phone videos that are stored sideways with a rotation flag (the preview copy might then be rotated differently from After Effects).

## Transcription seems stuck
* **The first transcription on a new computer downloads the speech model (about 1.6 GB).** The message under the progress bar and the app's black window say *"Downloading the speech model … MB of … (n %)"*; wait for it (it happens once). Before 0.9.3 this showed only "4 %". If it fails: check the internet connection/firewall/proxy and press Transcribe again, or run `.\scripts\setup.ps1 -PreloadModels` in PowerShell in the install folder.
* Otherwise look at the black window (it names the step it is in) and the **System check** in section 10, and send both when asking for help.

## Transcription
| Symptom | Cause / fix |
|---|---|
| "The speech model … could not be loaded" | First use needs internet once (1.6 GB). Connect, retry. For the Hinglish model run `.\scripts\setup_hinglish.ps1` |
| Very slow transcription | The GPU is not used. System check → GPU row. Update the NVIDIA driver; `setup.ps1` (without `-CpuOnly`) installs the CUDA libraries |
| GPU "out of memory" | Close other GPU apps (After Effects uses VRAM too) and retry. If the model cannot be *loaded* on the GPU the app falls back to the CPU by itself; a failure in the middle of a run is not retried automatically |
| "could not be read as audio or video" | Unsupported/damaged file. Supported: mp4, mov, mkv, avi, webm, m4v, wav, mp3, m4a |
| Red "missing speech?" on the timeline | Loud audio with no recognised words. Click ▶ in section 1, listen, and add the words in section 2 ("Insert a missed word"). The engine already tried a second decoding pass |
| Hindi words came out in English | You used **English** mode: it translates Hindi. Use **Auto** or **Hinglish** and transcribe again |
| English speech came out as Roman Hindi | Auto chose Hinglish for a strongly accented English speaker. Choose **English** |
| Digits/numbers wrong or missing | Fix them in section 2; numbers are the least reliable part of the rescue pass |
| Wrong words | Edit them in section 2 — timing is untouched. Flagged words (tags) are the least certain |

## Captions and preview
| Symptom | Cause / fix |
|---|---|
| Captions cover the speaker's face | Section 8 ▸ **Vertical position** (default 0.60 = lower middle) |
| A caption stays too short / long | Section 3 ▸ hold times, min visible; very fast speech cannot stay longer without overlapping the next caption (the tool never overlaps) |
| A word appears a little late / early-looking | By design a word is shown **at or after** its recognised start, never before. Section 3 ▸ *Reveal delay* shifts every reveal later; there is deliberately no setting to show words earlier |
| Preview glow/blur looks different from After Effects | Those three are approximations in the preview; timing, layout and motion are exact |
| Font looks wrong in the preview | The font must be installed in Windows. Pick another in section 5 |
| A colour/font change in section 5/6 "does nothing" on some captions | Those captions use a layout (e.g. *stack*) with its own override of that property. Since v0.8.1 editing "all layouts" replaces it; in older versions switch "Editing" to that layout |
| The Fill colour has no effect | The role uses a gradient, which hides the solid fill. Section 6 ▸ **Fill type** → Solid colour (or edit the gradient top/bottom) |

## After Effects
| Symptom | Cause / fix |
|---|---|
| App shows "After Effects … not connected" | Run `adapters\jsx-core\fcg_connect.jsx` (File ▸ Script ▸ Run Script File…) once per After Effects session; wait ~10 s |
| The script alerts "not allowed to write files" | Edit ▸ Preferences ▸ Scripting & Expressions ▸ tick **Allow Scripts to Write Files and Access Network** |
| Nothing happens after "Generate" | A modal dialog in After Effects (e.g. the disk-cache warning at startup) blocks scripts — close it. The app times out after 15 minutes |
| "font … not installed; using ArialMT" | After Effects does not have that font. Install it or choose another; the layers still build |
| Generation is slow | Time grows with the word count: about 0.15 s per word with all effects and animation (measured: 1,520 words ≈ 4 minutes, 283 words ≈ 1 minute). After Effects is busy meanwhile but stays responsive |
| Verification shows problems | The message names them (premature start, overlap, style not applied). Please keep the `work\ae_test` folder and report it |
| I edited layers in After Effects and Update removed my edits | "Update" replaces every layer whose **Comment** starts with `FCG:` (that is how the tool recognises its own layers). To keep a hand-edited layer, clear its Comment field (Layer ▸ Comment column), or generate into a differently named composition (section 9) |
| After Effects shows **"Fatal Error — Error at hooking API 'NtProtectVirtualMemory'"** on its loading screen and closes | **Not caused by this tool** (it adds nothing to After Effects' startup; the connect script runs only when you run it). Diagnosed 2026-10-15 on the dev PC: the error box is titled with the DLL that raised it — `aejuice_utils.dll`, loaded while the splash said "AEJuice Pack Manager 4" — i.e. a third-party plug-in's hooking code failing (AE's own plug-in scan had finished). Fix: update/reinstall that plug-in or contact its vendor; to disable it, **move** (as Administrator) `C:\Program Files\Adobe\Common\Plug-ins\7.0\MediaCore\AEJuice Pack Manager` out of the Plug-ins tree (e.g. to `C:\AEJuice_disabled_backup\`). **Renaming it is not enough** — After Effects scans plug-in sub-folders recursively and loads every `.aex`/DLL there whatever the folder is called (a `.disabled` rename still loaded `aejuice_utils.dll`; verified 2026-10-15), and an uninstall can leave this folder behind. The error title bar always names the module — read it first. Other plug-ins that hook APIs (overlays, anti-cheat, audio/voice tools) can produce the same box |
| After Effects 2024 / 2026 | **Not tested.** The tool warns when the version is not 25.x. See COMPATIBILITY.md |

## Cleaning up / freeing space
* `work\` is scratch space (test renders, variants). Safe to delete: `Remove-Item work\* -Recurse -Force` (PowerShell, project folder) — it is re-created when needed.
* `models\hf\` (original Hinglish weights, 1.5 GB) and `.venv-convert\` are only needed to convert the model: `.\scripts\setup_hinglish.ps1 -CleanUp`.
* **Projects:** section 1 ▸ *Recent projects* shows what each one uses (the preview copy of a video is the big part). Tick one or more and press **Delete selected…**. Only this tool's saved work for the project is removed (transcript, your word corrections, caption settings, preview copy); your original video/audio files, other projects and anything already in After Effects are never touched, and it is refused while a task (transcription, preview copy, After Effects build) is running. Deleting cannot be undone. If a file that is not the tool's own is found in a project folder it is left in place and you are told.

## Reporting a problem
Run the system check, then send: its text, the project folder `projects\<name>` (no video inside; only small JSON files), and what you clicked.
