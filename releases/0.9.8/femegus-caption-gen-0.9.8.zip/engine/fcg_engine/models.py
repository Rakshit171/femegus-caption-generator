"""Model registry and language-mode presets.

Model names resolve to anything ``faster_whisper.WhisperModel`` accepts (built-in size alias, Hugging Face repo id, or local
CTranslate2 directory). Nothing here downloads anything by itself; downloading happens on first use of a model.

Hinglish note: a Hindi-capable model does NOT automatically give Roman-script Hinglish. Two strategies exist and are
benchmarked separately (see docs/HINGLISH.md):
  A. a Hindi->Hinglish fine-tuned model (Oriserve Whisper-Hindi2Hinglish, Apache-2.0) converted to CTranslate2
  B. stock Whisper with language="hi" plus a Roman-script ``initial_prompt`` that steers the output script
"""
from __future__ import annotations

# friendly key -> faster-whisper model reference
MODELS: dict[str, str] = {
    "turbo": "large-v3-turbo",
    "large-v3": "large-v3",
    "distil-large-v3": "distil-large-v3",  # English only
    "medium": "medium",
    "small": "small",
}

# Extra user/registered models (e.g. converted Hinglish model) are read from models_local.json at runtime.

HINGLISH_PROMPT = (
    "Aaj hum video editing ke baare mein baat karenge. Yaar, ye scene bahut accha hai, "
    "lekin edit thoda aur smooth hona chahiye, matlab flow ke saath. Chalo shuru karte hain."
)

LANGUAGE_MODES = ("english", "hinglish", "auto")
