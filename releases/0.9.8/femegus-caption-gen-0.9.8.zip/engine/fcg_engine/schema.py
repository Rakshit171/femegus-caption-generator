"""Transcript data model (schema v1). Plain dicts so the file is trivially consumable by JS / ExtendScript adapters.

transcript.json
{
  "schema": 1,
  "source": {"file": str, "duration": float},
  "engine": {"model": str, "device": str, "compute_type": str, "language_mode": str, "options": {...}},
  "language": {"mode": "english|hinglish|auto", "detected": str|None, "probability": float|None},
  "words": [{"id": "w000001", "text": "edits,", "start": 0.52, "end": 0.84, "confidence": 0.93, "segment": 0, "lang": "en"|None}],
  "segments": [{"id": 0, "start": float, "end": float, "text": str, "word_ids": [..], "lang": str|None}],
  "warnings": [str, ...]
}

``text`` is the recognised text exactly as produced (punctuation attached, leading space stripped).
Later editing layers store corrections in a separate overrides structure; they never overwrite engine output.
"""
from __future__ import annotations

SCHEMA_VERSION = 1


def word_id(index: int) -> str:
    return f"w{index + 1:06d}"
