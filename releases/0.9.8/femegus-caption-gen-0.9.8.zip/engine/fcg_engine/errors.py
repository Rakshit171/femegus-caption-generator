"""User-facing engine errors (messages say what to do, not what the library crashed on)."""
import os


class ModelLoadError(RuntimeError):
    """The speech model could not be loaded."""

    def __init__(self, key: str, ref: str, cause: Exception):
        local = os.path.isdir(ref) or os.path.isabs(ref)
        hint = (f"The model folder '{ref}' is missing or damaged. Re-create it (see README: Hinglish model conversion) or choose another model."
                if local else
                f"The first use of '{ref}' needs an internet connection to download it once (about 1.6 GB for the default model); after that it works offline. "
                "If you are offline, connect once, or copy the model into the Hugging Face cache.")
        super().__init__(f"The speech model '{key}' could not be loaded. {hint} (Details: {type(cause).__name__}: {str(cause).splitlines()[0][:160]})")


class MediaReadError(ValueError):
    """The file is not audio/video the decoder understands."""


def media_error(path: str) -> MediaReadError:
    return MediaReadError(f"'{os.path.basename(path)}' could not be read as audio or video (is it a damaged or unsupported file?). "
                          "Supported: mp4, mov, mkv, avi, webm, m4v, wav, mp3, m4a.")


def is_decode_error(exc: Exception) -> bool:
    return type(exc).__module__.startswith("av") or "InvalidData" in type(exc).__name__ or "No such file" in str(exc)