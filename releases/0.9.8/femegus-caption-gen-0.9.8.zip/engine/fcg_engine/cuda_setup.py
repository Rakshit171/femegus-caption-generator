"""Make the pip-installed NVIDIA CUDA 12 / cuDNN 9 DLLs visible to CTranslate2 on Windows.

Must run BEFORE ``ctranslate2`` / ``faster_whisper`` are imported. No system-wide CUDA toolkit is needed:
the DLLs come from the ``nvidia-cublas-cu12`` / ``nvidia-cudnn-cu12`` wheels inside the project venv.
"""
from __future__ import annotations

import importlib.util
import os
import sys

_PACKAGES = ("nvidia.cublas", "nvidia.cudnn", "nvidia.cuda_nvrtc", "nvidia.cuda_runtime")
_done = False


def prepare_cuda_dlls() -> list[str]:
    """Add every nvidia wheel ``bin`` directory to the DLL search path. Returns the directories added."""
    global _done
    added: list[str] = []
    if _done or sys.platform != "win32":
        _done = True
        return added
    for pkg in _PACKAGES:
        try:
            spec = importlib.util.find_spec(pkg)
        except (ModuleNotFoundError, ValueError):
            continue
        if spec is None or not spec.submodule_search_locations:
            continue
        for loc in spec.submodule_search_locations:
            bin_dir = os.path.join(loc, "bin")
            if os.path.isdir(bin_dir):
                os.add_dll_directory(bin_dir)
                os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")
                added.append(bin_dir)
    _done = True
    return added
