"""CLI:  python -m fcg_engine transcribe VIDEO [--language english|hinglish|auto] [--out FILE] [--show]"""
from __future__ import annotations

import argparse
import json
import os
import sys


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="fcg_engine")
    sub = ap.add_subparsers(dest="cmd", required=True)
    t = sub.add_parser("transcribe", help="transcribe a video/audio file to transcript.json")
    t.add_argument("input")
    t.add_argument("--language", default="english", choices=["english", "hinglish", "auto"])
    t.add_argument("--english-model", default="turbo")
    t.add_argument("--hinglish-model", default="hinglish-apex")
    t.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    t.add_argument("--no-vad", action="store_true")
    t.add_argument("--prompt", default=None, help="initial prompt override")
    t.add_argument("--out", default=None, help="output JSON path (default: <input>.transcript.json)")
    t.add_argument("--show", action="store_true", help="print words with times")
    e = sub.add_parser("evaluate", help="word error rate of a transcript.json against a reference .txt")
    e.add_argument("transcript")
    e.add_argument("reference")
    e.add_argument("--variants", default=None, help="JSON {canonical: [spelling variants]} treated as equal")
    v = sub.add_parser("envelope", help="write a loudness envelope JSON (used by fcg_core for pauses/onsets)")
    v.add_argument("input")
    v.add_argument("--out", required=True)
    args = ap.parse_args(argv)

    if args.cmd == "envelope":
        from .audio import compute_envelope
        env = compute_envelope(args.input)
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(env, f)
        print(f"[engine] envelope: {len(env['db'])} frames -> {args.out}", file=sys.stderr)
        return 0

    if args.cmd == "evaluate":
        from .evaluate import canon_map, hyp_tokens, load_reference, wer
        ref = load_reference(args.reference)
        hyp = hyp_tokens(json.load(open(args.transcript, encoding="utf-8")))
        canon = canon_map(json.load(open(args.variants, encoding="utf-8-sig"))) if args.variants else None
        r = wer(ref, hyp, canon)
        print(f"WER {r['wer']*100:.1f}%  (sub {r['sub']}, del {r['del']}, ins {r['ins']}, ref words {r['ref_words']})")
        for op, a, b in r["ops"]:
            if op != "ok":
                print(f"  {op:<4} ref={a!r:<16} hyp={b!r}")
        return 0

    from .engine import Engine  # heavy import after arg parsing

    here = os.path.dirname(os.path.abspath(__file__))
    eng = Engine(args.device, os.path.join(here, "..", "models_local.json"), args.english_model, args.hinglish_model)
    extra = {"initial_prompt": args.prompt} if args.prompt is not None else {}
    res = eng.transcribe(args.input, args.language, vad=not args.no_vad,
                         progress=lambda p: print(f"\r[engine] {p*100:5.1f}%", end="", file=sys.stderr), **extra)
    print(file=sys.stderr)
    out = args.out or (os.path.splitext(args.input)[0] + ".transcript.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)
    e = res["engine"]
    print(f"[engine] model={e['model']} {e['device']}/{e['compute_type']} words={len(res['words'])} "
          f"lang={res['language']['detected']} route={res['language']['route']} "
          f"{e['transcribe_seconds']}s (RTF {e['realtime_factor']}) -> {out}", file=sys.stderr)
    for w in res["warnings"]:
        print(f"[warn] {w}", file=sys.stderr)
    if args.show:
        for w in res["words"]:
            fl = ",".join(w.get("flags", []))
            print(f"{w['start']:7.2f} {w['end']:7.2f}  {w['confidence']:.2f}  {w['text']}  {('['+fl+']') if fl else ''}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
