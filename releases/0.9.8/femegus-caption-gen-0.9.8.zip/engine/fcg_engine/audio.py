"""Loudness envelope (RMS dB per 10 ms) for the timing core. Uses faster-whisper's PyAV decoder: no extra dependency."""
from __future__ import annotations

import numpy as np


def compute_envelope(path: str, hop_s: float = 0.01, sr: int = 16000) -> dict:
    from faster_whisper.audio import decode_audio
    from .errors import is_decode_error, media_error
    try:
        x = decode_audio(path, sampling_rate=sr)
    except Exception as exc:
        if is_decode_error(exc):
            raise media_error(path) from exc
        raise
    hop = int(sr * hop_s)
    n = len(x) // hop
    if n == 0:
        return {"hop": hop_s, "db": []}
    rms = np.sqrt((x[: n * hop].reshape(n, hop) ** 2).mean(1)) + 1e-9
    return {"hop": hop_s, "db": [round(float(v), 1) for v in 20 * np.log10(rms)]}
