"""FemeGus Caption Generator — local transcription engine (no After Effects dependency)."""
try:                                           # tolerate a PyAV whose open() lacks an argument faster-whisper passes (see compat.py)
    from . import compat as _compat
    _compat.apply()
except Exception:                              # never let a compatibility helper stop the engine from importing
    pass
