"""Word-error-rate evaluation against a reference transcript (lines like ``[m:ss.ss] text``; ``#`` lines ignored).

Two scores are reported because Roman Hinglish has no fixed spelling:
  strict      exact token match after normalisation
  spelling    additionally treats listed spelling variants as equal (variants.json-style dict: canonical -> [variants])
Normalisation: lowercase, hyphens split, punctuation removed, "10,000" / ",000" left as written (a caption showing ",000" is a visible error).
"""
from __future__ import annotations

import re
from typing import Iterable

_TS = re.compile(r"^\s*\[\d+:\d+(?:\.\d+)?\]\s*")


def load_reference(path: str) -> list[str]:
    toks: list[str] = []
    with open(path, "r", encoding="utf-8-sig") as f:
        for line in f:
            if line.lstrip().startswith("#") or not line.strip():
                continue
            toks += tokenize(_TS.sub("", line))
    return toks


def tokenize(text: str) -> list[str]:
    text = text.lower().replace("-", " ").replace("’", "'")
    text = re.sub(r"[^\w\s',]", " ", text)
    text = re.sub(r"(?<=\d),(?=\d)", "", text)          # 10,000 -> 10000
    text = text.replace(",", " ")
    return [t.strip("'") for t in text.split() if t.strip("'")]


def canon_map(variants: dict[str, Iterable[str]] | None) -> dict[str, str]:
    m: dict[str, str] = {}
    for canon, vs in (variants or {}).items():
        m[canon] = canon
        for v in vs:
            m[v] = canon
    return m


def align(ref: list[str], hyp: list[str], canon: dict[str, str] | None = None):
    """Levenshtein alignment. Returns (S, D, I, ops) with ops = [(op, ref_tok, hyp_tok)]."""
    c = canon or {}
    eq = lambda a, b: c.get(a, a) == c.get(b, b)
    n, m = len(ref), len(hyp)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (0 if eq(ref[i - 1], hyp[j - 1]) else 1))
    i, j, ops = n, m, []
    while i or j:
        if i and j and d[i][j] == d[i - 1][j - 1] + (0 if eq(ref[i - 1], hyp[j - 1]) else 1):
            ops.append(("ok" if eq(ref[i - 1], hyp[j - 1]) else "sub", ref[i - 1], hyp[j - 1])); i -= 1; j -= 1
        elif i and d[i][j] == d[i - 1][j] + 1:
            ops.append(("del", ref[i - 1], "")); i -= 1
        else:
            ops.append(("ins", "", hyp[j - 1])); j -= 1
    ops.reverse()
    s = sum(o[0] == "sub" for o in ops); dl = sum(o[0] == "del" for o in ops); ins = sum(o[0] == "ins" for o in ops)
    return s, dl, ins, ops


def wer(ref: list[str], hyp: list[str], canon: dict[str, str] | None = None) -> dict:
    s, dl, ins, ops = align(ref, hyp, canon)
    return {"wer": round((s + dl + ins) / max(1, len(ref)), 4), "sub": s, "del": dl, "ins": ins, "ref_words": len(ref), "ops": ops}


def hyp_tokens(transcript: dict) -> list[str]:
    return tokenize(" ".join(w["text"] for w in transcript["words"]))
