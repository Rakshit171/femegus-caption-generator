"""Compatibility shims for third-party libraries whose API drifts between versions. Applied once, automatically, when the engine is imported.

Why this exists: a friend's computer reported ``TypeError: open() got an unexpected keyword argument 'metadata_errors'`` the moment Transcribe was pressed.
faster-whisper calls ``av.open(..., metadata_errors="ignore")``; a PyAV whose ``open`` does not take that argument makes every transcription fail.
The tested versions are pinned (requirements.txt / requirements.lock.txt) and checked by the System check, but a computer can still end up with a
different combination, so the one place where this has already happened is made tolerant: an argument that ``av.open`` rejects is dropped and the call is
retried. Everything else is left alone (a real error is still a real error).
"""
from __future__ import annotations

import re
import sys

_REJECTED = re.compile(r"unexpected keyword argument '([A-Za-z_][A-Za-z0-9_]*)'")
dropped: list[str] = []                     # names of arguments the installed PyAV refused (shown in the support info)


def apply() -> bool:
    """Patch ``av.open`` (idempotent). Returns True when the patch is in place."""
    try:
        import av
    except Exception:                       # PyAV missing: the System check reports that; nothing to patch
        return False
    real = av.open
    if getattr(real, "_fcg_compat", False):
        return True

    def open_(*args, **kwargs):
        for _ in range(8):                  # a few drifted arguments at most; never loop forever
            try:
                return real(*args, **kwargs)
            except TypeError as e:
                m = _REJECTED.search(str(e))
                if m and m.group(1) in kwargs:
                    name = m.group(1)
                    kwargs.pop(name)
                    if name not in dropped:
                        dropped.append(name)
                        print(f"[compat] this PyAV does not accept av.open({name}=...); retrying without it (PyAV {getattr(av, '__version__', '?')})",
                              file=sys.stderr, flush=True)
                    continue
                raise
        return real(*args, **kwargs)
    open_._fcg_compat = True                # type: ignore[attr-defined]
    open_.__wrapped__ = real                # type: ignore[attr-defined]
    open_.__doc__ = getattr(real, "__doc__", None)
    av.open = open_
    return True


def pyav_report() -> dict:
    """Facts about the installed PyAV for the System check / support info (never raises)."""
    out: dict = {"installed": False}
    try:
        import av
        real = getattr(av.open, "__wrapped__", av.open)
        out.update(installed=True, version=getattr(av, "__version__", "?"), file=getattr(av, "__file__", "?"), open_is=type(real).__name__,
                   dropped_arguments=list(dropped), patched=bool(getattr(av.open, "_fcg_compat", False)))
        try:                                # does the REAL open take the argument faster-whisper passes? (a missing file is an acceptable failure)
            real("__fcg_probe_missing__.mp4", mode="r", metadata_errors="ignore")
        except TypeError as e:
            out["accepts_metadata_errors"] = False
            out["probe_error"] = str(e)[:200]
        except Exception:
            out["accepts_metadata_errors"] = True
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"
    return out
