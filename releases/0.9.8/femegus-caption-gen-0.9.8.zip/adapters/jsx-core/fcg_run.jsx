// FemeGus Caption Generator — After Effects entry script (ExtendScript, ES3).
// Run with File > Script > Run Script File...  (no installation, no changes to the After Effects folder).
//
// Job file: fcg_job.json next to this script (optional). If absent, you are asked to pick a groups.json.
//   { "action": "build" | "inspect", "groups": "C:/path/groups.json", "options": { ...see fcg_build.jsxinc... },
//     "report": "C:/path/report.json", "save_project": "C:/path/test.aep" }
#target aftereffects
#include "lib/fcg_json.jsxinc"
#include "lib/fcg_util.jsxinc"
#include "lib/fcg_profile.jsxinc"
#include "../../core/anim/anim.js"
#include "lib/fcg_layout.jsxinc"
#include "lib/fcg_build.jsxinc"
#include "lib/fcg_job.jsxinc"

(function () {
    var here = File($.fileName).parent;
    var job;
    try {
        var jf = new File(here.fsName + "/fcg_job.json");
        if (jf.exists) job = fcgReadJSON(jf.fsName);
        else {
            var pick = File.openDialog("Select groups.json made by FemeGus Caption Generator", "JSON:*.json");
            if (!pick) return;
            job = { action: "build", groups: pick.fsName };
        }
    } catch (e) { alert("FemeGus Captions: cannot read the job file.\n" + e); return; }
    var report = fcgRunJob(job);
    if (!report.ok) alert("FemeGus Captions failed:\n" + report.errors.join("\n"));
    else if (!job.report) alert("FemeGus Captions: " + report.words + " caption layers created in '" + report.comp.name + "'." +
                                (report.warnings.length ? "\n\nWarnings:\n" + report.warnings.join("\n") : ""));
})();
