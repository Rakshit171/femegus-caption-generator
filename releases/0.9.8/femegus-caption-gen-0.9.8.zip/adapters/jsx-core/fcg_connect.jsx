// FemeGus Caption Generator — "Connect" script for After Effects (ExtendScript, ES3).
//
// HOW TO USE: in After Effects choose  File > Script > Run Script File...  and pick this file. Do it once per After Effects session.
// Nothing is installed and nothing in the After Effects folder is changed. No window opens; the caption app's "Generate in AE" section turns green.
//
// What it does: it checks the folder  <project>/work/ae_inbox  about once a second (app.scheduleTask). When the caption app drops a job there, this
// script builds the caption layers, writes a report next to the job, and the app verifies the layers it finds. Close After Effects (or run this file again)
// to stop it. Requires Preferences > Scripting & Expressions > "Allow Scripts to Write Files and Access Network".
//
// This file is a tiny fixed stub: ALL logic is re-read from adapters/jsx-core/lib/*.jsxinc for every job, so updating the tool never needs this script re-run.
#target aftereffects
#targetengine "fcg_connect"

var FCG_CONNECT_VERSION = "connect-1";
var FCG_DIR = File($.fileName).parent.fsName.replace(/\\/g, "/");
var FCG_INBOX = File($.fileName).parent.parent.parent.fsName.replace(/\\/g, "/") + "/work/ae_inbox";
var FCG_BUSY = false, FCG_POLLS = 0;
if (typeof FCG_TASK === "undefined") var FCG_TASK = null;

function fcgConnectBeat() {
    var f = new File(FCG_INBOX + "/heartbeat_connect.txt"); f.encoding = "UTF-8";
    if (f.open("w")) { f.write(String(new Date().getTime()) + "\n" + app.version + "\n" + FCG_CONNECT_VERSION + "\n"); f.close(); }
}

function fcgConnectPoll() {
    if (FCG_BUSY) return;
    FCG_POLLS++;
    if (FCG_POLLS % 5 === 1) fcgConnectBeat();
    var jf = new File(FCG_INBOX + "/job_connect.json");
    if (!jf.exists) return;
    FCG_BUSY = true;
    try {
        $.evalFile(new File(FCG_DIR + "/lib/fcg_connect_run.jsxinc"));
        fcgConnectRunOnce(jf);
    } catch (e) { try { jf.remove(); } catch (e2) { } }
    FCG_BUSY = false;
}

(function () {
    if (!new Folder(FCG_INBOX).exists) new Folder(FCG_INBOX).create();
    var t = new File(FCG_INBOX + "/.write_test");
    if (!t.open("w")) {
        alert("FemeGus Captions: After Effects is not allowed to write files.\n\nEnable  Edit > Preferences > Scripting & Expressions >\n'Allow Scripts to Write Files and Access Network'  and run this script again.");
        return;
    }
    t.write("x"); t.close(); t.remove();
    if (FCG_TASK !== null) { try { app.cancelTask(FCG_TASK); } catch (e) { } }
    fcgConnectBeat();
    FCG_TASK = app.scheduleTask("fcgConnectPoll()", 1000, true);
})();
