@echo off
rem Double-click to install the FemeGus Caption Generator (guided; asks a few questions; safe to run again).
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install.ps1" %*
echo.
pause
