// Timeline: loudness waveform, caption blocks, word ticks, playhead. Click to seek / select a caption.
import { S, on, emit } from './store.js';
import { get } from './api.js';
import { fmtTime } from './dom.js';

export class Timeline {
  constructor(canvas, scroller, video, zoomEl) {
    this.cv = canvas; this.sc = scroller; this.video = video; this.zoomEl = zoomEl; this.ctx = canvas.getContext('2d');
    this.env = null; this.pps = +zoomEl.value;
    zoomEl.addEventListener('input', () => { this.pps = +zoomEl.value; this.layout(); });
    canvas.addEventListener('click', (e) => this.click(e));
    on('groups', () => this.draw()); on('project', () => this.loadEnv());
    const loop = () => { this.draw(); requestAnimationFrame(loop); };
    loop();
  }
  async loadEnv() {
    this.env = null;
    try { this.env = await get('/api/envelope?step=5'); } catch (e) { /* no project yet */ }
    this.layout();
  }
  duration() { return (S.meta && S.meta.probe && S.meta.probe.duration) || this.video.duration || (S.groups && S.groups.groups.length ? S.groups.groups.at(-1).exit : 10); }
  layout() {
    const dpr = window.devicePixelRatio || 1, w = Math.max(this.sc.clientWidth, Math.ceil(this.duration() * this.pps) + 20), h = this.sc.clientHeight - 2;
    this.cv.width = w * dpr; this.cv.height = h * dpr; this.cv.style.width = w + 'px'; this.cv.style.height = h + 'px'; this.dpr = dpr; this.W = w; this.H = h; this.draw();
  }
  x(t) { return 10 + t * this.pps; }
  click(e) {
    const r = this.cv.getBoundingClientRect(), t = (e.clientX - r.left - 10) / this.pps;
    this.video.currentTime = Math.max(0, Math.min(this.duration(), t));
    if (S.groups) {
      const g = S.groups.groups.find((g) => t >= g.start && t < g.exit);
      S.selectedGroup = g ? g.id : null; emit('selectedGroup');
    }
  }
  draw() {
    if (!this.W) return this.layout();
    const c = this.ctx, d = this.dpr, W = this.W, H = this.H;
    c.setTransform(d, 0, 0, d, 0, 0); c.clearRect(0, 0, W, H);
    // waveform
    const wf = 58;
    c.fillStyle = '#111318'; c.fillRect(0, 0, W, wf);
    if (this.env && this.env.db.length) {
      c.fillStyle = '#4b5a7a';
      const hop = this.env.hop;
      for (let i = 0; i < this.env.db.length; i++) {
        const x = this.x(i * hop), v = Math.max(0, Math.min(1, (this.env.db[i] + 60) / 50));
        c.fillRect(x, wf - v * (wf - 4), Math.max(1, hop * this.pps), v * (wf - 4));
      }
    }
    // possible missing speech (loud audio with no recognised words)
    for (const [a, b] of ((S.transcript && S.transcript.quality && S.transcript.quality.speech_gaps) || [])) {
      c.fillStyle = 'rgba(255,93,93,.35)'; c.fillRect(this.x(a), 0, Math.max(2, (b - a) * this.pps), wf);
      c.fillStyle = '#ff9a9a'; c.font = '10px sans-serif'; c.fillText('missing speech?', this.x(a) + 3, wf - 12);
    }
    // time ruler
    c.fillStyle = '#9aa1b2'; c.font = '10px Consolas, monospace'; c.textBaseline = 'top';
    const step = this.pps >= 160 ? 1 : this.pps >= 70 ? 2 : 5;
    for (let t = 0; t < this.duration(); t += step) { c.fillRect(this.x(t), 0, 1, 6); c.fillText(fmtTime(t, false), this.x(t) + 3, 2); }
    // captions + words
    if (S.groups) {
      for (const g of S.groups.groups) {
        const x0 = this.x(g.start), x1 = this.x(g.exit), sel = S.selectedGroup === g.id;
        c.fillStyle = sel ? '#3b6fd6' : '#2c4f93'; c.fillRect(x0, wf + 6, Math.max(2, x1 - x0 - 1), 40);
        c.fillStyle = '#e8eaf0'; c.font = '11px "Segoe UI", sans-serif'; c.textBaseline = 'middle';
        c.save(); c.beginPath(); c.rect(x0, wf + 6, Math.max(2, x1 - x0 - 1), 40); c.clip();
        c.fillText(g.words.map((w) => w.display).join(' '), x0 + 3, wf + 26); c.restore();
        for (const w of g.words) {
          c.fillStyle = w.role === 'accent' ? '#ff7a1a' : '#cfd4e0'; const xr = this.x(w.reveal);
          c.fillRect(xr, wf + 52, 2, 22); c.fillStyle = 'rgba(160,170,190,.35)'; c.fillRect(this.x(w.start), wf + 77, Math.max(1, (w.end - w.start) * this.pps), 4);
        }
        c.fillStyle = 'rgba(255,255,255,.2)'; c.fillRect(x1 - 1, wf + 6, 1, 40);
      }
    }
    // playhead
    const px = this.x(this.video.currentTime || 0);
    c.fillStyle = '#ff5d5d'; c.fillRect(px - 0.5, 0, 1.5, H);
    if (!this.video.paused) {
      const l = this.sc.scrollLeft, vw = this.sc.clientWidth;
      if (px > l + vw - 60 || px < l) this.sc.scrollLeft = Math.max(0, px - 80);
    }
  }
}
