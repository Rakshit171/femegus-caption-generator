// Small shared form widgets (used by the style panels and the per-word selection panel).
import { S } from './store.js';
import { h } from './dom.js';

// Family + style pickers over EVERY font installed on this computer (After Effects uses the same PostScript names).
// `unchanged` adds a "(font unchanged)" entry for the per-word panel; the PostScript name chosen is reported through onChange and via `.getFont()`.
export function fontPair(currentPs, onChange, { unchanged = false } = {}) {
  const cur = (currentPs && S.fontMap[currentPs]) || { family: '', postscript: currentPs || '' };
  const fams = [...new Set(S.fonts.map((f) => f.family))].sort((a, b) => a.localeCompare(b));
  const famSel = h('select', { style: { maxWidth: '170px' } },
    unchanged ? h('option', { value: '' }, '(font unchanged)') : null,
    !unchanged && cur.postscript && !fams.includes(cur.family) ? h('option', { value: '' }, `${cur.postscript} (not installed?)`) : null,
    fams.map((f) => h('option', { value: f, selected: f === cur.family }, f)));
  const styleSel = h('select', {});
  const fill = () => {
    const list = famSel.value ? S.fonts.filter((f) => f.family === famSel.value) : [];
    styleSel.replaceChildren(...list.map((f) => h('option', { value: f.postscript, selected: f.postscript === cur.postscript }, f.style)));
    styleSel.style.display = list.length ? '' : 'none';
  };
  famSel.onchange = () => { fill(); if (onChange && styleSel.value) onChange(styleSel.value); };
  styleSel.onchange = () => { if (onChange) onChange(styleSel.value); };
  fill();
  const box = h('span', {}, famSel, styleSel);
  box.getFont = () => (famSel.value ? styleSel.value : '');
  return box;
}

export function colorInput(value, onChange) {
  const c = h('input', { type: 'color', value }), t = h('input', { type: 'text', value, style: { width: '78px' } });
  c.oninput = () => { t.value = c.value; if (onChange) onChange(c.value); };
  t.onchange = () => { if (/^#[0-9a-f]{6}$/i.test(t.value)) { c.value = t.value; if (onChange) onChange(t.value); } else t.value = c.value; };
  const box = h('span', {}, c, t);
  box.getValue = () => c.value;
  return box;
}
