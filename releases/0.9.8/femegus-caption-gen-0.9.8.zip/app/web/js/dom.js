// Tiny DOM helpers (no framework).
export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else if (k === 'checked') el.checked = !!v;
    else if (k === 'disabled') el.disabled = !!v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}
export const $ = (sel, root = document) => root.querySelector(sel);
export function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }
export function fmtTime(t, frac = true) {
  if (!isFinite(t)) t = 0;
  const m = Math.floor(t / 60), s = t - m * 60;
  return `${m}:${(frac ? s.toFixed(2) : Math.floor(s).toString()).padStart(frac ? 5 : 2, '0')}`;
}
export function fmtBytes(n) {
  if (!isFinite(n) || n <= 0) return '0 KB';
  if (n < 1e6) return Math.max(1, Math.round(n / 1e3)) + ' KB';
  return (n < 1e9 ? (n / 1e6).toFixed(n < 1e7 ? 1 : 0) + ' MB' : (n / 1e9).toFixed(2) + ' GB');
}
export function toast(msg, kind = '', ms = 4500) {
  if ([...$('#toasts').children].some((t) => t.textContent === msg)) return;       // never stack identical messages
  const el = h('div', { class: 'toast ' + kind }, msg);
  $('#toasts').append(el);
  setTimeout(() => el.remove(), ms);
}
export function setStatus(msg) { $('#status').textContent = msg || ''; }
const REPLACE_KEYS = ['template_styles'];          // a style that has these keys owns them completely (see project.py deep_merge)
export function deepMerge(base, over) {            // mirrors fcgMerge in the After Effects adapter (arrays are replaced)
  if (over === undefined) return base;
  if (base && over && typeof base === 'object' && typeof over === 'object' && !Array.isArray(base) && !Array.isArray(over)) {
    const out = { ...base };
    for (const k of Object.keys(over)) out[k] = REPLACE_KEYS.includes(k) ? over[k] : k in base ? deepMerge(base[k], over[k]) : over[k];
    return out;
  }
  return over;
}
// Per-word style on top of a role style (mirrors fcgWordStyle in the adapter): a solid `fill` without a `gradient` key turns the gradient off.
export function wordStyle(st, ov) {
  if (!ov) return st;
  const out = deepMerge(st, ov);
  if (ov.fill !== undefined && ov.gradient === undefined && out.gradient) out.gradient = { ...out.gradient, enabled: false };
  return out;
}
export const clone =(o) => JSON.parse(JSON.stringify(o));
export function getPath(o, path) { return path.split('.').reduce((a, k) => (a == null ? a : a[k]), o); }
export function setPath(o, path, v) {
  const ks = path.split('.'); let cur = o;
  for (let i = 0; i < ks.length - 1; i++) { if (cur[ks[i]] == null || typeof cur[ks[i]] !== 'object') cur[ks[i]] = {}; cur = cur[ks[i]]; }
  cur[ks[ks.length - 1]] = v;
}
