// Section 1: video & audio input, language, local transcription.
import { S, on, emit, loadProject, closeProject } from './store.js';
import { get, post, waitJob } from './api.js';
import { h, toast, setStatus, fmtTime, fmtBytes } from './dom.js';

const LANGS = [
  ['auto', 'Automatic', 'Decides English vs Hinglish for the whole file by checking how much Hindi it hears. Switching inside a sentence is handled by the Hinglish route, not detected separately.'],
  ['english', 'English', 'Forces English. Use only for English speech: Whisper translates any Hindi it hears into English in this mode.'],
  ['hinglish', 'Hinglish', 'Hindi written in Roman letters, English words kept in English spelling. Measured 3.4 % word error on one real clip; always review the transcript.'],
];

export function renderInput(root) {
  const m = S.meta;
  const pathIn = h('input', { type: 'text', placeholder: 'C:\\path\\to\\video.mp4', style: { flex: 1 } });
  const openBtn = h('button', { class: 'primary' }, 'Open');
  const open = async (path, lang) => {
    try {
      setStatus('opening…');
      await post('/api/projects/open', { video: path, language: lang || (m && m.language) || 'auto' });
      await loadProject();
      toast('Project opened', 'ok');
    } catch (e) { toast(e.message, 'err'); } finally { setStatus(''); }
  };
  openBtn.onclick = () => pathIn.value.trim() && open(pathIn.value.trim());
  pathIn.addEventListener('keydown', (e) => e.key === 'Enter' && openBtn.click());
  const browse = h('button', {}, 'Browse…');
  browse.onclick = async () => {
    try { const r = await post('/api/pick-video'); if (r.path) { pathIn.value = r.path; open(r.path); } } catch (e) { toast(e.message, 'err'); }
  };
  const recents = h('div', {});
  const paintRecents = () => get('/api/projects').then((r) => {
    const rows = r.projects.map((p) => {
      const cb = h('input', { type: 'checkbox', 'data-id': p.id, title: 'select for deletion' });
      const isOpen = !!(m && m.id === p.id);
      return h('div', { class: 'row tight' }, cb,
        h('button', { class: 'small', onclick: async () => { try { await post('/api/projects/load', { id: p.id }); await loadProject(); } catch (e) { toast(e.message, 'err'); paintRecents(); } } }, 'open'),
        h('span', {}, p.id), isOpen ? h('span', { class: 'pill on small' }, 'open') : null,
        h('span', { class: 'hint small' }, (p.has_transcript ? `${p.words} words` : 'not transcribed') + ` · ${fmtBytes(p.bytes)}` + (p.created ? ` · ${p.created.slice(0, 10)}` : '')));
    });
    if (!r.projects.length) { recents.replaceChildren(h('div', { class: 'hint' }, 'No projects yet.')); return; }
    const total = r.projects.reduce((a, p) => a + (p.bytes || 0), 0);
    const del = h('button', { class: 'danger small', disabled: true }, 'Delete selected…');
    const all = h('input', { type: 'checkbox', title: 'select all' });
    const boxes = () => rows.map((row) => row.querySelector('input[type=checkbox]'));
    const sync = () => { const n = boxes().filter((c) => c.checked).length; del.disabled = n === 0; del.textContent = n ? `Delete selected (${n})…` : 'Delete selected…'; all.checked = n === boxes().length; };
    rows.forEach((row) => row.querySelector('input[type=checkbox]').addEventListener('change', sync));
    all.onchange = () => { boxes().forEach((c) => { c.checked = all.checked; }); sync(); };
    del.onclick = async () => {
      const ids = boxes().filter((c) => c.checked).map((c) => c.dataset.id);
      if (!ids.length) return;
      const size = r.projects.filter((p) => ids.includes(p.id)).reduce((a, p) => a + (p.bytes || 0), 0);
      const msg = `Delete ${ids.length === 1 ? 'this project' : ids.length + ' projects'}?\n\n` + ids.map((i) => '  • ' + i + (m && m.id === i ? '   (open now)' : '')).join('\n') +
        `\n\nThis permanently removes the transcript, your word corrections, the caption settings and the preview copy (about ${fmtBytes(size)}).\n\n` +
        'Your original video/audio files and anything already built in After Effects are NOT deleted.\nThis cannot be undone.';
      if (!confirm(msg)) return;
      del.disabled = true;
      try {
        const res = await post('/api/projects/delete', { ids });
        if (res.closed_current) closeProject();
        if (res.deleted.length) toast(`Deleted ${res.deleted.length} project${res.deleted.length > 1 ? 's' : ''} · freed ${fmtBytes(res.freed)}`, 'ok');
        res.failed.forEach((f) => toast(`${f.id}: ${f.error}`, 'err', 12000));
        const left = res.deleted.flatMap((d) => d.kept);
        if (left.length) toast(`Left in place (not created by this tool): ${[...new Set(left)].join(', ')}`, '', 12000);
        if (!res.closed_current) paintRecents();               // closing the open project re-draws this whole panel
      } catch (e) { toast(e.message, 'err', 12000); del.disabled = false; }
    };
    recents.replaceChildren(...rows,
      h('div', { class: 'row tight' }, all, h('span', { class: 'hint small' }, `select all · ${r.projects.length} project${r.projects.length > 1 ? 's' : ''}, ${fmtBytes(total)} on disk`), del),
      h('div', { class: 'hint small' }, 'Deleting removes only this tool\'s saved work for a project. Your video files are never deleted.'));
    sync();
  }).catch(() => {});
  paintRecents();

  const els = [h('h2', {}, '1 · Video & audio input'),
    h('div', { class: 'hint' }, 'Everything runs on this computer. The video is never uploaded anywhere.'),
    h('div', { class: 'row' }, pathIn, browse, openBtn), h('h3', {}, 'Recent projects'), recents];

  if (m) {
    const pr = m.probe || {};
    const lang = h('select', {}, LANGS.map(([v, l]) => h('option', { value: v, selected: v === (m.language || 'auto') }, l)));
    const langHint = h('div', { class: 'hint small' });
    const upd = () => { langHint.textContent = LANGS.find((x) => x[0] === lang.value)[2]; }; lang.onchange = upd; upd();
    const bar = h('div', { class: 'bar' }, h('i', {})), msg = h('div', { class: 'hint small' });
    const go = h('button', { class: 'primary' }, S.transcript ? 'Transcribe again' : 'Transcribe');
    const strategy = h('select', {}, [['hybrid', 'Hybrid (recommended)'], ['apex', 'Hinglish model only'], ['stock_prompt', 'Stock Whisper + Roman prompt']].map(([v, l]) => h('option', { value: v }, l)));
    go.onclick = async () => {
      if (S.transcript && !confirm('Transcribe again? Your manual corrections are kept, but word ids may change, so some may no longer match.')) return;
      go.disabled = true; bar.firstChild.style.width = '2%'; msg.textContent = 'starting…';
      try {
        const job = await post('/api/transcribe', { language: lang.value, strategy: strategy.value });
        const done = await waitJob(job, (j) => { bar.firstChild.style.width = Math.round(j.progress * 100) + '%'; msg.textContent = (j.message || j.state) + (j.seconds ? '  ·  ' + Math.round(j.seconds) + ' s' : ''); setStatus(`${j.kind}: ${Math.round(j.progress * 100)} %`); });
        if (done.state !== 'done') throw new Error(done.error || done.state);
        await loadProject(); toast(`Transcribed ${done.result.words} words in ${done.seconds}s`, 'ok');
        emit('section', 'transcript');
      } catch (e) { toast(e.message, 'err', 9000); msg.textContent = e.message; } finally { go.disabled = false; setStatus(''); }
    };
    const imp = h('input', { type: 'file', accept: '.json', style: { display: 'none' } });
    imp.onchange = async () => {
      const f = imp.files[0]; if (!f) return;
      try { const t = JSON.parse(await f.text()); const r = await post('/api/transcript/import', t); await loadProject(); toast(`Imported (${r.stats.groups} captions)`, 'ok'); } catch (e) { toast(e.message, 'err'); }
    };
    els.push(h('div', { class: 'card' }, h('b', {}, m.id), h('div', { class: 'hint small' }, m.video),
      h('div', { class: 'hint small' }, pr.width ? `${pr.width}×${pr.height} · ${pr.fps ? pr.fps.toFixed(3) : '?'} fps · ${fmtTime(pr.duration || 0, false)}` : 'audio only / unknown'),
      pr.has_video === false ? null : h('div', { class: 'row tight' }, h('button', { class: 'small', title: 'Makes a small copy of the video that every browser can play (only the preview uses it)',
        onclick: () => S.usePreviewCopy && S.usePreviewCopy(true) }, 'Picture black or choppy? Make a preview copy'))),
      h('h3', {}, 'Language'), lang, langHint,
      h('details', { class: 'small' }, h('summary', {}, 'Advanced'), h('div', { class: 'row' }, h('label', { class: 'l' }, 'Hinglish route'), strategy)),
      h('div', { class: 'row' }, go, h('button', { onclick: () => imp.click() }, 'Import transcript.json…'), imp), bar, msg);
    if (S.transcript) {
      const t = S.transcript, q = (t.quality && t.quality.flag_counts) || {};
      const gaps = (t.quality && t.quality.speech_gaps) || [], fus = t.quality && t.quality.fusion;
      if (gaps.length) els.push(h('div', { class: 'card' }, h('b', { class: 'bad' }, 'Possible missing speech'),
        h('div', { class: 'small' }, 'The audio is loud here but no words were recognised. Listen and add the words in section 2:'),
        ...gaps.map(([a, b]) => h('div', { class: 'row tight' }, h('button', { class: 'small', onclick: () => { document.getElementById('video').currentTime = Math.max(0, a - 0.2); document.getElementById('video').play(); } }, '▶'), h('span', {}, `${fmtTime(a)} → ${fmtTime(b)}  (${(b - a).toFixed(1)} s)`)))));
      else if (fus && fus.patched_words > 0) els.push(h('div', { class: 'card small ok' }, `✓ The first decoding pass left silence over loud speech, so a second pass filled it (${fus.patched_words} word(s) recovered, main pass: ${fus.primary}). No missing speech detected.`));
      els.push(h('h3', {}, 'Last transcription'),
        h('div', { class: 'small' }, `${t.words.length} words · route ${t.language.route || t.language.mode} · ${t.engine.device}/${t.engine.compute_type} · ${t.engine.transcribe_seconds}s`),
        Object.keys(q).length ? h('div', { class: 'warn small' }, 'Flagged for review: ' + Object.entries(q).map(([k, v]) => `${v} ${k.replace('_', ' ')}`).join(', ')) : h('div', { class: 'ok small' }, 'No suspicious words flagged.'),
        ...t.warnings.slice(0, 6).map((w) => h('div', { class: 'hint small' }, '• ' + w)));
    }
  }
  root.replaceChildren(...els);
}
