// Sections 5-8: typography, colours & emphasis, animation, layout. Every control edits S.style (data), never code.
import { S, styleChanged, emit } from './store.js';
import { h, toast, deepMerge, getPath, setPath } from './dom.js';
import { fontPair } from './widgets.js';

let target = 'base';               // 'base' = every layout, a template name whose overrides are edited, or 'variant:<k>' = key-word treatment k
const EASES = ['linear', 'easeOut', 'easeOutSoft', 'easeInOut', 'easeIn', 'overshoot'];
const isVariant = () => target.startsWith('variant:');
const variantIndex = () => parseInt(target.slice(8), 10);
const rolesShown = () => (isVariant() ? ['accent'] : ['support', 'accent']);      // a key-word treatment only exists for the accent role

// "Edit" button of the Look section: jump to the typography section with that treatment as the edit target
export function editVariant(k) { target = 'variant:' + k; emit('section', 'typography'); }

// ---- read/write a role property for the current edit target. 'stack' writes into template_styles.stack.<role>, base into roles.<role>,
// a key-word treatment into roles.accent.variants[k] (merged over the accent role, so unset fields show the role's value)
function effective(role, path) {
  const base = S.style.roles[role];
  if (isVariant()) { const v = base.variants && base.variants[variantIndex()]; return getPath(v ? deepMerge(base, v) : base, path); }
  const ts = target !== 'base' && S.style.template_styles && S.style.template_styles[target] && S.style.template_styles[target][role];
  return getPath(ts ? deepMerge(base, ts) : base, path);
}
function delPath(o, path) {
  const ks = path.split('.'); let cur = o;
  for (let i = 0; i < ks.length - 1; i++) { cur = cur && cur[ks[i]]; if (cur == null || typeof cur !== 'object') return false; }
  return ks[ks.length - 1] in cur && delete cur[ks[ks.length - 1]];
}
// Editing "all layouts" must really change all layouts: a layout-specific override of the same property (e.g. the stack layout's own accent
// colour/font) would otherwise silently win, so the change would look like it "does nothing" on those captions. Such overrides are replaced.
function write(role, path, v) {
  if (isVariant()) setPath(S.style, `roles.accent.variants.${variantIndex()}.${path}`, v);
  else if (target === 'base') {
    setPath(S.style, `roles.${role}.${path}`, v);
    const hit = [];
    for (const [tpl, ts] of Object.entries(S.style.template_styles || {})) if (ts && ts[role] && delPath(ts[role], path)) hit.push(tpl);
    if (hit.length) toast(`Also applied to the "${hit.join('", "')}" layout — its own setting for this was replaced.`, 'ok');
  } else setPath(S.style, `template_styles.${target}.${role}.${path}`, v);
  styleChanged();
}
function targetBar(rerender) {
  const tpls = ['base', 'stack', 'tiers', 'flow', 'centered'];
  const vs = (S.style.roles.accent && S.style.roles.accent.variants) || [];
  if (isVariant() && !vs[variantIndex()]) target = 'base';
  return h('div', { class: 'row' }, h('label', { class: 'l' }, 'Editing'), h('select', { onchange: (e) => { target = e.target.value; rerender(); } },
    tpls.map((t) => h('option', { value: t, selected: t === target }, t === 'base' ? 'all layouts (base style)' : `only the "${t}" layout (overrides)`)),
    vs.map((v, i) => h('option', { value: 'variant:' + i, selected: target === 'variant:' + i }, `key-word treatment: ${v.name || i + 1}`))),
    h('span', { class: 'hint small' }, isVariant() ? 'Only fields you change here differ from the key-word role; everything else is inherited.'
      : 'Changing a value under "all layouts" replaces that layout-specific value too (e.g. the stack layout’s own accent colour).'));
}

// ---- field builders
function num(label, role, path, { min, max, step = 1 } = {}) {
  const i = h('input', { type: 'number', min, max, step, value: effective(role, path) });
  i.onchange = () => write(role, path, parseFloat(i.value));
  return h('div', { class: 'row tight' }, h('label', { class: 'l' }, label), i);
}
function color(label, role, path) {
  const v = effective(role, path) || '#ffffff', c = h('input', { type: 'color', value: v }), t = h('input', { type: 'text', value: v, style: { width: '84px' } });
  c.oninput = () => { t.value = c.value; write(role, path, c.value); };
  t.onchange = () => { if (/^#[0-9a-f]{6}$/i.test(t.value)) { c.value = t.value; write(role, path, t.value); } else t.value = c.value; };
  return h('div', { class: 'row tight' }, h('label', { class: 'l' }, label), c, t);
}
function check(label, role, path) {
  const c = h('input', { type: 'checkbox', checked: !!effective(role, path) }); c.onchange = () => write(role, path, c.checked);
  return h('div', { class: 'row tight' }, h('label', { class: 'l' }, label), c);
}
function slider(label, role, path, min, max, step) {
  const v = effective(role, path), r = h('input', { type: 'range', min, max, step, value: v }), n = h('input', { type: 'number', min, max, step, value: v });
  r.oninput = () => { n.value = r.value; write(role, path, +r.value); }; n.onchange = () => { r.value = n.value; write(role, path, +n.value); };
  return h('div', { class: 'row tight' }, h('label', { class: 'l' }, label), r, n);
}
function fontPicker(role) {
  return h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Font'), fontPair(effective(role, 'font'), (ps) => write(role, 'font', ps)));
}
// solid colour or gradient: only the controls that apply are shown (a gradient hides the solid fill, so both used to look "broken")
function fillRows(role, rerender) {
  const grad = !!effective(role, 'gradient.enabled');
  const sel = h('select', {}, h('option', { value: 'solid', selected: !grad }, 'Solid colour'), h('option', { value: 'gradient', selected: grad }, 'Gradient (top → bottom, inside the letters)'));
  sel.onchange = () => { write(role, 'gradient.enabled', sel.value === 'gradient'); rerender(); };
  return [h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Fill type'), sel),
    ...(grad ? [color('Gradient top', role, 'gradient.top'), color('Gradient bottom', role, 'gradient.bottom')] : [color('Fill', role, 'fill')])];
}
function roleBlock(role, ...rows) { return h('div', { class: 'card' }, h('b', {}, role === 'accent' ? 'Key words — accent (big, emphasised)' : 'Support words (small)'), ...rows); }

// ---- sections
export function renderTypography(root) {
  const re = () => renderTypography(root);
  // where key words sit in the "centered" layout: on a line of their own, or inside the running text (a bold word within a sentence)
  const lineRow = (r) => {
    if (r !== 'accent') return null;
    const s = h('select', {}, [['own', 'on their own line'], ['inline', 'inside the running text']].map(([v, t]) => h('option', { value: v, selected: (effective(r, 'line') || 'own') === v }, t)));
    s.onchange = () => write(r, 'line', s.value);
    return h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Key words sit'), s, h('span', { class: 'hint small' }, 'used by the "centered" layout'));
  };
  root.replaceChildren(h('h2', {}, '5 · Typography'), h('div', { class: 'hint small' }, 'Fonts are the ones installed on this computer (After Effects uses the same PostScript names). Any family can be used for key words only.'), targetBar(re),
    ...rolesShown().map((r) => roleBlock(r, fontPicker(r), num('Size (px)', r, 'size', { min: 8, max: 600 }), num('Tracking', r, 'tracking', { min: -200, max: 400 }),
      num('Max line width (× frame)', r, 'fit_width', { min: 0.2, max: 1, step: 0.01 }),
      (() => { const s = h('select', {}, ['none', 'upper'].map((v) => h('option', { value: v, selected: effective(r, 'caps') === v }, v === 'upper' ? 'ALL CAPS' : 'as spoken'))); s.onchange = () => write(r, 'caps', s.value); return h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Capitalisation'), s); })(), lineRow(r))));
}
export function renderColors(root) {
  const re = () => renderColors(root);
  root.replaceChildren(h('h2', {}, '6 · Colours & emphasis'), targetBar(re),
    ...rolesShown().map((r) => roleBlock(r, ...fillRows(r, re),
      num('Outline width', r, 'stroke.width', { min: 0, max: 40, step: 0.5 }), color('Outline colour', r, 'stroke.color'),
      check('Drop shadow', r, 'shadow.enabled'), color('Shadow colour', r, 'shadow.color'), slider('Shadow opacity', r, 'shadow.opacity', 0, 1, 0.05), slider('Shadow distance', r, 'shadow.distance', 0, 30, 0.5), slider('Shadow softness', r, 'shadow.softness', 0, 40, 0.5),
      check('Glow', r, 'glow.enabled'), color('Glow colour A', r, 'glow.color_a'), color('Glow colour B', r, 'glow.color_b'), slider('Glow radius', r, 'glow.radius', 0, 100, 1), slider('Glow strength', r, 'glow.intensity', 0, 3, 0.05))),
    h('div', { class: 'hint small' }, 'Key words = the accent role. Which words are key words is chosen automatically and can be flipped per word in section 2 (A/s buttons). Colour, gradient, font, size and effects of just some words: tick them in section 2 → "Style the selected words" (all fonts installed here are available; can also cover every occurrence of a word).'));
}
export function renderAnimation(root) {
  const re = () => renderAnimation(root);
  const easeRow = (r) => {
    const cur = effective(r, 'anim.ease'), isArr = Array.isArray(cur);
    const sel = h('select', {}, [...EASES, 'custom'].map((e) => h('option', { value: e, selected: isArr ? e === 'custom' : e === cur }, e)));
    const box = h('span', {}, ...[0, 1, 2, 3].map((i) => h('input', { type: 'number', step: 0.05, style: { width: '58px' }, value: isArr ? cur[i] : (FCGAnim.PRESETS[cur] || [0, 0, 1, 1])[i] })));
    const read = () => [...box.querySelectorAll('input')].map((x) => +x.value);
    sel.onchange = () => { if (sel.value === 'custom') write(r, 'anim.ease', read()); else { write(r, 'anim.ease', sel.value); } re(); };
    box.querySelectorAll('input').forEach((i) => (i.onchange = () => write(r, 'anim.ease', read())));
    return h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Easing'), sel, box);
  };
  const slideRow = (r) => {
    const s = effective(r, 'anim.slide') || [0, 0];
    const x = h('input', { type: 'number', value: s[0], style: { width: '64px' } }), y = h('input', { type: 'number', value: s[1], style: { width: '64px' } });
    x.onchange = y.onchange = () => write(r, 'anim.slide', [+x.value, +y.value]);
    return h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Slide in from (px)'), 'x', x, 'y', y);
  };
  // per-letter reveal: each letter fades/un-blurs/rises one after another, newly shown letters carry a tint that settles to the fill colour
  const unitRow = (r) => {
    const s = h('select', {}, [['word', 'whole word at once'], ['letter', 'letter by letter']].map(([v, t]) => h('option', { value: v, selected: (effective(r, 'anim.unit') || 'word') === v }, t)));
    s.onchange = () => { write(r, 'anim.unit', s.value); re(); };
    return h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Reveal'), s);
  };
  const tintRow = (r) => {
    const cur = effective(r, 'anim.letters.tint') || '', on = h('input', { type: 'checkbox', checked: !!cur });
    const c = h('input', { type: 'color', value: cur || '#e5b8c6' }), t = h('input', { type: 'text', value: cur || '#e5b8c6', style: { width: '84px' } });
    on.onchange = () => write(r, 'anim.letters.tint', on.checked ? c.value : '');
    c.oninput = () => { t.value = c.value; if (on.checked) write(r, 'anim.letters.tint', c.value); };
    t.onchange = () => { if (/^#[0-9a-f]{6}$/i.test(t.value)) { c.value = t.value; if (on.checked) write(r, 'anim.letters.tint', t.value); } else t.value = c.value; };
    return h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Tint while revealing'), on, c, t, h('span', { class: 'hint small' }, 'hidden by a gradient fill'));
  };
  const blockFor = (r) => ((effective(r, 'anim.unit') || 'word') === 'letter'
    ? [unitRow(r), slider('Letter delay (s)', r, 'anim.letters.stagger', 0, 0.15, 0.002), slider('Letter fade (s)', r, 'anim.letters.duration', 0.02, 0.6, 0.01), easeLetterRow(r),
       slider('Letter blur (px)', r, 'anim.letters.blur_from', 0, 40, 1), slider('Letter rise (px)', r, 'anim.letters.rise', -60, 60, 1), slider('Fade from', r, 'anim.letters.opacity_from', 0, 1, 0.05),
       tintRow(r), slider('Tint fades over (s)', r, 'anim.letters.tint_duration', 0, 1, 0.01), slider('Whole word at most (s)', r, 'anim.letters.max_total', 0.1, 2, 0.05)]
    : [unitRow(r), slider('Duration (s)', r, 'anim.duration', 0, 0.8, 0.01), easeRow(r), slideRow(r), slider('Scale from', r, 'anim.scale_from', 0.5, 1.6, 0.01),
       slider('Fade from', r, 'anim.opacity_from', 0, 1, 0.05), slider('Blur from (px)', r, 'anim.blur_from', 0, 60, 1)]);
  function easeLetterRow(r) {
    const cur = effective(r, 'anim.letters.ease') || 'easeOut', sel = h('select', {}, EASES.filter((e) => e !== 'overshoot').map((e) => h('option', { value: e, selected: cur === e }, e)));
    sel.onchange = () => write(r, 'anim.letters.ease', sel.value);
    return h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Letter easing'), sel);
  }
  root.replaceChildren(h('h2', {}, '7 · Animation'), h('div', { class: 'hint small' }, 'Each word animates in starting exactly at its reveal time; the motion can never start earlier — in letter mode the first letter starts at the reveal and every later letter after it. Scrub or play the preview to see it. Exit is a clean cut.'), targetBar(re),
    ...rolesShown().map((r) => roleBlock(r, ...blockFor(r))),
    h('div', { class: 'hint small' }, 'Overshoot easing bounces the scale; motion along a path is kept smooth (After Effects cannot overshoot a position path). Entrances are shortened automatically when a caption leaves quickly. Letter mode replaces the word-level blur/slide/scale.'));
}
export function renderLayout(root) {
  const L = S.style.layout, set = (p, v) => { setPath(S.style.layout, p, v); styleChanged(); };
  const sl = (label, p, min, max, step) => { const v = getPath(L, p), r = h('input', { type: 'range', min, max, step, value: v }), n = h('input', { type: 'number', min, max, step, value: v });
    r.oninput = () => { n.value = r.value; set(p, +r.value); }; n.onchange = () => { r.value = n.value; set(p, +n.value); }; return h('div', { class: 'row tight' }, h('label', { class: 'l' }, label), r, n); };
  const tpl = h('select', {}, ['auto', 'tiers', 'stack', 'flow', 'centered'].map((t) => h('option', { value: t, selected: L.template === t }, t)));
  tpl.onchange = () => set('template', tpl.value);
  const cyc = h('input', { type: 'text', value: (L.auto_cycle || []).join(', '), style: { width: '190px' } });
  cyc.onchange = () => { const v = cyc.value.split(',').map((s) => s.trim()).filter((s) => ['tiers', 'stack', 'flow'].includes(s)); if (v.length) set('auto_cycle', v); else cyc.value = L.auto_cycle.join(', '); };
  const offs = h('input', { type: 'text', value: (getPath(L, 'stack.x_offsets') || []).join(', '), style: { width: '150px' } });
  offs.onchange = () => set('stack.x_offsets', offs.value.split(',').map((s) => parseFloat(s)).filter((x) => !isNaN(x)));
  const comp = S.meta && S.meta.probe ? `${S.meta.probe.width}×${S.meta.probe.height}` : 'comp';
  root.replaceChildren(h('h2', {}, '8 · Position & layout'), h('div', { class: 'hint small' }, `Positions are fractions of the ${comp} frame. The whole caption is laid out before its first word appears, so nothing jumps.`),
    h('div', { class: 'card' }, h('div', { class: 'row' }, h('label', { class: 'l' }, 'Layout'), tpl), h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Auto pattern'), cyc, h('span', { class: 'hint small' }, 'tiers / stack / flow, repeated')),
      sl('Vertical position', 'anchor_y', 0.1, 0.95, 0.01), sl('Horizontal position', 'anchor_x', 0.2, 0.8, 0.01), sl('Max text width', 'max_width', 0.3, 1, 0.01), sl('Safe margin', 'safe_margin', 0, 0.2, 0.005), sl('Word space (em)', 'word_space_em', 0.1, 0.6, 0.01)),
    h('div', { class: 'card' }, h('b', {}, '"tiers" layout'), sl('Gap between lines (px)', 'tiers.gap_px', -60, 60, 1), sl('Support line inset (px)', 'tiers.support_inset_px', -120, 120, 1), sl('Baseline step (px)', 'tiers.baseline_step_px', 0, 30, 1)),
    h('div', { class: 'card' }, h('b', {}, '"stack" layout'), sl('Line gap (em)', 'stack.gap_em', -0.4, 0.4, 0.01), h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Horizontal offsets'), offs)),
    h('div', { class: 'card' }, h('b', {}, '"centered" layout'), h('div', { class: 'hint small' }, 'Centred lines; a new line starts when the text treatment changes (running text → key words on their own line → running text).'),
      sl('Line gap (em of the smaller line)', 'centered.gap_em', -0.4, 0.6, 0.01), sl('Extra line gap (px)', 'centered.gap_px', -60, 60, 1)),
    h('div', { class: 'hint small' }, 'Tip: for a talking head, keep the text below the mouth — raise “Vertical position” until the face is clear.'));
}
