// Section 4: caption looks. A look = a complete style (fonts, colours, layout, animation) stored as a preset file; applying one is a single click and
// never touches wording or timing. Also: save your own looks, and tune the accent treatments of looks that have several.
import { S, styleChanged, emit } from './store.js';
import { get, put, del } from './api.js';
import { h, toast, clone, deepMerge } from './dom.js';
import { drawLookThumb } from './look_thumb.js';
import { editVariant } from './panel_style.js';

const styles = {};                                   // preset name -> full style (fetched once; user presets are re-fetched after saving)
async function styleOf(name) {
  if (!styles[name]) styles[name] = (await get('/api/presets/' + encodeURIComponent(name))).style;
  return styles[name];
}
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
// does every value of `patch` appear (equal) in `style`? (objects compared key by key, arrays/values by content)
function matchesPatch(style, patch) {
  if (patch && typeof patch === 'object' && !Array.isArray(patch)) return style != null && typeof style === 'object' && Object.keys(patch).every((k) => matchesPatch(style[k], patch[k]));
  return JSON.stringify(style) === JSON.stringify(patch);
}

async function applyLook(p) {
  try {
    S.style = clone(await styleOf(p.name));
    if (S.meta) S.meta.style_preset = p.name;
    styleChanged();
    const g = S.style.grouping;
    toast(`Look applied: ${p.look.title}` + (g && g.max_words ? ` — captions re-cut to at most ${g.max_words} words per line` : ''), 'ok');
    emit('section', 'look');
  } catch (e) { toast(e.message, 'err'); }
}

// One-click switch of a look (e.g. "Smooth slide-up animation" of Clean 4-Word): the look's `toggle` has an `on` and an `off` style patch.
function toggleCard(p) {
  const t = p && p.look && p.look.toggle;
  if (!t) return null;
  const on = matchesPatch(S.style, t.on), off = !on && matchesPatch(S.style, t.off);
  const state = on ? 'on' : off ? 'off' : 'custom';
  const btn = h('button', { class: 'switch ' + state, role: 'switch', 'aria-checked': on ? 'true' : 'false', title: 'click to turn ' + (on ? 'off' : 'on') }, h('span', { class: 'knob' }), on ? 'ON' : off ? 'OFF' : 'CUSTOM');
  btn.onclick = () => {
    S.style = deepMerge(S.style, on ? t.off : t.on);
    styleChanged(); toast(`${t.label}: ${on ? 'off — plain text' : 'on'}`, 'ok'); emit('section', 'look');
  };
  return h('div', { class: 'card' }, h('div', { class: 'row' }, h('b', {}, t.label), btn),
    h('div', { class: 'hint small' }, (t.hint || '') + (state === 'custom' ? ' Your own animation settings (section 7) are active; clicking applies this look\'s ' + 'on-state.' : '')));
}

export function renderLook(root) {
  const cur = (S.meta && S.meta.style_preset) || 'reference_style';
  const grid = h('div', { class: 'looks' });
  const cards = S.presets.map((p) => {
    const cv = h('canvas', { width: 216, height: 384, class: 'lookthumb' });
    const badge = h('span', { class: 'pill off small' }, '');
    const useBtn = h('button', { class: 'primary small' }, 'Use this look');
    useBtn.onclick = () => applyLook(p);
    const delBtn = p.builtin ? null : h('button', { class: 'small danger', title: 'delete this saved look', onclick: async () => {
      if (!confirm('Delete the saved look "' + p.name + '"?')) return;
      try { await del('/api/presets/' + encodeURIComponent(p.name)); delete styles[p.name]; S.presets = (await get('/api/presets')).presets; emit('section', 'look'); } catch (e) { toast(e.message, 'err'); } } }, 'Delete');
    const card = h('div', { class: 'lookcard' + (p.name === cur ? ' current' : '') }, cv,
      h('div', { class: 'lookbody' }, h('b', {}, p.look.title), badge, h('div', { class: 'hint small' }, p.look.description || (p.builtin ? '' : 'Your saved look')),
        h('div', { class: 'hint small' }, (p.look.tags || []).join(' · ')), h('div', { class: 'row tight' }, useBtn, delBtn)));
    styleOf(p.name).then((st) => {
      drawLookThumb(cv, st);
      if (p.name === cur) {
        // the look's own on/off switch is not an "edit"
        const t = p.look.toggle, pure = same(st, S.style) || (t && (same(deepMerge(st, t.on), S.style) || same(deepMerge(st, t.off), S.style)));
        badge.className = 'pill on small'; badge.textContent = pure ? 'current look' : 'current look (edited)';
      }
    }).catch(() => { badge.textContent = 'could not load'; });
    return card;
  });
  grid.append(...cards);

  // save the current style as a new look
  const name = h('input', { type: 'text', placeholder: 'my look', style: { width: '170px' } });
  const save = h('button', { onclick: async () => {
    const n = name.value.trim();
    if (!n) return toast('Give the look a name first', 'err');
    try {
      await put('/api/presets/' + encodeURIComponent(n), S.style);
      delete styles[n]; S.presets = (await get('/api/presets')).presets; if (S.meta) S.meta.style_preset = n; styleChanged();
      toast('Saved look: ' + n, 'ok'); emit('section', 'look');
    } catch (e) { toast(e.message, 'err'); } } }, 'Save current look as…');

  root.replaceChildren(h('h2', {}, '4 · Caption look'),
    h('div', { class: 'hint small' }, 'One click changes the whole look — fonts, colours, layout and animation — on every caption. Wording and timing are never touched, and a word still never appears before it is spoken. Your look-specific tweaks (sections 5–8) are replaced, so save them first if you want to keep them.'),
    toggleCard(S.presets.find((p) => p.name === cur)), grid, accentCard(), h('h3', {}, 'Keep the current look'), h('div', { class: 'row' }, name, save),
    h('div', { class: 'hint small' }, 'A look is a plain JSON file in presets/ (yours go in presets/user/). Share it by copying the file.'));
}

// Looks like "Soft Editorial" give key words several treatments; choose which are used, how they are picked, and edit each one.
function accentCard() {
  const acc = S.style && S.style.roles && S.style.roles.accent, vs = acc && acc.variants;
  if (!vs || !vs.length) return null;
  const pool = new Set(acc.variant_pool && acc.variant_pool.length ? acc.variant_pool : vs.map((_, i) => i));
  const mode = h('select', {}, [['rotate', 'rotate through the ticked treatments'], ['fixed', 'always the first ticked treatment']].map(([v, t]) => h('option', { value: v, selected: (acc.variant_mode || 'rotate') === v }, t)));
  mode.onchange = () => { acc.variant_mode = mode.value; styleChanged(); };
  const boxes = [];
  const rows = vs.map((v, i) => {
    const c = h('input', { type: 'checkbox', checked: pool.has(i) });
    boxes.push(c);
    c.onchange = () => {
      const next = boxes.map((b, j) => (b.checked ? j : -1)).filter((j) => j >= 0);
      if (!next.length) { c.checked = true; return toast('At least one treatment must stay ticked', 'err'); }
      acc.variant_pool = next; styleChanged();
    };
    return h('div', { class: 'row tight' }, c, h('span', {}, v.name || 'Treatment ' + (i + 1)), h('button', { class: 'small', title: 'edit font, size, colours, glow and animation of this treatment', onclick: () => editVariant(i) }, 'edit'));
  });
  return h('div', { class: 'card' }, h('b', {}, 'Key-word treatments'),
    h('div', { class: 'hint small' }, 'Each phrase of key words takes the next treatment, like an editor varying the emphasis. A single word can be switched in section 2 (word list → "make accent" panel).'),
    h('div', { class: 'row tight' }, h('label', { class: 'l' }, 'Picking'), mode), ...rows);
}
