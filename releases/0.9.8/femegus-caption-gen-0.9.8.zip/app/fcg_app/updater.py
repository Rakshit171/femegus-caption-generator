"""Free, opt-in updates from a static host (by default the public GitHub repository's raw files).

Two kinds of update, both described by one small manifest (`latest.json`):
  * LOOK PACKS - single preset .json files (pure data). They are validated (allowed keys only, size limit, checksum) and stored in
    presets/downloaded/. Safe to install at any time; no restart needed.
  * APP UPDATES - a zip of the program files. Checksum-verified, extracted to a staging folder with strict path rules, the files that will
    be replaced are backed up first, then copied over; any failure restores the backup. A restart is needed afterwards.

Nothing is contacted unless the user presses "Check now" or has switched on automatic checks. Only GET requests are made; no data about the
user, the footage or the projects is ever sent (the request carries the app name and version in the User-Agent, like any browser would).
Never touched by an update: projects/, models/, .venv, work/, presets/user/, presets/downloaded/, settings, backups.

Security note (documented in docs/UPDATES.md): the SHA-256 in the manifest protects against damaged downloads and against mixing files from
different releases; it cannot protect against someone who controls the publishing repository. Protect that GitHub account with two-factor sign-in.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import shutil
import time
import urllib.error
import urllib.request
import zipfile
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

DEFAULT_BASE = "https://raw.githubusercontent.com/Rakshit171/femegus-caption-generator/main/"
SCHEMA = "fcg.update"
MAX_MANIFEST = 1 << 20                  # 1 MB
MAX_LOOK = 256 * 1024                   # a preset is a few KB
MAX_ZIP = 300 * 1024 * 1024
MAX_UNPACKED = 600 * 1024 * 1024
KEEP_BACKUPS = 3
CHECK_INTERVAL_S = 24 * 3600            # automatic checks run at most once a day

# what an app-update zip may contain (everything else is rejected, the whole update then fails before anything is written)
ALLOWED_DIRS = ("app/", "core/", "engine/", "adapters/", "scripts/", "docs/")
ALLOWED_FILES = {"VERSION", "CHANGELOG.md", "README.md", "LICENSE", "LICENSE.txt", "Start-FemeGus.cmd", "Install-FemeGus.cmd",
                 "requirements.txt", "requirements-gpu.txt", "requirements.lock.txt"}
PROTECTED = (".venv", ".venv-convert", "models", "projects", "work", "backup", "presets/user", "presets/downloaded", ".git",
             "engine/models_local.json", "adapters/jsx-core/fcg_job.json")        # the last two are written by the user's own setup / experiments
LOOK_KEYS = {"_comment", "_look", "layout", "roles", "template_styles", "grouping"}
LOOK_NAME = re.compile(r"^[A-Za-z0-9_-]{1,40}$")
VERSION_RE = re.compile(r"^\d+(\.\d+){0,3}$")


class UpdateError(Exception):
    """A problem the user can understand (shown as is in the app)."""


def vtuple(v: str) -> tuple:
    if not isinstance(v, str) or not VERSION_RE.match(v):
        raise UpdateError(f"unexpected version number: {v!r}")
    return tuple(int(x) for x in v.split("."))


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _norm_text_hash(paths: list[str]) -> str:
    """Hash of text files with line endings normalised (so Windows/Git line-ending differences do not matter)."""
    h = hashlib.sha256()
    for p in paths:
        try:
            with open(p, "rb") as f:
                h.update(f.read().replace(b"\r\n", b"\n"))
        except OSError:
            h.update(b"<missing>")
    return h.hexdigest()


def requirements_hash(root: str) -> str:
    return _norm_text_hash([os.path.join(root, n) for n in ("requirements.txt", "requirements-gpu.txt")])


def safe_member(name: str) -> bool:
    """Is this zip member allowed to be written into the project folder?"""
    if not name or "\\" in name or name.startswith("/") or ":" in name:
        return False
    parts = name.rstrip("/").split("/")
    if any(p in ("", ".", "..") for p in parts):
        return False
    low = name.lower()
    if any(low == p or low.startswith(p + "/") for p in PROTECTED):
        return False
    if name in ALLOWED_FILES or name.startswith(ALLOWED_DIRS):
        return True
    return name.startswith("presets/") and name.count("/") == 1 and name.endswith(".json")      # built-in looks only (not presets/user, presets/downloaded)


class Updater:
    def __init__(self, root: str, base: Optional[str] = None, version: Optional[str] = None):
        self.root = os.path.abspath(root)
        self.base = base or os.environ.get("FCG_UPDATE_BASE") or DEFAULT_BASE
        if not self.base.endswith("/"):
            self.base += "/"
        self.running_version = version or ""            # the version the RUNNING program was started with (fixed until it is restarted)
        self.downloaded = os.path.join(self.root, "presets", "downloaded")
        self.backup_dir = os.path.join(self.root, "backup")

    # ------------------------------------------------------------------------------------------------------------------ basics
    def current_version(self) -> str:
        """The INSTALLED version = the VERSION file on disk (it changes the moment an update or rollback is applied, while the running program keeps
        the old code until it is restarted - so 'Check for updates' must never use the running version, or it would offer the same update forever)."""
        try:
            with open(os.path.join(self.root, "VERSION"), "r", encoding="utf-8-sig") as f:
                v = f.readline().strip()
            vtuple(v)
            return v
        except (OSError, UpdateError):
            return "0.0.0"

    @staticmethod
    def _scheme_ok(url: str) -> bool:
        u = urlparse(url)
        return u.scheme == "https" or (u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost"))      # plain http only for local testing

    def _resolve(self, rel: str) -> str:
        if not isinstance(rel, str) or not rel:
            raise UpdateError("the update information is incomplete (missing address)")
        url = urljoin(self.base, rel)
        if not url.startswith(self.base) or not self._scheme_ok(url):
            raise UpdateError("the update information points outside the update site and was ignored")
        return url

    def _download(self, url: str, limit: int) -> bytes:
        if not self._scheme_ok(url):
            raise UpdateError("updates must be downloaded over https")
        req = urllib.request.Request(url, headers={"User-Agent": f"FemeGusCaptions/{self.current_version()}", "Cache-Control": "no-cache"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                if not self._scheme_ok(r.geturl()):
                    raise UpdateError("the download was redirected to an insecure address and was refused")
                data = r.read(limit + 1)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise UpdateError("No update has been published yet (the update site has no such file).")
            raise UpdateError(f"the update site answered with an error ({e.code}).")
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise UpdateError("Could not reach the update site. Check your internet connection and try again.") from e
        if len(data) > limit:
            raise UpdateError("the download is larger than expected and was refused")
        return data

    # ------------------------------------------------------------------------------------------------------------------ manifest
    def fetch_manifest(self) -> dict:
        raw = self._download(urljoin(self.base, "latest.json"), MAX_MANIFEST)
        try:
            m = json.loads(raw.decode("utf-8-sig"))
        except (ValueError, UnicodeDecodeError):
            raise UpdateError("the update information is damaged")
        if not isinstance(m, dict) or m.get("schema") != SCHEMA:
            raise UpdateError("the update information is not in the expected format")
        vtuple(m.get("version", ""))
        if not isinstance(m.get("looks", []), list):
            raise UpdateError("the update information is damaged (looks)")
        return m

    def _look_local(self, name: str) -> Optional[str]:
        for d in (self.downloaded, os.path.join(self.root, "presets")):
            p = os.path.join(d, name + ".json")
            if os.path.isfile(p):
                return p
        return None

    def _look_status(self, e: dict) -> str:
        name = e.get("name", "")
        if not LOOK_NAME.match(name):
            return "invalid"
        p = self._look_local(name)
        if p is None:
            return "new"
        with open(p, "rb") as f:
            return "current" if sha256_bytes(f.read()) == e.get("sha256") else "update"

    @property
    def setup_flag(self) -> str:
        return os.path.join(self.root, "work", "needs_setup.flag")

    def needs_setup(self) -> bool:
        return os.path.exists(self.setup_flag)

    def restart_needed(self) -> bool:
        return bool(self.running_version) and self.current_version() != self.running_version

    def check(self) -> dict:
        """Compare with the published manifest. Read-only."""
        m = self.fetch_manifest()
        cur = self.current_version()
        app = m.get("app") if isinstance(m.get("app"), dict) else None
        newer = bool(app) and vtuple(m["version"]) > vtuple(cur)
        looks = []
        for e in m.get("looks", []):
            if isinstance(e, dict) and LOOK_NAME.match(str(e.get("name", ""))):
                looks.append({"name": e["name"], "title": str(e.get("title") or e["name"])[:80], "status": self._look_status(e)})
        return {"current": cur, "running": self.running_version or cur, "restart_needed": self.restart_needed(), "latest": m["version"], "released": m.get("released"), "notes": [str(n)[:300] for n in (m.get("notes") or [])][:30],
                "app_update": newer, "app_size": (app or {}).get("size"),
                "needs_setup": bool(newer and app.get("requirements_sha256") and app["requirements_sha256"] != requirements_hash(self.root)),
                "looks": looks, "checked_at": time.time()}

    # ------------------------------------------------------------------------------------------------------------------ look packs
    @staticmethod
    def validate_look(name: str, data: bytes) -> dict:
        if not LOOK_NAME.match(name):
            raise UpdateError(f"invalid look name {name!r}")
        if len(data) > MAX_LOOK:
            raise UpdateError(f"look '{name}' is too large")
        try:
            d = json.loads(data.decode("utf-8-sig"))
        except (ValueError, UnicodeDecodeError):
            raise UpdateError(f"look '{name}' is damaged")
        if not isinstance(d, dict) or not set(d) <= LOOK_KEYS or not isinstance(d.get("roles"), dict) or not isinstance(d.get("layout"), dict):
            raise UpdateError(f"look '{name}' has unexpected content and was refused (a look may only contain layout, roles, template_styles, grouping)")
        meta = d.get("_look")
        if meta is not None and not (isinstance(meta, dict) and isinstance(meta.get("title", ""), str)):
            raise UpdateError(f"look '{name}' has a damaged description")
        return d

    def install_looks(self, names: list[str]) -> list[str]:
        m = self.fetch_manifest()
        wanted = {e["name"]: e for e in m.get("looks", []) if isinstance(e, dict) and LOOK_NAME.match(str(e.get("name", "")))}
        done = []
        os.makedirs(self.downloaded, exist_ok=True)
        for n in names:
            e = wanted.get(n)
            if e is None:
                raise UpdateError(f"'{n}' is not in the published list of looks")
            data = self._download(self._resolve(e.get("url")), MAX_LOOK)
            if sha256_bytes(data) != e.get("sha256"):
                raise UpdateError(f"look '{n}' failed its integrity check and was not installed")
            self.validate_look(n, data)
            tmp = os.path.join(self.downloaded, n + ".json.tmp")
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, os.path.join(self.downloaded, n + ".json"))
            done.append(n)
        return done

    # ------------------------------------------------------------------------------------------------------------------ app update
    def _validate_zip(self, data: bytes, version: str) -> zipfile.ZipFile:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise UpdateError("the downloaded update is not a valid zip file")
        total = 0
        names = set()
        for i in z.infolist():
            if i.is_dir():
                if not (safe_member(i.filename.rstrip("/") + "/x") or i.filename.rstrip("/") in ("app", "core", "engine", "adapters", "scripts", "docs", "presets")):
                    raise UpdateError(f"the update contains a folder that is not allowed: {i.filename}")
                continue
            if (i.external_attr >> 16) & 0o170000 == 0o120000:
                raise UpdateError("the update contains a link, which is not allowed")
            if not safe_member(i.filename):
                raise UpdateError(f"the update contains a file that is not allowed: {i.filename}")
            total += i.file_size
            names.add(i.filename)
        if total > MAX_UNPACKED:
            raise UpdateError("the update is larger than expected")
        for must in ("VERSION", "app/fcg_app/server.py"):
            if must not in names:
                raise UpdateError(f"the update is incomplete (missing {must})")
        if z.read("VERSION").decode("utf-8-sig").splitlines()[0].strip() != version:
            raise UpdateError("the update's version does not match its description")
        return z

    def apply_app_update(self) -> dict:
        m = self.fetch_manifest()
        app = m.get("app")
        if not isinstance(app, dict):
            raise UpdateError("this release has no app update")
        if vtuple(m["version"]) <= vtuple(self.current_version()):
            raise UpdateError("You already have the newest version.")
        data = self._download(self._resolve(app.get("url")), MAX_ZIP)
        if sha256_bytes(data) != app.get("sha256"):
            raise UpdateError("the download failed its integrity check and was not installed")
        z = self._validate_zip(data, m["version"])
        files = [i for i in z.infolist() if not i.is_dir()]
        old = self.current_version()
        old_req = requirements_hash(self.root)                                  # BEFORE the files are replaced: did the needed Python packages change?
        stamp = time.strftime("%Y%m%d-%H%M%S")
        bdir = os.path.join(self.backup_dir, f"{old}-{stamp}")
        os.makedirs(os.path.join(bdir, "files"), exist_ok=True)
        replaced, created = [], []
        try:
            for i in files:                                                    # 1. back up what will be overwritten
                dst = os.path.join(self.root, *i.filename.split("/"))
                if os.path.isfile(dst):
                    bk = os.path.join(bdir, "files", *i.filename.split("/"))
                    os.makedirs(os.path.dirname(bk), exist_ok=True)
                    shutil.copy2(dst, bk)
                    replaced.append(i.filename)
                else:
                    created.append(i.filename)
            with open(os.path.join(bdir, "undo.json"), "w", encoding="utf-8") as f:
                json.dump({"version_before": old, "version_after": m["version"], "replaced": replaced, "created": created}, f, indent=1)
            for i in sorted(files, key=lambda x: x.filename == "VERSION"):     # 2. write; VERSION last, so a half-finished update never claims the new version
                dst = os.path.join(self.root, *i.filename.split("/"))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                tmp = dst + ".fcgnew"
                try:
                    with open(tmp, "wb") as f:
                        f.write(z.read(i))
                    os.replace(tmp, dst)
                except BaseException:
                    if os.path.exists(tmp):                                    # never leave a half-written temporary file behind
                        os.remove(tmp)
                    raise
        except Exception as e:
            self._restore(bdir)
            if isinstance(e, UpdateError):
                raise
            raise UpdateError(f"the update could not be installed ({e}); your previous version was restored") from e
        self._prune_backups()
        needs_setup = bool(app.get("requirements_sha256") and app["requirements_sha256"] != old_req)
        if needs_setup:                                                        # remembered on disk so a reloaded page still knows the restart must install components
            try:
                os.makedirs(os.path.join(self.root, "work"), exist_ok=True)
                with open(self.setup_flag, "w", encoding="utf-8") as f:
                    f.write(m["version"])
            except OSError:
                pass
        return {"version": m["version"], "previous": old, "files": len(files), "restart_required": True, "needs_setup": needs_setup}

    # ------------------------------------------------------------------------------------------------------------------ backups / rollback
    def backups(self) -> list[dict]:
        out = []
        if os.path.isdir(self.backup_dir):
            for n in sorted(os.listdir(self.backup_dir), reverse=True):
                u = os.path.join(self.backup_dir, n, "undo.json")
                if os.path.isfile(u):
                    try:
                        with open(u, "r", encoding="utf-8") as f:
                            d = json.load(f)
                        out.append({"id": n, "version": d.get("version_before"), "replaced_by": d.get("version_after")})
                    except (OSError, ValueError):
                        pass
        return out

    def _restore(self, bdir: str) -> None:
        u = os.path.join(bdir, "undo.json")
        if not os.path.isfile(u):                                              # failure before the undo record existed: nothing was written yet
            shutil.rmtree(bdir, ignore_errors=True)
            return
        with open(u, "r", encoding="utf-8") as f:
            d = json.load(f)
        for rel in d.get("replaced", []):
            src = os.path.join(bdir, "files", *rel.split("/"))
            dst = os.path.join(self.root, *rel.split("/"))
            if os.path.isfile(src):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
        for rel in d.get("created", []):
            p = os.path.join(self.root, *rel.split("/"))
            if os.path.isfile(p):
                os.remove(p)
        shutil.rmtree(bdir, ignore_errors=True)

    def rollback(self) -> dict:
        b = self.backups()
        if not b:
            raise UpdateError("There is no previous version to go back to.")
        self._restore(os.path.join(self.backup_dir, b[0]["id"]))
        return {"version": self.current_version(), "restart_required": True}

    def _prune_backups(self) -> None:
        for b in self.backups()[KEEP_BACKUPS:]:
            shutil.rmtree(os.path.join(self.backup_dir, b["id"]), ignore_errors=True)
