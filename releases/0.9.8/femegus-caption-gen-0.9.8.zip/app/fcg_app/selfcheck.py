"""System check: is this computer ready to use the tool, and if not, what exactly should the user do?

Every check returns {id, status: ok|warn|fail, title, detail, fix, fix_action}. The CHECKS read things only (no installs, no changes), and each check is isolated
so one failure never hides the others. Run it with:  python -m fcg_app --check   (or the 'Run system check' button in section 10).
``fix_action`` names a one-click repair the page can offer for that problem (see FIX_META and fixes.py): the check itself still changes nothing.
"""
from __future__ import annotations

import glob
import importlib
import os
import re
import shutil
import socket
import subprocess
import sys
from typing import Callable

from .ops import ROOT

MIN_PY = (3, 10)
RUNTIME_PACKAGES = [("faster_whisper", "faster-whisper"), ("ctranslate2", "ctranslate2"), ("av", "PyAV (av)"), ("numpy", "numpy"), ("onnxruntime", "onnxruntime")]
WARN_FREE_GB = 5.0


# One-click repairs the page can offer. ``restart`` ones re-install components in the launcher before the app starts again (a running program keeps its
# libraries locked); the others run inside the app as a background job with progress (fixes.py).
FIX_META = {
    "repair": {"label": "Repair components", "size": "a few minutes", "internet": True, "restart": True,
               "note": "Re-installs the tested versions of the Python components, then restarts the app. Your projects, looks and downloaded models are kept."},
    "repair_gpu": {"label": "Install the GPU libraries", "size": "about 1.5 GB, a few minutes", "internet": True, "restart": True,
                   "note": "Installs the NVIDIA CUDA libraries the speech engine needs for the graphics card, then restarts the app. (Also update the NVIDIA driver if it is old.)"},
    "english_model": {"label": "Download the English speech model", "size": "about 1.6 GB", "internet": True, "restart": False,
                      "note": "Downloads the stock speech model (large-v3-turbo) from Hugging Face. Needed for English, Hinglish and Auto."},
    "hinglish_model": {"label": "Set up the Hinglish model", "size": "about 3 GB download, then a few minutes of conversion", "internet": True, "restart": False,
                       "note": "Downloads the Hinglish model, converts it once for the speech engine and removes the conversion tools afterwards (frees about 4 GB again)."},
    "register_hinglish": {"label": "Reconnect the Hinglish model", "size": "a few seconds", "internet": False, "restart": False,
                          "note": "The model is on this computer but the app does not know where; this writes that down (no download)."},
    "show_connect_script": {"label": "Show me the connect script", "size": "", "internet": False, "restart": False,
                            "note": "Opens the folder with fcg_connect.jsx so you can run it from After Effects (File > Script > Run Script File…)."},
}
FIX_ORDER = ["english_model", "register_hinglish", "hinglish_model", "repair_gpu", "repair"]      # "Fix everything": downloads first, restart-type repairs last


def _r(id_: str, status: str, title: str, detail: str = "", fix: str = "", fix_action: str = "") -> dict:
    return {"id": id_, "status": status, "title": title, "detail": detail, "fix": fix, "fix_action": fix_action}


def check_python() -> dict:
    v = sys.version_info
    ok = (v.major, v.minor) >= MIN_PY
    in_venv = os.path.abspath(sys.prefix).lower().startswith(os.path.abspath(os.path.join(ROOT, ".venv")).lower())
    if not ok:
        return _r("python", "fail", f"Python {v.major}.{v.minor} is too old", "Python 3.10 or newer is needed.", "Install Python 3.10–3.12 from python.org, then run scripts\\setup.ps1 again.")
    if not in_venv:
        return _r("python", "warn", f"Python {v.major}.{v.minor}.{v.micro} (not the project's own environment)", f"Running from {sys.prefix}",
                  "Start the app with scripts\\fcgapp.ps1 (or Start-FemeGus.cmd) so the project's .venv is used.")
    return _r("python", "ok", f"Python {v.major}.{v.minor}.{v.micro} in the project environment")


def check_packages() -> dict:
    missing, vers = [], []
    for mod, label in RUNTIME_PACKAGES:
        try:
            m = importlib.import_module(mod)
            vers.append(f"{label} {getattr(m, '__version__', '')}".strip())
        except Exception as e:
            missing.append(f"{label} ({type(e).__name__})")
    if missing:
        return _r("packages", "fail", "Missing Python packages: " + ", ".join(missing), "", "In the app (section 10) press the Fix button 'Repair components', or run scripts\\setup.ps1 (it installs everything from requirements.txt).", "repair")
    return _r("packages", "ok", "Python packages installed", "; ".join(vers))


TESTED_KEYS = ("av", "faster-whisper", "ctranslate2", "numpy", "onnxruntime", "tokenizers", "huggingface-hub")


def _norm(n: str) -> str:
    return re.sub(r"[-_.]+", "-", n).lower()


def tested_versions() -> dict:
    """name -> version of the set this tool was developed and tested with (requirements.lock.txt)."""
    out = {}
    try:
        with open(os.path.join(ROOT, "requirements.lock.txt"), "r", encoding="utf-8-sig") as f:
            for line in f:
                m = re.match(r"^([A-Za-z0-9_.\-]+)==([^\s#;]+)", line.strip())
                if m:
                    out[_norm(m.group(1))] = m.group(2)
    except OSError:
        pass
    return out


def check_versions() -> dict:
    """Different library versions than the tested ones are the most common reason for odd errors on another computer (e.g. a PyAV that rejects an
    argument faster-whisper passes). Reported as a warning with the one-click repair as the fix."""
    from importlib import metadata
    want, diff = tested_versions(), []
    for k in TESTED_KEYS:
        if k not in want:
            continue
        try:
            have = metadata.version(k)
        except metadata.PackageNotFoundError:
            continue                                     # a missing package is reported by check_packages
        if have != want[k]:
            diff.append(f"{k} {have} (tested: {want[k]})")
    if diff:
        return _r("versions", "warn", "Some components differ from the tested versions", "; ".join(diff),
                  "In the app (section 10) press the Fix button 'Repair components', or run Install-FemeGus.cmd again. The tool usually still works.", "repair")
    return _r("versions", "ok", "Components match the tested versions")


def check_pyav() -> dict:
    try:
        from fcg_engine import compat
        rep = compat.pyav_report()
    except Exception as e:
        return _r("pyav", "warn", "Could not inspect PyAV", f"{type(e).__name__}: {e}")
    if not rep.get("installed"):
        return _r("pyav", "fail", "PyAV (video/audio decoder) is not usable", rep.get("error", ""), "In the app (section 10) press the Fix button 'Repair components', or run Install-FemeGus.cmd.", "repair")
    if rep.get("accepts_metadata_errors") is False:
        return _r("pyav", "warn", f"PyAV {rep.get('version')} does not accept an argument faster-whisper uses", rep.get("probe_error", ""),
                  "The tool works around it automatically; 'Repair components' (Fix button, section 10) installs the tested PyAV.", "repair")
    return _r("pyav", "ok", f"PyAV {rep.get('version')} works with the speech engine")


def check_gpu() -> dict:
    name = None
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"], capture_output=True, text=True, timeout=15)
        if out.returncode == 0 and out.stdout.strip():
            name = out.stdout.strip().splitlines()[0]
    except Exception:
        pass
    try:
        from fcg_engine.cuda_setup import prepare_cuda_dlls
        dirs = prepare_cuda_dlls()
        import ctranslate2
        n = ctranslate2.get_cuda_device_count()
    except Exception as e:
        return _r("gpu", "warn", "GPU check could not run", str(e), "The CPU will be used (slower).")
    if n > 0:
        return _r("gpu", "ok", "NVIDIA GPU ready for transcription", f"{name or 'GPU'} · CUDA devices seen by the engine: {n} · CUDA libraries from pip: {len(dirs)} folder(s)")
    if name:
        return _r("gpu", "warn", "NVIDIA GPU found but not usable by the engine", name + " — the CUDA 12 / cuDNN 9 libraries are probably missing",
                  "Press the Fix button (installs nvidia-cublas-cu12 and nvidia-cudnn-cu12) and update the NVIDIA driver. Until then the CPU is used (about 7x slower).", "repair_gpu")
    return _r("gpu", "warn", "No NVIDIA GPU detected — the CPU will be used", "Transcription still works, roughly 7x slower on this class of machine.", "")


ENGLISH_MODEL = "large-v3-turbo"
HINGLISH_MIN_BYTES = 300_000_000          # the converted fp16 model.bin is about 1.6 GB; a stub or an interrupted conversion is far smaller


def english_model_ready() -> bool:
    """Is the stock speech model completely on this computer? (faster-whisper's own cache lookup: an interrupted download does not count.)"""
    try:
        from faster_whisper.utils import download_model
        download_model(ENGLISH_MODEL, local_files_only=True)
        return True
    except Exception:
        return False


def hinglish_model_dir(root: str | None = None) -> str:
    return os.path.join(root or ROOT, "models", "ct2", "hinglish-apex-fp16")


def hinglish_state(root: str | None = None) -> str:
    """'ready' | 'unregistered' (converted model present but engine/models_local.json does not point to it) | 'missing'."""
    root = root or ROOT
    d = hinglish_model_dir(root)
    try:
        present = os.path.getsize(os.path.join(d, "model.bin")) >= HINGLISH_MIN_BYTES and os.path.isfile(os.path.join(d, "config.json"))
    except OSError:
        present = False
    if not present:
        return "missing"
    try:
        import json
        with open(os.path.join(root, "engine", "models_local.json"), "r", encoding="utf-8-sig") as f:
            path = (json.load(f) or {}).get("hinglish-apex")
    except (OSError, ValueError):
        path = None
    return "ready" if path and os.path.isfile(os.path.join(str(path), "model.bin")) else "unregistered"


def check_models() -> list[dict]:
    res = []
    cached = english_model_ready()
    res.append(_r("model_english", "ok" if cached else "warn", "English / stock speech model " + ("downloaded" if cached else "not downloaded yet"),
                  "large-v3-turbo (about 1.6 GB)" if cached else "Transcription needs it: it is downloaded automatically the first time you transcribe (internet needed once).",
                  "" if cached else "Press the Fix button to download it now (about 1.6 GB), or run scripts\\setup.ps1 -PreloadModels.", "" if cached else "english_model"))
    state = hinglish_state()
    detail = {"ready": "Oriserve Whisper-Hindi2Hinglish-Apex (Apache-2.0), converted for CTranslate2",
              "unregistered": "The converted model is in the models folder, but the app does not know where it is (was the folder moved?).",
              "missing": "Hinglish and Auto modes will fall back to a lower-quality method."}[state]
    fix = {"ready": "", "unregistered": "Press the Fix button (no download needed).",
           "missing": "Press the Fix button (about 3 GB download, a few minutes), or run scripts\\setup_hinglish.ps1 once."}[state]
    res.append(_r("model_hinglish", "ok" if state == "ready" else "warn", "Hinglish model " + {"ready": "ready", "unregistered": "found but not connected", "missing": "not set up"}[state],
                  detail, fix, {"ready": "", "unregistered": "register_hinglish", "missing": "hinglish_model"}[state]))
    return res


def check_fonts() -> dict:
    try:
        from . import fontscan
        fonts = fontscan.scan(cache_path=os.path.join(ROOT, "work", "fonts_cache.json"))
        have_arial = any(f["postscript"] == "ArialMT" for f in fonts)
        if not fonts:
            return _r("fonts", "fail", "No fonts found", "", "Check that C:\\Windows\\Fonts exists.")
        return _r("fonts", "ok" if have_arial else "warn", f"{len(fonts)} fonts found" + ("" if have_arial else " (Arial missing)"),
                  "" if have_arial else "The default look uses Arial.", "" if have_arial else "Pick other fonts in section 5.")
    except Exception as e:
        return _r("fonts", "warn", "Font scan failed", str(e), "")


def find_after_effects() -> list[dict]:
    out = []
    for exe in glob.glob(r"C:\Program Files\Adobe\Adobe After Effects *\Support Files\AfterFX.exe"):
        m = re.search(r"After Effects (\d{4}|[\w. ]+)\\Support", exe)
        ver = None
        try:
            ps = ["powershell", "-NoProfile", "-Command", f"(Get-Item '{exe}').VersionInfo.ProductVersion"]
            ver = subprocess.run(ps, capture_output=True, text=True, timeout=20).stdout.strip() or None
        except Exception:
            pass
        out.append({"path": exe, "name": m.group(1) if m else "?", "version": ver})
    return out


def read_script_pref(prefs_root: str | None = None) -> dict:
    """Read-only look at the 'Allow Scripts to Write Files and Access Network' preference of each installed After Effects version."""
    root = prefs_root or os.path.join(os.environ.get("APPDATA", ""), "Adobe", "After Effects")
    res: dict[str, bool | None] = {}
    if not os.path.isdir(root):
        return res
    for d in sorted(os.listdir(root)):
        pf = os.path.join(root, d, f"Adobe After Effects {d} Prefs.txt")
        if os.path.isfile(pf):
            val = None
            try:
                with open(pf, "r", encoding="utf-8", errors="ignore") as f:
                    for line in f:
                        if "Pref_SCRIPTING_FILE_NETWORK_SECURITY" in line:
                            val = '"1"' in line
                            break
            except OSError:
                pass
            res[d] = val if val is not None else False
    return res


def check_after_effects() -> list[dict]:
    res = []
    inst = find_after_effects()
    if not inst:
        res.append(_r("ae_install", "warn", "No After Effects installation found in C:\\Program Files\\Adobe", "You can still transcribe and edit captions; generating layers needs After Effects.",
                      "Install After Effects (tested: 2025 / 25.2 only)."))
    else:
        res.append(_r("ae_install", "ok", "After Effects found: " + ", ".join(f"{i['name']} ({i['version'] or 'version unknown'})" for i in inst),
                      "Only 2025 (25.2) has been tested; other versions are not claimed.", ""))
    prefs = read_script_pref()
    if prefs:
        latest = sorted(prefs)[-1]
        ok = bool(prefs[latest])
        res.append(_r("ae_pref", "ok" if ok else "warn", f"After Effects {latest}: scripts may write files" if ok else f"After Effects {latest}: scripts are NOT allowed to write files",
                      "" if ok else "The connection report cannot be written, so generating from the app will not work.",
                      "" if ok else "In After Effects: Edit > Preferences > Scripting & Expressions > tick 'Allow Scripts to Write Files and Access Network'."))
    try:
        from . import ae_bridge
        st = ae_bridge.status()
        res.append(_r("ae_connection", "ok" if st["connected"] else "warn",
                      "After Effects is connected" if st["connected"] else ("After Effects is open but the connect script is not running" if st["ae_running"] else "After Effects is not running"),
                      f"version reported: {st['ae_version']}" if st["connected"] else "",
                      "" if st["connected"] else "In After Effects: File > Script > Run Script File… > adapters\\jsx-core\\fcg_connect.jsx (once per session).",
                      "" if st["connected"] else "show_connect_script"))
    except Exception as e:
        res.append(_r("ae_connection", "warn", "Could not check the After Effects connection", str(e), ""))
    return res


def check_disk() -> dict:
    try:
        free = shutil.disk_usage(ROOT).free / 1e9
    except OSError as e:
        return _r("disk", "warn", "Could not read free disk space", str(e), "")
    try:
        os.makedirs(os.path.join(ROOT, "projects"), exist_ok=True)
        t = os.path.join(ROOT, "projects", ".write_test")
        open(t, "w").close(); os.remove(t)
    except OSError as e:
        return _r("disk", "fail", "The projects folder is not writable", str(e), "Move the tool to a folder you can write to (not Program Files).")
    if free < WARN_FREE_GB:
        return _r("disk", "warn", f"Only {free:.1f} GB free on the drive holding the tool", "Models need about 5 GB; projects are small.", "Free some space.")
    return _r("disk", "ok", f"{free:.0f} GB free; projects folder writable")


def check_port() -> dict:
    try:
        s = socket.socket(); s.bind(("127.0.0.1", 0)); s.close()
        return _r("network", "ok", "Local port available (the app is never reachable from other computers)")
    except OSError as e:
        return _r("network", "fail", "Cannot open a local port", str(e), "Check firewall / security software.")


def run_all() -> dict:
    checks: list[dict] = []
    for fn in (check_python, check_packages, check_versions, check_pyav, check_gpu, check_models, check_fonts, check_after_effects, check_disk, check_port):
        try:
            r = fn()
            checks.extend(r if isinstance(r, list) else [r])
        except Exception as e:                       # a broken check must not hide the rest
            checks.append(_r(fn.__name__, "warn", f"{fn.__name__} crashed", f"{type(e).__name__}: {e}", ""))
    for c in checks:                                  # attach what the page needs to draw the one-click button
        meta = FIX_META.get(c.get("fix_action") or "")
        if meta and c["status"] != "ok":
            c["fix_meta"] = {"label": meta["label"], "size": meta["size"], "internet": meta["internet"], "restart": meta["restart"], "note": meta["note"]}
        else:
            c["fix_action"] = ""
    worst = "fail" if any(c["status"] == "fail" for c in checks) else ("warn" if any(c["status"] == "warn" for c in checks) else "ok")
    todo = [a for a in FIX_ORDER if any(c["fix_action"] == a for c in checks)]
    return {"overall": worst, "checks": checks, "fix_all": todo}


def format_report(rep: dict) -> str:
    sym = {"ok": "[ OK ]", "warn": "[WARN]", "fail": "[FAIL]"}
    lines = []
    for c in rep["checks"]:
        lines.append(f"{sym[c['status']]} {c['title']}")
        if c["detail"]:
            lines.append(f"       {c['detail']}")
        if c["fix"] and c["status"] != "ok":
            lines.append(f"       -> {c['fix']}")
    lines.append("")
    lines.append({"ok": "Everything is ready.", "warn": "Ready, with the notes above.", "fail": "Not ready: fix the [FAIL] items above."}[rep["overall"]])
    return "\n".join(lines)
