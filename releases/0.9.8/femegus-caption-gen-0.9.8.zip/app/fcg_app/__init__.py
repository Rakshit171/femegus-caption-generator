"""FemeGus Caption Generator — local editor application (web UI + API). Depends on engine/ and core/, never on After Effects objects."""
