"""Project storage. One folder per video under ``projects/``; every file is plain JSON so it can be inspected, versioned and recovered.

projects/<id>/
  project.json     {id, video, language, created, config (segmenter overrides), style_preset, style (full style object), ae}
  transcript.json  engine output (never edited by the app)
  overrides.json   user corrections (see core/fcg_core/edits.py) — the ONLY place manual edits live
  envelope.json    loudness envelope (pauses / onsets)
  groups.json      latest built captions
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import threading
import time
from typing import Any, Optional

_lock = threading.RLock()


def _atomic_write(path: str, data: Any) -> None:
    d = os.path.dirname(path)
    os.makedirs(d, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=d, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def _read(path: str, default: Any = None) -> Any:
    if not os.path.isfile(path):
        return default
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


REPLACE_KEYS = ("template_styles",)       # a style that has these keys owns them completely (a look with no layout overrides must not inherit the default look's)


def deep_merge(base: Any, over: Any) -> Any:
    if isinstance(base, dict) and isinstance(over, dict):
        out = dict(base)
        for k, v in over.items():
            out[k] = v if k in REPLACE_KEYS else deep_merge(base[k], v) if k in base else v
        return out
    return over


# The ONLY files the app ever creates inside a project folder. Deleting a project removes exactly these and nothing else, so a file the user (or another
# program) put there is never touched, and the original video is never inside the project folder in the first place (project.json stores its path).
PROJECT_FILE = re.compile(r"(project|transcript|overrides|envelope|groups)\.json|preview\.mp4(\.part)?|ae_report_[0-9a-f]+\.json|[^/\\]+\.tmp")
PID_RE = re.compile(r"[A-Za-z0-9_-]+")


def is_project_file(name: str) -> bool:
    return PROJECT_FILE.fullmatch(name) is not None


def slug(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "-", name).strip("-")[:40] or "project"


class Project:
    FILES = ("transcript", "overrides", "envelope", "groups")

    def __init__(self, folder: str):
        self.folder = folder
        self.meta = _read(os.path.join(folder, "project.json"), {})

    @property
    def id(self) -> str:
        return self.meta["id"]

    def path(self, name: str) -> str:
        return os.path.join(self.folder, name + ".json")

    def get(self, name: str, default: Any = None) -> Any:
        with _lock:
            return _read(self.path(name), default)

    def put(self, name: str, data: Any) -> None:
        with _lock:
            _atomic_write(self.path(name), data)

    def save_meta(self) -> None:
        with _lock:
            _atomic_write(os.path.join(self.folder, "project.json"), self.meta)

    def disk_bytes(self) -> int:
        """Space used by the files this app keeps in the project folder (what deleting the project frees)."""
        total = 0
        try:
            for name in os.listdir(self.folder):
                p = os.path.join(self.folder, name)
                if is_project_file(name) and os.path.isfile(p) and not os.path.islink(p):
                    total += os.path.getsize(p)
        except OSError:
            pass
        return total

    def summary(self) -> dict:
        damaged = False
        try:
            t = self.get("transcript")
            words = len(t["words"]) if t else 0
        except (OSError, ValueError, KeyError, TypeError):               # a damaged transcript must not make the project vanish from the list (it could not be deleted then)
            t, words, damaged = None, 0, True
        return {"id": self.id, "video": self.meta.get("video"), "language": self.meta.get("language"),
                "created": self.meta.get("created"), "has_transcript": t is not None, "damaged": damaged,
                "words": words, "has_groups": os.path.isfile(self.path("groups")),
                "style_preset": self.meta.get("style_preset"), "bytes": self.disk_bytes()}


class ProjectStore:
    def __init__(self, base: str, default_style: dict, default_preset: str = "reference_style"):
        self.base = base
        self.default_style = default_style
        self.default_preset = default_preset
        os.makedirs(base, exist_ok=True)

    def _id_for(self, video: str) -> str:
        h = hashlib.sha1(os.path.abspath(video).lower().encode("utf-8")).hexdigest()[:6]
        return f"{slug(os.path.splitext(os.path.basename(video))[0])}-{h}"

    def open_video(self, video: str, language: str = "auto") -> Project:
        if not os.path.isfile(video):
            raise FileNotFoundError(f"video not found: {video}")
        pid = self._id_for(video)
        folder = os.path.join(self.base, pid)
        p = Project(folder)
        if not p.meta:
            p.meta = {"id": pid, "video": os.path.abspath(video), "language": language, "created": time.strftime("%Y-%m-%d %H:%M:%S"),
                      "config": {}, "style_preset": self.default_preset, "style": self.default_style, "ae": {}}
            os.makedirs(folder, exist_ok=True)
            p.save_meta()
            p.put("overrides", {})
        return p

    def load(self, pid: str) -> Project:
        if not re.fullmatch(r"[A-Za-z0-9_-]+", pid):
            raise ValueError("bad project id")
        folder = os.path.join(self.base, pid)
        p = Project(folder)
        if not p.meta:
            raise FileNotFoundError(pid)
        return p

    def delete(self, pid: str) -> dict:
        """Delete one project's own files (never the original video, never anything unknown). Returns {"id", "freed", "kept"}.
        Safety rules: the id must be a plain name; the folder must be a real folder directly inside the projects folder (a link/junction is refused); it must
        contain project.json (so only genuine projects can be deleted); only the files listed in PROJECT_FILE are removed, project.json LAST, so a deletion
        that is interrupted leaves a project that is still listed and can be deleted again; the folder itself is removed only when it ends up empty."""
        if not PID_RE.fullmatch(pid or ""):
            raise ValueError("bad project id")
        folder = os.path.join(self.base, pid)
        real_base = os.path.normcase(os.path.realpath(self.base))
        if os.path.islink(folder) or os.path.normcase(os.path.realpath(folder)) != os.path.join(real_base, os.path.normcase(pid)):
            raise ValueError("the project folder is not a plain folder inside the projects folder; it was left alone")
        if not os.path.isdir(folder) or not os.path.isfile(os.path.join(folder, "project.json")):
            raise FileNotFoundError(pid)
        freed, kept = 0, []
        with _lock:
            names = sorted(n for n in os.listdir(folder))
            for name in sorted(names, key=lambda n: n == "project.json"):           # project.json last
                p = os.path.join(folder, name)
                if not (is_project_file(name) and os.path.isfile(p) and not os.path.islink(p)):
                    kept.append(name)
                    continue
                size = os.path.getsize(p)
                for attempt in range(3):                                           # a file that was being read (video preview) can be busy for a moment
                    try:
                        os.remove(p)
                        freed += size
                        break
                    except FileNotFoundError:
                        break
                    except PermissionError:
                        if attempt == 2:
                            raise PermissionError(f"'{name}' is in use by another program; close it and press Delete again")
                        time.sleep(0.4)
            if not kept:
                try:
                    os.rmdir(folder)
                except OSError:
                    kept.append("(folder not empty)")
        return {"id": pid, "freed": freed, "kept": kept}

    def list(self) -> list[dict]:
        out = []
        for name in sorted(os.listdir(self.base)):
            f = os.path.join(self.base, name)
            if os.path.isfile(os.path.join(f, "project.json")):
                try:
                    out.append(Project(f).summary())
                except (OSError, ValueError, KeyError, TypeError):             # one unreadable project must not hide the others
                    pass
        return out
