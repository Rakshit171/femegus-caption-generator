"""Start the caption editor:  python -m fcg_app [--port N] [--no-browser]"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
import webbrowser

from .server import serve

LOG_MAX = 2 * 1024 * 1024


class _Tee:
    """Everything printed in the black window is also written to work\\app.log, so a problem can be reported with the text that was on screen."""

    def __init__(self, stream, logfile):
        self.stream, self.logfile = stream, logfile

    def write(self, s):
        for f in (self.stream, self.logfile):
            try:
                if f is not None:
                    f.write(s)
            except Exception:
                pass
        return len(s)

    def flush(self):
        for f in (self.stream, self.logfile):
            try:
                if f is not None:
                    f.flush()
            except Exception:
                pass

    def __getattr__(self, name):
        return getattr(self.stream, name)


def _setup_logging(root: str) -> None:
    try:
        import faulthandler
        os.makedirs(os.path.join(root, "work"), exist_ok=True)
        faulthandler.enable(open(os.path.join(root, "work", "app_crash.log"), "a", encoding="utf-8"))     # a hard abort leaves its reason here
        path = os.path.join(root, "work", "app.log")
        if os.path.isfile(path) and os.path.getsize(path) > LOG_MAX:
            os.replace(path, path + ".1")
        log = open(path, "a", encoding="utf-8", errors="replace", buffering=1)
        log.write(f"\n===== start {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n")
        sys.stdout = _Tee(sys.stdout, log)
        sys.stderr = _Tee(sys.stderr, log)
    except Exception:
        pass


def _take_restart_handoff(root: str):
    """After 'Restart' from the app the previous copy leaves work\\restart.json: re-use its port and token so the browser page keeps working."""
    p = os.path.join(root, "work", "restart.json")
    try:
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        os.remove(p)
        if time.time() - float(d.get("ts", 0)) < 120:
            return int(d["port"]), str(d["token"])
    except (OSError, ValueError, KeyError):
        pass
    return None


def main() -> int:
    ap = argparse.ArgumentParser(prog="fcg_app")
    ap.add_argument("--port", type=int, default=0, help="0 = pick a free port")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--projects", default=None, help="folder for projects (default: <project>/projects)")
    ap.add_argument("--token", default=None, help="fixed session token (development only; default: random)")
    ap.add_argument("--check", action="store_true", help="run the system check and exit (exit code 1 if something is not ready)")
    args = ap.parse_args()
    if args.check:
        from . import selfcheck
        rep = selfcheck.run_all()
        print(selfcheck.format_report(rep))
        return 1 if rep["overall"] == "fail" else 0
    from .ops import ROOT
    _setup_logging(ROOT)
    handoff = _take_restart_handoff(ROOT) if args.port == 0 and args.token is None else None
    if handoff:
        try:
            httpd, app = serve(handoff[0], args.projects, handoff[1])
            args.no_browser = True                                   # the page that asked for the restart is still open and reconnects by itself
        except OSError:                                              # port still busy: fall back to a normal start (new page opens)
            httpd, app = serve(args.port, args.projects, args.token)
    else:
        httpd, app = serve(args.port, args.projects, args.token)
    port = httpd.server_address[1]
    url = f"http://127.0.0.1:{port}/?token={app.token}"
    print("FemeGus Caption Generator is running (local only).")
    print(f"Version {app.updater.running_version}")
    print(f"Open: {url}")
    print("Press Ctrl+C to stop.")
    if not args.no_browser:
        webbrowser.open(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
