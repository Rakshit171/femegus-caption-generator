"""Installed-font scanner (Windows). Reads only the sfnt 'name' and 'OS/2' tables of each .ttf/.otf/.ttc — no dependencies.

Why: After Effects wants PostScript names (e.g. ``Poppins-Bold``); the browser preview needs family + weight + italic. This maps one to the other.
"""
from __future__ import annotations

import json
import os
import struct
from typing import Optional

SYSTEM_DIR = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
USER_DIR = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts")


def _decode(rec_platform: int, raw: bytes) -> str:
    try:
        return raw.decode("utf-16-be") if rec_platform in (0, 3) else raw.decode("latin-1")
    except UnicodeDecodeError:
        return raw.decode("latin-1", "ignore")


def _read_font(data: bytes, offset: int = 0) -> Optional[dict]:
    if len(data) < offset + 12:
        return None
    tag = data[offset:offset + 4]
    if tag not in (b"\x00\x01\x00\x00", b"OTTO", b"true"):
        return None
    n = struct.unpack(">H", data[offset + 4:offset + 6])[0]
    tables = {}
    for i in range(n):
        rec = data[offset + 12 + 16 * i: offset + 28 + 16 * i]
        if len(rec) < 16:
            return None
        t, _cs, off, ln = struct.unpack(">4sIII", rec)
        tables[t.decode("latin-1")] = (off, ln)
    if "name" not in tables:
        return None
    off, ln = tables["name"]
    nt = data[off:off + ln]
    if len(nt) < 6:
        return None
    count, str_off = struct.unpack(">HH", nt[2:6])
    names: dict[int, tuple[int, str]] = {}
    for i in range(count):
        r = nt[6 + 12 * i: 18 + 12 * i]
        if len(r) < 12:
            break
        plat, enc, lang, nid, length, o = struct.unpack(">HHHHHH", r)
        raw = nt[str_off + o: str_off + o + length]
        s = _decode(plat, raw).strip("\x00")
        if not s:
            continue
        # prefer Windows/English (platform 3, lang 0x409), then any Windows, then Mac
        rank = 0 if (plat == 3 and lang == 0x409) else (1 if plat == 3 else 2)
        if nid not in names or rank < names[nid][0]:
            names[nid] = (rank, s)
    ps = names.get(6, (9, ""))[1]
    if not ps:
        return None
    fam = names.get(16, names.get(1, (9, "")))[1]
    sub = names.get(17, names.get(2, (9, "Regular")))[1]
    weight, italic = 400, False
    if "OS/2" in tables:
        o2, l2 = tables["OS/2"]
        blk = data[o2:o2 + min(l2, 64)]
        if len(blk) >= 64:
            weight = struct.unpack(">H", blk[4:6])[0]
            italic = bool(struct.unpack(">H", blk[62:64])[0] & 1)
    if "italic" in sub.lower() or "oblique" in sub.lower():
        italic = True
    return {"postscript": ps, "family": fam, "style": sub, "weight": weight, "italic": italic}


def scan_file(path: str) -> list[dict]:
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return []
    out = []
    if data[:4] == b"ttcf":
        n = struct.unpack(">I", data[8:12])[0]
        offs = [struct.unpack(">I", data[12 + 4 * i:16 + 4 * i])[0] for i in range(min(n, 8))]
        for o in offs:
            r = _read_font(data, o)
            if r:
                out.append(r)
    else:
        r = _read_font(data)
        if r:
            out.append(r)
    for r in out:
        r["file"] = path
    return out


def scan(dirs: Optional[list[str]] = None, cache_path: Optional[str] = None) -> list[dict]:
    dirs = [d for d in (dirs or [SYSTEM_DIR, USER_DIR]) if d and os.path.isdir(d)]
    sig = {d: [os.path.getmtime(d), len(os.listdir(d))] for d in dirs}
    if cache_path and os.path.isfile(cache_path):
        try:
            with open(cache_path, "r", encoding="utf-8") as f:
                c = json.load(f)
            if c.get("sig") == sig:
                return c["fonts"]
        except (OSError, ValueError, KeyError):
            pass
    fonts: dict[str, dict] = {}
    for d in dirs:
        for name in os.listdir(d):
            if name.lower().endswith((".ttf", ".otf", ".ttc")):
                for r in scan_file(os.path.join(d, name)):
                    fonts.setdefault(r["postscript"], r)
    res = sorted(fonts.values(), key=lambda r: (r["family"].lower(), r["weight"], r["italic"]))
    if cache_path:
        try:
            os.makedirs(os.path.dirname(cache_path), exist_ok=True)
            with open(cache_path, "w", encoding="utf-8") as f:
                json.dump({"sig": sig, "fonts": res}, f, ensure_ascii=False)
        except OSError:
            pass
    return res
