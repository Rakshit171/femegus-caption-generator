@echo off
rem Double-click to start the FemeGus Caption Generator (it opens in your browser; nothing leaves this computer).
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo The tool is not set up yet. Run this once in PowerShell:   .\scripts\setup.ps1
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\fcgapp.ps1"
echo.
echo The app has stopped. You can close this window.
pause
