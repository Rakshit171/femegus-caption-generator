# FemeGus Caption Generator

Turns a talking video into **animated, fully editable After Effects captions** that follow what the speaker really says — word by word, in English, Hinglish (Hindi in Roman letters) or both —
with a look modelled on your reference video. Everything runs **on your own computer, free, offline** (no paid API, no subscription, your footage is never uploaded).

> **Status: v0.9 — first complete version plus a second look ("Soft Editorial", switch looks in one click in section 4).** Verified on **After Effects 2025 (25.2) only**. After Effects 2024 and 2026 are planned and *not claimed*.
> Tested honestly: see [docs/TESTING.md](docs/TESTING.md) for what was measured and what is still open.

## What you get
* **Speech-synchronised captions.** A word is never shown before it is spoken. Groups of words are cut at sentences, pauses and natural phrase boundaries, using the real audio — not fixed timers.
* **Hinglish and English**, with a language choice (English / Hinglish / Automatic). English words keep their English spelling; Hindi appears in Roman letters. Corrections are always possible.
* **Real text layers in After Effects** (one per word, with gradient, glow, shadow, blur and keyframed entrance) — not a flattened video. You can restyle them like any layer.
* **Everything is editable without code:** transcript text and timing, accent/support words, fonts, sizes, colours, effects, animation (duration, easing, slide, scale, fade, blur), layout, position, presets.
* **Live preview** with the same layout and motion maths as After Effects (measured: positions agree to well under 1 px on average).
* **Self-checking:** every generation is read back from After Effects and verified (timing, text, style); the transcription checks itself for stretches of speech it missed.

## Quick start
Needs Windows, Python 3.10–3.12 (the installer can fetch it), After Effects 2025, ~5–12 GB disk; an NVIDIA GPU is recommended (CPU works, slower). Details: [docs/INSTALL.md](docs/INSTALL.md).
1. Double-click **`Install-FemeGus.cmd`** — a guided installer (checks the computer, asks a few questions, installs everything inside this folder, runs a system check).
2. Follow [docs/FIRST_RUN.md](docs/FIRST_RUN.md): once tick *Preferences ▸ Scripting & Expressions ▸ Allow Scripts to Write Files and Access Network*; each After Effects session run *File ▸ Scripts ▸ Run Script File…* → `adapters\jsx-core\fcg_connect.jsx` (nothing is installed in After Effects).
3. Double-click **`Start-FemeGus.cmd`** (or the desktop shortcut). The app opens in your browser (the top right says *After Effects … connected*).

**Updates:** section 10 ▸ *Updates* checks for new versions and new caption looks (opt-in; free; see [docs/UPDATES.md](docs/UPDATES.md)).

## The workflow (ten sections on the left of the app)
1. **Video & input** — choose the video/audio, the language, press *Transcribe* (runs in the background with progress).
2. **Transcript & timing** — fix words or times, flip emphasis, split/insert/delete, glossary (crr → crore). Your original transcript is never overwritten.
3. **Caption grouping** — how many words per caption, pause rules, hold times.
4. **Caption look** — a gallery of complete looks (fonts, colours, layout, animation) with live thumbnails; **one click changes the whole look**. Built in: *Reference (orange glow)* (the original, unchanged), *Soft Editorial* (centred light-sans lines, key words in serif caps / bold glow / bold inline…, blur-in words and letter-by-letter serif reveals — modelled on `reference\look2`) and *Clean 4-Word* (plain white text, at most four words on one line, with a **one-click smooth slide-up switch**) and *Clean Poppins*. Save your own looks here.
5–8. **Typography · Colours · Animation · Position & layout** — every visual property, for all words, for key words only (any installed font), or for one key-word treatment.
9. **Generate in AE** — builds the layers and shows the verification result.
10. **Export & help** — **download the captions as an .srt subtitle file** (one cue per caption, or a word-by-word build-up), `groups.json`, updates, repair, **system check**, troubleshooting.
Play the video with *Space*; click the timeline to jump. Details: [docs/APP.md](docs/APP.md).

## Honest limits (read before relying on it)
* **Only After Effects 25.2 has been tested.** Other versions will show a warning and are not supported yet ([docs/AE_API_VERSIONS.md](docs/AE_API_VERSIONS.md) is the plan).
* **Hinglish is good, not perfect:** 3.4 % word error on one speaker's 110 s clip against a provisional reference; fast speech (1.4×) degrades to ~14 %. Always skim the transcript. Digits are the weakest part. Forced *English* mode **translates** Hindi — use Auto or Hinglish for mixed speech.
* **Automatic language detection is a heuristic** checked on three clips.
* The look (Arial, orange gradient, glow, tiers/stack layouts) approximates the reference; per-letter wipes, sparkle glints and exit animations are not built.
* "Update" replaces the layers the tool generated (recognised by their comment `FCG:`); hand-edits inside them are lost unless you clear that comment.
* Glow/blur/shadow in the *preview* are approximations; timing, layout and motion are exact.

## Licence
Free to use, including for paid client work; what you create is yours; the tool itself may not be sold or passed on to others — send them to the official download page. Full text: [LICENSE](LICENSE).

## Documents
| | |
|---|---|
| [docs/INSTALL.md](docs/INSTALL.md) · [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) | install, update, every problem I know how to fix |
| [docs/APP.md](docs/APP.md) · [docs/STYLE.md](docs/STYLE.md) | the app · all look/animation options |
| [docs/SEGMENTER.md](docs/SEGMENTER.md) · [docs/HINGLISH.md](docs/HINGLISH.md) | how captions are timed · language design and evidence |
| [docs/TESTING.md](docs/TESTING.md) · [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) · [docs/AE_API_VERSIONS.md](docs/AE_API_VERSIONS.md) | what was tested · supported versions · API plan |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) · [docs/AE_ADAPTER.md](docs/AE_ADAPTER.md) · [docs/PROJECT_STRUCTURE.md](docs/PROJECT_STRUCTURE.md) | design · After Effects adapter · file map |
| [docs/LICENSES.md](docs/LICENSES.md) | what is free, and the one thing that is not (After Effects) |
| [docs/REFERENCE_ANALYSIS.md](docs/REFERENCE_ANALYSIS.md) | the reference video's caption style |

## Command line (optional)
```powershell
.\scripts\fcg.ps1 transcribe "C:\path\video.mp4" --language auto --show     # transcript with word times
.\scripts\fcgcore.ps1 build work\clip.transcript.json --envelope work\clip.envelope.json --show
.\scripts\test.ps1            # fast tests (10 s)    .\scripts\test.ps1 -Full   # all tests (~18 min)
```
