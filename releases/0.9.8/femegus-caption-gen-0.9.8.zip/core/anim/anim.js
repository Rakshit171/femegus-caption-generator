// Shared animation maths. ES3-compatible: runs unchanged in After Effects (ExtendScript), in Node (tests) and in a browser (preview).
// NO host objects here. Everything is a pure function of numbers.
//
// An "entrance" is described relative to the word's in-point (= its reveal time), so animation can never move a reveal:
//   { duration: s, ease: [x1,y1,x2,y2] (CSS cubic-bezier), slide: [dx,dy] px, scale_from: 1.12, opacity_from: 0, blur_from: 24 }
var FCGAnim = (function () {
    var EPS = 1e-7;

    // CSS-style cubic-bezier easing: returns y(u) for u in [0,1], where x(s)=3(1-s)^2 s x1 + 3(1-s)s^2 x2 + s^3 (x1,x2 in [0,1]).
    function cubicBezier(x1, y1, x2, y2) {
        function bx(s) { var m = 1 - s; return 3 * m * m * s * x1 + 3 * m * s * s * x2 + s * s * s; }
        function by(s) { var m = 1 - s; return 3 * m * m * s * y1 + 3 * m * s * s * y2 + s * s * s; }
        function dbx(s) { var m = 1 - s; return 3 * m * m * x1 + 6 * m * s * (x2 - x1) + 3 * s * s * (1 - x2); }
        return function (u) {
            if (u <= 0) return 0;
            if (u >= 1) return 1;
            var s = u, i, d, lo = 0, hi = 1, x;
            for (i = 0; i < 8; i++) {                  // Newton
                x = bx(s) - u; d = dbx(s);
                if (Math.abs(x) < EPS) return by(s);
                if (Math.abs(d) < 1e-6) break;
                s -= x / d;
            }
            if (s < 0 || s > 1 || isNaN(s)) s = u;
            for (i = 0; i < 60; i++) {                 // bisection fallback (monotonic because x1,x2 in [0,1])
                x = bx(s);
                if (Math.abs(x - u) < EPS) break;
                if (x < u) lo = s; else hi = s;
                s = (lo + hi) / 2;
            }
            return by(s);
        };
    }

    var PRESETS = {
        linear: [0, 0, 1, 1],
        easeOut: [0.16, 1, 0.3, 1],         // fast start, long soft landing (reference-like)
        easeOutSoft: [0.25, 0.8, 0.35, 1],
        easeInOut: [0.65, 0, 0.35, 1],
        easeIn: [0.5, 0, 0.9, 0.5],
        overshoot: [0.2, 1.4, 0.4, 1]       // y2 > 1 is NOT allowed by the AE mapping below only when x stays in [0,1]; y may exceed 1
    };

    function resolveEase(e) {
        if (e instanceof Array && e.length === 4) return e;
        if (typeof e === "string" && PRESETS[e]) return PRESETS[e];
        return PRESETS.easeOut;
    }

    // value of an eased property u in [0,1] -> from + (to-from)*ease(u)
    function lerp(from, to, k) { return from + (to - from) * k; }

    // Map a cubic-bezier to After Effects temporal ease for ONE segment (two keyframes) of a property that moves by deltaV in T seconds.
    // AE's temporal interpolation is a cubic bezier through (0,0)..(T,deltaV) whose handles are described by (influence, speed):
    //   out handle at key A:  (influence_out*T,  speed_out*influence_out*T)      with influence_out = x1,      speed_out = (y1/x1) * deltaV/T
    //   in  handle at key B:  (T - influence_in*T, deltaV - speed_in*influence_in*T), influence_in = 1 - x2,  speed_in  = ((1-y2)/(1-x2)) * deltaV/T
    // Influences are returned in percent (0.1..100) as AE expects.
    function easeToKeyframe(bez, deltaV, T) {
        var x1 = Math.max(bez[0], 0.001), x2 = Math.min(bez[2], 0.999), avg = deltaV / T;
        return {
            out: { influence: x1 * 100, speed: (bez[1] / x1) * avg },
            inn: { influence: (1 - x2) * 100, speed: ((1 - bez[3]) / (1 - x2)) * avg }
        };
    }

    // Inverse of the above (used by tests): reconstruct the bezier from AE's influence/speed.
    function keyframeToEase(k, deltaV, T) {
        var avg = deltaV / T, x1 = k.out.influence / 100, x2 = 1 - k.inn.influence / 100;
        return [x1, avg === 0 ? 0 : (k.out.speed / avg) * x1, x2, avg === 0 ? 1 : 1 - (k.inn.speed / avg) * (1 - x2)];
    }

    // Clamp an entrance to the time available (until the group exits). Returns {duration, clamped}.
    function clampDuration(duration, available, frameDuration) {
        var maxD = Math.max(available - frameDuration, 0);
        if (duration <= maxD) return { duration: duration, clamped: false };
        return { duration: Math.max(maxD, 0), clamped: true };
    }

    // Value of every animated property of an entrance at time tRel (seconds after the in-point).
    // base = { x, y, scale (percent, final) }. Returns { opacity, x, y, scale, blur }.
    // Mirrors what After Effects really does (verified against AE 25.2 keyframes, see docs/AE_ADAPTER.md):
    //  * opacity is clamped to [0,100] and blur to >= 0 even when the curve overshoots
    //  * scale follows the curve unclamped (overshoot works, exact match with AE)
    //  * POSITION runs along a spatial path: AE does not reproduce an overshooting curve there (measured up to 14 % deviation),
    //    so position always uses the same curve with its y-handles limited to [0,1] (positionEase) -- in the evaluator AND in the keyframes.
    function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
    function positionEase(bez) { return [bez[0], clamp(bez[1], 0, 1), bez[2], clamp(bez[3], 0, 1)]; }
    function entranceAt(spec, base, tRel) {
        var D = spec.duration, k, kp, u;
        var bez = resolveEase(spec.ease);
        u = D <= 0 ? 1 : Math.max(0, Math.min(1, tRel / D));
        k = cubicBezier.apply(null, bez)(u);
        kp = cubicBezier.apply(null, positionEase(bez))(u);
        var slide = spec.slide || [0, 0], sf = spec.scale_from === undefined ? 1 : spec.scale_from;
        var of = spec.opacity_from === undefined ? 0 : spec.opacity_from, bf = spec.blur_from || 0;
        return {
            opacity: clamp(lerp(of * 100, 100, k), 0, 100),
            x: lerp(base.x + slide[0], base.x, kp), y: lerp(base.y + slide[1], base.y, kp),
            scale: lerp(base.scale * sf, base.scale, k),
            blur: Math.max(0, lerp(bf, 0, k))
        };
    }

    // ---- per-letter reveal ("letters" entrance, reference look 2) ----------------------------------------------------------------------------
    // Letter i (0-based) of a word starts i*stagger seconds after the word's in-point, so the first letter starts exactly at the reveal and
    // no letter can ever be visible earlier. Each letter then runs the same eased fade / un-blur / rise over `duration`; its tint colour
    // (the "wet ink" colour newly revealed letters have) fades over `tint_duration`.
    //   L = { stagger, duration, ease, blur_from (px), opacity_from (0..1), rise (px, letters start this far BELOW their place),
    //         tint (hex or ""), tint_duration, max_total (s, cap for the whole reveal of long words) }
    // letterPlan fits the reveal into the time available (until the group exits) and the max_total cap; returns the numbers actually used.
    function letterPlan(L, n, available, frameDuration) {
        var stagger = L.stagger === undefined ? 0.033 : L.stagger, dur = L.duration === undefined ? 0.16 : L.duration;
        var tdur = L.tint ? (L.tint_duration === undefined ? 0.3 : L.tint_duration) : 0;
        var cap = L.max_total > 0 ? L.max_total : 1e9, room = Math.max(available - frameDuration, 0);
        var total = Math.max(0, n - 1) * stagger + Math.max(dur, 0), lim = Math.min(cap, room), s = 1;
        if (total > lim) s = total > 0 ? lim / total : 1;
        return { stagger: stagger * s, duration: dur * s, tint_duration: tdur * s, clamped: s < 1 };
    }
    // State of letter i of n at tRel seconds after the in-point. plan = letterPlan(...), L = the spec.
    // Returns { opacity 0..100, blur px, dy px (positive = below the final place), tint 0..1 (1 = fully tinted) }
    function letterAt(L, plan, tRel, i) {
        var f = cubicBezier.apply(null, resolveEase(L.ease)), t0 = i * plan.stagger, t = tRel - t0;
        var of = L.opacity_from === undefined ? 0 : L.opacity_from, bf = L.blur_from || 0, rise = L.rise || 0;
        var u = plan.duration <= 0 ? 1 : clamp(t / plan.duration, 0, 1), k = f(u);
        var tu = plan.tint_duration <= 0 ? 1 : clamp(t / plan.tint_duration, 0, 1);
        return { opacity: clamp(lerp(of * 100, 100, k), 0, 100), blur: Math.max(0, lerp(bf, 0, k)), dy: lerp(rise, 0, k), tint: L.tint ? 1 - f(tu) : 0 };
    }
    // Time (relative to the in-point) when the last letter has finished fading in.
    function letterEnd(plan, n) { return Math.max(0, n - 1) * plan.stagger + plan.duration; }

    // Source of an After Effects EXPRESSION SELECTOR "Amount" (0..100 = how much of the animator's "hidden" values letter textIndex still has).
    // kind "reveal": 100*(1 - ease(progress)) -> drives Opacity (opacity_from), Blur (blur_from) and Position (0, rise) of one animator.
    // kind "tint":   100*(1 - ease(tintProgress)) -> drives Fill Colour (tint) of a second animator.
    // It evaluates exactly letterAt() (tested in Node by running this text), with the numbers of `plan` baked in, so a letter can never start
    // before layer.inPoint + index*stagger.
    function letterExpression(L, plan, kind) {
        var b = resolveEase(L.ease), dur = kind === "tint" ? plan.tint_duration : plan.duration;
        function num(x) { return String(Math.round(x * 1e9) / 1e9); }
        return "var t = time - thisLayer.inPoint - (textIndex - 1) * " + num(plan.stagger) + ";\n" +
            "function ez(u) { if (u <= 0) return 0; if (u >= 1) return 1; var lo = 0, hi = 1, s = u, x, m, i;\n" +
            "  for (i = 0; i < 60; i++) { m = 1 - s; x = 3 * m * m * s * " + num(b[0]) + " + 3 * m * s * s * " + num(b[2]) + " + s * s * s; if (Math.abs(x - u) < 1e-9) break; if (x < u) lo = s; else hi = s; s = (lo + hi) / 2; }\n" +
            "  m = 1 - s; return 3 * m * m * s * " + num(b[1]) + " + 3 * m * s * s * " + num(b[3]) + " + s * s * s; }\n" +
            "var u = " + (dur <= 0 ? "1" : "Math.max(0, Math.min(1, t / " + num(dur) + "))") + ";\n" +
            "100 * (1 - ez(u))";
    }

    return { cubicBezier: cubicBezier, PRESETS: PRESETS, resolveEase: resolveEase, positionEase: positionEase, lerp: lerp, easeToKeyframe: easeToKeyframe,
             keyframeToEase: keyframeToEase, clampDuration: clampDuration, entranceAt: entranceAt, letterPlan: letterPlan, letterAt: letterAt, letterEnd: letterEnd,
             letterExpression: letterExpression };
})();

if (typeof module !== "undefined" && module.exports) module.exports = FCGAnim;
