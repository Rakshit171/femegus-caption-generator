"""Independent invariant checker for a built caption result. Used by tests AND at runtime (the CLI exits non-zero on violations).

It re-derives nothing from the segmenter: it only checks the contract on the output + the source words.
"""
from __future__ import annotations

from .config import SegmenterConfig

EPS = 1e-6


def verify(result: dict, source_words: list[dict], cfg: SegmenterConfig) -> list[str]:
    v: list[str] = []
    src = {w["id"]: w for w in source_words}
    groups = result["groups"]
    hard_before = set(result.get("hard_boundaries_before", []))
    seen: list[str] = []
    for gi, g in enumerate(groups):
        ws = g["words"]
        if not ws:
            v.append(f"{g['id']}: empty group")
            continue
        if len(ws) > cfg.max_words:
            v.append(f"{g['id']}: {len(ws)} words > max_words")
        prev_r = -1.0
        for k, w in enumerate(ws):
            s = src.get(w["id"])
            if s is None:
                v.append(f"{g['id']}: word {w['id']} not in source")
                continue
            seen.append(w["id"])
            if not cfg.allow_lead and w["reveal"] < s["start"] - EPS:
                v.append(f"PREMATURE {g['id']} {w['id']} '{w['display']}': reveal {w['reveal']:.3f} < spoken start {s['start']:.3f}")
            if w["reveal"] < prev_r - EPS:
                v.append(f"{g['id']}: reveals not monotonic at {w['id']}")
            prev_r = w["reveal"]
            if k > 0 and w["id"] in hard_before:
                v.append(f"CROSSES HARD BOUNDARY: {g['id']} contains {w['id']} '{w['display']}' after a sentence/pause boundary")
        if abs(g["start"] - ws[0]["reveal"]) > EPS:
            v.append(f"{g['id']}: group start != first reveal")
        if g["exit"] <= ws[-1]["reveal"]:
            v.append(f"{g['id']}: exit {g['exit']:.3f} <= last reveal {ws[-1]['reveal']:.3f}")
        if g["exit"] < ws[-1]["end"] - EPS:
            v.append(f"{g['id']}: exit {g['exit']:.3f} cuts the last word (ends {ws[-1]['end']:.3f})")
        if gi + 1 < len(groups) and groups[gi + 1]["words"]:
            if groups[gi + 1]["start"] < g["exit"] - EPS:
                v.append(f"OVERLAP {g['id']} exit {g['exit']:.3f} > next start {groups[gi + 1]['start']:.3f}")
    expected = [w["id"] for w in source_words]
    if seen != expected:
        missing = set(expected) - set(seen)
        dup = {i for i in seen if seen.count(i) > 1}
        v.append(f"word coverage mismatch: missing={sorted(missing)[:5]} duplicated={sorted(dup)[:5]}")
    return v
