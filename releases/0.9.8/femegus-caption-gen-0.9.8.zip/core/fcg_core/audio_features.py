"""Audio-derived timing cues from a loudness envelope. Pure Python, no audio decoding here (the engine produces the envelope).

envelope = {"hop": 0.01, "db": [float, ...]}   # RMS dB per hop seconds, from t=0

Why: Whisper word timestamps abut each other, so the timestamp gap hides real breaths/pauses (a sentence break measured 0.00 s in timestamps
but 0.14 s in the audio), and word starts are often a little early. Both are visible in the loudness envelope.
"""
from __future__ import annotations

from typing import Optional

Envelope = Optional[dict]


def _percentile(sorted_vals: list[float], p: float) -> float:
    if not sorted_vals:
        return 0.0
    k = (len(sorted_vals) - 1) * p / 100.0
    lo, hi = int(k), min(int(k) + 1, len(sorted_vals) - 1)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (k - lo)


def speech_threshold(env: dict, fraction: float) -> float:
    s = sorted(env["db"])
    floor, peak = _percentile(s, 10), _percentile(s, 95)
    return floor + fraction * (peak - floor)


def _idx(env: dict, t: float) -> int:
    return max(0, min(len(env["db"]) - 1, int(t / env["hop"])))


def pause_after(words: list[dict], env: Envelope, fraction: float, pad: float = 0.15) -> list[float]:
    """Seconds of real silence between each word and the next (last word: 0). Falls back to the timestamp gap without an envelope."""
    n = len(words)
    out = [0.0] * n
    if env is None or not env.get("db"):
        for i in range(n - 1):
            out[i] = max(0.0, words[i + 1]["start"] - words[i]["end"])
        return out
    thr = speech_threshold(env, fraction)
    db, hop = env["db"], env["hop"]
    for i in range(n - 1):
        a = _idx(env, words[i]["end"] - pad)
        b = _idx(env, words[i + 1]["start"] + pad)
        best = cur = 0
        for k in range(a, b + 1):
            if db[k] < thr:
                cur += 1
                best = max(best, cur)
            else:
                cur = 0
        out[i] = max(best * hop, max(0.0, words[i + 1]["start"] - words[i]["end"]))
    return out


def word_loudness(words: list[dict], env: Envelope) -> list[Optional[float]]:
    """Peak loudness of each word mapped to 0..1 between the file's noise floor (p10) and its loud speech (p95). None without envelope."""
    if env is None or not env.get("db"):
        return [None] * len(words)
    s = sorted(env["db"])
    floor, peak = _percentile(s, 10), _percentile(s, 95)
    span = max(peak - floor, 1e-6)
    out = []
    for w in words:
        a, b = _idx(env, w["start"]), _idx(env, w["end"])
        m = max(env["db"][a:b + 1] or [floor])
        out.append(max(0.0, min(1.0, (m - floor) / span)))
    return out


def refined_onsets(words: list[dict], env: Envelope, mode: str, max_shift: float, fraction: float) -> list[float]:
    """Acoustic onset per word, ALWAYS >= the recognised start and <= start + max_shift (never earlier = never premature).

    silence: if the recognised start falls in a quiet stretch, move to the first loud frame (<= max_shift later).
    slope:   additionally, in continuous speech move to the steepest energy rise (>= 8 dB within 30 ms) inside the window.
    """
    n = len(words)
    starts = [w["start"] for w in words]
    if mode == "off" or env is None or not env.get("db"):
        return starts
    thr = speech_threshold(env, fraction)
    db, hop = env["db"], env["hop"]
    out = []
    for w in words:
        s = w["start"]
        lim = min(s + max_shift, max(s, w["end"] - 0.03))
        a, b = _idx(env, s), _idx(env, lim)
        onset = s
        if db[a] < thr:
            for k in range(a, b + 1):
                if db[k] >= thr:
                    onset = max(s, k * hop)
                    break
        elif mode == "slope":
            best, at = 0.0, None
            for k in range(a, min(b, len(db) - 4) + 1):
                rise = db[k + 3] - db[k]
                if rise > best:
                    best, at = rise, k
            if at is not None and best >= 8.0:
                onset = max(s, at * hop)
        out.append(round(min(onset, lim if lim >= s else s), 4))
    return out
