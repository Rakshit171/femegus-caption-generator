"""Display-text normalisation. NON-destructive: the raw recognised text stays in ``text``; the normalised form goes in ``display``.

Rules (all optional via flags):
  * join number fragments  "15" ",000"           -> "15,000"
  * join hyphen fragments  "one" "-on" "-one"    -> "one-on-one"   (also "high" "-ticket")
  * glossary               {"crr": "crore", "rs": "rupees"}  (case-insensitive, whole word, punctuation preserved)
A merged display word keeps the start of its first part and the end of its last part, ``merged_ids`` lists every source id.
"""
from __future__ import annotations

import re

_NUM_FRAG = re.compile(r"^[,.]\d")
_ENDS_DIGIT = re.compile(r"\d[\"')]*$")
_PUNCT_SPLIT = re.compile(r"^([^\w]*)(.*?)([^\w]*)$", re.UNICODE)


def apply_glossary(text: str, glossary: dict[str, str]) -> str:
    if not glossary:
        return text
    m = _PUNCT_SPLIT.match(text)
    lead, core, trail = m.group(1), m.group(2), m.group(3)
    rep = glossary.get(core.lower())
    return f"{lead}{rep}{trail}" if rep is not None else text


def normalize(words: list[dict], glossary: dict[str, str] | None = None, join_numbers: bool = True,
              join_hyphens: bool = True) -> list[dict]:
    out: list[dict] = []
    gl = {k.lower(): v for k, v in (glossary or {}).items()}
    for w in words:
        w = dict(w)
        t = w.get("text", "")
        prev = out[-1] if out else None
        joinable = False
        if prev is not None:
            if join_numbers and _NUM_FRAG.match(t) and _ENDS_DIGIT.search(prev["display"]):
                joinable = True
            elif join_hyphens and (t.startswith("-") and len(t) > 1 or prev["display"].endswith("-")) and \
                    prev["display"] != "-":
                joinable = True
        if joinable:
            prev["display"] += t
            prev["end"] = w["end"]
            prev["merged_ids"].append(w["id"])
            prev["confidence"] = min(prev.get("confidence", 1.0), w.get("confidence", 1.0))
            prev["flags"] = sorted(set(prev.get("flags", [])) | set(w.get("flags", [])))
            if not prev["flags"]:
                prev.pop("flags")
            continue
        w["display"] = t
        w["merged_ids"] = [w["id"]]
        out.append(w)
    for w in out:
        new = apply_glossary(w["display"], gl)
        if new != w["display"]:
            w["glossary"] = True                       # the user's own replacement: later text polish leaves it alone
        w["display"] = new
    return out
