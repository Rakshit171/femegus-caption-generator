"""Reveal and exit times.

reveal(word) = max(recognised start, acoustic onset) + reveal_offset      -> never earlier than the recognised start (unless allow_lead)
exit(group)  = max(last word end + adaptive hold, first reveal + readable time), but never later than (next group's first reveal - exit_gap)

Animation settings elsewhere may only be defined RELATIVE to these times, so a style change cannot move a reveal.
"""
from __future__ import annotations

from .config import SegmenterConfig


def reveal_times(words: list[dict], onsets: list[float], cfg: SegmenterConfig, warns: list[str]) -> list[float]:
    off = cfg.reveal_offset_s
    if off < 0 and not cfg.allow_lead:
        warns.append("negative reveal_offset_s ignored (would show words before they are spoken); set allow_lead to opt in")
        off = 0.0
    out = []
    for w, o in zip(words, onsets):
        r = max(w["start"], o) + off if not cfg.allow_lead else max(0.0, max(w["start"], o) + off)
        r = min(r, max(w["end"], w["start"]))      # never reveal after the word has finished
        out.append(r)
    return out


def schedule(groups_words: list[list[dict]], reveals: list[list[float]], cfg: SegmenterConfig, warns: list[str]):
    """groups_words[g] = words, reveals[g] = per-word reveal times. Returns [(group_start, exit)] and fixes monotonic reveals in place."""
    sched = []
    for g, (ws, rv) in enumerate(zip(groups_words, reveals)):
        for k in range(1, len(rv)):
            rv[k] = max(rv[k], rv[k - 1])
        first, last = rv[0], ws[-1]
        avg = sum(w["end"] - w["start"] for w in ws) / len(ws)
        hold = min(cfg.hold_max_s, max(cfg.hold_min_s, cfg.hold_factor * avg))
        readable = max(cfg.min_group_visible_s, cfg.min_read_per_word_s * len(ws))
        desired = max(last["end"] + hold, first + readable)
        if g + 1 < len(groups_words):
            nxt_first = reveals[g + 1][0]
            cap = max(nxt_first - cfg.exit_gap_s, last["end"])   # never cut a word that is still being spoken
            if desired > cap:
                desired = cap
        exit_t = max(desired, rv[-1] + 0.01)
        if exit_t - rv[-1] < cfg.min_last_word_visible_s:
            warns.append(f"group {g + 1}: last word '{last['display']}' visible only {exit_t - rv[-1]:.2f}s "
                         "(next phrase starts immediately; overlap avoided)")
        sched.append((first, exit_t))
    return sched
