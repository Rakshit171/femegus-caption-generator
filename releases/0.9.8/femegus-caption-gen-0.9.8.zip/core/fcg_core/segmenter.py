"""Phrase grouping: hard boundaries first, then an optimal split (dynamic programming) of each stretch between hard boundaries.

HARD boundaries (a group can NEVER cross them, so words of the next sentence are never shown with the current one):
  sentence    previous word ends with . ? ! … । (not an abbreviation)
  pause       acoustic/timestamp pause >= hard_pause_s
  sentence_cue  next word is Capitalised, previous word has no punctuation, and a real pause >= sentence_cue_pause_s separates them
                (recovers sentence starts when the recogniser dropped punctuation, e.g. Roman-script Hindi spans)
  excluded    a junk word was removed between the two words
  forced      user said "break before this word"
SOFT cues (only influence where a long stretch is cut): pause length, comma/colon/dash, recogniser segment end, capital after an
unpunctuated word, a conjunction starting the next group; penalised: group ending on a function word, undersized groups, over/under target size.
"""
from __future__ import annotations

import math
from typing import Optional

from .config import SegmenterConfig

CLOSERS = "\"')]}”’»"
SOFT_END = ",;:–—-"
I_FORMS = {"i", "i'm", "i'll", "i've", "i'd"}


def _strip(t: str) -> str:
    return t.rstrip(CLOSERS)


def is_sentence_end(text: str, cfg: SegmenterConfig) -> bool:
    t = _strip(text)
    if not t or t[-1] not in cfg.sentence_end_chars:
        return False
    if t.endswith("..") and not t.endswith("…"):
        return False  # "..." trailing off is a soft cue, not a sentence end
    low = t.lower()
    if low in cfg.abbreviations or any(low.endswith(" " + a) for a in cfg.abbreviations):
        return False
    return True  # a false hard break only makes a group shorter; a missed one could merge two sentences


def ends_soft(text: str) -> bool:
    t = _strip(text)
    return bool(t) and t[-1] in SOFT_END


def has_punct(text: str, cfg: SegmenterConfig) -> bool:
    t = _strip(text)
    return bool(t) and (t[-1] in cfg.sentence_end_chars or t[-1] in SOFT_END)


def _core(text: str) -> str:
    return text.strip(CLOSERS + ".,;:!?…।-–—\"'").lower()


def hard_boundaries(words: list[dict], pauses: list[float], cfg: SegmenterConfig, forced: set[str],
                    gap_break: set[int]) -> dict[int, str]:
    """index i -> reason, meaning a hard boundary BETWEEN word i-1 and word i."""
    b: dict[int, str] = {}
    for i in range(1, len(words)):
        prev, cur = words[i - 1], words[i]
        if cur["id"] in forced:
            b[i] = "forced"
        elif is_sentence_end(prev["display"], cfg):
            b[i] = "sentence"
        elif pauses[i - 1] >= cfg.hard_pause_s:
            b[i] = "pause"
        elif i in gap_break:
            b[i] = "excluded"
        elif (cfg.sentence_cue_enabled and cur["display"][:1].isupper() and not has_punct(prev["display"], cfg)
              and _core(cur["display"]) not in I_FORMS and pauses[i - 1] >= cfg.sentence_cue_pause_s):
            b[i] = "sentence_cue"
    return b


def _group_cost(words, pauses, i, j, cfg: SegmenterConfig, span_len: int, internal_cut_after: bool) -> float:
    """Cost of a group made of words[i:j] (j exclusive). Includes the quality of the cut after word j-1 when it is internal."""
    n = j - i
    c = cfg.w_size * (n - cfg.target_words) ** 2
    if n < cfg.min_words and span_len >= cfg.min_words:
        c += cfg.w_min_words * (cfg.min_words - n) ** 2
    dur = words[j - 1]["end"] - words[i]["start"]
    if dur < cfg.min_duration_s:
        c += cfg.w_short_duration * (cfg.min_duration_s - dur) / cfg.min_duration_s
    if internal_cut_after:
        last, nxt = words[j - 1], words[j]
        c -= cfg.w_pause * min(1.0, pauses[j - 1] / cfg.pause_full_credit_s)
        if ends_soft(last["display"]):
            c -= cfg.w_punct
        if last.get("segment") is not None and nxt.get("segment") is not None and last["segment"] != nxt["segment"]:
            c -= cfg.w_segment
        if nxt["display"][:1].isupper() and not has_punct(last["display"], cfg) and _core(nxt["display"]) not in I_FORMS:
            c -= cfg.w_capital
        if _core(nxt["display"]) in cfg.start_prefer:
            c -= cfg.w_start_prefer
        if _core(last["display"]) in cfg.end_avoid:
            c += cfg.w_end_avoid
        lt = _strip(last["display"])
        if lt and lt[-1].isdigit():
            c += cfg.w_number_end
        # on-screen time of the last word before the next group takes over (the next group may not overlap it)
        tail = nxt["start"] - last["start"]
        if tail < cfg.min_last_word_visible_s:
            c += cfg.w_short_tail * (cfg.min_last_word_visible_s - tail) / cfg.min_last_word_visible_s
    return c


def _cut_reason(words, pauses, j, cfg: SegmenterConfig) -> str:
    """Name the strongest soft cue at the cut after word j-1 (informational)."""
    last, nxt = words[j - 1], words[j]
    cues = {
        "pause": cfg.w_pause * min(1.0, pauses[j - 1] / cfg.pause_full_credit_s),
        "punct": cfg.w_punct if ends_soft(last["display"]) else 0.0,
        "segment": cfg.w_segment if (last.get("segment") is not None and last.get("segment") != nxt.get("segment")) else 0.0,
        "capital": cfg.w_capital if (nxt["display"][:1].isupper() and not has_punct(last["display"], cfg)) else 0.0,
        "conjunction": cfg.w_start_prefer if _core(nxt["display"]) in cfg.start_prefer else 0.0,
    }
    k = max(cues, key=cues.get)
    return k if cues[k] > 0.5 else "length"


def _solve_span(words, pauses, a, b, cfg: SegmenterConfig, joins: set[int]) -> Optional[list[int]]:
    """Cut positions (absolute indices, exclusive group ends) for words[a:b]; None if infeasible with the join constraints."""
    n = b - a
    INF = math.inf
    dp = [INF] * (n + 1)
    back = [-1] * (n + 1)
    dp[0] = 0.0
    for k in range(1, n + 1):
        for size in range(1, min(cfg.max_words, k) + 1):
            j0 = k - size
            if dp[j0] == INF:
                continue
            i, j = a + j0, a + k
            if j0 > 0 and i in joins:
                continue                              # a cut before word i is forbidden
            chars = sum(len(words[x]["display"]) for x in range(i, j)) + size - 1
            if size > 1 and (chars > cfg.max_chars or words[j - 1]["end"] - words[i]["start"] > cfg.max_duration_s):
                continue
            cost = dp[j0] + _group_cost(words, pauses, i, j, cfg, n, internal_cut_after=(k < n))
            if cost < dp[k]:
                dp[k], back[k] = cost, j0
    if dp[n] == INF:
        return None
    cuts, k = [], n
    while k > 0:
        cuts.append(a + k)
        k = back[k]
    return sorted(cuts)


def segment(words: list[dict], pauses: list[float], cfg: SegmenterConfig, forced: set[str] | None = None,
            joins: set[str] | None = None, gap_break: set[int] | None = None):
    """Returns (groups, hard, warnings). groups = list of (start_idx, end_idx_exclusive, reason_for_break_after)."""
    warns: list[str] = []
    if not words:
        return [], {}, warns
    hard = hard_boundaries(words, pauses, cfg, forced or set(), gap_break or set())
    join_idx = {i for i, w in enumerate(words) if joins and w["id"] in joins}
    edges = [0] + sorted(hard) + [len(words)]
    groups: list[tuple[int, int, str]] = []
    for s, e in zip(edges, edges[1:]):
        cuts = _solve_span(words, pauses, s, e, cfg, join_idx)
        if cuts is None:
            cuts = _solve_span(words, pauses, s, e, cfg, set())
            warns.append(f"join_before constraint near '{words[s]['display']}' conflicts with size limits; ignored")
        start = s
        for c in cuts:
            reason = hard.get(c, "length") if c == e and e < len(words) else (
                _cut_reason(words, pauses, c, cfg) if c < e else ("end" if e == len(words) else hard[e]))
            groups.append((start, c, reason))
            start = c
    return groups, hard, warns
