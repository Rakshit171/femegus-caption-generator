"""Emphasis (accent vs support) SUGGESTION. Manual role overrides always win; this only provides the default.

score = length + spoken duration + capital/number bonus + loudness (when an envelope exists) - low-confidence penalty;
function words (config STOP_WORDS) are never suggested.
"""
from __future__ import annotations

import re

from .config import SegmenterConfig, STOP_WORDS

_STOP = set(STOP_WORDS)


def _core(t: str) -> str:
    return re.sub(r"[^\w']", "", t.lower())


def word_score(w: dict, loud: float | None, extra_stop: set | None = None) -> float:
    c = _core(w["display"])
    if not c or c in _STOP or (extra_stop and c in extra_stop):
        return -1.0
    s = min(len(c), 10) / 10.0
    s += min((w["end"] - w["start"]) / 0.5, 1.0)
    if re.search(r"\d", c) or (w["display"][:1].isupper() and not w.get("first_in_sentence")):
        s += 0.4
    if loud is not None:
        s += max(0.0, min(1.0, loud))
    if w.get("confidence", 1.0) < 0.5:
        s -= 0.3
    return s


def assign_roles(words: list[dict], loud: list[float | None], cfg: SegmenterConfig) -> None:
    """Sets w['role'] in {'accent','support'} and w['role_source'] in {'auto','manual'} for one group (in place)."""
    n = len(words)
    k = 0 if n < cfg.accent_min_group_words and not (n == 1) else (1 if n <= 4 else cfg.accent_max_per_group)
    k = min(k, cfg.accent_max_per_group)
    extra = {s.lower() for s in (cfg.accent_stop_words or [])}
    scores = [word_score(w, l, extra) for w, l in zip(words, loud)]
    ranked = sorted((i for i in range(n) if scores[i] >= cfg.accent_min_score), key=lambda i: -scores[i])[:k]
    chosen = set(ranked)
    for i, w in enumerate(words):
        manual = w.get("role_override")
        if manual in ("accent", "support"):
            w["role"], w["role_source"] = manual, "manual"
        else:
            w["role"], w["role_source"] = ("accent" if i in chosen else "support"), "auto"
