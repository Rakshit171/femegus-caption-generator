"""FemeGus Caption Generator — shared caption timing/segmentation core. Pure Python, no After Effects, no speech-model dependency."""
from .config import SegmenterConfig  # noqa: F401
from .pipeline import build  # noqa: F401
