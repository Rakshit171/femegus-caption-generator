"""Hinglish text polish: the DISPLAY layer between what the recogniser heard and what appears in captions / .srt.

Contract (see docs/HINGLISH_STYLE.md)
  * The raw recognised text (``text``) is never touched; everything here edits ``display`` only and every edit is recorded (``report["changes"]``).
  * Words are never added, removed, merged or re-timed: ids, start, end, reveal times are identical before and after (a test enforces it).
  * A word the user edited by hand (``edited``) is never changed.
  * Rules are contextual and evidence based. Where the evidence is weak the text is left as recognised (and, for amounts, flagged for review).

What it does, in this order
  1. spelling   one preferred spelling per Hinglish word (voh, toh, nahin, tumhaare, theek, yeh …); ``to`` becomes ``toh`` only in a Hindi context
  2. numbers    spoken Hindi/English number words before lakh/crore/hazaar/thousand become digits ("paanch laakh" -> "5 lakh"), bare 5–7 digit amounts get
                separators ("40000" -> "40,000"), magnitude/currency spellings are unified; a lone "1" between words becomes "one"
  3. homophones sells/cells, sale/sail — only with sales-domain context AND a not-quite-sure word; never over a confident recognition
  4. punctuation sentence-level: "?" only for genuine questions (a fully English statement ending in "?" gets "."), a comma before a capitalised sentence
                starter becomes ".", sentence starts are capitalised, mid-sentence function words are not, a final full stop
  5. checks     amounts that look like they lost their number are FLAGGED (``missing_amount``); the digits of every recognised number must survive
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

# ---------------------------------------------------------------------------------------------------------------------------------------------- vocabulary
TERMINAL = ".?!…।"
_SPLIT = re.compile(r"^([^\w]*)(.*?)([^\w]*)$", re.UNICODE)


def split_punct(text: str) -> tuple[str, str, str]:
    m = _SPLIT.match(text)
    return m.group(1), m.group(2), m.group(3)


def core_of(text: str) -> str:
    return split_punct(text)[1]


# Roman-Hindi words that are not also common English words. Used to recognise a Hindi sentence/context (never to rewrite anything).
HINDI_LEX = frozenset("""
main mai mein men mujhe mujhko mera meri mere hum ham humein hamara hamaara hamari hamaare tum tumhaare tumhare tumhara tumhaara tumhari tumhaari tumhen tumko
tumne aap aapka aapki aapke aapko aapne ye yeh yah yahi voh woh vah wo vo vahi wahi ve unka unki unke unhen usne usko uska uski uske isko iska iski iske isne inka
inhen koi kuch kuchh sab sabhi kaun kya kyun kyon kyu kyunki kyonki kaise kaisa kaisi kab kahan kahaan kidhar kitna kitne kitni kisi kisko kisne kiska kiski kiske
konsa kaunsa jo jis jise jinhen jab jahan jaise jaisa jitna ka ki ke ko se par pe tak liye lie saath baad pehle pahle bina andar bahar upar neeche aur ya lekin
magar phir tab agar warna isliye bhi hi na nahin nahi nahee mat haan ji hai hain hoon ho hu tha thi thhe hoga hogi honge hota hoti hote hona raha rahi rahe rahega
rahenge gaya gayi gaye jaata jaati jaate jaana jao jaao jaa aa aaya aayi aaye aata aati aate aao kar kare karo karna karne karte karta karti karke kiya kiye karenge
karega karoge karun kijiye karni dena diya dete deta dega lo lena liya leta lete le dekh dekho dekhna dekha bol bolo bolna bolte bola bolega bata batao bataya
bataaya batana sun suno suna samajh samjha samajhna pata lag laga lagta lagti lagega chahiye chaahie chahie chahta chahti sakta sakti sakte sake milta mila mili
mile padta padega padenge padti padi pada rakh rakho rakhna baith baithna baithkar kaam baat log logon cheez waqt din raat saal mahina paisa paise rupaye rupay rupe
aaj kal abhi ab bahut bohot bahot zyada jyada kam thoda thodi bilkul sirf sirph bas bhai yaar dost achha accha acha theek thik sahi galat bura bure kharaab mushkil
aasaan naya nayi naye purana bada badi bade chhota chhoti ghar aise waise vaise itna itni itne utna utni utne kabhi kahin har dusra doosra pehla pahla ek teen chaar
paanch chhah saat aath nau das dus sau hazaar hazar lakh laakh karod aaiye aaie chaliye chalo chal hoon hun hain mainne maine mene unse usse isse kyunki pichhle
pichhale hathiyaar chakoo achaanak sudhaar baithkar sakta rahi rahiye rakha rahta rehta rehte rehna kehna kehte kaha kahte kahenge matlab samay zaroor zarur
ladka ladki bachche bachchon beta beti bhaiya didi sunna dekhte dekhenge milega milenge mil jaata jaayega jaayenge chhodna chhod chhodo laga lagi lage
""".split())

# English words that decide "this sentence is English" when no Hindi word is present is NOT needed: a sentence without a single HINDI_LEX word is treated as English.

WH = frozenset({"what", "why", "how", "when", "where", "who", "whom", "whose", "which"})
AUX = frozenset({"is", "are", "am", "was", "were", "do", "does", "did", "can", "could", "will", "would", "should", "shall", "may", "might", "must", "have", "has", "had"})
PRON = frozenset({"i", "you", "we", "they", "he", "she", "it", "there", "this", "that", "these", "those", "anyone", "everyone", "someone", "anybody"})
FILLERS = frozenset({"and", "but", "so", "now", "then", "okay", "ok", "well", "also", "because", "yeah", "like", "actually", "basically", "see", "look"})
TAGS = ("right", "okay", "ok", "no", "yeah", "huh", "correct", "isn't it", "aren't you", "don't you", "doesn't it", "won't you", "can't you", "wasn't it",
        "weren't you", "haven't you", "hasn't it", "didn't you", "shall we", "isn't that right", "isn't that so")
WH_SECOND = frozenset({"come", "many", "much", "long", "often", "far", "old", "big", "else"})

# Words a sentence can start with after a comma that the recogniser capitalised: the capital letter is the recogniser's own sign of a new sentence.
SENTENCE_STARTERS = frozenset("""
tumhaare tumhare tumhara tumhari tum main mainne maine hum ham aap aapko aapka ye yeh yah voh vah woh wo ab abhi kaise kyun kyon kya kaun kab kahan koi sabse
jab agar kyonki kyunki isliye mujhe mera meri mere
now we you they he she it this these those what why how when where who which we're you're they're he's she's it's that's there's
""".split())

# Function words that are never capitalised in the middle of a sentence (a stray capital is the recogniser's, not the speaker's)
LOWER_MID = frozenset("""
my the a an to of in on at for with by from and but or so if that this is are was were be your our his her their its you we they it me him them us as than then not
just what how why when where who which do does did can could will would should have has had am been about into over under up out
""".split())

# Roman-Hindi function words: capitalised in the middle of a sentence ("bhi Apni jab problem") the capital is the recogniser's, not the speaker's.
# Names and nouns are deliberately not in this list.
LOWER_MID_HINDI = frozenset("""
apni apna apne aur ki ke ka ko se mein par pe hai hain tha thi ho hoon toh bhi hi na nahin main tum hum aap yeh voh kya kaise jab tab agar lekin phir abhi ab kal aaj
bahut mere mera meri tumhaare tumhaari uska uski uske isko usko itna kuch koi sab
""".split())

CURRENCY = frozenset({"rupees", "rupaye", "rupay", "rupe", "rupiya", "rs", "dollars", "dollar", "usd", "inr", "euros", "pounds"})
MAGNITUDE_CANON = {
    "lakh": "lakh", "laakh": "lakh", "lakhs": "lakh", "lac": "lakh", "lacs": "lakh", "laks": "lakh",
    "crore": "crore", "crores": "crore", "karod": "crore", "karor": "crore", "karodon": "crore", "crr": "crore",
    "hazaar": "hazaar", "hazar": "hazaar", "hajar": "hazaar", "hazaarr": "hazaar",
}
MAGNITUDE_WORDS = frozenset(MAGNITUDE_CANON.values()) | {"thousand", "million", "billion", "hundred"}
CONVERT_BEFORE = frozenset(MAGNITUDE_CANON.values()) | {"thousand", "million", "billion"}   # "five lakh" -> "5 lakh"; "one hundred percent" stays

_ONES = {"zero": 0, "shunya": 0, "ek": 1, "one": 1, "do": 2, "two": 2, "teen": 3, "three": 3, "chaar": 4, "char": 4, "four": 4, "paanch": 5, "panch": 5, "five": 5,
         "chhah": 6, "chhe": 6, "che": 6, "six": 6, "saat": 7, "seven": 7, "aath": 8, "eight": 8, "nau": 9, "nine": 9, "das": 10, "dus": 10, "ten": 10,
         "gyaarah": 11, "gyarah": 11, "eleven": 11, "baarah": 12, "barah": 12, "twelve": 12, "terah": 13, "thirteen": 13, "chaudah": 14, "fourteen": 14,
         "pandrah": 15, "fifteen": 15, "solah": 16, "sixteen": 16, "satrah": 17, "seventeen": 17, "atharah": 18, "eighteen": 18, "unnis": 19, "nineteen": 19,
         "bees": 20, "twenty": 20, "pachchis": 25, "pachis": 25, "tees": 30, "thirty": 30, "chaalees": 40, "chalis": 40, "forty": 40, "pachaas": 50, "pachas": 50,
         "fifty": 50, "saath": 60, "sixty": 60, "sattar": 70, "seventy": 70, "assi": 80, "eighty": 80, "nabbe": 90, "ninety": 90}
# "do" (two) is also an English verb and "saath" also means "with": they are converted ONLY directly before a magnitude word ("do lakh"), never on their own.

# "to" / "hay" / "ham" can also be English words: SPELLING_HINDI_ONLY below applies only with a Hindi word next to them.
ENGLISH_INFINITIVE_VERBS = frozenset("""
pay go be do have get make take give see say tell know call close send buy sell start stop try use help work handle ask show share write read learn understand
explain talk speak meet win lose grow build create convert solve move change think feel look find keep let put run check follow watch hear leave bring
""".split())

# ------------------------------------------------------------------------------------------------------------------------------------------- spelling
# variant -> preferred. Sources: the project's convention (voh/toh/nahin/tumhaare/mujhe, see docs/HINGLISH_STYLE.md) and the owner's corrected reference
# transcript (theek, yeh, maine, kuch, zyaadatar, hazaaron). Whole words only; case is carried over; punctuation is kept.
SPELLING: dict[str, str] = {
    "vah": "voh", "woh": "voh", "wo": "voh", "vo": "voh",
    "yah": "yeh", "ye": "yeh",
    "nahi": "nahin", "nahee": "nahin", "nahin": "nahin",
    "tumhare": "tumhaare", "tumhara": "tumhaara", "tumhari": "tumhaari", "hamare": "hamaare", "hamara": "hamaara", "hamari": "hamaari",
    "thik": "theek", "thikk": "theek", "theek": "theek",
    "mujhay": "mujhe", "mainne": "maine", "mene": "maine",
    "sirph": "sirf", "kuchh": "kuch", "kuchch": "kuch",
    "zyaadaatar": "zyaadatar", "zyadatar": "zyaadatar", "jyadatar": "zyaadatar", "hazaaro": "hazaaron", "hazaron": "hazaaron",
    "aesa": "aisa",
    "rupeez": "rupees", "rupis": "rupees", "rupes": "rupees", "rupay": "rupaye", "rupaiye": "rupaye", "rupe": "rupaye", "rupya": "rupaye",
    "rs": "rupees",
}
SPELLING_HINDI_ONLY: dict[str, str] = {"to": "toh", "hay": "hai", "ham": "hum"}

# ------------------------------------------------------------------------------------------------------------------------------------------ homophones
SALES_CUES = frozenset("""
sales sale sell selling sold sells story stories prospect prospects client clients customer customers price pricing product offer pitch close closing deal deals
buy buying buyer lead leads funnel revenue coach coaches marketing brand presentation tells tell convert conversion call calls script objection objections
""".split())
BIOLOGY_CUES = frozenset("""
body blood brain stem cancer human immune white red skin tissue dna biology organ bacteria plant animal tumor tumour nerve muscle fat solar battery prison phone
jail spreadsheet excel biological nucleus membrane mitochondria
""".split())
NAUTICAL_CUES = frozenset("boat ship wind sea ocean yacht sailor sailing captain mast water".split())
HOMOPHONE_MAX_CONFIDENCE = 0.90      # a recognition the model is this sure of is never overridden by context


# ------------------------------------------------------------------------------------------------------------------------------------------- config
@dataclass
class PolishOptions:
    spelling: bool = True
    numbers: bool = True
    homophones: bool = True
    punctuation: bool = True
    number_grouping: str = "indian"          # indian (5,00,000) | international (500,000) | none
    abbreviations: tuple = ("mr.", "mrs.", "ms.", "dr.", "vs.", "e.g.", "i.e.", "jr.", "sr.")
    extra_spelling: Optional[dict] = None    # the project's own additions: {"variant": "preferred"} (overrides.json "spelling")


# ------------------------------------------------------------------------------------------------------------------------------------------- helpers
def _recase(src_core: str, new: str) -> str:
    if src_core.isupper() and len(src_core) > 1:
        return new.upper()
    if src_core[:1].isupper():
        return new[:1].upper() + new[1:]
    return new


def _is_terminal(display: str, abbreviations) -> bool:
    lead, core, trail = split_punct(display)
    if not any(c in TERMINAL for c in trail):
        return False
    return (core + trail[:1]).lower() not in abbreviations


def group_digits(digits: str, style: str) -> str:
    if style == "none" or not digits.isdigit() or not (5 <= len(digits) <= 7):
        return digits
    if style == "international":
        return f"{int(digits):,}"
    head, tail = digits[:-3], digits[-3:]
    parts = []
    while len(head) > 2:
        parts.insert(0, head[-2:])
        head = head[:-2]
    if head:
        parts.insert(0, head)
    return ",".join(parts + [tail])


def _norm_tok(display: str) -> str:
    return core_of(display).lower()


def _hindi_ctx(tokens: list[str], i: int) -> bool:
    """A neighbouring (previous or next) word is an unmistakable Hindi word."""
    return (i > 0 and tokens[i - 1] in HINDI_LEX) or (i + 1 < len(tokens) and tokens[i + 1] in HINDI_LEX)


class _Log:
    def __init__(self, words: list[dict]):
        self.words, self.changes = words, []
        self.expected_digit_loss: list[str] = []         # digits that were turned into a word on purpose ("1" -> "one")

    def set(self, i: int, new_display: str, rule: str) -> None:
        w = self.words[i]
        if new_display == w["display"]:
            return
        self.changes.append({"id": w["id"], "rule": rule, "before": w["display"], "after": new_display, "t": round(w.get("start", 0.0), 2)})
        w["display"] = new_display
        w.setdefault("polish", [])
        if rule not in w["polish"]:
            w["polish"].append(rule)


# ------------------------------------------------------------------------------------------------------------------------------------------- steps
def _step_spelling(log: _Log, opt: PolishOptions) -> None:
    ws = log.words
    toks = [_norm_tok(w["display"]) for w in ws]
    table = {**SPELLING, **{k.lower(): v for k, v in (opt.extra_spelling or {}).items()}}
    for i, w in enumerate(ws):
        if w.get("edited") or w.get("glossary"):
            continue
        lead, core, trail = split_punct(w["display"])
        low = core.lower()
        if not low:
            continue
        new = table.get(low)
        if low == "rs" and not (i and (any(c.isdigit() for c in toks[i - 1]) or toks[i - 1] in MAGNITUDE_WORDS or toks[i - 1] in MAGNITUDE_CANON)):
            new = None                                          # "Rs 500" (prefix) is left alone; "5 lakh rs" -> "5 lakh rupees"
        if new is None and low in SPELLING_HINDI_ONLY:
            if low == "to":
                nxt = toks[i + 1] if i + 1 < len(toks) else ""
                prv = toks[i - 1] if i else ""
                # "to" is "toh" next to a Hindi word; but "<hindi word> to pay …" (infinitive before an English verb) stays English
                if (nxt in HINDI_LEX) or (prv in HINDI_LEX and nxt not in ENGLISH_INFINITIVE_VERBS):
                    new = SPELLING_HINDI_ONLY[low]
            elif _hindi_ctx(toks, i):
                new = SPELLING_HINDI_ONLY[low]
        if new is not None and new != low:
            log.set(i, lead + _recase(core, new) + trail, "spelling")


def _number_value(tok: str) -> Optional[int]:
    return _ONES.get(tok)


def _step_numbers(log: _Log, opt: PolishOptions) -> None:
    ws = log.words
    n = len(ws)
    toks = [_norm_tok(w["display"]) for w in ws]
    for i, w in enumerate(ws):
        if w.get("edited") or w.get("glossary"):
            continue
        lead, core, trail = split_punct(w["display"])
        low = core.lower()
        # magnitude / currency spelling: lakh, crore, hazaar
        if low in MAGNITUDE_CANON and MAGNITUDE_CANON[low] != low:
            canon = MAGNITUDE_CANON[low]
            log.set(i, lead + (canon if low == "crr" else _recase(core, canon)) + trail, "number_word")
            toks[i] = MAGNITUDE_CANON[low]
            continue
        # number word directly before a magnitude word -> digits
        nxt = toks[i + 1] if i + 1 < n else ""
        nxt = MAGNITUDE_CANON.get(nxt, nxt)
        if low in _ONES and nxt in CONVERT_BEFORE and not any(c.isdigit() for c in core):
            log.set(i, lead + str(_ONES[low]) + trail, "number_word")
            toks[i] = str(_ONES[low])
            continue
        # bare 5-7 digit amounts: 40000 -> 40,000
        if core.isdigit() and 5 <= len(core) <= 7 and opt.number_grouping != "none":
            log.set(i, lead + group_digits(core, opt.number_grouping) + trail, "number_format")
            continue
    # a lone "1" between two words ("that 1 problem") is the word "one", not an amount
    for i, w in enumerate(ws):
        if w.get("edited") or w.get("glossary"):
            continue
        lead, core, trail = split_punct(w["display"])
        if core != "1" or i == 0 or i + 1 >= n or trail.strip(",") != "":
            continue
        prv, nx = toks[i - 1], toks[i + 1]
        unit_like = MAGNITUDE_WORDS | CURRENCY | {"percent", "x", "k", "hours", "hour", "minutes", "minute", "days", "day", "months", "month", "years", "year", "weeks",
                                                  "week", "lakh", "crore", "million", "billion", "dollars", "rupees", "rs", "to", "by", "of", "number", "no", "step",
                                                  "point", "round", "part", "rank", "level", "vs", "tier"}
        if (prv.isalpha() and nx.isalpha() and nx not in unit_like and prv not in unit_like and not _is_terminal(ws[i - 1]["display"], opt.abbreviations)
                and ws[i - 1]["display"].strip()[-1:] not in ".?!"):
            log.set(i, lead + "one" + trail, "number_word")
            log.expected_digit_loss.append("1")


def _step_homophones(log: _Log, opt: PolishOptions) -> None:
    ws = log.words
    toks = [_norm_tok(w["display"]) for w in ws]
    n = len(ws)
    for i, w in enumerate(ws):
        if w.get("edited") or w.get("glossary"):
            continue
        lead, core, trail = split_punct(w["display"])
        low = core.lower()
        if low not in ("cells", "cell", "sail", "sails"):
            continue
        conf = w.get("confidence")
        conf = 0.5 if conf is None else float(conf)
        if conf >= HOMOPHONE_MAX_CONFIDENCE:
            continue                                            # clear audio evidence beats context
        near = toks[max(0, i - 6):i] + toks[i + 1:i + 7]
        if low in ("cells", "cell"):
            if any(t in BIOLOGY_CUES for t in near):
                continue
            prev = toks[i - 1] if i else ""
            if not (any(t in SALES_CUES for t in near) or (low == "cells" and prev in ("he", "she", "it", "who", "that", "which", "story"))):
                continue
            log.set(i, lead + _recase(core, "sells" if low == "cells" else "sell") + trail, "homophone")
        else:
            if any(t in NAUTICAL_CUES for t in near):
                continue
            if not any(t in SALES_CUES for t in near):
                continue
            log.set(i, lead + _recase(core, "sale" if low == "sail" else "sales") + trail, "homophone")


def _en_question_liberal(tokens: list[str], raw_clauses: list[list[str]]) -> bool:
    """Is this (English) sentence plausibly a question? Used to KEEP a "?" the recogniser wrote."""
    if len(tokens) <= 3:
        return True                                              # "Right?", "Why?", "Really?" — echo / tag questions
    tail = " ".join(tokens[-3:])
    if any(tail.endswith(t) for t in TAGS):
        return True
    for cl in raw_clauses:
        c = [t for t in cl if t not in FILLERS] or cl
        if not c:
            continue
        if c[0] in WH and len(c) > 1 and (c[1] in AUX or c[1] in WH_SECOND or (c[0] in ("what", "which", "whose") and any(t in AUX for t in c[1:3]))):
            return True
        if c[0] in AUX and len(c) > 1 and (c[1] in PRON or c[1] == "not"):
            return True
        if c[0] in AUX and c[0] not in ("do", "have", "has", "had") and len(c) > 2:
            return True
    return False


def _en_question_strict(clauses: list[list[str]]) -> bool:
    """Unmistakable English question pattern, used before ADDING a "?"."""
    for cl in clauses[:2]:
        c = [t for t in cl if t not in FILLERS] or cl
        if len(c) >= 3 and c[0] in WH and c[1] in AUX:
            return True
        if len(c) >= 3 and c[0] in AUX and c[1] in PRON and c[1] not in ("this", "that") and c[0] not in ("have", "has", "had"):
            return True
    return False


def _sentence_spans(ws: list[dict], opt: PolishOptions) -> list[tuple[int, int]]:
    spans, a = [], 0
    for i, w in enumerate(ws):
        if _is_terminal(w["display"], opt.abbreviations):
            spans.append((a, i))
            a = i + 1
    if a < len(ws):
        spans.append((a, len(ws) - 1))
    return spans


def _step_punctuation(log: _Log, opt: PolishOptions) -> None:
    ws = log.words
    n = len(ws)
    if not n:
        return
    # 1. the recogniser capitalised a sentence starter right after a comma: that capital is its own sign of a new sentence
    for i in range(1, n):
        a, b = ws[i - 1], ws[i]
        if a.get("edited") or b.get("edited") or a.get("glossary") or b.get("glossary"):
            continue
        al, ac, at = split_punct(a["display"])
        bl, bc, bt = split_punct(b["display"])
        if at.endswith(",") and bc[:1].isupper() and bc.lower() in SENTENCE_STARTERS and bc not in ("I",):
            log.set(i - 1, al + ac + at[:-1] + "." + "", "comma_to_period")
    # 2. questions
    toks_all = [_norm_tok(w["display"]) for w in ws]
    for a, b in _sentence_spans(ws, opt):
        last = ws[b]
        if last.get("edited") or last.get("glossary"):
            continue
        lead, core, trail = split_punct(last["display"])
        toks = [t for t in toks_all[a:b + 1] if t]
        clauses, cur = [], []
        for k in range(a, b + 1):
            t = toks_all[k]
            if t:
                cur.append(t)
            if split_punct(ws[k]["display"])[2].rstrip(".?!…").endswith(",") or k == b:
                if cur:
                    clauses.append(cur)
                cur = []
        hindi = any(t in HINDI_LEX for t in toks)
        if "?" in trail and not hindi and not _en_question_liberal(toks, clauses):
            log.set(b, lead + core + trail.replace("?", "."), "question_mark_removed")
        elif trail.startswith(".") and not hindi and len(toks) >= 3 and _en_question_strict(clauses):
            log.set(b, lead + core + trail.replace(".", "?", 1), "question_mark_added")
    # 3. capitalisation: sentence starts up, stray capitals on function words down
    spans = _sentence_spans(ws, opt)
    starts = {a for a, _ in spans}
    for i, w in enumerate(ws):
        if w.get("edited") or w.get("glossary"):
            continue
        lead, core, trail = split_punct(w["display"])
        if not core or not core[0].isalpha():
            continue
        if i in starts:
            if core[0].islower():
                log.set(i, lead + core[0].upper() + core[1:] + trail, "capitalisation")
        elif core[0].isupper() and (core.lower() in LOWER_MID or core.lower() in LOWER_MID_HINDI) and core != "I" and not core.isupper():
            log.set(i, lead + core[0].lower() + core[1:] + trail, "capitalisation")
        elif core in ("i", "i'm", "i'll", "i've", "i'd"):
            log.set(i, lead + core[0].upper() + core[1:] + trail, "capitalisation")
    # 4. a final full stop when the last sentence is clearly finished
    last = ws[-1]
    if not last.get("edited") and not last.get("glossary") and spans and not _is_terminal(last["display"], opt.abbreviations):
        a, b = spans[-1]
        if b - a + 1 >= 3:
            log.set(n - 1, last["display"].rstrip(",;:") + ".", "final_full_stop")


def _step_checks(log: _Log, raw_displays: list[str], opt: PolishOptions) -> list[dict]:
    """Flags and problems. Nothing is invented: a currency/magnitude word without a number in front of it is only FLAGGED."""
    ws = log.words
    problems = []
    toks = [_norm_tok(w["display"]) for w in ws]
    NUMLIKE = lambda t: any(c.isdigit() for c in t) or t in _ONES or t in MAGNITUDE_WORDS
    connectors = {"agar", "ya", "or", "aur", "and", "of", "ki", "to", "toh", "the", "if", "that", "with", "for", "only", "about", "around", "approx"}
    for i, w in enumerate(ws):
        t = toks[i]
        if t not in CURRENCY and t not in MAGNITUDE_WORDS:
            continue
        if i == 0:
            continue
        prv = toks[i - 1]
        if NUMLIKE(prv) or prv in ("a", "an", "some", "few", "many", "lots", "crores", "thousands", "lakhs", "hundreds", "millions", "of", "in", "no", "any"):
            continue
        gap = w.get("start", 0.0) - ws[i - 1].get("end", 0.0)
        if prv in connectors or gap >= 0.30:
            flags = w.setdefault("flags", [])
            if "missing_amount" not in flags:
                flags.append("missing_amount")
            problems.append({"id": w["id"], "kind": "missing_amount", "t": round(w.get("start", 0.0), 2),
                             "text": f"'{ws[i - 1]['display']} {w['display']}': an amount may be missing before '{w['display']}' — listen and add it in the transcript editor"})
    # every digit sequence that was recognised must still be there after polishing
    def digits(s: str) -> list[str]:
        return re.findall(r"\d+", s.replace(",", ""))
    from collections import Counter
    missing = Counter(d for s in raw_displays for d in digits(s)) - Counter(d for w in ws for d in digits(w["display"]))
    missing.subtract(Counter(log.expected_digit_loss))
    for d, k in missing.items():
        if k > 0:
            problems.append({"kind": "number_lost", "text": f"the recognised number {d} is missing after text polish"})
    return problems


# ------------------------------------------------------------------------------------------------------------------------------------------- public
def polish(words: list[dict], opt: Optional[PolishOptions] = None) -> tuple[list[dict], dict]:
    """Return (words with improved ``display``, report). ``words`` are the normalised display words (textnorm.normalize output); a copy is returned."""
    opt = opt or PolishOptions()
    ws = [dict(w) for w in words]
    for w in ws:
        w["display"] = w.get("display", w.get("text", ""))
        if "flags" in w:
            w["flags"] = list(w["flags"])
    raw = [w["display"] for w in ws]
    log = _Log(ws)
    if opt.spelling:
        _step_spelling(log, opt)
    if opt.numbers:
        _step_numbers(log, opt)
    if opt.homophones:
        _step_homophones(log, opt)
    if opt.punctuation:
        _step_punctuation(log, opt)
    problems = _step_checks(log, raw, opt)
    counts: dict[str, int] = {}
    for c in log.changes:
        counts[c["rule"]] = counts.get(c["rule"], 0) + 1
    return ws, {"enabled": True, "changes": log.changes, "counts": counts, "problems": problems}
