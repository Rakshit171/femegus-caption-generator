"""CLI:  python -m fcg_core build TRANSCRIPT.json [--envelope ENV.json] [--overrides O.json] [--config C.json] [--out groups.json] [--show]"""
from __future__ import annotations

import argparse
import json
import sys

from .config import SegmenterConfig
from .pipeline import build


def _load(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="fcg_core")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="group a transcript into timed caption groups")
    b.add_argument("transcript")
    b.add_argument("--envelope")
    b.add_argument("--overrides")
    b.add_argument("--config")
    b.add_argument("--out")
    b.add_argument("--show", action="store_true")
    d = sub.add_parser("defaults", help="print the default configuration as JSON")
    args = ap.parse_args(argv)
    if args.cmd == "defaults":
        print(json.dumps(SegmenterConfig().to_dict(), indent=1))
        return 0
    cfg, cw = SegmenterConfig.from_dict(_load(args.config) if args.config else None)
    res = build(_load(args.transcript), _load(args.overrides) if args.overrides else None, cfg,
                _load(args.envelope) if args.envelope else None)
    res["warnings"] = cw + res["warnings"]
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=1)
    if args.show:
        for g in res["groups"]:
            print(f"{g['id']} {g['start']:7.2f} -> {g['exit']:7.2f}  [{g['break_after']}]")
            for w in g["words"]:
                mark = "*" if w["role"] == "accent" else " "
                print(f"     {mark} {w['reveal']:7.2f}  {w['display']}   (spoken {w['start']:.2f}, pause {w['pause_after']:.2f})")
    for w in res["warnings"]:
        print(f"[warn] {w}", file=sys.stderr)
    print(f"[core] {json.dumps(res['stats'])}", file=sys.stderr)
    if res["violations"]:
        for v in res["violations"]:
            print(f"[VIOLATION] {v}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
