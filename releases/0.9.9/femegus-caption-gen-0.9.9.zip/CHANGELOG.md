# Changelog

Each release has a `## <version>` heading followed by bullet points; the bullets are what the app shows as "what's new" when an update is available.

## 0.9.9
- Fix: Hinglish captions with no Hindi words. Two causes: the speech model sometimes translated a spoken Hindi sentence into English (so no Hindi was found), and the Hinglish model sometimes got stuck repeating itself ("vah, vah, vah…"), which left whole stretches of Hindi out of the captions. Both are now detected and those stretches are decoded again. Restart the app and transcribe the clip again to get the corrected text.
- Fix: Automatic language now also notices Hindi that the speech model translated into English, so a Hinglish clip is no longer treated as English.
- Fix: random words flashing on screen for a few frames. Runs of words squeezed into a few hundredths of a second (a repeated phrase the speech model invented) are left out of the captions and listed under "Excluded", where you can bring a word back.
- New: Clean 4-Word look gets two options (both off by default): "Whole line at once" (the line appears together when its first word is spoken) and "Solid box behind the text" (any colour, opacity, padding, corner roundness; a separate editable shape layer in After Effects).
- Improved: the After Effects read-back check understands the new options.

## 0.9.8
- New: one-click fixes in the system check (section 10). If a speech model or component is missing, a Fix button appears next to it (download the English model, set up the Hinglish model, GPU libraries, repair), plus "Fix everything", with progress and Cancel.
- Improved: the system check now notices an incomplete model download and a Hinglish model that is present but not connected.

## 0.9.7
- Fix: spoken amounts lost inside Hindi sentences ("agar 40,000 ya 50,000 rupees … toh kal mujhe 5 lakh rupees" came out as "agar ya rupees … mujhe rupe"). Numbers are now kept, and an amount that may have lost its number is flagged instead of silently missing.
- Fix: English words in a stretch the first pass skipped now come from the stock model ("story sells", not "story cells"); a Hindi stretch the Hinglish model skipped is asked again so the first words ("Stories batao") are no longer left out.
- New: Hinglish text polish (section 2): one spelling per word (voh, yeh, toh, nahin, tumhaare, theek…), "paanch laakh" → "5 lakh", question marks only for real questions, sentence capitals. Every change is listed and it can be switched off.
- New: Hinglish regression suite with measurements (scripts/hinglish_eval.py) and the writing convention in docs/HINGLISH_STYLE.md.
- Fix: a stray "null" text under the transcript table (and in other panels) is gone.

## 0.9.6
- Fix: captions missing for the first seconds of a clip (seen with Hinglish on clips cut mid-sentence; English uses the same safety net). Missing starts are now found, refilled from a second decoding pass and, if needed, by decoding the first seconds again.
- New: download your captions as an .srt subtitle file (section 10): one cue per caption, or a word-by-word build-up. It shows the cue count and the first cues before you download.
- Unfillable gaps at the very start are now marked red on the timeline from 0.6 s (before: 1.5 s), so you can listen and add the words.

## 0.9.5
- New: delete recent projects to free disk space (section 1). Each project shows its size; tick one or more and press Delete selected. Only the tool's saved work is removed — your video/audio files and After Effects are never touched.
- Fix: a project with a damaged transcript no longer disappears from the Recent projects list.

## 0.9.4
- Fix: Transcribe failing with "unexpected keyword argument 'metadata_errors'" on some computers. Differing PyAV versions are tolerated, only tested library versions are installed, and errors now say what to do.
- Fix: a graphics-card failure in the middle of a transcription now continues on the processor instead of stopping.
- Fix: after Update the button came back with no confirmation. Now: "Update installed — restart to finish" with a Restart now button, and Check for updates always says whether you have the latest version.
- New: Repair components and Copy support info buttons (section 10); the System check warns about components that differ from the tested versions.
- If you are on 0.9.3 or older: after this update close the black window and start the app again once; later restarts are one click.

## 0.9.3
- Fix: black picture with working sound. Some videos (phone and screen-recorder files, HEVC/H.265) cannot be shown by the browser. The app now notices and makes a small preview copy automatically (a progress message is shown); there is also a "Picture black or choppy? Make a preview copy" button in section 1. Only the preview uses the copy; After Effects and the transcription still use your original file.
- Fix: transcription that seemed stuck at "4 %". The first transcription on a new computer downloads the speech model (about 1.6 GB); this is now shown with MB and percent (and a clear message if the download fails). Every step is named, with elapsed seconds, and also printed in the app's black window.

## 0.9.2
- Fix: clicking "Browse..." could shut the whole app down on some computers ("The caption app is not reachable"). The file dialog now runs separately and can no longer take the app down; if it cannot open, you are told to paste the path instead.
- One clear message when the app has stopped (instead of a pile of identical errors), and a crash log (`work\app_crash.log`) for support if it ever happens again.

## 0.9.1
- New look "Clean 4-Word": plain white text, at most four words per line, with a one-click smooth slide-up animation switch.
- New look "Soft Editorial": centred light-sans lines, key words in serif caps / bold glow / bold inline / warm bold / gold glow / serif italic, letter-by-letter reveals.
- Caption looks gallery (section 4): change the whole style in one click; save your own looks.
- Per-word and key-word styling: any installed font, solid or gradient fill, outline and glow, for one word or every occurrence.
- Updates: check for new versions and new looks from inside the app (opt-in).
- Fixes: fill colour hidden by a gradient, layout-specific overrides ignoring "all layouts" edits, After Effects reports for relative project folders.
