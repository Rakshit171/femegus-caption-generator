"""Common Roman-script Hindi words that are practically never English, used as EVIDENCE that a stretch of speech is Hindi.

Why this exists: the Hinglish hybrid route finds Hindi stretches by the script the stock model writes them in (Devanagari). Sometimes the stock model
does not write Hindi at all but TRANSLATES a whole spoken Hindi sentence into fluent English ("Tumhen koi bhi is kal ko master karna hai" came back as
"you have to master any of this skill"). Nothing in the skeleton then says "Hindi", and the Hinglish model's correct words were thrown away: the user saw
no Hinglish words at all. The Hinglish model's OWN output shows Hindi through these words (see hybrid.translated_spans).

Rules for this list: only words that are Hindi function words or very frequent everyday words in their usual Roman spellings, and NOT English words
(so no "to", "me", "do", "so", "ho", "hi", "par", "main", "is", "us", "pe", "na", "ab"). A single hit proves nothing (a name, a brand); the detector needs
several hits close together AND disagreement with what the stock model wrote there.
"""
from __future__ import annotations

HINDI_WORDS = frozenset("""
hai hain hoon hoga hogi honge hoti hota hote tha thi thay raha rahi rahe rahega rahenge
kya kyun kyon kyonki kyunki kaise kaisa kaisi kahan kab kaun kitna kitne kitni koi kuch kuchh
nahi nahin nhi mat aur ya lekin magar toh bhi sirf sirph bas abhi jab jo jis jise jaise waise vaise
yeh ye woh wo vah yah isko usko isliye isse usse unko inko unhen unhein inhen
mujhe mujhko mera meri mere tera teri tere tumhara tumhari tumhare tumhen tumhein tum tumko aap aapka aapki aapke aapko
hum hamara hamari hamare humein hamen apna apni apne ko ke ki ka mein saath sath liye wala wali wale
karna karne karo kare karta karti karte karenge karoge karunga kiya kiye kijiye
jaana jana jaata jaate jaati jao chahiye chaahie chahta chahte chahti sakte sakta sakti milta milte milti
dena dene lena lene batao bolo dekho suno sunna samajh theek thik accha achha acha
bahut bohot thoda thodi zyada jyada zyaada zaroor zaroori kaafi sabse sab saare sabhi logon aise aisa aisi
yahan wahan matlab yaar bhai chalo chalaana chalana pehle pahle baad phir kabhi kahin hamesha ek teen chaar paanch
""".split())
