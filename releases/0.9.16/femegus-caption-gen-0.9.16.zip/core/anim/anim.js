// Shared animation maths. ES3-compatible: runs unchanged in After Effects (ExtendScript), in Node (tests) and in a browser (preview).
// NO host objects here. Everything is a pure function of numbers.
//
// An "entrance" is described relative to the word's in-point (= its reveal time), so animation can never move a reveal:
//   { duration: s, ease: [x1,y1,x2,y2] (CSS cubic-bezier), slide: [dx,dy] px, scale_from: 1.12, opacity_from: 0, blur_from: 24 }
var FCGAnim = (function () {
    var EPS = 1e-7;

    // CSS-style cubic-bezier easing: returns y(u) for u in [0,1], where x(s)=3(1-s)^2 s x1 + 3(1-s)s^2 x2 + s^3 (x1,x2 in [0,1]).
    function cubicBezier(x1, y1, x2, y2) {
        function bx(s) { var m = 1 - s; return 3 * m * m * s * x1 + 3 * m * s * s * x2 + s * s * s; }
        function by(s) { var m = 1 - s; return 3 * m * m * s * y1 + 3 * m * s * s * y2 + s * s * s; }
        function dbx(s) { var m = 1 - s; return 3 * m * m * x1 + 6 * m * s * (x2 - x1) + 3 * s * s * (1 - x2); }
        return function (u) {
            if (u <= 0) return 0;
            if (u >= 1) return 1;
            var s = u, i, d, lo = 0, hi = 1, x;
            for (i = 0; i < 8; i++) {                  // Newton
                x = bx(s) - u; d = dbx(s);
                if (Math.abs(x) < EPS) return by(s);
                if (Math.abs(d) < 1e-6) break;
                s -= x / d;
            }
            if (s < 0 || s > 1 || isNaN(s)) s = u;
            for (i = 0; i < 60; i++) {                 // bisection fallback (monotonic because x1,x2 in [0,1])
                x = bx(s);
                if (Math.abs(x - u) < EPS) break;
                if (x < u) lo = s; else hi = s;
                s = (lo + hi) / 2;
            }
            return by(s);
        };
    }

    var PRESETS = {
        linear: [0, 0, 1, 1],
        easeOut: [0.16, 1, 0.3, 1],         // fast start, long soft landing (reference-like)
        easeOutSoft: [0.25, 0.8, 0.35, 1],
        easeInOut: [0.65, 0, 0.35, 1],
        easeIn: [0.5, 0, 0.9, 0.5],
        overshoot: [0.2, 1.4, 0.4, 1],      // y2 > 1 is NOT allowed by the AE mapping below only when x stays in [0,1]; y may exceed 1
        // "silk" curves, fitted to two professional reference intros (see docs/STYLE.md "Silk motion"):
        silkFade: [0.45, 0.2, 0.45, 1],     // soft start, quick middle, soft landing (fits a measured fade-in to rms 0.02); use over ~0.2 s
        silkMove: [0.16, 0.8, 0.36, 1]      // exponential-out: 20 % of the travel per time constant, no stop (fits 1 - e^(-5u) to rms 0.0025); use over ~1 s
    };

    function resolveEase(e) {
        if (e instanceof Array && e.length === 4) return e;
        if (typeof e === "string" && PRESETS[e]) return PRESETS[e];
        return PRESETS.easeOut;
    }

    // value of an eased property u in [0,1] -> from + (to-from)*ease(u)
    function lerp(from, to, k) { return from + (to - from) * k; }

    // ---- motion channels ("silk") ----------------------------------------------------------------------------------------------------------------
    // Until now one duration and one curve drove opacity, slide, scale and blur together. Measured on two professional "smooth text" intros the
    // channels are NOT in lock-step: the fade is over in ~0.2 s while the slide keeps decelerating exponentially for ~1 s (never stopping
    // abruptly), and that is what reads as smooth. A spec may therefore carry
    //   channels: { opacity|position|scale|blur: { duration: s, ease: name|[x1,y1,x2,y2], fit: "compress"|"cut" } }
    //   (or recipe: "silk", optionally overridden channel by channel).
    // A channel that is not given uses the spec's own duration/ease, so a spec WITHOUT channels behaves exactly as before.
    //   fit "compress" (default): the channel is shortened so it completes before the caption leaves (opacity and blur must complete).
    //   fit "cut": the channel keeps its real length and the caption's hard cut simply ends it (slide and scale: never rushed).
    // Nothing here can move a reveal: every channel is relative to the in-point and starts there (the fade starts at opacity_from, i.e. hidden).
    var CHANNELS = ["opacity", "position", "scale", "blur"];
    var RECIPES = {
        silk: {
            word: {
                opacity: { duration: 0.2, ease: "silkFade", fit: "compress" },
                blur: { duration: 0.32, ease: "silkFade", fit: "compress" },
                position: { duration: 1.0, ease: "silkMove", fit: "cut" },
                scale: { duration: 0.6, ease: "silkMove", fit: "cut" }
            },
            letters: {
                opacity: { ease: "silkFade" },            // duration = the look's own letter fade (keeps the stagger and the whole-word cap unchanged)
                blur: { duration: 0.3, ease: "silkFade" },
                rise: { duration: 0.5, ease: "silkMove" }
            }
        }
    };
    // NOTE: ExtendScript throws on `for (k in null)` (V8 does not), so both arguments are guarded.
    function mergeChannel(a, b) { var o = {}, k; if (a) for (k in a) o[k] = a[k]; if (b) for (k in b) o[k] = b[k]; return o; }
    // -> { opacity, position, scale, blur: { duration, ease, fit } } or null when the spec has no channels / recipe (legacy lock-step motion)
    function wordChannels(spec) {
        var rc = spec && spec.recipe && RECIPES[spec.recipe] ? RECIPES[spec.recipe].word : null, ch = spec && spec.channels, out = {}, i, n, base;
        if (!rc && !ch) return null;
        for (i = 0; i < CHANNELS.length; i++) {
            n = CHANNELS[i];
            base = mergeChannel({ duration: spec.duration, ease: spec.ease }, mergeChannel(rc && rc[n], ch && ch[n]));
            out[n] = { duration: base.duration > 0 ? base.duration : 0, ease: base.ease, fit: base.fit === "cut" ? "cut" : "compress" };
        }
        return out;
    }
    // Final durations of every channel for one word. available = seconds until the caption leaves, fd = frame duration,
    // snapDur(d) = frame-snapped duration (the caller's own frame snapping, so preview and After Effects agree), may be omitted.
    // Returns { channels: { name: { duration, ease } } (duration 0 = that channel is instant), span, clamped, skipped } -- skipped = nothing animates (all < 2 frames).
    function planEntrance(spec, available, fd, snapDur) {
        var ch = wordChannels(spec) || (function () { var o = {}, i; for (i = 0; i < CHANNELS.length; i++) o[CHANNELS[i]] = { duration: spec.duration > 0 ? spec.duration : 0, ease: spec.ease, fit: "compress" }; return o; })();
        var room = Math.max(available - fd, 0), out = {}, clamped = false, span = 0, i, n, d, alive = false;
        for (i = 0; i < CHANNELS.length; i++) {
            n = CHANNELS[i]; d = ch[n].duration;
            if (ch[n].fit !== "cut" && d > room) { d = room; clamped = true; }
            if (snapDur && d > 0) d = snapDur(d);
            if (d < 2 * fd - 1e-6) d = 0; else alive = true;
            out[n] = { duration: d, ease: ch[n].ease };
            if (d > span) span = d;
        }
        return { channels: out, span: span, clamped: clamped, skipped: !alive };
    }

    // Map a cubic-bezier to After Effects temporal ease for ONE segment (two keyframes) of a property that moves by deltaV in T seconds.
    // AE's temporal interpolation is a cubic bezier through (0,0)..(T,deltaV) whose handles are described by (influence, speed):
    //   out handle at key A:  (influence_out*T,  speed_out*influence_out*T)      with influence_out = x1,      speed_out = (y1/x1) * deltaV/T
    //   in  handle at key B:  (T - influence_in*T, deltaV - speed_in*influence_in*T), influence_in = 1 - x2,  speed_in  = ((1-y2)/(1-x2)) * deltaV/T
    // Influences are returned in percent (0.1..100) as AE expects.
    function easeToKeyframe(bez, deltaV, T) {
        var x1 = Math.max(bez[0], 0.001), x2 = Math.min(bez[2], 0.999), avg = deltaV / T;
        return {
            out: { influence: x1 * 100, speed: (bez[1] / x1) * avg },
            inn: { influence: (1 - x2) * 100, speed: ((1 - bez[3]) / (1 - x2)) * avg }
        };
    }

    // Inverse of the above (used by tests): reconstruct the bezier from AE's influence/speed.
    function keyframeToEase(k, deltaV, T) {
        var avg = deltaV / T, x1 = k.out.influence / 100, x2 = 1 - k.inn.influence / 100;
        return [x1, avg === 0 ? 0 : (k.out.speed / avg) * x1, x2, avg === 0 ? 1 : 1 - (k.inn.speed / avg) * (1 - x2)];
    }

    // Clamp an entrance to the time available (until the group exits). Returns {duration, clamped}.
    function clampDuration(duration, available, frameDuration) {
        var maxD = Math.max(available - frameDuration, 0);
        if (duration <= maxD) return { duration: duration, clamped: false };
        return { duration: Math.max(maxD, 0), clamped: true };
    }

    // Value of every animated property of an entrance at time tRel (seconds after the in-point).
    // base = { x, y, scale (percent, final) }. Returns { opacity, x, y, scale, blur }.
    // Mirrors what After Effects really does (verified against AE 25.2 keyframes, see docs/AE_ADAPTER.md):
    //  * opacity is clamped to [0,100] and blur to >= 0 even when the curve overshoots
    //  * scale follows the curve unclamped (overshoot works, exact match with AE)
    //  * POSITION runs along a spatial path: AE does not reproduce an overshooting curve there (measured up to 14 % deviation),
    //    so position always uses the same curve with its y-handles limited to [0,1] (positionEase) -- in the evaluator AND in the keyframes.
    function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
    function positionEase(bez) { return [bez[0], clamp(bez[1], 0, 1), bez[2], clamp(bez[3], 0, 1)]; }
    // spec.channels (or a recipe) gives every property its own duration and curve (see "motion channels" above); without them all four share
    // spec.duration / spec.ease exactly as before. For channels the durations must already be final (planEntrance), like spec.duration.
    function entranceAt(spec, base, tRel) {
        var ch = wordChannels(spec), prog = {}, i, n, D, u, bz;
        for (i = 0; i < CHANNELS.length; i++) {
            n = CHANNELS[i];
            D = ch ? ch[n].duration : spec.duration;
            bz = resolveEase(ch ? ch[n].ease : spec.ease);
            u = D <= 0 ? 1 : Math.max(0, Math.min(1, tRel / D));
            prog[n] = cubicBezier.apply(null, n === "position" ? positionEase(bz) : bz)(u);
        }
        var slide = spec.slide || [0, 0], sf = spec.scale_from === undefined ? 1 : spec.scale_from;
        var of = spec.opacity_from === undefined ? 0 : spec.opacity_from, bf = spec.blur_from || 0;
        return {
            opacity: clamp(lerp(of * 100, 100, prog.opacity), 0, 100),
            x: lerp(base.x + slide[0], base.x, prog.position), y: lerp(base.y + slide[1], base.y, prog.position),
            scale: lerp(base.scale * sf, base.scale, prog.scale),
            blur: Math.max(0, lerp(bf, 0, prog.blur))
        };
    }

    // ---- per-letter reveal ("letters" entrance, reference look 2) ----------------------------------------------------------------------------
    // Letter i (0-based) of a word starts i*stagger seconds after the word's in-point, so the first letter starts exactly at the reveal and
    // no letter can ever be visible earlier. Each letter then runs the same eased fade / un-blur / rise over `duration`; its tint colour
    // (the "wet ink" colour newly revealed letters have) fades over `tint_duration`.
    //   L = { stagger, duration, ease, blur_from (px), opacity_from (0..1), rise (px, letters start this far BELOW their place),
    //         tint (hex or ""), tint_duration, max_total (s, cap for the whole reveal of long words) }
    // letterPlan fits the reveal into the time available (until the group exits) and the max_total cap; returns the numbers actually used.
    // Letters may carry channels too (L.channels or L.recipe): { opacity, blur, rise: { duration, ease } } -- the fade, the un-blur and the rise
    // each get their own curve (a letter's rise keeps decelerating long after it has faded in). The opacity channel's duration defaults to
    // L.duration, so the stagger and the "whole word at most" cap behave exactly as without channels; the blur and rise durations are scaled by the same
    // fitting factor as everything else. null = legacy: one curve and one duration for all three.
    function letterChannels(L) {
        var rc = L && L.recipe && RECIPES[L.recipe] ? RECIPES[L.recipe].letters : null, ch = L && L.channels, out = {}, names = ["opacity", "blur", "rise"], i, n, b;
        if (!rc && !ch) return null;
        for (i = 0; i < names.length; i++) {
            n = names[i];
            b = mergeChannel({ duration: L.duration === undefined ? 0.16 : L.duration, ease: L.ease }, mergeChannel(rc && rc[n], ch && ch[n]));
            out[n] = { duration: b.duration > 0 ? b.duration : 0, ease: b.ease };
        }
        return out;
    }
    function letterPlan(L, n, available, frameDuration) {
        var stagger = L.stagger === undefined ? 0.033 : L.stagger, lc = letterChannels(L), dur = lc ? lc.opacity.duration : (L.duration === undefined ? 0.16 : L.duration);
        var tdur = L.tint ? (L.tint_duration === undefined ? 0.3 : L.tint_duration) : 0;
        var cap = L.max_total > 0 ? L.max_total : 1e9, room = Math.max(available - frameDuration, 0);
        var total = Math.max(0, n - 1) * stagger + Math.max(dur, 0), lim = Math.min(cap, room), s = 1;
        if (total > lim) s = total > 0 ? lim / total : 1;
        return { stagger: stagger * s, duration: dur * s, tint_duration: tdur * s, clamped: s < 1,
                 blur_duration: (lc ? lc.blur.duration : dur) * s, rise_duration: (lc ? lc.rise.duration : dur) * s, channels: !!lc };
    }
    // State of letter i of n at tRel seconds after the in-point. plan = letterPlan(...), L = the spec.
    // Returns { opacity 0..100, blur px, dy px (positive = below the final place), tint 0..1 (1 = fully tinted) }
    function letterAt(L, plan, tRel, i) {
        var lc = plan.channels ? letterChannels(L) : null, f = cubicBezier.apply(null, resolveEase(lc ? lc.opacity.ease : L.ease)), t0 = i * plan.stagger, t = tRel - t0;
        var of = L.opacity_from === undefined ? 0 : L.opacity_from, bf = L.blur_from || 0, rise = L.rise || 0;
        var u = plan.duration <= 0 ? 1 : clamp(t / plan.duration, 0, 1), k = f(u), kb = k, kr = k;
        if (lc) {
            kb = plan.blur_duration <= 0 ? 1 : cubicBezier.apply(null, resolveEase(lc.blur.ease))(clamp(t / plan.blur_duration, 0, 1));
            kr = plan.rise_duration <= 0 ? 1 : cubicBezier.apply(null, resolveEase(lc.rise.ease))(clamp(t / plan.rise_duration, 0, 1));
        }
        var tu = plan.tint_duration <= 0 ? 1 : clamp(t / plan.tint_duration, 0, 1);
        return { opacity: clamp(lerp(of * 100, 100, k), 0, 100), blur: Math.max(0, lerp(bf, 0, kb)), dy: lerp(rise, 0, kr), tint: L.tint ? 1 - cubicBezier.apply(null, resolveEase(lc ? lc.opacity.ease : L.ease))(tu) : 0 };
    }
    // Time (relative to the in-point) when the last letter has finished fading in.
    function letterEnd(plan, n) { return Math.max(0, n - 1) * plan.stagger + plan.duration; }

    // Source of an After Effects EXPRESSION SELECTOR "Amount" (0..100 = how much of the animator's "hidden" values letter textIndex still has).
    // kind "reveal": 100*(1 - ease(progress)) -> drives Opacity (opacity_from), Blur (blur_from) and Position (0, rise) of one animator.
    // kind "tint":   100*(1 - ease(tintProgress)) -> drives Fill Colour (tint) of a second animator.
    // It evaluates exactly letterAt() (tested in Node by running this text), with the numbers of `plan` baked in, so a letter can never start
    // before layer.inPoint + index*stagger.
    function letterExpression(L, plan, kind) {
        // kinds: "reveal" (legacy: one animator drives opacity, blur and rise), "tint", and with channels "fade" | "blur" | "rise" (one animator each)
        var lc = plan.channels ? letterChannels(L) : null, b, dur;
        if (kind === "tint") { b = resolveEase(lc ? lc.opacity.ease : L.ease); dur = plan.tint_duration; }
        else if (kind === "blur") { b = resolveEase(lc ? lc.blur.ease : L.ease); dur = plan.blur_duration; }
        else if (kind === "rise") { b = resolveEase(lc ? lc.rise.ease : L.ease); dur = plan.rise_duration; }
        else { b = resolveEase(lc ? lc.opacity.ease : L.ease); dur = plan.duration; }           // "reveal" / "fade"
        function num(x) { return String(Math.round(x * 1e9) / 1e9); }
        return "var t = time - thisLayer.inPoint - (textIndex - 1) * " + num(plan.stagger) + ";\n" +
            "function ez(u) { if (u <= 0) return 0; if (u >= 1) return 1; var lo = 0, hi = 1, s = u, x, m, i;\n" +
            "  for (i = 0; i < 60; i++) { m = 1 - s; x = 3 * m * m * s * " + num(b[0]) + " + 3 * m * s * s * " + num(b[2]) + " + s * s * s; if (Math.abs(x - u) < 1e-9) break; if (x < u) lo = s; else hi = s; s = (lo + hi) / 2; }\n" +
            "  m = 1 - s; return 3 * m * m * s * " + num(b[1]) + " + 3 * m * s * s * " + num(b[3]) + " + s * s * s; }\n" +
            "var u = " + (dur <= 0 ? "1" : "Math.max(0, Math.min(1, t / " + num(dur) + "))") + ";\n" +
            "100 * (1 - ez(u))";
    }

    return { cubicBezier: cubicBezier, PRESETS: PRESETS, RECIPES: RECIPES, resolveEase: resolveEase, positionEase: positionEase, lerp: lerp, easeToKeyframe: easeToKeyframe,
             keyframeToEase: keyframeToEase, clampDuration: clampDuration, entranceAt: entranceAt, wordChannels: wordChannels, planEntrance: planEntrance,
             letterChannels: letterChannels, letterPlan: letterPlan, letterAt: letterAt, letterEnd: letterEnd, letterExpression: letterExpression };
})();

if (typeof module !== "undefined" && module.exports) module.exports = FCGAnim;
