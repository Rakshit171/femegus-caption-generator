# Reference Video Analysis

Source: `reference/Video-44837.mp4` — 720×1280 (9:16), 23.976 fps, 23.1 s.
Only the **opening ~6 s** was inspected (as instructed). Frames were extracted with OpenCV
(already installed on this machine): every 0.25 s for 0–6 s, plus frame-by-frame (≈42 ms) sequences around
three moments (entrance of "You're edits", entrance of "Quality", exit of the first group at ≈1.8–2.1 s).
Images are in `reference/analysis/`. Everything below is **observed**, except items marked *(guess)*.

Non-caption editing in the clip (blur-zoom transitions at 0.0 and 4.0 s, light leak at 3.75 s) is video
editing, not captions, and is out of scope.

## 1. Structure: "groups" of words, shown cumulatively

| Group | Time (approx.) | Words (as shown) | Layout variant |
|---|---|---|---|
| 1 | 0.25 → 1.8 s | The reason / You're edits / Don't feel pro | **A** – mixed case, 3 tiers |
| 2 | 2.0 → ~2.9 s | Isn't the camera / Quality | **A** (2 tiers) |
| 3 | 3.0 → 3.9 s | ITS / YOU'RE / TEXT | **B** – italic caps stack |
| 4 | 4.0 → 4.9 s | That's / Exactly / How I | **A′** – all white, bold, stacked |
| 5 | 5.0 → 5.6 s | CAUGHT / YOU'R(E) / ATTENTION | **B** |

* Words appear **one at a time**, in speech order, and **stay visible** while later words of the same group
  appear (cumulative build-up). A group is therefore 2–7 words, driven by phrase, not a fixed count.
* At the end of a group everything **disappears at once** (hard cut: present at 1.800 s, gone at 1.842 s —
  at most ~1 frame, no visible fade-out). The next group starts a few frames later.
* The reference's own text has errors ("You're edits" for "Your edits", "ITS", "Was…"). The tool must therefore
  not copy the text — and this confirms the editable-transcript requirement.

## 2. Typography

* Typeface family: a **neo-grotesque sans** (Helvetica Neue / Neue Haas / Arial-like proportions) *(guess —
  not identified with certainty; to be matched against fonts installed on the user's PC in Stage 5)*.
* **Support words**: white, regular→medium/bold weight, small. Soft dark drop shadow for legibility.
* **Accent words**: ≈ **2×** the size of support words, **bold**, filled with a **vertical orange gradient**
  (lighter orange top → deeper red-orange bottom), with a soft **orange outer glow** and a subtle drop shadow.
  Variant B accent also reaches a yellow-orange.
* Variant B: **bold italic ALL-CAPS**, very tight leading (≈0.8–0.9, lines nearly touching), stacked
  3 words; one word orange, the others white (the white one can sit slightly right-shifted).
* Variant A′ (group 4): white bold mixed-case words stacked at different sizes, slight overlap.
* Tracking: slightly tight on accent words.
* Small **4-point sparkle glints** (✦) appear briefly beside emphasised words (≈0.75–1.25 s) — decorative, optional.

## 3. Layout

* Block is **horizontally centred**, vertically around **mid-frame (≈ 40–55 % of height)** — over the chest,
  not the usual bottom-third.
* Variant A is deliberately **scattered**: small white words top-left → giant orange in the middle →
  small white words lower-right, with slightly different baselines ("Don't" vs "feel" vs "pro" step downward).
  Placement is *consistent per template*, not random: the same slots recur from group to group.
* Everything stays inside the safe area; no clipping.

## 4. Animation (frame-level observations)

* **Support words** (e.g. "The reason", "Isn't the camera"): fade in **from heavy blur to sharp** over ≈ 3–5 frames
  (~0.12–0.2 s) with slight upward/lateral drift.
* **Accent words** (e.g. "You're", "edits", "Quality"): reveal over ≈ 5 frames (~0.2 s) with
  **ease-out slide from the left (≈ one word-width at the start) + opacity ramp + scale settle (starts larger/softer)**;
  the first visible frames are tinted more red and semi-transparent, then settle to full orange.
  During the move the next word briefly overlaps the previous one ("You'reedits" at 0.50–0.54 s) and then
  slides apart to its final position — i.e. **overlap during the move is acceptable; final layout is clean**.
* No overshoot/bounce was visible (restrained ease-out); *(guess)* a very small overshoot may exist but is not discernible at 24 fps.
* Between words of one group nothing else moves — the layout is **stable**; only the new word animates.
* Each word's reveal appears **locked to its onset** (e.g. "Quality" first visible at ≈ 2.33 s while the mouth is
  forming the word). Caveat: only video frames were inspected, not the audio, so exact sync is judged from the
  speaker's mouth and is unverified. Stage 2 will transcribe this clip and compare onsets numerically.
* Exit: hard cut (see §1).

## 5. Emphasis logic

* Accent words are content words (the *what*): "You're edits", "Quality", "You're" (B), "ATTENTION" is white while "YOU'RE" is orange —
  so emphasis is **not strictly a fixed position in the stack**; it is chosen per word *(editor judgement)*.
* Therefore: emphasis = suggested automatically (content word + duration + loudness), **overridable per word**.

## 6. What this means for the tool

1. Layout is **template-driven slots** (tier/offset/size/colour per *role*), with roles `support` / `accent`.
2. A word's visible time = its spoken onset; the group's exit = last word end + hold (configurable), hard cut by default.
3. Animation parameters per role: duration, easing, blur-in amount, slide offset, scale-from, opacity ramp, optional glow & sparkle.
4. All of the above must be **data**, not code, so the user can edit them.

---

# Reference 2 — `reference/look2/Video-34323.mp4` (look "Soft Editorial")

720×1280, 30 fps, 30.1 s, English, one speaker. Analysed 2026-10-15 from contact sheets every 0.5 s and frame-by-frame strips (30 fps) around ten moments;
the clip was transcribed with the engine (78 words, `work/look2/ref.transcript.json`) to compare caption onsets with speech. Observed unless marked *(guess)*.
Out of scope (not captions): the phone-frame / pixel-block background and "Made by" label, logo pill ("Whisper"), UI cards ("Any Audio file", "Analyzing", price cards),
the tan highlight box behind "parakeet TDT", light-leak/zoom/blur transitions at 0–2 s and 4 s. Text inside such assets was ignored.

## Structure and layout
* Captions are **short phrases (2–6 words) in centred lines**, over the chest (block centre ≈ 60 % of the frame height, the same default as look 1). Lines change with the *treatment* of the words: running text line → key-word line (bigger, other font) → running text line, e.g. `that transcribes` / `AN HOUR` / `of audio`; or one line with an inline bold word (`save **money**?`, `the **simple** setup guide.`).
* Line pitch is tight: ink boxes of neighbouring lines are ~0.1 × the smaller font size apart.
* **Exit = hard cut** (visible at 12.50 s, gone at 12.53 s). The next phrase starts a few frames later.
* The editor often shows a *whole phrase at once* ("The days of", "Ready to save money?") before the later words are spoken; elsewhere words come one by one with speech ("that" → "that transcribes"). Our tool must never show a word before it is spoken, so it always goes word by word.

## Typography (sizes relative to a 1080-wide comp, measured from widths and cap heights)
| Role | Look | Size | Notes |
|---|---|---|---|
| running text | light/regular grotesque (Google-Sans-like), white, tracking ≈ −2 % | ≈ 58 px | soft shadow; lower-case as spoken |
| key word A | **high-contrast serif, ALL CAPS**, white | ≈ 115 px (cap height ≈ 84 px) | "AN HOUR"; letter-by-letter reveal |
| key word B | serif italic, mixed case | ≈ 110 px | "Nvidia"; letter reveal |
| key word C | bold grotesque, white, soft white glow, tracking ≈ −3 % | ≈ 92 px | "completely free" |
| key word D | bold grotesque, warm tan (≈ #DDB08C) | ≈ 92 px | "paid options" |
| key word E | bold inline, same size as running text | ≈ 58 px | "money", "simple" |
| key word F | medium grotesque, pale yellow (≈ #FFF1B0) with a strong warm-yellow glow (≈ #FFC93C) | ≈ 86 px | `Comment "speech"`; letter reveal |

## Animation (frame-level)
* **Running-text words**: sharpen out of a blur while fading in and **rising ≈ 1 em** (e.g. "that": 64 → 46 px in 8 frames, mostly in the first 4); total ≈ 0.25 s, ease-out.
* **Serif / glow key words**: **letter by letter, ≈ 1 letter per frame (33 ms)**; each letter fades in over ≈ 5 frames (≈ 0.17 s) from blurred and slightly lower, and **newly shown letters are tinted pale pink (≈ #DCBBC2) that settles to the fill colour** over ≈ 0.3 s ("1 second": "second" still pink 4 frames after it appeared).
* **Bold key words**: whole-word fade + un-blur over ≈ 0.3 s (no letter stagger); "completely free" also gains its glow while sharpening.
* No overshoot/bounce seen. Whole captions never scale; the zoom visible in some frames is the video's own camera move.
* Onsets: the reference appears 0–0.25 s after the recognised word start (hand-timed); our reveals follow the same rule as look 1 (at or after the spoken onset).

## How this maps to the tool
New style capabilities (STYLE.md "Look 2"): `centered` layout, `line` own/inline, accent `variants` (rotation), per-letter `anim.unit = "letter"` with tint, `fit_width`, `font_fallbacks`. Verified in After Effects 25.2 (opacity timing ≤ 0.1 % vs the shared maths).

## Motion study — two "smooth text" intros (2026-11-19)
Owner supplied two clips (`Smooth Text Animation Tutorial (Premiere Pro)`, 1280×720 @ 60 fps, and `Smooth Text Animation in After Effects — Apple Style`, 720×1280 @ 30 fps) and asked to study **only the entrance of the text at the start of each**, not the tutorials, and make our animations equally smooth without changing any look or timing. Used: first 7 s decoded frame by frame (PyAV), contact sheets, then a per-frame fit of a word's crop as `alpha · shift_dy(gaussian_blur_σ(settled word))` (least squares) — measurements in `tests/fixtures/silk_reference_measurements.json`, re-fit with `scripts/fit_silk_curves.py`.

| | Premiere clip (60 fps) | After Effects clip (30 fps; every frame repeats once) |
|---|---|---|
| What enters | word by word, left to right, one centred line (layout fixed from the start); whole line fades and drifts up to leave | word by word ("Smooth", "Text", "Animation"), later per letter with a colour sweep (an Apple-style preset: not copied) |
| Fade | 0 → 100 % in ≈ 0.19 s with a soft start (7, 11, 21, 31, 49, 67, 78, 89, 95, 96 % on consecutive frames); 50 % after ≈ 0.08 s | ≈ 0.4 s, concave (11, 29, 43, 58, 68, 77, 83, 90, 97 %) |
| Slide | rises ≈ 22 px (≈ 0.8 em) **exponentially**: 62 % left after 0.1 s, 42 % after 0.2 s, 27 % after 0.3 s, 18 % after 0.4 s → τ = 0.233 s; < 1 px after ≈ 0.8 s | rises ≈ 22 px (≈ 0.37 em), τ = 0.112 s |
| Blur | σ ≤ 0.5–1 px (none) | σ ≈ 2.5 px for the first frame only |
| Scale | none | none |
| Overlap | a word starts ≈ 0.3 s after the previous; its slide is still running when the next one enters | the same |
| Exit | line fades over ≈ 0.45 s while drifting up another ≈ 25 px (ease-out) | cut to the next scene |
**What makes it read as smooth, in one sentence:** the fade is quick and has a soft start, while the slide is one exponential decay that lasts ≈ 1 s — the properties are *decoupled*, nothing pops, and the motion never ends with a stop. Our old model used one 0.26 s curve for everything. Implemented as "Silk motion" (STYLE.md); applied to Look 2 only, available to every future look.
**Not copied:** the colour-sweep gradient and per-letter wipe of the Apple-style preset (a different look), the exit fade/drift of the Premiere clip (exits stay a hard cut so out-points never change), the fonts. **Limits of the study:** one word each (two for the 60 fps clip) in two clips; the 30 fps clip's duplicated frames make its curves coarser; text size differs between clips so the slide is expressed in em (0.4–0.8 em) — Look 2's 46 px slide on a 58 px font = 0.79 em, i.e. the 60 fps clip's travel.
