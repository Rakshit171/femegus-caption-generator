# Stage 7 — test matrix and results (2026-10-14)

All results are from real runs on this machine (RTX 3060 6 GB, After Effects 25.2x131). "Reference clip" = the owner's Hinglish video with a provisional
word-level reference (353 words). Nothing here is claimed beyond what is listed; open items are at the end.

## Automated suite
`.\.venv\Scripts\python.exe -m pytest tests -q` — **113 tests, ≈18 minutes** (it really transcribes several clips). Last full run: 113 passed (2026-10-14).
Fast subset (≈10 s, no models): `.\.venv\Scripts\python.exe -m pytest tests/core tests/anim tests/ae tests/engine/test_coverage.py tests/engine/test_hybrid.py tests/engine/test_quality_and_sanitize.py -q`
(PowerShell, in `C:\Claude\AE caption Gen`). Layers: engine (flags, hybrid, coverage, bad input, real-clip regressions),
core (segmenter / timing / edits / emphasis, property tests on 360 random streams), animation + layout maths (Node), After Effects fixtures (real dumps), app API.
Clip-dependent tests skip themselves when the owner's files are absent.

## Real-speech robustness (reference clip, full pipeline: transcribe → group → invariants)
The reference clip was time-stretched / edited with ffmpeg to create the conditions on your QA list. WER is against the provisional reference.

| Condition | Words | WER | Captions | Timing violations | Notes |
|---|---|---|---|---|---|
| Normal speech (control) | 351 | **3.4 %** | 91 | 0 | |
| **Fast** speech (1.4×, 4.2 words/s) | 334 | 14.4 % | 86 | 0 | 17 captions end on a very short last word (reported as warnings; fast speech leaves no room without overlapping the next caption) |
| **Slow** speech (0.75×) | 353 | 7.4 % | 92 | 0 | |
| **Long pause** (2.5 s silence inserted mid-speech) | 351 | 4.5 % | 89 | 0 | the pause became a caption boundary |
| **Speed change** (0.8× then 1.35×) | 344 | 16.4 % | 88 | 0 | |
Honest reading: accuracy falls with speech rate (a 1.4× rate is unusually fast), but **timing guarantees never broke** and no speech went missing.

## Second and third clips (owner's files, Stage 7) — and the failures they exposed
| Clip | Result |
|---|---|
| `Cutted version if you selling.mp4` (41 s, Hinglish: Hindi sentences around English business terms) | **first run silently lost ~70 % of the speech** (36 words; "market market market…" loops from the Hinglish model; forced-English route produced a fluent *translation* instead of what was said). Now 166 words, no uncovered speech |
| `60 seconds audio.mp3` (actually 85 s, nearly pure Hindi, audio only) | first run lost the **last ~11 s** (233 words). Now 276–284 words, complete |
| American-accent English reference (23 s) | unchanged, 97 words |
No reference transcripts exist for the two new clips, so **their accuracy is not measured** — only completeness (no loud audio without words) and sanity of the text. Please correct them
if you want them added as numeric regression fixtures.

### What was wrong and how it is handled now
1. **Long-form decoding can drop whole stretches or loop** — measured on two clips. Batched decoding (independent VAD chunks) is robust but **less accurate on digits** (reference clip 10.5 % WER vs 3.4 %).
2. Therefore the engine is *sequential-first* and **verifies its own coverage**: it compares the words against the loudness of the audio, finds loud stretches with no usable words (looping or junk words do not count),
   and only then runs the batched decoder and fills the holes from whichever pass has the words (`engine/fcg_engine/coverage.py`). Remaining holes are shown in the UI (red on the timeline, a card in section 1) and warned about.
3. The same check fills holes inside the Hinglish hybrid from the Hinglish model's own words.
4. Forced **English mode translates Hindi** (shown again here). Use Auto or Hinglish for mixed speech.

## QA checklist from the master prompt
| Item | Evidence | Status |
|---|---|---|
| Slow / fast speech, pauses, speed changes | table above (real audio) | ✅ |
| Sentence boundaries, long sentences, very short phrases | `tests/core` + real clips; 7 unpunctuated sentence starts recovered on the reference clip | ✅ |
| Incorrect transcription corrected manually | API + UI (edited "CRR"→"crore": reveal unchanged, 0 violations) | ✅ |
| Words that overflow the layout | After Effects run with 45- and 34-letter words: all 15 words inside the safe area, long ones shrunk to 25 % / 36 % (reported) | ✅ (a 25 % word is small but readable; it is never clipped) |
| Font and colour changes, preset changes | two real presets built in After Effects: all in/out points identical, style verified on every layer | ✅ |
| Different caption durations | 360 random streams (slow/fast/mixed) property-tested; invariants never broken | ✅ |
| Preview ≡ final output | position error 0.56 / 0.33 px mean, identical fit factors; animation ≤ 0.014 px | ✅ |
| Missing fonts | After Effects substitutes Arial and warns | ✅ |
| Missing model files | Hinglish model missing → stock fallback + warning; any model missing → plain-language message (internet needed once) | ✅ |
| Bad input | non-media file refused (HTTP 415, no project created); silent audio → "no speech", no false alarm | ✅ |
| Installation and launch in After Effects | connect script via File ▸ Script ▸ Run Script File; no installer, nothing in the After Effects folder; works on **25.2 only** | ✅ for 25.2 |
| Audio-only input | mp3 → preview on a black 9:16 stage; 283 layers built in After Effects with the sound as a layer; verified | ✅ |
| Long project | **1,520 layers** (9 min comp, all effects + keyframes) built in 226 s; After Effects stayed responsive (4 GB); timing/text/style/7,600 animation samples verified | ✅ build; playback speed with 1,520 glow layers **not measured** |

## Bugs found by Stage 7 and fixed
1. Sequential decoding drops/loops (see above) → coverage check + fusion.
2. Auto routed the new mp4 to Hinglish (correct), but its first-pass Hindi-mode skeleton was Devanagari *garbage* for much of the clip — the decode failure above, not the routing, was the fault. It does show the routing rule is only a heuristic (see limitations).
3. False "missing speech" alarm on silent audio → needs dynamic range + a minimum loudness before anything counts as speech.
4. Raw library errors for missing models / unreadable files → plain-language messages (`engine/fcg_engine/errors.py`).
5. Audio-only files broke the After Effects builder (footage without a picture has no size) and the preview.
6. Emphasis picked Hindi grammar words ("karo", "rahe", "agar") as accents → Hindi stop-word list + a per-project `accent_stop_words` setting.
7. A loop-filter flaw found by its own test: the first 3 copies of a repeated word leaked through → whole loops are now dropped.
8. Test-harness mistakes of mine (ffmpeg `-t` placement made a bad "mixed speed" clip) — the pipeline was right; corrected and re-run.

## Known limitations / open items
* **Auto language routing is a heuristic** (share of Devanagari in a Hindi-mode first pass) and is validated on three clips only. A *pure-English clip with a strong Indian accent* has not been tested and could be misrouted; if captions look like Roman Hindi for English speech, choose English.
* Accuracy numbers exist for **one speaker** (reference clip). Fast speech (1.4×) degrades to 14 % WER.
* Digits and numerals are less reliable in the batched rescue pass.
* Playback performance in After Effects of a 1,500-word glow-heavy composition is untested.
* The browser UI has no automated browser test; it was driven by hand.
* After Effects 2024 / 2026 are untested.

## v0.8.1 / v0.9.0 additions (2026-10-15)
| What | How | Result |
|---|---|---|
| Per-word colour/gradient rule (a solid word fill switches the gradient off) in Python, preview and the AE adapter | `tests/core/test_word_style.py` (Node runs the real ES3 file and compares with Python) | ✅ |
| Letter-reveal maths (never visible before its start, left-to-right, clamping to the time available, max total) | `tests/anim/test_look2.js` (2,300+ checks) | ✅ |
| AE expression text == preview evaluator | same file, runs the generated expression for 3 specs × 8 letters × 25 times | ✅ ≤ 1e-4 |
| Centred layout, accent-variant assignment (rotation, fixed, pool, override, determinism), width cap | same file + random groups inside the safe area | ✅ |
| Look metadata API, `template_styles` replacement, defaults unchanged | `tests/app/test_server.py::test_looks_gallery_metadata_and_look2_replaces_layout_overrides` | ✅ |
| Read-back check with variants, font fallbacks and letter animators (and catching a missing animator / wrong treatment) | `tests/core/test_look2.py` | ✅ |
| **Real After Effects 25.2**: Soft Editorial on the reference clip (78 layers), on the Hinglish clip (345 layers, 25 s), reference look rebuilt; all verified by read-back; frames rendered with aerender and compared with the shared maths | manual run, see COMPATIBILITY.md | ✅ |
| Browser UI (looks gallery, treatment editing, per-word panel, thumbnails) | exercised by hand in the built-in browser; **no automated browser tests** | ⚠️ manual only |

## v0.9.1 — look 3 "Clean 4-Word" (2026-10-17)
| What | How | Result |
|---|---|---|
| Plain by default, switch patches only touch `anim`, on→off→on lossless, grouping valid, one-line layout | `tests/core/test_look2.py` | ✅ |
| Slide-up quality: vertical only, no overshoot/blur/scale, monotone, ends exactly in place, per-frame step bound at 30 fps | `tests/anim/test_look2.js` | ✅ |
| `wrap:false` keeps one line (shrinks) | same file | ✅ |
| The look's grouping re-cuts captions to ≤ 4 words (same words, same order, never before spoken, reveal times unchanged), animation-only edits do NOT re-cut, another look releases the rule | `tests/app/test_server.py::test_look3_…` (real server + frozen English transcript) | ✅ |
| Preview in the built-in browser: look applied, switch OFF→ON, grouping re-cut, slide-up frames at 0/33/100/133/200 ms | manual | ✅ |
| **After Effects 25.2 build, animation ON** (English clip, 78 layers; run on 2026-10-17 in a fresh empty project after the owner closed theirs) | through the app (Generate, read-back verification) + `tests/ae/verify_anim.js` on the dump | ✅ verified; 78 animated; keyframes vs shared maths over 390 samples: opacity ≤ 7e-8, y ≤ 0.0033 px, x ≤ 3e-5 px; 0 timing/text/style problems; 0 lines scaled down at size 60 |
| **After Effects build, animation OFF** | same | ✅ verified; 0 words animated (no keyframes), no warnings |
| **After Effects build, Hinglish clip** (345 layers, 4-word captions, animation ON, 47 s) | same | ✅ verified; 107 slides shortened (fast speech: the caption changes < 0.48 s after the word), 3 skipped (< 2 frames); one real edge case found and fixed in the checker (below) |
| **Rendered frames (aerender)** of the slide: first frame at the reveal is invisible, then per-frame steps 9.9 → 7.1 → 4.7 → 3.0 → 1.9 → 1.2 → 0.7 → 0.4 → 0.25 px, never moves backwards, settled (≤ 0.5 px) 9 frames (0.3 s) after the reveal, opacity 0.30 → 1.00 | measured from the TIFF frames | ✅ smooth ease-out exactly as designed |
| Regression: last caption whose last word is revealed < 1 frame before the exit keeps its one-frame minimum (out-point = last in-point + 1 frame) — the read-back check used to call that a fault | `tests/ae/test_verify_dump.py` | ✅ |

## v0.9.1 — release builder, installer, updater (2026-10-20)
| What | How | Result |
|---|---|---|
| Release zip contains only allowed files (no tests, .venv, work, projects, reference, user presets, CLAUDE.md, machine-specific files); every member passes the updater's path rules; version inside matches; checksums; every look pack validates; deterministic; private details block a build | `tests/app/test_updater.py` | ✅ |
| Check: new version / new / updated / current looks, "needs setup" when requirements changed, friendly errors (unreachable, nothing published), https-only + update-site-only URLs | same | ✅ |
| Look packs: validation rejects code/unknown keys/bad names/oversize, checksum mismatch refused, only `presets/downloaded/` is written | same | ✅ |
| App update: replaces program files, keeps projects/models/.venv/own+downloaded looks/machine file untouched, backup, rollback; failure halfway restores byte-for-byte; tampered zip refused before anything changes; 16 forms of forbidden zip members (`..`, absolute, drive, backslash, protected folders, `tests/`…) abort the whole update; incomplete/mislabelled zip refused | same | ✅ (found and fixed 2 real bugs: leftover `.fcgnew` file after a failed write; "needs setup" computed after the requirements file was already replaced) |
| Opt-in: automatic check off by default (no network), at most once a day, a manual check always asks, failure of a silent check shows nothing | same, through the real HTTP server | ✅ |
| Release extracted into an empty folder: `install.ps1 -Preflight` passes; the app starts from it, serves the UI and API, lists the 4 looks, system check runs; Hinglish correctly reports "not set up" (machine file is not shipped) | manual, 2026-10-20 | ✅ |
| Full update in the real UI (sandbox copy + local update site): badge, check, install a look, update to a newer version, rollback; VERSION and files verified on disk | manual in the built-in browser | ✅ |
| **NOT tested:** the full download path of `install.ps1`/`setup.ps1` on a computer without this project's `.venv`/models (several GB); winget Python install; the real GitHub update site (nothing published yet); Windows SmartScreen behaviour on a downloaded zip | needs a second computer / a first publish | ⚠️ open |

## Hinglish accuracy work (2026-10-24, not released yet)
Full write-up, root causes and measurements: [HINGLISH_STYLE.md](HINGLISH_STYLE.md). Evidence is in `tests/fixtures/hinglish/cases.json` (17 real-clip cases),
`tests/core/test_hinglish_polish.py` (33 rule tests), `tests/core/test_hinglish_regression.py` (cases + measured quality), `tests/engine/test_hinglish_pipeline.py` (merge, audit, window re-decode, no models).

## v0.9.6 — start of the clip + .srt export (2026-10-24)
Field report: with Hinglish, no captions for the first few seconds although the speaker is talking. Reproduced on the owner's four real cut clips (kept outside the project; cut mid-sentence, so no lead-in) through the real engine (`Engine.transcribe`, GPU, turbo + Hinglish model):

| Clip | Speech starts | First caption BEFORE | AFTER (what was recovered) |
|---|---|---|---|
| PC 3 Storytelling Sales call | 0.10 s | 1.34 s (and the first words were a garbled guess) | 0.00 s — "Stories batao. presentation" (second decoding pass) |
| PC 4 3 gate method | 0.00 s | 1.00 s | 0.00 s — "set the frame," |
| PC 5 Sales call fear | 0.05 s | 1.12 s | 0.00 s — "sales calls" (start-of-clip rescue, 3 windows tried) |
| Podcast clip 1 | 0.05 s | 1.00 s | 0.00 s — "Ek mistake" |
| Who am I (reference, WER clip) | 0.00 s | 0.00 s | unchanged: no second pass needed, WER 5.1 % strict (5.1–5.7 % between runs: the GPU decoder is not bit-reproducible) |
| English reference clips (2) | 0.00–0.15 s | 0.00 s | unchanged, no second pass |

**Cause:** the sequential (most accurate) decoder skips the first second or two of a clip that starts mid-speech. The coverage safety net only looked for holes of 1.5 s or more, so a 0.6–1.3 s start hole was invisible. **Fix:** uncovered speech of 0.6 s or more is now filled from the batched pass (which becomes the main pass only if the sequential one lost 2 s or more more than it); if the very start is still empty, the first seconds are decoded again on their own behind 1–2 s of silence (up to three windows, same language route, words must be ≥ 0.20 certain, moved back onto the real timeline) and used only to fill that hole; a start hole that nothing could fill is reported (red on the timeline) from 0.6 s on. Applies to English and Hinglish alike (same code path); the English clips needed no rescue, the logic is covered by unit tests with both routes.
Findings worth knowing: padding the start with silence for the MAIN decode is NOT a fix (it made another clip lose its first word "The"); the sequential decoder differs from run to run on the same file (one run lost 9 s of PC 4, another nothing) — that is exactly what the coverage net is for; "tum jaa" (≈ 0.7 s) at the start of PC 5 is still not recovered.

| What | How | Result |
|---|---|---|
| Hole detection at 0.6 s, fill from the other pass, head-hole rescue (route, attempts, confidence filter, silence-zone words dropped, failures never break a transcription, switch-off), switch-to-batched margin, unfillable short start hole reported, short middle hole not | `tests/engine/test_coverage.py` (22 tests, no models needed) | ✅ |
| All engine tests incl. the real-model integration tests | `pytest tests/engine` | ✅ 54 passed, 3 skipped (clips not present) |
| .srt: valid SubRip syntax, CRLF, UTF-8, no overlaps, positive lengths, long cue split in two lines, word-by-word mode never shows a word before its reveal time, same-instant words/captions, empty/odd input, Devanagari text, real caption fixture, API (download headers, info, 400/409) | `tests/app/test_srt.py` | ✅ |
| Section 10 in the built-in browser (real project copy in a throw-away folder): card shows cue count/length/first cues for both modes; the button downloads `<project>.srt` (application/x-subrip, CRLF) | manual | ✅ |
| **NOT tested:** import of the .srt into YouTube / Premiere / DaVinci / CapCut (standard SubRip, but not tried in them); English clip with a really missing start (none of the English test clips failed) | | |

## Look 3 options (whole line / solid box) and the Hinglish "flashing text" fix — built 2026-11-06, not released
Measured / observed today (PowerShell, project root; results are from this session, nothing here is copied from earlier records).

| What | How | Result |
|---|---|---|
| **Flashing text, cause** | the owner's real Hinglish podcast clip (project transcribed 2026-11-02 with v0.9.8): groups visible 0.22–0.44 s, words 0.02 s long | 3 runs of words squeezed into 0.02 s slots (16 words: "to 1 touch is very important kyonki", "hai, sabki problem alag hai, …"), all from the Hinglish model; the loudness envelope shows silence under them. One of the five test clips (PC 5) has one run ("zyaada hi knowledge usse tumhen, zyaada"); the other 10 transcripts on disk have none. The decoder is not reproducible run to run, so the same clip may or may not show it |
| **Flashing text, fix** (`collapsed` flag, core) | same clip through `fcg_core.build` before/after | before: 7 groups visible < 0.45 s incl. 0.22 s and 0.26 s ones; after: the 16 words are listed under *excluded*, no group below 0.3 s except a genuinely fast spoken "Phir level" (0.26 s of speech); 0 violations; every other word keeps its reveal time (test) |
| New tests | `pytest tests/core/test_collapsed_words.py` (5), property test updated (random fast streams now leave out squeezed runs and say so) | ✅ |
| Option patches, preset data, look packs, options reaching AE, read-back checks (`reveal`/`box`), exception to the no-early rule limited to "line" mode | `pytest tests/core/test_look3_options.py` (9) | ✅ |
| Box geometry + reveal function (shared with the preview and the builder) | `node tests/anim/test_look3_options.js` (39 checks) | ✅ |
| **Real builder code, stand-in host** | `pytest tests/ae/test_builder_mock.py` (9): the real `fcg_build.jsxinc` runs in Node against `tests/ae/mock_ae.js` (345 layers; word mode, line mode, box, both, rebuild replaces instead of duplicating, box off again, all four built-in looks) and the report passes `verify` + `verify_style` | ✅ — shows the code runs and does what it intends; **it is not After Effects** (lenient property tree, no rendering) |
| UI (built-in browser, throw-away `--projects` copy of the podcast project) | apply Look 3 → switch *Whole line at once* ON: at 1.10 s the whole "one to one touch" is on screen (OFF: only "one") → switch *Solid box* ON: black box, colour field changed to #c0392b → box turns red, saved style has `box.color`, `reveal.mode`; both OFF again: style back to `word`/`enabled:false`, badge says "current look" (not "edited") | ✅ |
| **Real After Effects 25.2x131 (2026-11-07, in the owner's open project, builds not saved, test comps removed afterwards)** | 4 builds of Look 3 on the 345-word Hinglish fixture (92 captions): default, whole line, box (#c0392b), both; plus a rebuild of "both" in the same comp name | ✅ all `ok`, 345 text layers each, 0 errors/warnings; 92 box layers in the two box builds (the rebuild did not duplicate); `ae_verify.verify` + `verify_style` report **no problems** for all four; whole-line: every word of a caption has the first word's in-point (2.5, 2.5, 2.5, 2.5 vs reveals 2.5/2.84/3.12/3.42); box colour, opacity 0.85, roundness 16 read back correctly, box sits directly beneath its words' layers in all 92 captions, and all 345 word ink rectangles lie inside their box (smallest vertical margin 14.3 px). Build times 18–50 s. **Not looked at:** a rendered frame (the project was not saved, so no aerender) — box/text alignment was checked from layer geometry only |
| **NOT tested** | box and whole line in AE 2024/2026; "keep in captions" for a squeezed word (it stays 0.02 s long: it would flash again unless its time is edited); `.srt` in whole-line mode is unchanged (one cue per caption anyway) | |

## Hinglish: translated Hindi and decoder loops — field report 2026-11-08 ("after transcribing no Hinglish words are coming"), not released
All measured on this PC (RTX 3060 Laptop, GPU decoding is **not** reproducible run to run, so every claim below was checked more than once or on the saved raw passes).

| What | Evidence | Result |
|---|---|---|
| **Cause 1: the stock model translated Hindi into English** | the owner's project "Learn this one skill" (44 s, 153 words, `no Hindi detected`, 0 Devanagari). Hinglish model alone on the same audio: "…Tumhen koi bhi is kal ko master karna hai, tumhen sirph is cycle ko chalaana hai…"; stock model: "you have to master any of this skill you have to start this cycle" (+ 86 "repaired" squeezed timestamps) | reproduced |
| Fix 1 (`hybrid.translated_spans`, `merge(translated=)`, auto-mode check) | same clip, Hinglish mode and Auto mode (Auto used to say English) | Hindi sentence complete and in place (span 25.9–29.62 s, 16 Hinglish-model words; neighbours stay the stock model's English); Auto → `hinglish-hybrid`, 16 translated words. English reference clips (`Video-44837`, `look2/Video-34323`) stay `english`, 0 translated words |
| Is it really Hindi there? (third opinion) | stock **large-v3** in Hindi mode on 103.5–111 s of the old reference clip | writes "तो आप अगर एक certified coach हो बट आपका business stuck है तो" — the new output ("to aap agar ek coach ho … aapka business stuck hai to") is right and the old English ("so if you are a coach … then", also in the owner's *provisional* reference text) was the translation. Whoami WER 6.2 % (351 words) vs the provisional reference is 5 words worse *because of this*; elsewhere unchanged. The reference file was left as it is |
| **Cause 2: the Hinglish model loops** | `Engine` sequence PC 3 → PC 4 → PC 5 (same sequence, 3 runs, identical numbers): PC 5 `non_roman` 44 words, 9 Hindi runs kept in Devanagari (excluded from captions); raw Apex pass: "ki vah, vah, vah, … " for ~17 s. Same on PODCAST 1 after other clips: `non_roman` 37, caused by ONE word "dekhekhekhekhekhekhe…" (3.8–17.7 s) that swallowed the next sentence. Not reproducible when the clip is transcribed alone or in a different order (state-dependent) — which is why the app, which keeps the models loaded, hit it | reproduced; also with the new translated-Hindi code switched off, so it is not a side effect of it |
| Fix 2 (`quality.is_stutter`, `Engine._repair_hinglish_loops`, `coverage.LOOP_*`) | saved bad passes re-run through the real Hinglish model; then the full engine on 7 real clips in one process (Learn, PC 3, PC 4, PC 5, Podcast clip 1, PODCAST 1, PODCAST 2) | PC 5 pass: 111 words recovered, kept-Devanagari 8 → 0, `non_roman` 48 → 0; PODCAST 1 pass: 73 words, 7 → 0. Whole sequence: **`non_roman` 0 on all 7** (was 44 and 37 on two of them); the repair fired on PC 3 (133 words), PC 4 (118), PC 5 (9). Windows whose first answer stopped after one sentence are rejected (found on PODCAST 1) |
| Tests | `pytest tests/engine/test_translated_hindi.py` (11), `tests/engine/test_hinglish_loops.py` (8) — canned decoders, real texts/times of these stretches, no models | ✅ |
| Side effect checked | `translated_spans` ignores stretches the stock model wrote in Devanagari (PC 3 had a false "translated" stretch before this was added); no false stretch on PC 4, Podcast clip 1, PODCAST 2 | ✅ |
| Whole suite | `python -m pytest tests` (PowerShell, project root; includes the real-model engine tests) after both fixes | ✅ **367 passed, 3 skipped** (clips not present), 182 s |
| **NOT verified** | the cause of the state dependence (the same clip decodes fine alone); that every possible loop is caught (a window that still loops after four attempts stays unrecovered: Devanagari, flagged, excluded, warned); Auto mode on a long English file costs one extra Hinglish-model pass (`auto_check_translated=False` switches it off); other speakers / pure-Hindi audio; cost of the repair on very long loops (one decode of ≤ 8 s per window and attempt) | |

## Hinglish on other computers — 0.9.11 to 0.9.13 (2026-11-09, field reports "stuck at 30-50 %" from a friend's PC)
All measured on the dev PC (RTX 3060 Laptop 6 GB, i9-12th gen), 40 s Hinglish clip ("Learn this one skill"); the friend's PC itself was NOT available.

| What | How | Result |
|---|---|---|
| Where the time goes (GPU) | stage timer around every engine pass | base passes 24 s, extra checks 145 s (0.9.10 had no limit; bar stood at 52 % of the Hinglish stage) |
| Time limit of the extra checks (0.9.11) | `coverage.Budget`; simulated slow PC (limit 1 × base) | 55 s instead of 170-222 s, complete transcript, warning |
| Missing `tokenizer.json` + dead network (0.9.12) | copy of the model folder without the file, cold HF cache, proxy to an unroutable address | before: not loaded after 150 s (retries, CPU/GPU idle); after: restored offline, loaded in 6 s |
| Runtime package versions | dev `.venv` vs `requirements.lock.txt` | identical |
| Hinglish model conversion (0.9.13) | converted again with the pinned tools (`scripts/requirements-convert.txt`, torch 2.14.1 CPU) and revision f3214eed… | **byte-identical** model.bin / config.json / vocabulary.json (SHA-256 1a47e83d…); the unpinned setup would have used ctranslate2 4.8.5 / transformers 5.20.2 today |
| GPU memory | `nvidia-smi` sampled every 0.3 s | English peak ~1.3 GB, Hinglish ~2.4 GB |
| Small GPU imitated (card filled until 1.86 GB free) | same clip | English 12 s (unchanged); Hinglish 267 s (vs 169 s); with the models taking turns (`gpu.py`, 2.17 GB free): 179 s, peak 1.4 GB |
| CPU only (`Engine("cpu")`) | same clip | 0.9.12: 399 s, the 2nd opinion overshot its 100 s share to 199 s; 0.9.13 (`Budget.note_attempt`): extras 167 s of 200 s, total 410 s (incl. the coverage safety net's batched pass). The app's bar is between 35 % and 60 % for most of that time |
| Release as shipped | 0.9.13 zip extracted into an empty folder, `.venv`/`models` linked, every module imported, Hinglish transcribed with `scripts\fcg.ps1` | 36 modules, 0 failures; bundled files' SHA-256 correct; 151 words, nothing skipped |
| Tests | `tests/engine/test_extras_budget.py`, `test_model_check.py`, `test_other_pcs.py`, `tests/app/test_stall_watch.py`, `test_fixes.py` | see CLAUDE.md for the counts |
| **NOT verified** | the friend's PC (GPU model, driver, which version they run, how their model was converted); a real 3 GB download + conversion with the pinned set on a fresh PC (the pinned set resolves in a dry run) | |

## Missing CUDA libraries — the friend's PC, finally pinned down (2026-11-11, 0.9.15)
The friend's **Deep check** (0.9.14, screenshot) named it: `RuntimeError: Library cublas64_12.dll is not found or cannot be loaded` (main model: started on the GPU,
fell back to the processor), then **"Hinglish model listens to the sample" WAITING for 180 s**. Python 3.12.10, 1 CUDA device, install from the 0.9.1 zip.

| What | How | Result |
|---|---|---|
| Reproduction | `scratchpad/no_cublas.py`: the deep-check child with the nvidia-cublas wheel hidden from `cuda_setup` | identical to the friend: main model falls back to the CPU; the Hinglish model, loaded on the GPU afterwards, **freezes forever in `faster_whisper … encode`** (stack via faulthandler; no processor use) |
| Fix 1: check before any model touches the GPU | `cuda_setup.cuda_libs_missing()` (loads cublas64_12/cublasLt64_12 with ctypes) in `transcribe.pick_device` | same imitation: every model on the processor from the start, all 11 steps finish, each says why + Fix |
| Fix 2: after one GPU failure, never the GPU again in this process | `transcribe.mark_gpu_broken` (in `_fall_back_to_cpu`), `Engine._get` moves a cached CUDA model to the CPU | `scratchpad/gpu_fail_runtime.py` (up-front check fooled): main model fails at its first decode, the Hinglish model then loads on the CPU, 80 words in 103 s, no freeze |
| System check | `check_gpu` now loads the DLLs too | "NVIDIA GPU found, but its CUDA libraries are missing" + Fix `repair_gpu` (was: "ready") |
| GPU-library install for the friend's Python | `pip install --dry-run --python-version 3.12 --platform win_amd64 -r requirements.txt -r requirements-gpu.txt -c requirements.lock.txt` | resolves to the exact pinned set (nvidia-cublas-cu12 12.9.2.10, cudnn 9.27.0.42, nvrtc 12.9.86) |
| Deep check Fix buttons | throw-away app with `CUDA_VISIBLE_DEVICES=-1`, deep check from the page | every affected step shows "Install the GPU libraries", plus "Fix it"; clicking sends `POST /api/fix/repair_gpu` (intercepted, not executed) |
| **NOT verified** | the repair actually run on the friend's PC (1.5 GB download, then the GPU used) | |

## Silk motion — smoother entrances for Look 2 (2026-11-19, UNRELEASED)
Request: the entrance animations of Soft Editorial were laggy/janky; make them as smooth as two professional reference intros, change nothing else, never move a reveal. Study and numbers: REFERENCE_ANALYSIS.md "Motion study", STYLE.md "Silk motion".

| What | How | Result |
|---|---|---|
| Reference motion measured | PyAV frames (60 fps and 30 fps clips), per-frame least-squares fit of fade / slide / blur | fade ≈ 0.19 s with a soft start, slide = exponential decay (τ 0.23 s / 0.11 s), blur ≤ 1–2 px; stored in `tests/fixtures/silk_reference_measurements.json`, re-fit by `scripts/fit_silk_curves.py` (test: `test_the_silk_curves_are_what_the_stored_measurements_give`) |
| Old vs new, Look 2 support word (46 px slide) | shared evaluator at 25 / 30 / 60 fps | biggest slide step 28.9 / 26.6 / 15.7 px → 8.4 / 7.1 / 3.7 px; after the first frame 58 % → 16 % of the slide covered, opacity 58 % → 12 %; 50 % opacity after 0.085 s, 90 % after 0.142 s (references ≈ 0.08 / 0.14 s) |
| Other looks unchanged | `tests/anim/test_silk.js` compares the new `entranceAt` with a verbatim copy of the old one over 4 specs × 51 times (all properties identical); legacy `planEntrance` equals the old clamp/snap/skip rule; `reference_style`, `clean_poppins`, `clean_four_words` contain no `channels`/`recipe` (pytest); Look 3 keyframes in the stand-in still share one length | pass |
| Timing untouched | `tests/ae/test_silk_mock.py` (REAL builder in the stand-in host, 345-word Hinglish fixture): every layer's in-point = reveal snapped up, every keyframe ≥ in-point, the first key of every property at the in-point with `opacity_from` there; letter stagger/duration/`max_total` and slide/blur/scale values pinned to the old numbers; `ae_verify.verify` + `verify_style` pass | pass |
| Hidden before the reveal | evaluator: opacity at t ≤ 0 = `opacity_from`; letters: opacity exactly 0 at `i × stagger` and before; AE expressions give 100 % hidden before the in-point | pass (29,025 checks in `test_silk.js`) |
| Smooth, monotone, no overshoot, lands exactly | evaluator over 25/30/60 fps | opacity never decreases, slide never reverses, blur never increases, ends on the final state, last step < 0.3 px |
| AE keyframe mapping legal | `easeToKeyframe` of both curves | influences 16 % / 64 % (slide) and 45 % / 55 % (fade) — inside AE's 0.1–100 %, handles do not cross, round-trips exactly; the mock records the real values the builder sets |
| Letter expressions | `letterExpression` run in a VM vs `letterAt`, fade / blur / rise / tint, 3 treatments × 8 letters | equal to 1e-4 |
| Read-back checks | `verify_style` wants `FCG Letters, FCG Letter Blur, FCG Letter Rise, FCG Tint` for a silk letter treatment and the old two for a style without channels; Python `MOTION_RECIPES` equals `Object.keys(FCGAnim.RECIPES)` | pass |
| UI | throw-away copy of a real project in the built-in browser: Look 2 selected, preview draws, section 7 shows the channel sliders, no console errors | pass (a visual comparison of single frames was not informative at preview size) |
| Test suites | fast suite (`scripts\test.ps1`) 337 passed; **whole suite `pytest tests` = 436 passed, 3 skipped** (11.5 min, real models included) | pass |
| **Real After Effects 25.2 (2026-11-20, empty untitled project)** | Look 2 on the 345-word fixture via the connect script; `verify_anim.js`; frames saved with `saveFrameToPng` and measured (alpha); `probes/probe_letter_silk.jsx` for the separate letter channels | **First run failed**: `TypeError: null is not an object` in `mergeChannel` (`for (k in null)` throws in ExtendScript, not in V8) → guarded + pinned by a test. Then: `ok`, 345 layers, 0 errors, 2 usual warnings (70 animations shortened, 1 word shrunk); `verify` + `verify_style` clean; **7,325 keyframe samples vs the shared evaluator: worst opacity 0.02 %, y 0.005 px, blur 0.003**; rendered word slide = evaluator to 0.01 px; letters (probe): fade worst 0.15 %, rise worst 0.02 px, blur σ ≈ 0.40 × value on the `silkFade` curve; 52 letter layers carry the right animators |
| **NOT verified** | playback speed of the extra animators in AE, 24 fps feel, a rendered *video* (frames only), the owner's judgement of how it looks, AE 2024/2026 | |
