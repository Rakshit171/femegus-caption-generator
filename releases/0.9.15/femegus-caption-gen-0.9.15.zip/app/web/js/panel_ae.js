// Section 9: generate/update in After Effects.  Section 10: export & troubleshooting.
import { S, emit } from './store.js';
import { get, post, put, waitJob } from './api.js';
import { h, toast, setStatus, fmtTime } from './dom.js';

export function renderGenerate(root) {
  const ae = S.ae || {};
  const comp = h('input', { type: 'text', value: (S.meta && S.meta.ae && S.meta.ae.comp_name) || 'FCG Captions', style: { width: '180px' } });
  const addVideo = h('input', { type: 'checkbox', checked: true }), recreate = h('input', { type: 'checkbox' });
  const bar = h('div', { class: 'bar' }, h('i', {})), msg = h('div', { class: 'small' }), result = h('div', {});
  const go = h('button', { class: 'primary', disabled: !S.groups || !ae.connected }, 'Generate / update in After Effects');
  go.onclick = async () => {
    go.disabled = true; result.replaceChildren(); bar.firstChild.style.width = '3%'; msg.textContent = 'sending to After Effects…';
    try {
      const job = await post('/api/ae/generate', { comp_name: comp.value, add_video: addVideo.checked, recreate_comp: recreate.checked });
      const done = await waitJob(job, (j) => { bar.firstChild.style.width = Math.round(j.progress * 100) + '%'; msg.textContent = j.message || j.state; }, 700);
      if (done.state !== 'done') throw new Error(done.error || done.state);
      const r = done.result;
      bar.firstChild.style.width = '100%'; msg.textContent = '';
      result.append(h('div', { class: 'card' }, r.ok ? h('b', { class: 'ok' }, `✓ ${r.words} editable text layers in “${r.comp.name}” (${r.seconds}s)`) : h('b', { class: 'bad' }, '✗ After Effects reported errors'),
        r.verified === true ? h('div', { class: 'ok small' }, '✓ Verified inside After Effects: every layer starts at or after its word’s reveal time, no captions overlap, texts match.') : null,
        r.verified === false ? h('div', { class: 'bad small' }, '✗ Verification found problems:') : null, ...(r.verify_problems || []).map((p) => h('div', { class: 'bad small' }, '• ' + p)),
        ...(r.errors || []).map((p) => h('div', { class: 'bad small' }, '• ' + p)), ...(r.warnings || []).map((p) => h('div', { class: 'warn small' }, '• ' + p)),
        r.anim_stats ? h('div', { class: 'hint small' }, `animated ${r.anim_stats.animated} words` + (r.anim_stats.clamped ? `, ${r.anim_stats.clamped} shortened to fit` : '')) : null));
      toast(r.ok ? 'Captions are in After Effects' : 'After Effects reported errors', r.ok ? 'ok' : 'err');
    } catch (e) { msg.textContent = ''; result.append(h('div', { class: 'card bad' }, e.message)); toast(e.message, 'err', 8000); } finally { go.disabled = !ae.connected || !S.groups; }
  };
  const refresh = h('button', { class: 'small', onclick: async () => { S.ae = await get('/api/ae/status'); emit('ae'); emit('section', 'generate'); } }, 'check connection');
  const path = ae.connect_script || 'adapters\\jsx-core\\fcg_connect.jsx';
  root.replaceChildren(h('h2', {}, '9 · Generate in After Effects'),
    h('div', { class: 'hint small' }, 'Creates real, editable text layers (one per word) with effects and keyframes. Running it again replaces only the layers this tool made.'),
    h('div', { class: 'card' }, h('div', { class: 'row' }, h('b', {}, 'Connection'), h('span', { class: 'pill ' + (ae.connected ? 'on' : ae.ae_running ? 'warn' : 'off') }, ae.connected ? `connected · AE ${ae.ae_version || ''}` : ae.ae_running ? 'After Effects is open, not connected' : 'After Effects is not running'), refresh),
      ae.connected ? null : h('div', { class: 'small' }, 'In After Effects choose ', h('b', {}, 'File ▸ Script ▸ Run Script File…'), ' and pick:', h('pre', {}, path), 'Run it once per After Effects session. No installation, nothing in the After Effects folder is changed. If it is already running, wait ~10 s and check again.')),
    h('div', { class: 'row' }, h('label', { class: 'l' }, 'Composition name'), comp), h('div', { class: 'row' }, h('label', { class: 'l' }, 'Add the video'), addVideo, h('span', { class: 'hint small' }, 'as the bottom layer (first time only)')),
    h('div', { class: 'row' }, h('label', { class: 'l' }, 'Start fresh'), recreate, h('span', { class: 'hint small' }, 'delete and recreate the composition')),
    h('div', { class: 'row' }, go), bar, msg, result,
    S.groups ? null : h('div', { class: 'hint' }, 'Nothing to generate yet — transcribe first.'));
}

// Subtitle file (.srt) of the captions as they are built right now (including your corrections and the current look's grouping).
function srtCard() {
  const mode = h('select', {},
    h('option', { value: 'caption', title: 'Standard subtitles: each caption appears as a whole' }, 'One cue per caption'),
    h('option', { value: 'word', title: 'The caption builds up: each word is added at the moment it is spoken' }, 'Word by word build-up'));
  const info = h('div', { class: 'small' }), pre = h('pre', { class: 'mono small', style: { margin: '6px 0 0', whiteSpace: 'pre-wrap', maxHeight: '150px', overflow: 'auto' } });
  const btn = h('button', { class: 'primary' }, '⬇ Download .srt');
  const paint = async () => {
    try {
      const r = await get('/api/export/srt/info?mode=' + mode.value);
      info.textContent = `${r.cues} subtitle cues · ${fmtTime(r.seconds, false)} · file name ${r.filename}`;
      info.className = 'small hint'; pre.textContent = r.preview; btn.disabled = !r.cues;
    } catch (e) { info.textContent = e.message; info.className = 'small bad'; pre.textContent = ''; btn.disabled = true; }
  };
  mode.onchange = paint;
  btn.onclick = async () => {
    btn.disabled = true;
    try {
      const res = await fetch('/api/export/srt?mode=' + mode.value, { credentials: 'same-origin' });
      if (!res.ok) { let m = res.statusText; try { m = (await res.json()).error || m; } catch (e) { /* not JSON */ } throw new Error(m); }
      const name = ((res.headers.get('Content-Disposition') || '').match(/filename="([^"]+)"/) || [])[1] || 'captions.srt';
      const url = URL.createObjectURL(await res.blob());
      const a = h('a', { href: url, download: name, style: { display: 'none' } });
      document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 10000);
      toast(`Saved ${name} to your Downloads folder (or where your browser asks)`, 'ok', 7000);
    } catch (e) { toast(e.message, 'err', 9000); } finally { await paint(); }
  };
  paint();
  return h('div', { class: 'card' }, h('b', {}, 'Subtitles (.srt)'),
    h('div', { class: 'hint small' }, 'For YouTube, Instagram, Premiere, DaVinci, CapCut and any video player. The look (fonts, colours, animation) exists only in After Effects; an .srt holds just the words and their timing.'),
    h('div', { class: 'row' }, mode, btn), info, pre,
    h('div', { class: 'hint small' }, 'Times follow the captions you see in this app, including your corrections. Make your final edits first, then download.'));
}

// System check with one-click fixes: every problem that can be repaired from here gets its own button, and "Fix everything" runs them in a sensible order
// (downloads first, the component repair that restarts the app last). Nothing is installed without the user pressing a button and confirming.
function systemCheckCard() {
  const out = h('div', {}), progress = h('div', {}), btn = h('button', { class: 'primary' }, 'Run system check');
  const col = { ok: 'ok', warn: 'warn', fail: 'bad' }, sym = { ok: '✓', warn: '!', fail: '✗' };
  let busy = false;
  const describe = (m) => `${m.label}\n   ${m.note}${m.size ? `\n   Size/time: ${m.size}` : ''}${m.internet ? '\n   Needs the internet.' : ''}`;

  // one background fix (a download / setup) with a live progress bar; resolves true when it finished
  async function runJobFix(action, meta) {
    const bar = h('div', { class: 'bar' }, h('i', {})), msg = h('div', { class: 'small' }), cancel = h('button', { class: 'small' }, 'Cancel');
    const wait = h('div', { class: 'row tight' }, cancel, h('span', { class: 'hint small' }, 'You can keep working in the app while this runs.'));
    const card = h('div', { class: 'card' }, h('b', {}, meta.label), bar, msg, wait);
    progress.replaceChildren(card);
    let job;
    try { job = await post('/api/fix/' + action, {}); } catch (e) { card.append(h('div', { class: 'bad small' }, e.message)); toast(e.message, 'err', 9000); return false; }
    cancel.onclick = () => { cancel.disabled = true; post('/api/jobs/' + job.id + '/cancel', {}).catch(() => {}); };
    const done = await waitJob(job, (j) => { bar.firstChild.style.width = Math.round(j.progress * 100) + '%'; msg.textContent = j.message || j.state; }, 700).catch((e) => ({ state: 'error', error: e.message }));
    wait.remove();
    if (done.state === 'done') { bar.firstChild.style.width = '100%'; msg.textContent = done.message || 'Done.'; toast(meta.label + ' — done', 'ok'); return true; }
    msg.className = 'bad small'; msg.textContent = done.error || done.message || done.state; toast(done.error || 'The fix did not finish', 'err', 12000);
    return false;
  }

  async function fixOne(action, meta) {
    if (busy) return;
    if (action === 'show_connect_script') {
      try { const r = await post('/api/fix/' + action, {}); toast('Opened the folder. In After Effects: File > Script > Run Script File… and pick fcg_connect.jsx', 'ok', 9000); } catch (e) { toast(e.message, 'err', 9000); }
      return;
    }
    if (!confirm('Fix this now?\n\n' + describe(meta))) return;
    if (meta.restart) { await restartApp(true, action); return; }
    busy = true;
    const ok = await runJobFix(action, meta);
    busy = false;
    if (ok) check();
  }

  async function fixAll(rep) {
    if (busy) return;
    const metas = {}; rep.checks.forEach((c) => { if (c.fix_action && c.fix_meta) metas[c.fix_action] = c.fix_meta; });
    const steps = rep.fix_all.filter((a) => a !== 'repair' || !rep.fix_all.includes('repair_gpu'));         // the GPU repair already contains the normal one
    if (!steps.length) return;
    if (!confirm('Fix everything that is missing?\n\n' + steps.map((a, i) => `${i + 1}. ${describe(metas[a])}`).join('\n\n') + (steps.some((a) => metas[a].restart) ? '\n\nThe app restarts at the end (this page reloads by itself).' : ''))) return;
    busy = true;
    for (const a of steps) {
      if (metas[a].restart) { busy = false; await restartApp(true, a); return; }
      if (!(await runJobFix(a, metas[a]))) { busy = false; check(); return; }                         // stop at the first problem and show it
    }
    busy = false;
    check();
  }

  async function check() {
    btn.disabled = true; out.replaceChildren(h('div', { class: 'hint' }, 'checking…'));
    try {
      const rep = await get('/api/selfcheck');
      const rows = rep.checks.map((c) => h('div', { class: 'row tight', style: { alignItems: 'flex-start' } }, h('b', { class: col[c.status] }, sym[c.status]),
        h('div', { style: { flex: 1 } }, h('div', {}, c.title, c.detail ? h('span', { class: 'hint small' }, '  ' + c.detail) : null),
          c.fix && c.status !== 'ok' ? h('div', { class: 'small' }, '→ ' + c.fix) : null,
          c.fix_action ? h('div', { class: 'row tight' }, h('button', { class: 'small primary', title: c.fix_meta.note, onclick: () => fixOne(c.fix_action, c.fix_meta) }, c.fix_meta.label),
            c.fix_meta.size ? h('span', { class: 'hint small' }, c.fix_meta.size + (c.fix_meta.internet ? ' · needs internet' : '')) : null) : null)));
      const doable = rep.fix_all.length;
      out.replaceChildren(h('div', { class: 'card' }, ...rows, h('b', { class: col[rep.overall] }, { ok: 'Everything is ready.', warn: 'Ready, with notes.', fail: 'Not ready — fix the ✗ items.' }[rep.overall]),
        doable ? h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => fixAll(rep) }, doable > 1 ? `Fix everything (${doable} steps)` : 'Fix it'),
          h('span', { class: 'hint small' }, 'Downloads and repairs what is missing; asks once before it starts.')) : null));
    } catch (e) { out.replaceChildren(h('div', { class: 'bad' }, e.message)); } finally { btn.disabled = false; }
  }
  btn.onclick = check;

  // Deep check: really runs both speech models on a short sample (separate process on the app side) and shows every step live.
  const deepBtn = h('button', {}, 'Deep check (2–10 min)'), deepOut = h('div', {});
  const dsym = { ok: '✓', warn: '!', fail: '✗', running: '…' }, dcol = { ok: 'ok', warn: 'warn', fail: 'bad', running: 'hint' };
  function drawDeep(rep, job) {
    const steps = (rep && rep.steps) || [];
    const rows = steps.map((s) => h('div', { class: 'row tight', style: { alignItems: 'flex-start' } }, h('b', { class: dcol[s.status] || '' }, dsym[s.status] || '?'),
      h('div', { style: { flex: 1 } }, h('div', {}, s.title, typeof s.seconds === 'number' ? h('span', { class: 'hint small' }, `  ${Math.round(s.seconds)} s`) : null),
        s.detail ? h('div', { class: 'hint small' }, s.detail) : null,
        s.fix && s.status !== 'ok' ? h('div', { class: 'small' }, '→ ' + s.fix) : null,
        s.fix_action && s.fix_meta && rep && rep.running === false ? h('div', { class: 'row tight' },
          h('button', { class: 'small primary', title: s.fix_meta.note, onclick: () => fixOne(s.fix_action, s.fix_meta) }, s.fix_meta.label),
          s.fix_meta.size ? h('span', { class: 'hint small' }, s.fix_meta.size + (s.fix_meta.internet ? ' · needs internet' : '') + (s.fix_meta.restart ? ' · restarts the app' : '')) : null) : null)));
    const parts = [h('b', {}, 'Deep check'), rep && rep.sample ? h('div', { class: 'hint small' }, 'Test sample: ' + rep.sample) : null, ...rows];
    if (rep && rep.running === false) {
      parts.push(h('b', { class: dcol[rep.overall] }, { ok: 'Everything works on this computer.', warn: 'Works, with notes (see the ! items).', fail: 'Found a problem (see the ✗ item).' }[rep.overall]));
      parts.push(h('div', { class: 'row tight' }, h('button', { class: 'small', onclick: async () => {
        try { await navigator.clipboard.writeText(rep.text || ''); toast('Report copied — paste it into a message', 'ok'); } catch (e) { toast('Could not copy: ' + e.message, 'err'); }
      } }, 'Copy report'), h('span', { class: 'hint small' }, 'Also saved as work\\deep_check.txt and included in "Copy support info".')));
      const todo = (rep.fix_all || []).filter((a) => a !== 'repair' || !(rep.fix_all || []).includes('repair_gpu'));      // the GPU repair contains the normal one
      if (todo.length) {
        parts.push(h('div', { class: 'row' }, h('button', { class: 'primary', onclick: () => fixAll({ checks: steps, fix_all: rep.fix_all }) },
          todo.length > 1 ? `Fix everything found (${todo.length} steps)` : 'Fix it'),
        h('span', { class: 'hint small' }, 'Then run the deep check again to confirm (after a repair that restarts the app, this page reloads by itself).')));
      }
    } else if (job) {
      parts.push(h('div', { class: 'hint small' }, (job.message || 'working…') + ` · ${Math.round(job.seconds || 0)} s`));
    }
    deepOut.replaceChildren(h('div', { class: 'card' }, ...parts));
  }
  deepBtn.onclick = async () => {
    if (!confirm('Run the deep check?\n\nIt loads both speech models and lets them listen to the first 20 seconds of the open video (or a spoken test sentence), exactly like a transcription, and shows which step fails or is slow.\nTakes 2–10 minutes; nothing is changed or downloaded.')) return;
    deepBtn.disabled = true; btn.disabled = true;
    let job;
    try { job = await post('/api/deepcheck', {}); } catch (e) { toast(e.message, 'err', 9000); deepBtn.disabled = false; btn.disabled = false; return; }
    const done = await waitJob(job, (j) => drawDeep(j.result, j), 1000).catch((e) => ({ state: 'error', error: e.message }));
    if (done.result) drawDeep(done.result, done); else deepOut.replaceChildren(h('div', { class: 'bad' }, done.error || done.state));
    deepBtn.disabled = false; btn.disabled = false;
  };
  return h('div', {}, h('div', { class: 'row tight' }, btn, deepBtn), h('div', { class: 'hint small' }, 'System check = are the files there (seconds). Deep check = do the speech models really work here, and how fast (minutes).'), out, progress, deepOut);
}

export function renderExport(root) {
  const d = S.diagnostics || {}, ae = S.ae || {};
  const link = (href, label) => h('a', { href, style: { color: 'var(--accent2)' } }, label);
  const rows = Object.entries(d).map(([k, v]) => h('tr', {}, h('td', { class: 'hint' }, k), h('td', {}, String(v))));
  root.replaceChildren(h('h2', {}, '10 · Export & troubleshooting'),
    S.groups ? srtCard() : h('div', { class: 'card' }, h('div', { class: 'hint' }, 'Nothing to export yet — transcribe first (section 1).')),
    S.groups ? h('div', { class: 'card' }, h('div', { class: 'row' }, link('/api/export/groups', '⬇ groups.json (timed captions)'))) : null,
    h('h3', {}, 'Project files'), h('div', { class: 'small' }, S.meta ? h('code', {}, 'projects\\' + S.meta.id) : '—', h('div', { class: 'hint small' }, 'transcript.json (engine output, never edited) · overrides.json (all your corrections) · groups.json · project.json (settings, style)')),
    h('h3', {}, 'Updates'), updatesCard(),
    h('h3', {}, 'Repair & help'), helpTools(),
    h('h3', {}, 'System check'),
    h('div', { class: 'hint small' }, 'Checks Python, packages, GPU, speech models, fonts, After Effects and its script permission, and disk space. The check only reads; when something is missing or broken a Fix button appears next to it.'),
    systemCheckCard(),
    h('h3', {}, 'System details'), h('table', {}, ...rows), h('div', { class: 'row' }, h('span', { class: 'pill ' + (ae.connected ? 'on' : 'off') }, ae.connected ? 'After Effects connected' : 'After Effects not connected')),
    h('h3', {}, 'Troubleshooting'),
    ...[['No After Effects connection', ' from File ▸ Script ▸ Run Script File once per session. Also tick Preferences ▸ Scripting & Expressions ▸ “Allow Scripts to Write Files and Access Network”.'],
        ['After Effects does nothing', 'A modal dialog (for example the disk-cache warning at startup) blocks scripts. Close it and try again.'],
        ['Transcription is slow or fails on the GPU', 'The app falls back to the CPU automatically. Check “cuda_devices” above; update the NVIDIA driver if it is 0.'],
        ['Words are wrong', 'Fix them in section 2; the timing stays. Flagged words (tags) are the least certain.'],
        ['Missing font in After Effects', 'The tool substitutes Arial and warns; install the font or pick another in section 5.'],
        ['Captions cover the speaker', 'Section 8 ▸ Vertical position.']].map(([q, a]) => h('details', {}, h('summary', {}, q), h('div', { class: 'small hint' }, a))));
}

// ---- updates: opt-in; contacts only the update site and only sends GET requests (nothing about you, your footage or your projects)
const clock = (t) => new Date(t * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

// Restart the app in place (the launcher starts a new copy on the same address) and reload this page when it answers. With `repair`, the launcher first
// re-installs the tested component versions (a few minutes, shown in the black window).
export async function restartApp(repair = false, action = null) {
  let r;
  try { r = await post(action ? '/api/fix/' + action : (repair ? '/api/repair' : '/api/restart'), {}); } catch (e) { toast(e.message, 'err'); return; }
  if (!r.supported) {
    alert((repair ? 'Repair needs the launcher. ' : '') + 'Please close the app\'s black window, then start it again with Start-FemeGus.cmd (the desktop shortcut). Your projects are saved.' +
      (repair ? '\n\nTo repair: double-click Install-FemeGus.cmd instead.' : ''));
    return;
  }
  window.__fcgRestarting = true;
  const veil = h('div', { style: { position: 'fixed', inset: 0, background: '#000c', zIndex: 99998, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', font: '16px system-ui,sans-serif', textAlign: 'center', padding: '24px' } },
    h('div', {}, h('b', {}, repair ? 'Repairing and restarting…' : 'Restarting…'), h('div', { class: 'small', style: { marginTop: '8px', opacity: 0.8 } },
      repair ? 'Components are being re-installed (needs internet, a few minutes; the black window shows the progress). This page reloads by itself.' : 'This page reloads by itself in a few seconds.')));
  document.body.append(veil);
  const t0 = Date.now();
  await new Promise((res) => setTimeout(res, 2500));
  for (;;) {
    try { const st = await fetch('/api/state', { credentials: 'same-origin' }); if (st.ok) { location.reload(); return; } } catch (e) { /* still restarting */ }
    if (Date.now() - t0 > 20 * 60 * 1000) { veil.remove(); window.__fcgRestarting = false; toast('The app did not come back. Start it again with Start-FemeGus.cmd.', 'err', 12000); return; }
    await new Promise((res) => setTimeout(res, 1500));
  }
}

async function copySupportInfo() {
  try {
    const { text } = await get('/api/support-info');
    try { await navigator.clipboard.writeText(text); toast('Support info copied — paste it into a message to the person who gave you the tool.', 'ok', 8000); }
    catch (e) {                                    // clipboard blocked: show it for manual copying
      const ta = h('textarea', { style: { width: '100%', height: '260px', fontFamily: 'Consolas, monospace', fontSize: '12px' } }); ta.value = text;
      document.querySelector('#panel').append(h('div', { class: 'card' }, h('b', {}, 'Select all and copy:'), ta)); ta.select();
    }
  } catch (e) { toast(e.message, 'err'); }
}

function updatesCard() {
  const box = h('div', { class: 'card' }), out = h('div', {}), restartBox = h('div', {});
  const stat = h('div', { class: 'small' }, `Installed version ${S.version || ''}`);
  const auto = h('input', { type: 'checkbox', checked: !!(S.settings && S.settings.update_check) });
  auto.onchange = async () => {
    try { await put('/api/update/setting', { enabled: auto.checked }); S.settings = { ...(S.settings || {}), update_check: auto.checked }; toast(auto.checked ? 'Automatic update checks on' : 'Automatic update checks off', 'ok'); } catch (e) { toast(e.message, 'err'); }
  };
  const btn = h('button', { class: 'primary' }, 'Check for updates');

  // "restart to finish": shown whenever the files on disk are newer than the program that is running — also after this page was re-drawn or reloaded
  const showRestart = (st, needsSetup) => {
    if (!st.restart_needed) { restartBox.replaceChildren(); return; }
    const go = h('button', { class: 'primary' }, needsSetup ? 'Repair components and restart' : 'Restart now');
    go.onclick = () => restartApp(!!needsSetup);
    restartBox.replaceChildren(h('div', { class: 'card', style: { borderColor: 'var(--warn)' } },
      h('b', { class: 'warn' }, `Update installed: version ${st.current} — restart to finish`), h('div', { class: 'small' }, `The program that is running is still version ${st.running}. The new version starts after a restart (your projects are kept).`),
      needsSetup ? h('div', { class: 'small warn' }, 'This version needs updated components: the restart will first install them (needs internet, a few minutes).') : null,
      st.restart_supported === false ? h('div', { class: 'small' }, 'Close the black window and start the app again with Start-FemeGus.cmd.') : go));
    S.update = { ...(S.update || {}), restart_needed: true, current: st.current }; paintUpdateBadge();
  };
  const refreshRestart = () => get('/api/update/status').then((st) => { stat.textContent = `Installed version ${st.current}` + (st.restart_needed ? ` · running version ${st.running}` : ''); showRestart(st, st.needs_setup); return st; }).catch(() => null);

  const render = (r) => {
    S.update = { ...r }; paintUpdateBadge();
    const kids = [];
    const news = (r.looks || []).filter((l) => l.status === 'new' || l.status === 'update');
    const when = r.checked_at ? ` (checked ${clock(r.checked_at)})` : '';
    if (!r.app_update && !news.length) kids.push(h('div', { class: 'ok' }, `✓ You have the latest version (${r.current}) and the latest caption looks.${when}`));
    else if (!r.app_update) kids.push(h('div', { class: 'ok' }, `✓ The program is the latest version (${r.current}).${when} New caption looks are available:`));
    if (r.app_update) {
      const apply = h('button', { class: 'primary' }, `Update to version ${r.latest}`);
      apply.onclick = async () => {
        if (!confirm('Update the program to version ' + r.latest + '?\n\nYour projects, saved looks and downloaded models are not touched. A backup of the replaced files is kept so you can go back.')) return;
        apply.disabled = true; apply.textContent = 'Updating…';
        try {
          const res = await post('/api/update/apply', {});
          out.replaceChildren(h('div', { class: 'ok' }, `✓ Version ${res.version} is installed (${res.files} files updated).`));
          await refreshRestart();
          toast(`Updated to version ${res.version} — restart to finish`, 'ok', 9000);
        } catch (e) { apply.disabled = false; apply.textContent = `Update to version ${r.latest}`; out.prepend(h('div', { class: 'bad' }, 'Update failed: ' + e.message)); toast(e.message, 'err', 12000); }
      };
      kids.push(h('div', { class: 'card' }, h('b', {}, `Version ${r.latest} is available`), r.released ? h('span', { class: 'hint small' }, '  released ' + r.released) : null,
        h('ul', { class: 'small' }, ...(r.notes || []).map((n) => h('li', {}, n))),
        r.needs_setup ? h('div', { class: 'warn small' }, 'Includes updated components — after the update the restart will install them first.') : null, apply));
    }
    if (news.length) {
      const rows = news.map((l) => {
        const c = h('input', { type: 'checkbox', checked: true, 'data-name': l.name });
        return h('div', { class: 'row tight' }, c, h('span', {}, l.title), h('span', { class: 'pill ' + (l.status === 'new' ? 'on' : 'warn') + ' small' }, l.status === 'new' ? 'new look' : 'updated look'));
      });
      const inst = h('button', { class: 'primary small' }, 'Install selected looks');
      inst.onclick = async () => {
        const names = rows.map((b) => b.querySelector('input')).filter((c) => c.checked).map((c) => c.dataset.name);
        if (!names.length) return;
        inst.disabled = true;
        try { const res = await post('/api/update/looks', { names }); S.presets = res.presets; toast(`Installed: ${res.installed.join(', ')} — see section 4`, 'ok'); await check(); } catch (e) { inst.disabled = false; toast(e.message, 'err'); }
      };
      kids.push(h('div', { class: 'card' }, h('b', {}, 'Caption looks'), h('div', { class: 'hint small' }, 'Look packs are plain data files; installing one changes nothing about your projects.'), ...rows, inst));
    }
    out.replaceChildren(...kids);
  };
  async function check() {
    btn.disabled = true; out.replaceChildren(h('div', { class: 'hint' }, 'contacting the update site…'));
    try { render(await post('/api/update/check', {})); await refreshRestart(); } catch (e) { out.replaceChildren(h('div', { class: 'bad' }, e.message)); } finally { btn.disabled = false; }
  }
  btn.onclick = check;
  const back = h('button', { class: 'small', title: 'put the files of the previous version back' }, 'Go back to the previous version');
  back.onclick = async () => {
    if (!confirm('Restore the previous version of the program files?')) return;
    try { const r = await post('/api/update/rollback', {}); toast(`Restored version ${r.version}. Restart the app.`, 'ok'); refreshRestart(); } catch (e) { toast(e.message, 'err'); }
  };
  get('/api/update/status').then((st) => {
    stat.textContent = `Installed version ${st.current}` + (st.restart_needed ? ` · running version ${st.running}` : '');
    showRestart(st, st.needs_setup);
    if (st.backups && st.backups.length) box.append(h('div', { class: 'row tight' }, back, h('span', { class: 'hint small' }, `previous version: ${st.backups[0].version}`)));
    if (st.cache && !st.restart_needed) render(st.cache);
  }).catch(() => {});
  box.append(stat, restartBox, h('div', { class: 'hint small' }, 'Updates come from a free public site (GitHub). Checking only downloads a small file; nothing about you, your footage or your projects is sent.'),
    h('div', { class: 'row tight' }, auto, h('label', {}, 'check automatically when the app starts (at most once a day)')), h('div', { class: 'row' }, btn), out);
  return box;
}

// Repair + support info: the two tools for "something does not work on my computer"
function helpTools() {
  const rep = h('button', {}, 'Repair components');
  rep.onclick = () => { if (confirm('Re-install the tested versions of the components (needs internet, a few minutes), then restart the app?\n\nYour projects, looks and downloaded models are kept.')) restartApp(true); };
  const sup = h('button', {}, 'Copy support info');
  sup.onclick = copySupportInfo;
  return h('div', { class: 'card' }, h('div', { class: 'row' }, rep, sup),
    h('div', { class: 'hint small' }, 'Repair fixes most odd errors after an install or update (wrong component versions). Support info = versions, your computer and the last lines of the black window — no videos, transcripts or passwords — to paste in a message when you ask for help.'));
}

export function paintUpdateBadge() {
  const r = S.update, el = document.getElementById('updpill');
  if (!el) return;
  const looks = r ? (r.looks || []).filter((l) => l.status === 'new' || l.status === 'update').length : 0;
  const restart = !!(r && r.restart_needed);
  el.style.display = (restart || (r && r.app_update) || looks) ? '' : 'none';
  el.textContent = restart ? 'Restart to finish the update' : (r && r.app_update ? `Update ${r.latest} available` : 'New caption looks available');
}
