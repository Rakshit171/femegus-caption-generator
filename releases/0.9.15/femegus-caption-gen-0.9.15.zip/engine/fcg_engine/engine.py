"""High-level engine: language-mode routing, model cache (models stay loaded), quality flags.

english  -> stock Whisper (default "turbo"), language forced to "en".  NOTE: forcing English makes Whisper TRANSLATE spoken Hindi into
            English, so use it only for English speech.
hinglish -> HYBRID (default): stock turbo in Hindi mode as the skeleton (English stays Latin, Hindi comes out Devanagari = free word-level
            language ID) + the Hinglish fine-tune (Oriserve Apex) supplying Roman text for each Hindi span. See hybrid.py, docs/HINGLISH.md.
            ``hinglish_strategy`` = "hybrid" | "apex" (fine-tune only) | "stock_prompt" (stock + Roman prompt, prompt-leak prone).
auto     -> run the skeleton pass; if >= ``auto_min_devanagari`` words (and >= ``auto_min_fraction`` of words) are Devanagari the audio is
            treated as Hinglish (hybrid), otherwise as English (forced-en pass). Per-FILE decision; the hybrid itself is word-level.
"""
from __future__ import annotations

import os
import time
from typing import Callable, Optional

from . import coverage as cov
from .coverage import fuse, uncovered_gaps
from .hybrid import is_devanagari, merge, translated_spans
from .models import HINGLISH_PROMPT
from .model_check import prepare_local_model
from .quality import _norm, audit_numbers, flag_words
from .status import say
from .transcribe import Transcriber, resolve_model, sanitize_words

STOCK_KEYS = ("turbo", "large-v3", "medium", "small", "distil-large-v3")
Progress = Optional[Callable[[float], None]]


def _slice(progress: Progress, a: float, b: float) -> Progress:
    return (lambda p: progress(a + (b - a) * p)) if progress else None


class Engine:
    def __init__(self, device: str = "auto", models_local_path: Optional[str] = None,
                 english_model: str = "turbo", hinglish_model: str = "hinglish-apex",
                 hinglish_strategy: str = "hybrid", auto_min_devanagari: int = 3, auto_min_fraction: float = 0.03,
                 auto_check_translated: bool = True):
        self.auto_check_translated = auto_check_translated     # auto mode: also run the Hinglish model when the stock model wrote no Devanagari (it may have translated Hindi)
        self.device = device
        self.models_local_path = models_local_path
        self.english_model, self.hinglish_model = english_model, hinglish_model
        self.hinglish_strategy = hinglish_strategy
        self.auto_min_devanagari, self.auto_min_fraction = auto_min_devanagari, auto_min_fraction
        self._cache: dict[str, Transcriber] = {}
        self._budget: Optional[cov.Budget] = None              # time limit of the extra passes while they run (see coverage.Budget)
        self._take_turns: Optional[bool] = None                # little free GPU memory: only the working model stays on the GPU (see gpu.py); decided at the first load

    def _get(self, key: str) -> Transcriber:
        if key not in self._cache:
            if self._take_turns is None and self.device in ("auto", "cuda"):
                from .gpu import free_vram_mib, models_must_take_turns
                free = free_vram_mib()
                self._take_turns = models_must_take_turns(free)
                if self._take_turns:
                    say(f"Little free graphics memory ({free if free is not None else '?'} MB): the speech models take turns on the GPU (same results, a little slower)")
            if self._take_turns:
                self._park_others(None)                         # make room before a new model is loaded
            self._cache[key] = Transcriber(key, self.device, models_local_path=self.models_local_path)
        t = self._cache[key]
        if getattr(t, "device", None) == "cuda":
            from .transcribe import gpu_problem
            problem = gpu_problem()
            if problem:                                        # another model's GPU failed: a CUDA model used after that froze forever (reproduced) -> processor
                try:
                    t._fall_back_to_cpu(RuntimeError(problem))
                except Exception as exc:
                    print(f"[engine] could not move '{key}' to the processor: {type(exc).__name__}: {exc}", flush=True)
        if self._take_turns and getattr(t, "device", None) == "cuda":
            self._park_others(key)
            try:
                m = t.model.model
                if not m.model_is_loaded:
                    m.load_model()                              # back from normal RAM onto the GPU: same weights
            except Exception as exc:
                print(f"[engine] could not move the model back to the GPU: {type(exc).__name__}: {exc}", flush=True)
        return t

    def _park_others(self, keep: Optional[str]) -> None:
        """Move every model except ``keep`` from the GPU into normal RAM (CTranslate2 unload_model(to_cpu=True)). Never raises."""
        for k, o in self._cache.items():
            if k == keep or getattr(o, "device", None) != "cuda":
                continue
            try:
                m = o.model.model
                if m.model_is_loaded:
                    m.unload_model(to_cpu=True)
            except Exception as exc:
                print(f"[engine] could not park model '{k}': {type(exc).__name__}: {exc}", flush=True)

    def hinglish_model_available(self) -> bool:
        """Is the Hinglish model usable? A model folder with missing files counts as NOT available (loading it would wait for the internet); small missing files
        are restored offline first (``model_check``). The reason is kept in ``self.hinglish_problems``."""
        key = self.hinglish_model
        self.hinglish_problems: list[str] = []
        if key in STOCK_KEYS:
            return True
        path = resolve_model(key, self.models_local_path)
        if not os.path.isdir(path):
            return False
        _restored, self.hinglish_problems = prepare_local_model(path)
        if not self.hinglish_problems:
            from .model_check import matches_tested_build
            self.hinglish_build_differs = matches_tested_build(path) is False     # quick check (config + size); the system check does the full hash
        return not self.hinglish_problems

    # ------------------------------------------------------------------ passes
    def _skeleton(self, path: str, progress: Progress, kw: dict) -> dict:
        """Stock model, Hindi mode, NO prompt: English words in Latin, Hindi words in Devanagari."""
        say("Pass 1: the main speech model is listening to the clip")
        return self._get(self.english_model).transcribe(path, "hinglish", progress=progress, initial_prompt="", **kw)

    def _expired(self, stage: str) -> bool:
        """Is the time limit of the extra passes (``coverage.Budget``) used up for this pass? Also moves the progress bar. No budget = never."""
        b = getattr(self, "_budget", None)
        if b is None:
            return False
        b.tick()
        return b.expired(stage)

    def _open_budget(self, base_s: float, audio_s: Optional[float], progress: Progress = None) -> Optional["cov.Budget"]:
        return cov.Budget.for_run(base_s, audio_s or 0.0, progress) if cov.EXTRAS_BUDGET else None

    def _hinglish(self, path: str, progress: Progress, kw: dict, skeleton: Optional[dict] = None, hinglish: Optional[dict] = None, windowed: Optional[dict] = None,
                  t_begin: Optional[float] = None):
        """Returns (result, prompt_used, warnings) for the configured Hinglish strategy. ``skeleton`` / ``hinglish`` / ``windowed`` = passes already made (auto mode).
        ``t_begin`` = when the work for this clip began (the base passes' time sets the limit of the extra passes, see ``coverage.Budget``)."""
        warns: list[str] = []
        t_enter = time.monotonic()
        strategy = self.hinglish_strategy
        if strategy in ("hybrid", "apex") and not self.hinglish_model_available():
            why = ("incomplete: " + "; ".join(self.hinglish_problems) + " - press Fix next to the Hinglish model in section 10") if getattr(self, "hinglish_problems", None) else "not found"
            warns.append(f"Hinglish model '{self.hinglish_model}' {why}; used stock {self.english_model} + Roman prompt "
                         "(lower quality, may repeat the prompt text — check flagged words)")
            strategy = "stock_prompt"
        if strategy == "hybrid" and getattr(self, "hinglish_build_differs", False):
            warns.append("the Hinglish model on this computer was converted with different tool versions than the tested one; if Hinglish misbehaves, "
                         "open section 10 > System check and press Fix to rebuild it")
        if strategy == "hybrid":
            t_s = time.monotonic()
            sk = skeleton or self._skeleton(path, _slice(progress, 0.0, 0.45), dict(kw))
            t_sk = (time.monotonic() - t_s) if skeleton is None else 0.0
            sk, sk_patched = self._patch_skeleton(path, sk, kw)
            if hinglish is None:
                model_h = self._get(self.hinglish_model)                       # (loading it is announced by the Transcriber)
                say("Pass 2: the Hinglish model is listening to the clip"
                    + (f" (pass 1 took {t_sk:.0f} s on this computer; this pass takes about as long)" if t_sk >= 20 else ""))
                hg = model_h.transcribe(path, "hinglish", progress=_slice(progress, 0.45, cov.EXTRAS_PROGRESS_FROM), initial_prompt="", **dict(kw))
            else:
                hg = hinglish
            for w in hg["words"]:
                w["origin"] = "hinglish_model"            # kept through any later fusion, so the text layer knows which recogniser wrote a word
            flag_words(hg["words"], hg["segments"], "hinglish")
            # from here on only EXTRA accuracy passes follow; they get a time limit so a slow PC never sits at one percentage for ever (coverage.Budget)
            bud = self._open_budget(time.monotonic() - (t_begin if t_begin is not None else t_enter), (sk.get("source") or {}).get("duration"), progress)
            self._budget = bud
            hg, loop = self._repair_hinglish_loops(path, hg, kw, sk["words"])             # a looped stretch ("vah, vah, vah…") would leave its Hindi unwritten
            if loop["loops"]:
                flag_words(hg["words"], hg["segments"], "hinglish")
                warns.append(f"the Hinglish model looped in {loop['loops']} stretch(es); {loop['words']} word(s) were recovered by decoding them again"
                             + (f" ({loop['failed']} window(s) could not be recovered)" if loop["failed"] else ""))
            say("Extra check 1: comparing the two models and re-listening where they disagree"
                + (f" (all extra checks together take at most about {bud.total:.0f} s)" if bud is not None else ""))
            hg, so = self._second_opinion(path, sk["words"], hg, kw)        # where the Hinglish model's long-form words contradict the stock model: decode that window again
            if so["words"]:
                flag_words(hg["words"], hg["segments"], "hinglish")
                warns.append(f"the Hinglish model's long pass disagreed with the stock model in {so['windows']} window(s); {so['words']} word(s) were taken from decoding "
                             "those windows again" + (f" ({so['failed']} window(s) could not be redone)" if so["failed"] else ""))
            if not windowed:
                say("Extra check 2: listening in short pieces for Hindi the first pass may have missed")
            hw = windowed or self._windowed_pass(path, sk["words"], None, kw)     # short windows hear Hindi the long pass wrote as English
            if hw:
                hg, n_ev = self._add_window_evidence(sk["words"], hg, hw)
                if n_ev:
                    flag_words(hg["words"], hg["segments"], "hinglish")
            say("Extra check 3: tidying the Hindi stretches")
            hg, n_tight = self._tighten_hindi(path, sk["words"], hg, kw)
            if n_tight:
                flag_words(hg["words"], hg["segments"], "hinglish")
            # Hindi the stock model TRANSLATED into English has no Devanagari to be found by: the Hinglish model's own Hindi words show where it is
            spans = translated_spans(sk["words"], hg["words"])
            res = merge(sk, hg, translated=spans)
            if res["hybrid_stats"]["runs_kept_devanagari"] and not kw.get("batched"):
                hg, n_win = self._rescue_hindi_runs(path, hg, res, kw)
                if n_win:
                    flag_words(hg["words"], hg["segments"], "hinglish")
                    res = merge(sk, hg, translated=translated_spans(sk["words"], hg["words"]))
                    res["hybrid_stats"]["hinglish_window_words"] = n_win
                    warns.append(f"{n_win} Hindi word(s) the Hinglish model had skipped were recovered by asking it again for just that stretch")
            if sk_patched:
                res["hybrid_stats"]["skeleton_patched_words"] = sk_patched
                warns.append(f"filled {sk_patched} word(s) the stock model skipped from its own second pass (English words stay as the stock model heard them)")
            res["words"] = sanitize_words(res["words"], res["warnings"])   # sources can overlap at span borders
            if getattr(self, "_env", None) and cov.APEX_FILL_GAPS:
                # the skeleton can miss stretches the Hinglish model heard (e.g. the stock model's first seconds): fill those from it
                res = fuse(res, hg, self._env, min_gap=cov.MIN_GAP_S)       # only long holes: the Hinglish model is weak on English words
                if res["fusion"]["patched_words"]:
                    warns.append(f"filled {res['fusion']['patched_words']} word(s) the stock model missed from the Hinglish model")
            lost = audit_numbers(res["words"], {"stock": sk["words"], "hinglish_model": hg["words"]})
            if lost:
                res["quality"] = {**(res.get("quality") or {}), "numbers_missing": lost}
                warns.append("number(s) heard by a decoding pass are missing from the result: " + ", ".join(f"'{x['text']}' at {x['t']:.1f}s" for x in lost[:8])
                             + " — listen there and correct them in the transcript editor")
            if res["hybrid_stats"].get("translated_runs"):
                warns.append(f"{res['hybrid_stats']['translated_runs']} Hindi stretch(es) had been translated into English by the stock model; "
                             "the Hinglish model's own words were used for them")
            if not res["hybrid_stats"]["hindi_runs"]:
                warns.append("no Hindi detected; result equals the English-script skeleton")
            self._budget = None
            if bud is not None and bud.hit:
                res["hybrid_stats"]["extras_skipped"] = sorted(bud.hit)
                warns.append(f"this computer is slow, so the extra accuracy checks were stopped after about {bud.elapsed():.0f} s (skipped: {', '.join(sorted(bud.hit))}); "
                             "the transcript is complete but a Hindi word may be less accurate — check the flagged words")
            return res, None, warns
        if strategy == "apex":
            return self._get(self.hinglish_model).transcribe(path, "hinglish", progress=progress,
                                                             initial_prompt="", **dict(kw)), None, warns
        prompt = kw.get("initial_prompt") or HINGLISH_PROMPT
        k = {x: y for x, y in kw.items() if x != "initial_prompt"}
        return self._get(self.english_model).transcribe(path, "hinglish", progress=progress, initial_prompt=prompt, **k), prompt, warns

    def _patch_skeleton(self, path: str, sk: dict, kw: dict) -> tuple[dict, int]:
        """Holes in the sequential stock-model skeleton (loud audio, no words) are filled from the stock model's OWN batched pass BEFORE the Hinglish model is
        merged in. Otherwise the hole is filled with the Hinglish model's words, which are good for Hindi but weak on English ("story sells" came out as
        "story cells"). Only for sequential passes and only when the loudness envelope is known; returns (skeleton, patched word count)."""
        env = getattr(self, "_env", None)
        if not env or kw.get("batched"):
            return sk, 0
        try:
            if not uncovered_gaps(sk["words"], env, cov.PATCH_GAP_S):
                return sk, 0
            alt = self._skeleton(path, None, {**kw, "batched": True})
            merged = fuse(sk, alt, env)
            n = merged["fusion"]["patched_words"]
            merged.pop("fusion", None)
            return (merged, n) if n else (sk, 0)
        except Exception as exc:                                      # a safety net must never break the transcription itself
            print(f"[engine] skeleton patch skipped: {type(exc).__name__}: {exc}", flush=True)
            return sk, 0

    # ------------------------------------------------------------------ public
    def transcribe(self, path: str, language_mode: str = "english", progress: Progress = None, envelope: Optional[dict] = None,
                   fusion: bool = True, **kw) -> dict:
        """Transcribe with a coverage safety net.

        1. decode sequentially (long-form): the most ACCURATE mode when it works (digits, English words), measured 3.4 % WER on the reference clip
        2. measure LOUD audio that has NO usable words (coverage gaps) against the loudness envelope. Long-form decoding can silently drop most
           of a clip or fall into "market market market…" loops (both seen on real clips); junk/looping words do not count as coverage
        3. only if there are gaps: decode in independent VAD chunks (batched: robust, but less accurate on digits) and fill each gap from
           whichever pass has the words
        Remaining gaps are reported (result["quality"]["speech_gaps"]) and warned about — never silently ignored.
        """
        if not fusion or "batched" in kw:
            return self._transcribe_once(path, language_mode, progress, **kw)
        from .audio import compute_envelope
        env = envelope or compute_envelope(path)
        self._env = env
        try:
            res = self._transcribe_once(path, language_mode, _slice(progress, 0.0, 0.65), batched=False, **kw)
            gaps = uncovered_gaps(res["words"], env, cov.PATCH_GAP_S)
            info = {"primary": "sequential", "alternate_used": False, "gaps_first_pass": [(round(a, 2), round(b, 2)) for a, b in gaps], "patched_words": 0}
            if gaps:
                alt = self._transcribe_once(path, language_mode, _slice(progress, 0.65, 1.0), batched=True, **kw)
                ga = uncovered_gaps(alt["words"], env, cov.PATCH_GAP_S)
                a_sec, b_sec = sum(b - a for a, b in gaps), sum(b - a for a, b in ga)
                primary, secondary, pname = (alt, res, "batched") if a_sec - b_sec >= cov.SWITCH_MARGIN_S else (res, alt, "sequential")
                merged = fuse(primary, secondary, env)
                merged["warnings"] = sorted(set(merged["warnings"]) | set(res["warnings"]) | set(alt["warnings"]))
                merged["quality"] = merged.get("quality") or {}
                info.update({"primary": pname, "alternate_used": True, "patched_words": merged["fusion"]["patched_words"],
                             "gaps_after_fusion": merged["fusion"]["gaps_after"]})
                res = merged
                res.pop("fusion", None)
            res, info["head_rescue"] = self._rescue_head(path, env, res, kw)
            info["patched_words"] += info["head_rescue"]["patched_words"]
            remaining = uncovered_gaps(res["words"], env)
            hole = cov.head_hole(res["words"], env)      # a hole at the very start is reported from 0.6 s on: it is where listeners notice a missing caption first
            if hole is not None and not any(a <= hole[0] + 0.05 and b >= hole[1] - 0.05 for a, b in remaining):
                remaining = [hole] + [g for g in remaining if g[0] >= hole[1]]
            info["gaps_remaining"] = [(round(a, 2), round(b, 2)) for a, b in remaining]
            res.setdefault("quality", {})["fusion"] = info
            res["quality"]["speech_gaps"] = info["gaps_remaining"]
            for a, b in remaining:
                res["warnings"].append(f"possible missing speech {a:.1f}–{b:.1f}s: the audio is loud there but no words were recognised — listen and add them in the transcript editor")
            if info["patched_words"]:
                res["warnings"].append(f"{info['patched_words']} word(s) were recovered from a second decoding pass ({info['primary']} was the main pass)")
            return res
        finally:
            self._env = None
            self._budget = None

    def _rescue_head(self, path: str, env: dict, res: dict, kw: dict) -> tuple[dict, dict]:
        """Start-of-clip rescue. A clip cut in the middle of a sentence has no lead-in, and decoders then often skip the first words (seen on every real
        Hinglish clip tried; the same can happen to English). If the audio is loud from the start but the first usable word comes >= HEAD_HOLE_S later, the
        first seconds are decoded once more on their own (several windows, see coverage.HEAD_ATTEMPTS), with the same language route as the main result,
        moved back to the real timeline and used ONLY to fill that hole. Never raises: the main result is returned unchanged if anything goes wrong."""
        info = {"attempted": False, "patched_words": 0, "tries": 0}
        if not cov.HEAD_RESCUE:
            return res, info

        head_gap = lambda r: cov.head_hole(r["words"], env)

        try:
            gap = head_gap(res)
            if gap is None:
                return res, info
            info.update(attempted=True, gap=[round(gap[0], 2), round(gap[1], 2)])
            from faster_whisper.audio import decode_audio
            audio = decode_audio(path, sampling_rate=16000)
            route = str((res.get("language") or {}).get("route") or "")
            mode = "hinglish" if route.startswith("hinglish") else "english"          # the route chosen for the WHOLE file (a 5 s window must not re-decide it)
            sub_kw = {k: v for k, v in kw.items() if k != "batched"}
            for pad, context in cov.HEAD_ATTEMPTS:                                    # a short decode is itself fickle: a few windows/paddings, stop once the hole is closed
                moved = self._decode_head(audio, mode, sub_kw, pad, gap[1] + context)
                info["tries"] += 1
                merged = fuse(res, {"words": moved}, env, min_gap=cov.PATCH_GAP_S, min_conf=cov.HEAD_MIN_CONF, gaps=[gap])
                if merged["fusion"]["patched_words"]:
                    info["patched_words"] += merged["fusion"]["patched_words"]
                    merged.pop("fusion", None)
                    res = merged
                gap = head_gap(res)
                if gap is None:
                    break
            if info["patched_words"]:
                res["warnings"] = list(res["warnings"]) + [f"{info['patched_words']} word(s) at the very start were recovered by decoding the first seconds again"]
            return res, info
        except Exception as exc:                                                       # never let the safety net break a transcription
            info["error"] = f"{type(exc).__name__}: {exc}"
            return res, info

    def _decode_window(self, audio, start_s: float, end_s: float, pad: float, run) -> list[dict]:
        """Decode ``audio[start_s:end_s]`` on its own behind ``pad`` seconds of silence with ``run(wav_path) -> transcript``; the words come back on the REAL
        timeline (the silence removed again). Decoders skip speech that starts right at the beginning of what they are given, which is why a window gets a
        run-in of silence and why the same stretch is worth a second try when the long decode lost it."""
        import tempfile
        import wave

        import numpy as np
        sr = 16000
        start_s = max(0.0, start_s)
        clip = np.concatenate([np.zeros(int(pad * sr), dtype=np.float32), audio[int(start_s * sr): int(min(len(audio) / sr, end_s) * sr)]])
        fd, tmp = tempfile.mkstemp(suffix=".wav")
        os.close(fd)
        try:
            with wave.open(tmp, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(sr)
                w.writeframes((np.clip(clip, -1.0, 1.0) * 32767).astype("<i2").tobytes())
            saved, self._env = getattr(self, "_env", None), None                       # the full-file envelope does not describe this clip
            t_run = time.monotonic()
            try:
                sub = run(tmp)
            finally:
                self._env = saved
                if getattr(self, "_budget", None) is not None:
                    self._budget.note_attempt(time.monotonic() - t_run)          # the time limit does not start an attempt that would end past its share
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass
        offset = start_s - pad
        moved = []
        for w in sub["words"]:
            w = dict(w)
            w["start"], w["end"] = round(w["start"] + offset, 3), round(w["end"] + offset, 3)
            if w["end"] > start_s:                                                     # anything inside the added silence is not speech
                w["start"] = max(start_s, w["start"])
                moved.append(w)
        return moved

    def _decode_head(self, audio, mode: str, kw: dict, pad: float, end_s: float) -> list[dict]:
        """The first ``end_s`` seconds, decoded again with the file's own language route (see ``_rescue_head``)."""
        return self._decode_window(audio, 0.0, end_s, pad, lambda p: self._transcribe_once(p, mode, None, batched=False, **kw))

    def _cut_points(self, dur: float) -> list[float]:
        """Window borders about ``coverage.WINDOW_PASS_S`` apart, each moved to the quietest moment within ``WINDOW_PASS_SLACK_S`` (a pause between words, so no
        word is cut in two). Without a loudness envelope the borders are simply evenly spaced."""
        env = getattr(self, "_env", None)
        pts = [0.0]
        t = 0.0
        while dur - t > cov.WINDOW_PASS_S + cov.WINDOW_PASS_SLACK_S:
            lo, hi = t + cov.WINDOW_PASS_S - cov.WINDOW_PASS_SLACK_S, t + cov.WINDOW_PASS_S + cov.WINDOW_PASS_SLACK_S
            c = t + cov.WINDOW_PASS_S
            if env and env.get("db"):
                hop, db = env["hop"], env["db"]
                k = max(1, int(0.15 / hop))
                best = None
                for i in range(int(lo / hop), min(int(hi / hop), len(db) - k)):
                    level = sum(db[i:i + k]) / k
                    if best is None or level < best[0]:
                        best = (level, (i + k / 2) * hop)
                if best:
                    c = best[1]
            pts.append(c)
            t = c
        pts.append(dur)
        return pts

    def _windowed_pass(self, path: str, sk_words: list[dict], progress: Progress, kw: dict, stage: str = "windowed") -> Optional[dict]:
        """The Hinglish model's words for the whole file decoded in short windows cut at pauses (``coverage.APEX_WINDOWED``) — EVIDENCE of Hindi, not the text
        that is used. On the long-form pass the model sees mostly English and then writes Hindi as English too ("bahut zyada overcrowded hai" came out as "is a lot
        of overcrowded", exactly like the stock model's translation, so nothing betrayed the Hindi). In short windows it hears the Hindi. As the main pass the
        windows were MEASURED to be less accurate (whoami clip: 6 % → 11 % word error, cut words and invented ones), so the long-form pass stays the text and
        the windows only supply the Hindi where the long-form pass has none (``_add_window_evidence``). Returns None when switched off or on any failure."""
        if not cov.APEX_WINDOWED:
            return None
        model = self._get(self.hinglish_model)
        try:
            from faster_whisper.audio import decode_audio
            from .hybrid import has_content
            audio = decode_audio(path, sampling_rate=16000)
            dur = len(audio) / 16000.0
            sub_kw = {k: v for k, v in kw.items() if k not in ("batched", "initial_prompt", "repetition_penalty", "no_repeat_ngram_size")}
            pts = self._cut_points(dur)
            words: list[dict] = []
            redone = 0
            for n, (a, b) in enumerate(zip(pts, pts[1:])):
                got = self._redecode(audio, a, b, sk_words, sub_kw, cov.WINDOW_PASS_ATTEMPTS, first_ok=True, stage=stage)
                if got is None:
                    got = []
                    if sum(1 for w in sk_words if a <= (w["start"] + w["end"]) / 2 < b and has_content(w["text"])) >= 3:      # (an empty answer for a silent window is normal)
                        redone += 1
                for w in got:
                    w["id"] = f"hw{len(words) + 1:06d}"
                    words.append(w)
                if progress:
                    progress((n + 1) / (len(pts) - 1))
            if not any(has_content(w["text"]) for w in words) and dur > 1.0:
                return None
            return {"schema": 1, "source": {"file": os.path.abspath(path), "duration": round(dur, 3)}, "engine": {"model": model.model_ref, "windowed": True},
                    "language": {"mode": "hinglish", "detected": "hi", "probability": 1.0}, "words": words, "segments": [], "warnings":
                    ([f"{redone} window(s) of the Hinglish model gave no usable answer"] if redone else [])}
        except Exception as exc:                                                     # never fail the transcription over this: without it the result is what it was before
            print(f"[engine] windowed Hinglish pass skipped ({type(exc).__name__}: {exc})", flush=True)
            return None

    def _tighten_hindi(self, path: str, sk_words: list[dict], hg: dict, kw: dict) -> tuple[dict, int]:
        """Each Hindi stretch that replaces a translation is decoded once more on its OWN (the stretch plus a quarter second): in an 8 s window that is mostly
        English the model's Hindi comes out garbled ("iskoi cost aadity" for "is skill ko master karna hai") and its repeated English leaks into the stretch. Several
        attempts are made; an answer needs at least two Hindi words and not much fewer words than the stretch has now; the most confident one (mean word
        probability) wins. Returns (pass, number of stretches changed). Never raises."""
        spans = translated_spans(sk_words, hg["words"])
        if not spans or not cov.TIGHT_ATTEMPTS:
            return hg, 0
        try:
            from faster_whisper.audio import decode_audio
            from .hindi_words import HINDI_WORDS, WEAK_HINDI_WORDS
            from .hybrid import has_content, is_devanagari
            audio = decode_audio(path, sampling_rate=16000)
            dur = len(audio) / 16000.0
            sub_kw = {k: v for k, v in kw.items() if k not in ("batched", "initial_prompt", "repetition_penalty", "no_repeat_ngram_size")}
            mid = lambda w: (w["start"] + w["end"]) / 2
            words = [dict(w) for w in hg["words"]]
            new: list[dict] = []
            inside: set[str] = set()
            n_changed = 0
            for t0, t1 in spans:
                a, b = max(0.0, t0 - 0.25), min(dur, t1 + 0.25)
                now = [w for w in words if a <= mid(w) < b]
                best = None
                for rp, ng, pad in cov.TIGHT_ATTEMPTS:
                    if self._expired("tight"):
                        break
                    moved = self._decode_window(audio, a - pad, b + pad, 0.0, lambda p, rp=rp, ng=ng: self._get(self.hinglish_model).transcribe(
                        p, "hinglish", initial_prompt="", batched=False, repetition_penalty=rp or None, no_repeat_ngram_size=ng or None, **sub_kw))
                    cand = [w for w in moved if a <= mid(w) < b and has_content(w["text"]) and not is_devanagari(w["text"])]
                    toks = [_norm(w["text"]) for w in cand]
                    hits = [t for t in toks if t in HINDI_WORDS]
                    if (not cand or self._looped(cand) or len(hits) < 2 or all(t in WEAK_HINDI_WORDS for t in hits)
                            or len(cand) < cov.LOOP_MIN_SHARE * len(now)):
                        continue
                    score = sum(w.get("confidence", 0.5) for w in cand) / len(cand)
                    if best is None or score > best[0]:
                        best = (score, cand)
                if best:
                    n_changed += 1
                    inside |= {w["id"] for w in now}
                    for w in best[1]:
                        w["origin"] = "hinglish_model"
                        w["id"] = f"ht{len(new) + 1:06d}"
                        new.append(w)
            if new:
                hg = {**hg, "words": self._replace_words(words, new, inside)}
            return hg, n_changed
        except Exception as exc:                                                       # a safety net must never break the transcription itself
            print(f"[engine] tight Hindi decode skipped: {type(exc).__name__}: {exc}", flush=True)
            return hg, 0

    def _add_window_evidence(self, sk_words: list[dict], hg: dict, hw: dict) -> tuple[dict, int]:
        """Where the windowed pass shows a Hindi stretch the stock model translated (``translated_spans``) but the long-form pass does not, the long-form words of
        that stretch are replaced by the windowed ones. Everything else stays as the long-form pass wrote it. Returns (pass, number of stretches)."""
        spans_w = translated_spans(sk_words, hw["words"])
        if not spans_w:
            return hg, 0
        spans_h = translated_spans(sk_words, hg["words"])
        new_spans = [s for s in spans_w if not any(min(s[1], h[1]) - max(s[0], h[0]) > 0.5 * (s[1] - s[0]) for h in spans_h)]
        if not new_spans:
            return hg, 0
        mid = lambda w: (w["start"] + w["end"]) / 2
        new = [dict(w) for w in hw["words"] if any(a - 0.05 <= mid(w) <= b + 0.05 for a, b in new_spans)]
        for k, w in enumerate(new):
            w["origin"] = "hinglish_model"
            w["id"] = f"hv{k + 1:06d}"
        inside = {w["id"] for w in hg["words"] if any(a - 0.05 <= mid(w) <= b + 0.05 for a, b in new_spans)}
        return {**hg, "words": self._replace_words([dict(w) for w in hg["words"]], new, inside)}, len(new_spans)

    @staticmethod
    def _looped(words: list[dict]) -> bool:
        """Does this word list loop? (three identical words in a row, or a handful of words with almost no variety)"""
        toks = [_norm(w["text"]) for w in words if _norm(w["text"])]
        return any(a == b == c for a, b, c in zip(toks, toks[1:], toks[2:])) or (len(toks) >= 6 and len(set(toks)) / len(toks) < 0.4)

    def _repair_hinglish_loops(self, path: str, hg: dict, kw: dict, reference: Optional[list[dict]] = None) -> tuple[dict, dict]:
        """The Hinglish model sometimes falls into a loop ("ki vah, vah, vah, vah, …", seen for 15+ seconds on a real clip). The looped words are junk and are
        never imported, so EVERY Hindi stretch inside the loop stayed in Devanagari, was flagged ``non_roman`` and left out of the captions: "no Hinglish
        words". Each looped stretch is decoded again in short windows with a repetition penalty; the first answer that does not loop replaces the loop.
        ``reference`` = the stock model's words: an answer must be about as long as what the stock model heard in that window (a decode that stops after
        the first sentence is no answer; seen on a real clip). Returns (hinglish pass, {"loops", "windows", "words", "failed"}). Never raises."""
        info = {"loops": 0, "windows": 0, "words": 0, "failed": 0}
        if not cov.LOOP_REPAIR:
            return hg, info
        seg_of = {i: s for s in hg.get("segments", []) for i in s.get("word_ids", [])}
        spans: list[list[float]] = []
        for w in sorted((w for w in hg["words"] if {"repeat_run", "repeat_phrase"} & set(w.get("flags", []))), key=lambda w: w["start"]):
            s = seg_of.get(w["id"])
            a, b = (min(w["start"], s["start"]), max(w["end"], s["end"])) if s else (w["start"], w["end"])    # the audio the decoder was working on, not just the squeezed words
            if spans and a - spans[-1][1] < 1.0:
                spans[-1][1] = max(spans[-1][1], b)
            else:
                spans.append([a, b])
        if not spans:
            return hg, info
        info["loops"] = len(spans)
        try:
            from faster_whisper.audio import decode_audio
            audio = decode_audio(path, sampling_rate=16000)
            dur = len(audio) / 16000.0
            sub_kw = {k: v for k, v in kw.items() if k not in ("batched", "initial_prompt", "repetition_penalty", "no_repeat_ngram_size")}
            words = [dict(w) for w in hg["words"]]
            new: list[dict] = []
            from .hybrid import has_content, is_devanagari
            for t0, t1 in spans:
                a = max(0.0, t0 - cov.LOOP_PAD_S)
                end = min(dur, t1 + cov.LOOP_PAD_S)
                while a < end - 0.3:
                    b = min(end, a + cov.LOOP_CHUNK_S)
                    info["windows"] += 1
                    got = self._redecode(audio, a, b, reference, sub_kw, cov.LOOP_ATTEMPTS, stage="loops")
                    if got:
                        for w in got:
                            w["id"] = f"hl{len(new) + 1:06d}"
                            new.append(w)
                    else:
                        info["failed"] += 1
                    a = b
            if new:
                # replaced: the looped words themselves, and any other word the new ones overlap (or repeat within a moment) — everything else stays as it was
                junk = {w["id"] for w in words if {"repeat_run", "repeat_phrase"} & set(w.get("flags", []))}
                hg = {**hg, "words": self._replace_words(words, new, junk)}
                info["words"] = len(new)
        except Exception as exc:                                                       # a safety net must never break the transcription itself
            print(f"[engine] Hinglish loop repair skipped: {type(exc).__name__}: {exc}", flush=True)
        return hg, info

    def _redecode(self, audio, a: float, b: float, reference: Optional[list[dict]], sub_kw: dict, attempts, first_ok: bool = False,
                  stage: Optional[str] = None) -> Optional[list[dict]]:
        """The Hinglish model decodes ``audio[a:b]`` on its own (short windows are far more reliable than its long-form pass: fewer loops, less garble — but a
        single short decode is still fickle: the same window came out right in two runs and as "Coachinging business bahuthings. I am content." in a third).
        Several attempts ((repetition_penalty, no_repeat_ngram_size, seconds of context on both sides), 0 = off) are made; an answer must not loop and must be about
        as long as what the stock model heard there (``reference``). The first answer in which at least ``REDECODE_GOOD_AGREEMENT`` of the stock model's words are
        matched wins at once (the stock model's English is reliable: a decode that reproduces it is a good decode); otherwise the best-agreeing answer is used.
        Returns its Latin words with mid inside [a, b), or None."""
        from .hybrid import agreement, has_content, is_devanagari
        n_ref = sum(1 for w in (reference or []) if a <= (w["start"] + w["end"]) / 2 < b and has_content(w["text"]))
        best: Optional[tuple[float, list[dict]]] = None
        for rp, ng, pad in attempts:
            if stage and self._expired(stage):                                      # time limit of the extra passes used up: keep what the earlier attempts gave
                break
            moved = self._decode_window(audio, a - pad, b + pad, 0.0, lambda p, rp=rp, ng=ng: self._get(self.hinglish_model).transcribe(
                p, "hinglish", initial_prompt="", batched=False, repetition_penalty=rp or None, no_repeat_ngram_size=ng or None, **sub_kw))
            cand = [w for w in moved if a <= (w["start"] + w["end"]) / 2 < b and has_content(w["text"]) and not is_devanagari(w["text"])]
            enough = len(cand) / (b - a) >= cov.LOOP_MIN_WORDS_PER_S
            if n_ref >= 3:                                                          # the stock model heard n_ref words here: the answer must not be much shorter
                enough = enough and len(cand) >= cov.LOOP_MIN_SHARE * n_ref
            if not (cand and not self._looped(cand) and enough):
                continue
            score = agreement(reference or [], cand, a, b)[2] / n_ref if n_ref >= 3 and not first_ok else 1.0         # first_ok: the first usable answer wins (main pass)
            if score >= cov.REDECODE_GOOD_AGREEMENT:
                best = (score, cand)
                break
            if best is None or score > best[0]:
                best = (score, cand)
        if best is None:
            return None
        for w in best[1]:
            w["origin"] = "hinglish_model"
        return best[1]

    @staticmethod
    def _replace_words(words: list[dict], new: list[dict], drop: set[str]) -> list[dict]:
        """``words`` without ``drop`` and without any word the ``new`` ones overlap (by more than half of its own length) or repeat within a moment, plus ``new``."""
        drop = set(drop)
        for w in words:
            wdur = max(w["end"] - w["start"], 1e-3)
            wn = _norm(w["text"])
            if any(min(w["end"], n["end"]) - max(w["start"], n["start"]) > 0.5 * wdur
                   or (wn and wn == _norm(n["text"]) and max(n["start"] - w["end"], w["start"] - n["end"]) < 0.3) for n in new):
                drop.add(w["id"])
        return sorted([w for w in words if w["id"] not in drop] + new, key=lambda w: (w["start"], w["end"]))

    def _second_opinion(self, path: str, sk_words: list[dict], hg: dict, kw: dict) -> tuple[dict, dict]:
        """The Hinglish model's long-form pass is sometimes wrong in a way that is not a loop: garbled English ("starts USB Or artists but you know") where the
        stock model has the right words, or nothing at all. In that case the stock model's TRANSLATION of Hindi cannot be seen either, because the proof of Hindi
        is the Hinglish model's own Hindi words: "bahut zyada overcrowded hai" came out as the caption "is a lot of overcrowded". Every window of
        ``coverage.SECOND_OPINION_WINDOW_S`` seconds where the two recognisers agree on fewer than ``SECOND_OPINION_MIN_AGREE`` of the stock model's English
        words is decoded again by the Hinglish model alone (short window); its answer replaces the long-form words of that window. Returns (pass, info). Never raises."""
        from .hybrid import agreement
        info = {"windows": 0, "words": 0, "failed": 0}
        if not cov.SECOND_OPINION:
            return hg, info
        try:
            from faster_whisper.audio import decode_audio
            audio = decode_audio(path, sampling_rate=16000)
            dur = len(audio) / 16000.0
            sub_kw = {k: v for k, v in kw.items() if k not in ("batched", "initial_prompt", "repetition_penalty", "no_repeat_ngram_size")}
            new: list[dict] = []
            redone: list[tuple[float, float]] = []
            a = 0.0
            while a < dur - 0.5:
                b = min(dur, a + cov.SECOND_OPINION_WINDOW_S)
                n_hg, n_sk, agree = agreement(sk_words, hg["words"], a, b)
                if n_sk >= 3 and agree < cov.SECOND_OPINION_MIN_AGREE * n_sk:
                    info["windows"] += 1
                    got = self._redecode(audio, a, b, sk_words, sub_kw, cov.SECOND_OPINION_ATTEMPTS, stage="second")
                    if got:
                        redone.append((a, b))
                        for w in got:
                            w["id"] = f"hs{len(new) + 1:06d}"
                            new.append(w)
                    else:
                        info["failed"] += 1
                a = b
            if new:
                inside = {w["id"] for w in hg["words"] if any(x <= (w["start"] + w["end"]) / 2 < y for x, y in redone)}      # the long-form words of a redone window are replaced
                hg = {**hg, "words": self._replace_words([dict(w) for w in hg["words"]], new, inside)}
                info["words"] = len(new)
        except Exception as exc:                                                       # a safety net must never break the transcription itself
            print(f"[engine] second opinion skipped: {type(exc).__name__}: {exc}", flush=True)
        return hg, info

    def _rescue_hindi_runs(self, path: str, hg: dict, res: dict, kw: dict) -> tuple[dict, int]:
        """A Hindi stretch the stock model heard (Devanagari) but the Hinglish model did NOT write down stays Devanagari, is flagged ``non_roman`` and is left
        out of the captions — a missing caption in the middle of speech. The Hinglish model is asked again for just that stretch (with a run-in of silence);
        its words are added to its pass and the merge is redone. Returns (hinglish pass, number of words added). Never raises."""
        spans: list[list[float]] = []
        for w in sorted((w for w in res["words"] if w.get("origin") == "skeleton_devanagari"), key=lambda w: w["start"]):
            if spans and w["start"] - spans[-1][1] < 0.8:
                spans[-1][1] = max(spans[-1][1], w["end"])
            else:
                spans.append([w["start"], w["end"]])
        if not spans:
            return hg, 0
        added = 0
        try:
            from faster_whisper.audio import decode_audio
            audio = decode_audio(path, sampling_rate=16000)
            sub_kw = {k: v for k, v in kw.items() if k not in ("batched", "initial_prompt")}
            known = list(hg["words"])
            from .hybrid import has_content, is_devanagari
            for t0, t1 in spans:
                n_sk = sum(1 for w in res["words"] if w.get("origin") == "skeleton_devanagari" and t0 - 0.01 <= w["start"] <= t1 + 0.01)
                best = None
                for pad, after in cov.WINDOW_ATTEMPTS:                                # a short decode is fickle: several windows, the most plausible one wins
                    if self._expired("rescue"):
                        break
                    moved = self._decode_window(audio, t0 - 1.0, t1 + after, pad, lambda p: self._get(self.hinglish_model).transcribe(
                        p, "hinglish", initial_prompt="", batched=False, **sub_kw))
                    cand = [w for w in moved if t0 - 0.15 <= (w["start"] + w["end"]) / 2 <= t1 + 0.15 and has_content(w["text"]) and not is_devanagari(w["text"])
                            and not any(min(w["end"], k["end"]) - max(w["start"], k["start"]) > 0.5 * (w["end"] - w["start"]) for k in known)]
                    toks = [_norm(w["text"]) for w in cand]
                    if not cand or any(a == b == c for a, b, c in zip(toks, toks[1:], toks[2:])) or (len(toks) > 1 and len(set(toks)) == 1):
                        continue                                                          # nothing, or a loop ("stories stories stories"): not usable
                    score = abs(len(cand) - n_sk)                                         # the stock model heard n_sk words there: the answer should be about as long
                    if best is None or score < best[0]:
                        best = (score, cand)
                    if score == 0:
                        break
                if best is not None and best[0] <= max(1, n_sk):
                    for w in best[1]:
                        w["origin"] = "hinglish_model"
                        w["id"] = f"hw{len(known) + 1:06d}"
                        known.append(w)
                    added += len(best[1])
            if added:
                known.sort(key=lambda w: (w["start"], w["end"]))
                hg = {**hg, "words": known}
        except Exception as exc:                                                       # a safety net must never break the transcription itself
            print(f"[engine] Hindi window rescue skipped: {type(exc).__name__}: {exc}", flush=True)
        return hg, added

    def _transcribe_once(self, path: str, language_mode: str = "english", progress: Progress = None, **kw) -> dict:
        warnings: list[str] = []
        prompt_used = None
        auto_info = None
        route = language_mode
        t_begin = time.monotonic()

        if language_mode == "english":
            res = self._get(self.english_model).transcribe(path, "english", progress=progress, **kw)
        elif language_mode == "hinglish":
            res, prompt_used, warnings = self._hinglish(path, progress, kw, t_begin=t_begin)
        elif language_mode == "auto":
            sk = self._skeleton(path, _slice(progress, 0.0, 0.3), dict(kw))
            n = len(sk["words"])
            d = sum(is_devanagari(w["text"]) for w in sk["words"])
            hindi = bool(n) and d >= self.auto_min_devanagari and d / n >= self.auto_min_fraction
            hg = None
            translated_words = 0
            if not hindi and self.auto_check_translated and self.hinglish_strategy == "hybrid" and self.hinglish_model_available():
                # the stock model may have TRANSLATED the Hindi into English (no Devanagari at all): ask the Hinglish model whether it hears Hindi words there
                self._budget = self._open_budget(time.monotonic() - t_begin, (sk.get("source") or {}).get("duration"))     # the decision pass is an extra too: it must not run for ever
                try:
                    hg = self._windowed_pass(path, sk["words"], _slice(progress, 0.3, 0.6), kw, stage="decide")
                finally:
                    self._budget = None
                spans = translated_spans(sk["words"], hg["words"]) if hg else []
                translated_words = sum(1 for h in (hg or {"words": []})["words"] if any(a - 0.05 <= (h["start"] + h["end"]) / 2 <= b + 0.05 for a, b in spans))
                hindi = translated_words >= self.auto_min_devanagari
            route = "hinglish" if hindi else "english"
            auto_info = {"devanagari_words": d, "words": n, "fraction": round(d / n, 3) if n else 0.0, "translated_hindi_words": translated_words, "decision": route}
            if hindi:
                res, prompt_used, warnings = self._hinglish(path, _slice(progress, 0.6, 1.0), kw, skeleton=sk, windowed=hg, t_begin=t_begin)
            else:
                res = self._get(self.english_model).transcribe(path, "english", progress=_slice(progress, 0.6, 1.0), **kw)
        else:
            raise ValueError("language_mode must be english, hinglish or auto")

        counts = flag_words(res["words"], res["segments"], "hinglish" if route == "hinglish" else "english", prompt_used)
        res["language"]["mode"] = language_mode
        res["language"].setdefault("route", route)
        if auto_info:
            res["language"]["auto"] = auto_info
        res["quality"] = {**(res.get("quality") or {}), "flag_counts": counts}
        res["warnings"] = warnings + res["warnings"] + [
            f"{n} word(s) flagged '{f}' — review in transcript editor" for f, n in counts.items()]
        return res
