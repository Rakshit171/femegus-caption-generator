"""Make the pip-installed NVIDIA CUDA 12 / cuDNN 9 DLLs visible to CTranslate2 on Windows.

Must run BEFORE ``ctranslate2`` / ``faster_whisper`` are imported. No system-wide CUDA toolkit is needed:
the DLLs come from the ``nvidia-cublas-cu12`` / ``nvidia-cudnn-cu12`` wheels inside the project venv.
"""
from __future__ import annotations

import importlib.util
import os
import sys

_PACKAGES = ("nvidia.cublas", "nvidia.cudnn", "nvidia.cuda_nvrtc", "nvidia.cuda_runtime")
_done = False


def prepare_cuda_dlls() -> list[str]:
    """Add every nvidia wheel ``bin`` directory to the DLL search path. Returns the directories added."""
    global _done
    added: list[str] = []
    if _done or sys.platform != "win32":
        _done = True
        return added
    for pkg in _PACKAGES:
        try:
            spec = importlib.util.find_spec(pkg)
        except (ModuleNotFoundError, ValueError):
            continue
        if spec is None or not spec.submodule_search_locations:
            continue
        for loc in spec.submodule_search_locations:
            bin_dir = os.path.join(loc, "bin")
            if os.path.isdir(bin_dir):
                os.add_dll_directory(bin_dir)
                os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")
                added.append(bin_dir)
    _done = True
    return added


# The CUDA libraries CTranslate2 needs at the first real use (it loads a model on the GPU WITHOUT them and only fails when it computes). CTranslate2's wheel
# brings its own cuDNN; cuBLAS comes only from the nvidia-cublas-cu12 wheel (requirements-gpu.txt).
REQUIRED_DLLS = ("cublas64_12.dll", "cublasLt64_12.dll")


def cuda_libs_missing() -> list[str]:
    """The required CUDA DLLs that cannot be loaded on this computer ([] = all there, or not Windows). Field report 2026-11-11: with cublas64_12.dll missing
    the first GPU model failed and fell back to the processor, and the SECOND model put on the GPU afterwards froze forever inside CTranslate2 (reproduced:
    no error, no processor use) - so the engine must know this BEFORE any model goes onto the GPU. Never raises."""
    if sys.platform != "win32":
        return []
    prepare_cuda_dlls()
    missing = []
    import ctypes
    for name in REQUIRED_DLLS:
        try:
            ctypes.WinDLL(name)
        except OSError:
            missing.append(name)
    return missing
