# The caption editor (local web app) — Stage 6

A small web app that runs **only on your computer** (`127.0.0.1`), opens in your browser, and covers the whole workflow: video → transcription → correct the
transcript and timing → grouping → look (typography, colours, animation, layout, presets) → live preview → generate editable layers in After Effects.
Nothing is uploaded anywhere; the page loads no external scripts, fonts or images.

## Start it (PowerShell, in `C:\Claude\AE caption Gen`)
```powershell
.\scripts\fcgapp.ps1
```
It prints an address with a one-time token and opens it. Leave the window open; Ctrl+C stops it. It resumes your last project.

## The ten sections
| # | Section | What it does |
|---|---|---|
| 1 | Video & input | choose the file (native picker or paste a path), language (Auto / English / Hinglish), run local transcription with a progress bar, import an existing `transcript.json`, recent projects (with the space each uses; tick one or more and **Delete selected…** to free the space — see "Deleting projects" below) |
| 2 | Transcript & timing | one row per word, grouped by caption: edit text and start/end, flip accent/support (A/s), force a caption break, delete, insert a missed word, play from a word, per-caption layout, display glossary (crr→crore), restore excluded/deleted words, style just the ticked words |
| 3 | Caption grouping | max/min/preferred words, characters, seconds; pause thresholds; reveal delay; onset correction; hold times (all the knobs of `docs/SEGMENTER.md`) |
| 4 | Caption look | gallery of looks (built-in + yours) with live thumbnails; **Use this look** replaces the whole style in one click (timing/wording untouched); save the current look as a new preset (`presets/` built-in read-only, `presets/user/` yours); for looks with several key-word treatments: tick which are used, rotate/fixed, edit each; for looks with a switch (Clean 4-Word: **Smooth slide-up animation**) an ON / OFF button; a look can also set the caption grouping (shown in section 3) |
| 5 | Typography | per role (support / accent): font (any installed font), size, tracking, caps, max line width, where key words sit (own line / inline); edit all layouts, one layout's overrides, or one key-word treatment |
| 6 | Colours & emphasis | fill type (solid / gradient), outline, drop shadow, glow |
| 7 | Animation | reveal per word or **letter by letter** (letter delay, fade, blur, rise, tint while revealing), or word duration, easing (presets or custom bezier), slide, scale, fade, blur |
| 8 | Position & layout | layout template (auto / tiers / stack / flow / **centered**) and auto pattern, vertical/horizontal position, width, safe margin, spacing |
| 9 | Generate in AE | connection status; builds the layers and shows the result **verified inside After Effects** |
| 10 | Export & help | **Subtitles (.srt)** (download button; one cue per caption, or a word-by-word build-up; shows the cue count and the first cues), `groups.json`, **Updates** (check for new versions and new caption looks, install them, go back to the previous version; automatic check is off unless you switch it on — see UPDATES.md), system check, **Deep check** (really runs both speech models on a 20 s sample in a separate process and reports every step: device, speed, waiting vs working, an estimate; `deepcheck.py`, report in `work\deep_check.txt`), diagnostics, troubleshooting |

Preview: the video with captions drawn on top; click the timeline to seek, Space = play/pause, ←/→ = 0.1 s (Shift = 1 s). Timing, layout and motion are exact;
glow, blur and drop shadow are approximations of After Effects' effects.

## Where everything is stored
`projects/<video-name>-<hash>/` : `transcript.json` (engine output, never edited) · `overrides.json` (every manual correction) · `envelope.json` · `groups.json` ·
`project.json` (settings + style). Corrections live only in `overrides.json`, so re-grouping or restyling never loses them.

## Connecting After Effects
After Effects must run `adapters\jsx-core\fcg_connect.jsx` once per session (File ▸ Script ▸ Run Script File…); the app shows "connected" within ~10 s.
Needs *Preferences ▸ Scripting & Expressions ▸ Allow Scripts to Write Files and Access Network*. (Until Stage 8 this file was called `fcg_dev_watch.jsx`; it was renamed to
`fcg_connect.jsx`, channel files `heartbeat_connect.txt` / `job_connect.json`.) A job is a JSON file dropped in `work\ae_inbox`; the report comes back as a file. A modal dialog inside After Effects blocks it.

**Every generation is checked** (`core/fcg_core/ae_verify.py`): the layers are read back and compared with the captions — never earlier than the word's reveal, no overlaps,
texts correct — and (new) that the **requested style actually applied** (size, colour, font, effects). The UI shows ✓ or the problems.

## Security
Bound to 127.0.0.1 · random per-session token in an HttpOnly cookie · Host header must be local (DNS-rebinding guard) · no CORS · static files served only from `app/web`
and two shared source files · video served with Range support from the project's own file only · presets: strict names, built-ins read-only ·
`/api/dev/save-json` (dev aid) writes only `work/devdump/<strict-name>.json`.

## Tests
* `tests/app/test_server.py` — 12 API tests incl. security, edits-never-change-timing, Range streaming, presets, exports, and a **real transcription job through the API**.
* `tests/app/test_preview_parity.py` — browser preview vs real After Effects layout.
* The browser UI itself was driven by hand in the built-in browser (open → transcribe → edit a word → load preset → generate in After Effects); there is no automated browser test yet.

## Preview parity (measured, real data)
Same captions + style (345 words, 1080×1920): browser vs After Effects — position mean error **0.56 px (x) / 0.33 px (y)**, shrink-fit factor identical for all 345 words,
ink height within 0.4 px, ink width within ~2 px (max 4 px). Two bugs found by this comparison and fixed: (1) After Effects' *All Caps option* lays text out ~5 % wider than typed
capitals → capitals are now typed into the layer; (2) a broken edit had silently stopped the text style from applying (timing checks could not see it) → the style check above.
Animation maths parity with After Effects keyframes: ≤ 0.014 px (see AE_ADAPTER.md).

## Audio-only files and missing-speech warnings (Stage 7)
* **Audio files** (mp3, wav, m4a…) work: the preview shows a black 9:16 stage with the captions, and After Effects gets a 1080×1920 composition with the sound as a layer.
* After transcription the app checks the **speech coverage**: loud audio with no recognised words is marked red on the timeline and listed in section 1 with a ▶ button, so a
  dropped stretch is never silent. A second decoding pass fills such holes automatically when it can.
* **Start of the clip (v0.9.6):** a clip cut in the middle of a sentence has no lead-in and the speech decoder often skips its first words (seen on every real Hinglish clip tried). Uncovered speech of 0.6 s or more is now filled from a second decoding pass, and if the very start is still empty the first seconds are decoded once more on their own (behind one second of silence, same language route) and only used to fill that hole. Holes of 1.5 s or more that nothing could fill are still marked red. Tests: `tests/engine/test_coverage.py`; measurements in TESTING.md.
* Files that are not audio/video are refused with a clear message; a missing model gives plain-language instructions.

## Deleting projects (v0.9.5)
Section 1 ▸ Recent projects: each project shows its size on disk; tick projects (or *select all*) and press **Delete selected…**, then confirm.
* Removed: exactly the files the app creates in `projects\<id>\` (`project.json`, `transcript/overrides/envelope/groups.json`, `preview.mp4`, `ae_report_*.json`, temporary `*.tmp`). `project.json` goes last, so an interrupted deletion leaves a project that can be deleted again.
* Never removed: the original video/audio (the project only stores its path), unknown files or sub-folders in the project folder (reported, left in place), other projects, After Effects content.
* Refused: ids that are not plain names, links/junctions, folders without `project.json`, and any request while a background task is running. Deleting the open project closes it and forgets it as the "last project".
* API: `POST /api/projects/delete {"ids": [...]}` → `{deleted, failed, freed, closed_current}`. Tests: `tests/app/test_project_delete.py`.

## One-click fixes in the system check (v0.9.8)
`GET /api/selfcheck` returns, per problem, a `fix_action` (+ label, size, internet need) and `fix_all` (the order for "Fix everything"). `POST /api/fix/<action>` runs it: `english_model`, `hinglish_model`, `register_hinglish` as background jobs (`fix-…`, progress + cancel, one at a time, 409 otherwise); `repair` / `repair_gpu` write `work
epair.flag` and restart through the launcher; `show_connect_script` opens Explorer. Code: `app/fcg_app/fixes.py`, `selfcheck.py` (`FIX_META`), `panel_ae.js` (`systemCheckCard`). Tests: `tests/app/test_fixes.py`. Details for users: TROUBLESHOOTING.md.

## Hinglish text polish (v0.9.7)
Section 2 ▸ *Hinglish text polish*: Automatic (on for Hinglish transcripts) / Always on / Off. Lists every change it made (spelling, numbers, homophones, punctuation, capitals) and the amounts
that may have lost their number (*Please check*, ▶ plays the spot). Words you edited, glossary entries and timing are never touched. Rules and measurements: HINGLISH_STYLE.md.

## Known limitations
* Glow / blur / shadow in the preview are approximations (the motion, layout and timing are exact).
* No automatic face avoidance — set the vertical position (section 8).
* Editing the text of a *merged* word (e.g. `15 ,000`) edits its first piece only.
* "Update" = rebuild the generated layers; hand edits made inside those layers in After Effects are replaced.
* Only After Effects 25.2 has been tested.
