"""Operations the API exposes: transcribe, envelope, build groups, SRT export, diagnostics. Heavy imports are lazy so the server starts fast."""
from __future__ import annotations

import os
import sys
import threading
import time
from typing import Optional

from .project import Project

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
for sub in ("core", "engine"):
    p = os.path.join(ROOT, sub)
    if p not in sys.path:
        sys.path.insert(0, p)

try:                                         # applies the PyAV compatibility layer (engine/fcg_engine/compat.py) before anything decodes audio or video
    import fcg_engine  # noqa: F401
except Exception:                            # a broken engine install is reported by the System check, not by a crash at start-up
    pass

_engine = None
_engine_key = None
_engine_lock = threading.Lock()


def friendly_error(exc: BaseException) -> str:
    """Turn a raw library error into something a non-programmer can act on, keeping the original text at the end for support."""
    text = f"{type(exc).__name__}: {exc}"
    low = text.lower()
    if isinstance(exc, (ValueError, FileNotFoundError)) and "could not be read" in low:
        return str(exc)                                              # already worded for the user (media_error)
    if "unexpected keyword argument" in low or "has no attribute" in low or "cannot import name" in low or isinstance(exc, (ImportError, AttributeError)):
        hint = ("A component of this installation has a different version than the one this tool was tested with. "
                "Open section 10 and press 'Repair components' (needs internet, a few minutes), then try again.")
    elif "cublas" in low or "cudnn" in low or "cuda" in low or "out of memory" in low:
        hint = "The graphics card could not be used. Try again (the tool continues on the processor), or run Install-FemeGus.cmd again."
    elif isinstance(exc, MemoryError) or "memoryerror" in low:
        hint = "The computer ran out of memory. Close other programs, or try a shorter file."
    elif isinstance(exc, PermissionError) or "permission" in low:
        hint = "Windows would not let the tool read or write a file. Move the install folder out of protected places such as Program Files, or check antivirus."
    else:
        hint = "If this keeps happening, open section 10, press 'Copy support info' and send it to the person who gave you the tool."
    return f"{hint}  [Details: {text[:300]}]"


def get_engine(strategy: str = "hybrid"):
    """One Engine per process: the Whisper models stay loaded between jobs."""
    global _engine, _engine_key
    with _engine_lock:
        if _engine is None or _engine_key != strategy:
            from fcg_engine.engine import Engine
            _engine = Engine("auto", os.path.join(ROOT, "engine", "models_local.json"), hinglish_strategy=strategy)
            _engine_key = strategy
        return _engine


def probe(video: str) -> dict:
    """Size / frame rate / duration of the video (PyAV ships with faster-whisper). Falls back to None fields on failure."""
    try:
        import av
        with av.open(video) as c:
            v = next((s for s in c.streams if s.type == "video"), None)
            has_audio = any(s.type == "audio" for s in c.streams)
            dur = float(c.duration / 1_000_000) if c.duration else None
            if v is None:
                return {"width": None, "height": None, "fps": None, "duration": dur, "has_video": False, "has_audio": has_audio}
            fps = float(v.average_rate) if v.average_rate else None
            vdur = float(v.duration * v.time_base) if v.duration and v.time_base else dur       # the container may be longer (audio tail)
            return {"width": v.codec_context.width, "height": v.codec_context.height, "fps": fps, "duration": vdur, "has_video": True,
                    "has_audio": has_audio}
    except Exception:
        return {"width": None, "height": None, "fps": None, "duration": None, "has_video": False, "has_audio": False}


def preview_path(project: Project) -> str:
    return os.path.join(project.folder, "preview.mp4")


def preview_ready(project: Project) -> bool:
    """A preview copy exists and is newer than the source video."""
    p, src = preview_path(project), project.meta.get("video") or ""
    return os.path.isfile(p) and os.path.getsize(p) > 0 and (not os.path.isfile(src) or os.path.getmtime(p) >= os.path.getmtime(src))


def make_preview_proxy(project: Project, job=None, max_seconds: Optional[float] = None, max_side: int = 960) -> dict:
    """Make a small H.264 + AAC copy of the video that EVERY browser can play. Browsers often cannot decode the picture of phone / screen-recorder files
    (HEVC/H.265, 10-bit, ...) and then show black with working sound. Only the preview uses this copy: After Effects and the transcription keep
    using the original file, and the copy has the same timing. Written to a temporary file first, so a failure never leaves a broken preview."""
    import av
    from fractions import Fraction
    src = project.meta["video"]
    dst = preview_path(project)
    tmp = dst + ".part"
    inp = av.open(src)
    out = None
    try:
        vs = next((s for s in inp.streams if s.type == "video"), None)
        if vs is None:
            raise RuntimeError("this file has no picture to preview")
        asr = next((s for s in inp.streams if s.type == "audio"), None)
        vs.thread_type = "AUTO"
        w0, h0 = vs.codec_context.width, vs.codec_context.height
        k = min(1.0, max_side / max(w0, h0))
        w, h = max(2, int(w0 * k) // 2 * 2), max(2, int(h0 * k) // 2 * 2)
        fps = vs.average_rate or Fraction(30)
        out = av.open(tmp, "w", format="mp4", options={"movflags": "+faststart"})
        ov, last_err = None, None
        for enc, opts in (("libx264", {"preset": "veryfast", "crf": "27"}), ("h264_mf", {}), ("h264_nvenc", {"preset": "p1"}), ("mpeg4", {})):
            try:
                ov = out.add_stream(enc, rate=fps)
                ov.width, ov.height, ov.pix_fmt = w, h, "yuv420p"
                ov.options = opts
                ov.codec_context.time_base = Fraction(1, 90000)
                ov.codec_context.open()
                break
            except Exception as e:                                      # encoder missing on this PyAV build: try the next one
                last_err, ov = e, None
                out.close()
                out = av.open(tmp, "w", format="mp4", options={"movflags": "+faststart"})
        if ov is None:
            raise RuntimeError(f"no video encoder available ({last_err})")
        oa = resampler = None
        if asr is not None:
            oa = out.add_stream("aac", rate=48000)
            oa.layout = "stereo"
            resampler = av.AudioResampler(format="fltp", layout="stereo", rate=48000)
        dur = float(inp.duration / 1_000_000) if inp.duration else (max_seconds or 0)
        limit = max_seconds
        t_last = 0.0
        streams = [vs] + ([asr] if asr is not None else [])
        for pkt in inp.demux(*streams):
            if job is not None and job.cancel_requested:
                raise RuntimeError("cancelled")
            for fr in pkt.decode():
                t = float(fr.pts * fr.time_base) if fr.pts is not None else t_last
                if limit and t > limit:
                    break
                if pkt.stream.type == "video":
                    nf = fr.reformat(width=w, height=h, format="yuv420p")
                    nf.pts = int(round(t * 90000))
                    nf.time_base = Fraction(1, 90000)
                    for p in ov.encode(nf):
                        out.mux(p)
                    t_last = max(t_last, t)
                    if job is not None and dur:
                        job.set(min(0.98, t / dur), f"Making a preview copy of the video… {min(99, int(100 * t / dur))} %")
                elif oa is not None:
                    for rf in resampler.resample(fr):
                        for p in oa.encode(rf):
                            out.mux(p)
            else:
                continue
            break
        for p in ov.encode(None):
            out.mux(p)
        if oa is not None:
            for rf in resampler.resample(None) or []:
                for p in oa.encode(rf):
                    out.mux(p)
            for p in oa.encode(None):
                out.mux(p)
        out.close()
        out = None
        os.replace(tmp, dst)
    except BaseException:
        if out is not None:
            try:
                out.close()
            except Exception:
                pass
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    finally:
        inp.close()
    return {"path": dst, "bytes": os.path.getsize(dst), "size": [w, h]}


def _log(msg: str) -> None:
    """Progress line in the app's black window (what the user sees there is the first thing support asks for)."""
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def ensure_speech_model(job=None, alias: str = "large-v3-turbo") -> None:
    """Make sure the speech model is on this computer. The first transcription on a fresh install has to download it (about 1.6 GB); that used to happen
    silently inside the model loader, so the job looked frozen at 4 %. Now the download runs here, with a visible, honest progress message."""
    import threading
    from faster_whisper.utils import _MODELS, download_model
    try:
        download_model(alias, local_files_only=True)
        return                                                              # already downloaded
    except Exception:
        pass
    repo = _MODELS.get(alias, alias)
    total = 0
    try:
        from huggingface_hub import HfApi
        info = HfApi().model_info(repo, files_metadata=True)
        total = sum((s.size or 0) for s in info.siblings if s.rfilename in ("model.bin",) or s.rfilename.startswith(("vocabulary", "tokenizer", "config", "preprocessor")))
    except Exception:
        total = int(1.62e9) if "turbo" in alias else 0
    from huggingface_hub import constants as hf_constants
    cache = os.path.join(hf_constants.HF_HUB_CACHE, "models--" + repo.replace("/", "--"))        # honours HF_HOME / HF_HUB_CACHE like the downloader itself
    stop = threading.Event()

    def done_bytes() -> int:
        n = 0
        for base, _d, files in os.walk(os.path.join(cache, "blobs")):
            for f in files:
                try:
                    n += os.path.getsize(os.path.join(base, f))
                except OSError:
                    pass
        return n

    def watch():
        last = -1
        while not stop.wait(1.0):
            got = done_bytes()
            frac = min(0.99, got / total) if total else 0.0
            msg = f"Downloading the speech model (first time only): {got / 1e6:,.0f} MB" + (f" of {total / 1e6:,.0f} MB ({frac * 100:.0f} %)" if total else "") + " - please wait"
            if job:
                job.set(0.02 + 0.03 * frac, msg)
            if int(got / 1e8) != last:
                last = int(got / 1e8)
                _log(msg)
    if job:
        job.set(0.02, "Downloading the speech model (first time only, about 1.6 GB)…")
    _log("Speech model not on this computer yet: downloading it from Hugging Face (about 1.6 GB, once)")
    t = threading.Thread(target=watch, daemon=True)
    t.start()
    try:
        download_model(alias)
    except Exception as e:
        raise RuntimeError("Could not download the speech model (about 1.6 GB). Check the internet connection, firewall or proxy and try again; "
                           "or run  scripts\\setup.ps1 -PreloadModels  once. Details: " + f"{type(e).__name__}: {e}") from e
    finally:
        stop.set()
    _log("Speech model downloaded")


def transcribe(project: Project, language: str, job=None, strategy: str = "hybrid") -> dict:
    if language not in ("english", "hinglish", "auto"):
        raise ValueError("language must be english, hinglish or auto")
    from fcg_engine.audio import compute_envelope
    video = project.meta["video"]
    _log(f"Transcription started: {os.path.basename(video)} ({language})")
    if job:
        job.set(0.01, "checking the speech model…")
    ensure_speech_model(job)
    eng = get_engine(strategy)
    if job:
        job.set(0.05, "measuring the audio…")
    _log("Measuring the audio…")
    env = compute_envelope(video)                              # used for pauses, onsets AND the speech-coverage safety net
    project.put("envelope", env)
    if job:
        job.set(0.058, "loading the speech model into memory and starting (the first run takes a moment)…")
    _log("Loading the speech model and transcribing…")
    res = eng.transcribe(video, language, envelope=env,
                         progress=(lambda p: job.set(0.06 + 0.88 * p, "transcribing…")) if job else None)
    _log(f"Transcription finished: {len(res['words'])} words")
    project.put("transcript", res)
    project.meta["language"] = language
    project.save_meta()
    if job:
        job.set(0.97, "grouping captions…")
    groups = build_groups(project)
    return {"words": len(res["words"]), "route": res["language"].get("route"), "warnings": res["warnings"], "groups": groups["stats"],
            "speech_gaps": (res.get("quality") or {}).get("speech_gaps", [])}


def import_transcript(project: Project, transcript: dict, with_envelope: bool = True) -> dict:
    if "words" not in transcript or not isinstance(transcript["words"], list):
        raise ValueError("transcript needs a 'words' list")
    for i, w in enumerate(transcript["words"]):
        for k in ("id", "text", "start", "end"):
            if k not in w:
                raise ValueError(f"word {i} is missing '{k}'")
    project.put("transcript", transcript)
    if with_envelope and project.get("envelope") is None and os.path.isfile(project.meta["video"]):
        try:
            from fcg_engine.audio import compute_envelope
            project.put("envelope", compute_envelope(project.meta["video"]))
        except Exception:                    # envelope is optional (pauses fall back to timestamps)
            pass
    return build_groups(project)


def build_groups(project: Project) -> dict:
    from fcg_core import SegmenterConfig, build
    t = project.get("transcript")
    if t is None:
        raise ValueError("no transcript yet")
    # the current LOOK may carry grouping rules (style.grouping, e.g. "four words per line"); they override the project's own settings while that look is
    # active, and vanish when another look replaces the style. Grouping never changes when a word is revealed.
    look_grouping = (project.meta.get("style") or {}).get("grouping") or {}
    cfg, warns = SegmenterConfig.from_dict({**(project.meta.get("config") or {}), **look_grouping})
    res = build(t, project.get("overrides") or {}, cfg, project.get("envelope"))
    res["look_grouping"] = look_grouping
    res["warnings"] = warns + res["warnings"]
    project.put("groups", res)
    return res


def _ts(sec: float, sep: str = ",") -> str:
    ms = max(0, int(round(sec * 1000)))
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d}{sep}{ms % 1000:03d}"


SRT_MAX_LINE = 42        # characters; a longer cue is split into two balanced lines (the usual subtitle convention)
SRT_MIN_CUE_S = 0.30     # a cue is held at least this long when the next cue leaves room for it
SRT_MODES = ("caption", "word")


def _srt_wrap(text: str, width: int = SRT_MAX_LINE) -> str:
    """Split into two lines of similar length when the text is longer than ``width`` (never splits a word)."""
    if len(text) <= width or " " not in text:
        return text
    words = text.split(" ")
    best = min(range(1, len(words)), key=lambda k: max(len(" ".join(words[:k])), len(" ".join(words[k:]))))
    return " ".join(words[:best]) + "\n" + " ".join(words[best:])


def srt_cues(groups: dict, mode: str = "caption") -> list[tuple[float, float, str]]:
    """Subtitle cues (start, end, text) from the built captions.
    ``caption`` (default): one cue per caption, from its first reveal to its exit, the whole text at once — what subtitle players and upload sites expect.
    ``word``: the caption builds up word by word, each cue adding the next word at that word's reveal time, so no word is ever shown before it is spoken.
    Either way: times come from the captions (never earlier than a word is spoken), cues never overlap and every cue has a positive length."""
    if mode not in SRT_MODES:
        raise ValueError(f"mode must be one of {SRT_MODES}")
    rows: list[list] = []
    for g in groups.get("groups", []):
        words = [w for w in g.get("words", []) if str(w.get("display", "")).strip()]
        if not words:
            continue
        exit_t = max(float(g["exit"]), float(words[-1].get("reveal", g["start"])))
        if mode == "caption":
            rows.append([float(g["start"]), exit_t, " ".join(str(w["display"]).strip() for w in words)])
            continue
        for k, w in enumerate(words):
            t0 = float(w.get("reveal", g["start"]))
            t1 = float(words[k + 1].get("reveal", exit_t)) if k + 1 < len(words) else exit_t
            if t1 - t0 < 0.001 and k + 1 < len(words):         # two words revealed at the same moment: one cue shows both
                continue
            rows.append([t0, t1, " ".join(str(x["display"]).strip() for x in words[:k + 1])])
    rows.sort(key=lambda r: (r[0], r[1]))
    for i, r in enumerate(rows):
        nxt = rows[i + 1][0] if i + 1 < len(rows) else None
        if nxt is not None and r[1] > nxt:
            r[1] = nxt                                          # never overlap the next cue
        if r[1] - r[0] < SRT_MIN_CUE_S:
            r[1] = r[0] + SRT_MIN_CUE_S if nxt is None else min(r[0] + SRT_MIN_CUE_S, nxt)
        if r[1] <= r[0]:
            r[1] = r[0] + 0.04                                  # two captions starting at the same instant: a 40 ms sliver is better than losing one
    return [(a, b, t) for a, b, t in rows]


def format_srt(cues: list) -> str:
    out = []
    for i, (a, b, text) in enumerate(cues, 1):
        out.append(f"{i}\r\n{_ts(a)} --> {_ts(b)}\r\n{_srt_wrap(text).replace(chr(10), chr(13) + chr(10))}\r\n")
    return "\r\n".join(out)


def export_srt(groups: dict, mode: str = "caption") -> str:
    """The captions as a .srt file (UTF-8, Windows line endings, ``HH:MM:SS,mmm`` times). See ``srt_cues`` for the two modes."""
    return format_srt(srt_cues(groups, mode))


def diagnostics() -> dict:
    d: dict = {"python": sys.version.split()[0], "root": ROOT}
    try:
        import ctranslate2
        d["ctranslate2"] = ctranslate2.__version__
        d["cuda_devices"] = ctranslate2.get_cuda_device_count()
    except Exception as e:
        d["ctranslate2"] = f"unavailable: {e}"
    try:
        import faster_whisper
        d["faster_whisper"] = faster_whisper.__version__
    except Exception as e:
        d["faster_whisper"] = f"unavailable: {e}"
    d["hinglish_model_present"] = os.path.isdir(os.path.join(ROOT, "models", "ct2", "hinglish-apex-fp16"))
    d["models_local_json"] = os.path.isfile(os.path.join(ROOT, "engine", "models_local.json"))
    d["engine_loaded"] = _engine is not None
    return d
