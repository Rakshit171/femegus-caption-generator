# Changelog

Each release has a `## <version>` heading followed by bullet points; the bullets are what the app shows as "what's new" when an update is available.

## 0.9.14
- New: **Deep check** (section 10, next to Run system check). The system check only looks at files; the deep check really runs both speech models on the first 20 seconds of the open video (or a spoken test sentence) and shows, step by step, what works, what fails or is slow, whether the graphics card or only the processor does the work, and how long a 1-minute Hinglish clip will take on this computer. A step that waits instead of working is stopped after 3 minutes and named, with a report of where it was waiting. "Copy report" gives a text to send for help (it is also included in "Copy support info"). Takes 2–10 minutes and changes nothing.

## 0.9.13
- Fix: every computer now builds exactly the same Hinglish model as the tested one. The Hinglish setup used to install the newest conversion tools, so other computers could end up with a slightly different model; the tool versions and the model version are now fixed (checked: the result is byte-for-byte identical). The system check shows "not the tested build" with a Rebuild button if an older setup made a different one.
- Fix: Hinglish on graphics cards with little free memory. Hinglish uses two speech models; when the card is short of memory they now take turns on it instead of overflowing into normal memory, which made it very slow. Same models, same results.
- Fix: on slow computers (for example without a usable NVIDIA card) the extra accuracy checks could run twice as long as their time limit. They now stop on time.
- Improved: the progress text tells how long the Hinglish pass will take on this computer and how long the extra checks may take at most.

## 0.9.12
- Fix: Hinglish transcription stuck with the graphics card and processor both idle (English worked). If a file of the Hinglish model's folder (for example tokenizer.json) was missing, the speech engine silently waited for the internet, for minutes when the connection was blocked or slow. The folder is now checked before it is used, a missing small file is put back from a copy inside the app (nothing is downloaded, the model itself is unchanged), and a folder that cannot be repaired is reported in plain words instead of waiting.
- Fix: the speech model that is already downloaded is now loaded from the computer only, without first asking the internet whether a newer version exists. A slow or blocked connection no longer delays it.
- New: the progress text now names what the program is doing ("Loading the speech model from disk", "Pass 2: the Hinglish model is listening…", "Extra check 1…"). If nothing happens for 90 s it says which step it is waiting in, and after 2 minutes it saves a report to work\stall_trace.txt that 'Copy support info' (section 10) includes, so a stall can be pinned down.
- Improved: the system check shows "Hinglish model incomplete" with a one-click Fix (no download) when such a file is missing.

## 0.9.11
- Fix: Hinglish transcription seeming stuck at one percentage (for example 35 %) on slower computers. The extra accuracy checks added in 0.9.9 and 0.9.10 can take several times longer than the transcription itself on a slow PC. They now have a time limit based on how fast your computer is, so the transcript always finishes; anything skipped is listed in a warning. On a fast computer nothing is skipped and the result is the same as before.
- Improved: the progress bar keeps moving while those extra checks run, instead of standing still.

## 0.9.10
- Fix: Hinglish sentences captioned in English instead of what was said ("bahut zyada overcrowded hai" came out as "is a lot of overcrowded"). The tool now notices when the speech model translated Hindi, asks the Hinglish model again for those few seconds and keeps the answer that two passes agree on.
- Fix: words missing from Hinglish captions ("out in this market you", "master karna hai"). A single common word such as "jo" no longer counts as proof of Hindi, a replacement is refused when it would drop most of the words the first pass heard, and each Hindi stretch is decoded again on its own.
- Known limit: the speech model is not repeatable, so now and then a Hindi stretch still comes out garbled or loses a word ("hai"). If you see that, transcribe once more or fix the word in the transcript table.

## 0.9.9
- Fix: Hinglish captions with no Hindi words. Two causes: the speech model sometimes translated a spoken Hindi sentence into English (so no Hindi was found), and the Hinglish model sometimes got stuck repeating itself ("vah, vah, vah…"), which left whole stretches of Hindi out of the captions. Both are now detected and those stretches are decoded again. Restart the app and transcribe the clip again to get the corrected text.
- Fix: Automatic language now also notices Hindi that the speech model translated into English, so a Hinglish clip is no longer treated as English.
- Fix: random words flashing on screen for a few frames. Runs of words squeezed into a few hundredths of a second (a repeated phrase the speech model invented) are left out of the captions and listed under "Excluded", where you can bring a word back.
- New: Clean 4-Word look gets two options (both off by default): "Whole line at once" (the line appears together when its first word is spoken) and "Solid box behind the text" (any colour, opacity, padding, corner roundness; a separate editable shape layer in After Effects).
- Improved: the After Effects read-back check understands the new options.

## 0.9.8
- New: one-click fixes in the system check (section 10). If a speech model or component is missing, a Fix button appears next to it (download the English model, set up the Hinglish model, GPU libraries, repair), plus "Fix everything", with progress and Cancel.
- Improved: the system check now notices an incomplete model download and a Hinglish model that is present but not connected.

## 0.9.7
- Fix: spoken amounts lost inside Hindi sentences ("agar 40,000 ya 50,000 rupees … toh kal mujhe 5 lakh rupees" came out as "agar ya rupees … mujhe rupe"). Numbers are now kept, and an amount that may have lost its number is flagged instead of silently missing.
- Fix: English words in a stretch the first pass skipped now come from the stock model ("story sells", not "story cells"); a Hindi stretch the Hinglish model skipped is asked again so the first words ("Stories batao") are no longer left out.
- New: Hinglish text polish (section 2): one spelling per word (voh, yeh, toh, nahin, tumhaare, theek…), "paanch laakh" → "5 lakh", question marks only for real questions, sentence capitals. Every change is listed and it can be switched off.
- New: Hinglish regression suite with measurements (scripts/hinglish_eval.py) and the writing convention in docs/HINGLISH_STYLE.md.
- Fix: a stray "null" text under the transcript table (and in other panels) is gone.

## 0.9.6
- Fix: captions missing for the first seconds of a clip (seen with Hinglish on clips cut mid-sentence; English uses the same safety net). Missing starts are now found, refilled from a second decoding pass and, if needed, by decoding the first seconds again.
- New: download your captions as an .srt subtitle file (section 10): one cue per caption, or a word-by-word build-up. It shows the cue count and the first cues before you download.
- Unfillable gaps at the very start are now marked red on the timeline from 0.6 s (before: 1.5 s), so you can listen and add the words.

## 0.9.5
- New: delete recent projects to free disk space (section 1). Each project shows its size; tick one or more and press Delete selected. Only the tool's saved work is removed — your video/audio files and After Effects are never touched.
- Fix: a project with a damaged transcript no longer disappears from the Recent projects list.

## 0.9.4
- Fix: Transcribe failing with "unexpected keyword argument 'metadata_errors'" on some computers. Differing PyAV versions are tolerated, only tested library versions are installed, and errors now say what to do.
- Fix: a graphics-card failure in the middle of a transcription now continues on the processor instead of stopping.
- Fix: after Update the button came back with no confirmation. Now: "Update installed — restart to finish" with a Restart now button, and Check for updates always says whether you have the latest version.
- New: Repair components and Copy support info buttons (section 10); the System check warns about components that differ from the tested versions.
- If you are on 0.9.3 or older: after this update close the black window and start the app again once; later restarts are one click.

## 0.9.3
- Fix: black picture with working sound. Some videos (phone and screen-recorder files, HEVC/H.265) cannot be shown by the browser. The app now notices and makes a small preview copy automatically (a progress message is shown); there is also a "Picture black or choppy? Make a preview copy" button in section 1. Only the preview uses the copy; After Effects and the transcription still use your original file.
- Fix: transcription that seemed stuck at "4 %". The first transcription on a new computer downloads the speech model (about 1.6 GB); this is now shown with MB and percent (and a clear message if the download fails). Every step is named, with elapsed seconds, and also printed in the app's black window.

## 0.9.2
- Fix: clicking "Browse..." could shut the whole app down on some computers ("The caption app is not reachable"). The file dialog now runs separately and can no longer take the app down; if it cannot open, you are told to paste the path instead.
- One clear message when the app has stopped (instead of a pile of identical errors), and a crash log (`work\app_crash.log`) for support if it ever happens again.

## 0.9.1
- New look "Clean 4-Word": plain white text, at most four words per line, with a one-click smooth slide-up animation switch.
- New look "Soft Editorial": centred light-sans lines, key words in serif caps / bold glow / bold inline / warm bold / gold glow / serif italic, letter-by-letter reveals.
- Caption looks gallery (section 4): change the whole style in one click; save your own looks.
- Per-word and key-word styling: any installed font, solid or gradient fill, outline and glow, for one word or every occurrence.
- Updates: check for new versions and new looks from inside the app (opt-in).
- Fixes: fill colour hidden by a gradient, layout-specific overrides ignoring "all layouts" edits, After Effects reports for relative project folders.
