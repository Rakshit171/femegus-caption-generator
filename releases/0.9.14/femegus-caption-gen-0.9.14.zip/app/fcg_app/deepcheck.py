"""Deep check: really RUN everything a transcription needs, step by step, and point at the step that fails, stalls or is too slow.

Why: the system check only looks at files and versions. On a friend's PC (2026-11-09) it said everything was fine while Hinglish never finished. The deep check
loads both speech models and lets them listen to a short real sample (the first seconds of the open video, otherwise a spoken test sentence), exactly like a
transcription, and reports per step: OK / warning / failed, how long it took, on which device (GPU or processor), and an estimate for a whole clip.

It runs in a SEPARATE Python process (``python -m fcg_app.deepcheck --child``) so that a hang or a hard crash inside a speech library cannot take the app down and
can be named. The child prints one JSON event per line; every 10 s it also reports how much processor time it has used. The parent tells WAITING (no new step
and almost no processor time for ``STALL_S``: network, disk, driver) from WORKING (slow but busy) and stops a waiting child; the child writes the stack of every
thread to its error output now and then, so a stall report names the exact call. Nothing here changes models, settings, projects or results."""
from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
from typing import Optional

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SAMPLE_S = 20.0           # seconds of audio the models listen to
STALL_S = 180.0           # no new step and < STALL_CPU_S processor seconds in this time = waiting, not working
STALL_CPU_S = 2.0
TOTAL_S = 1800.0          # the whole check never runs longer than this
BEAT_S = 10.0
SLOW_MIN_PER_MIN = 10.0   # Hinglish taking longer than this many minutes per minute of video = "very slow" warning
REPORT_FILE = os.path.join("work", "deep_check.txt")
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
TITLES = {
    "computer": "Computer (processor, memory, graphics card, disk)",
    "packages": "Program components (versions)",
    "english_files": "English / main speech model files",
    "hinglish_files": "Hinglish model files",
    "sample": "Test sample",
    "load_main": "Load the main speech model",
    "listen_main": "Main model listens to the sample",
    "load_hinglish": "Load the Hinglish model",
    "listen_hinglish": "Hinglish model listens to the sample",
    "route": "Full Hinglish transcription of the sample",
    "estimate": "Expected time for your videos",
}


# ================================================================================================================================ parent (inside the app)
def make_sample(video: Optional[str], out_dir: str) -> tuple[Optional[str], str]:
    """(wav path, description). The first SAMPLE_S seconds of the open video; otherwise a spoken test sentence (Windows speech); otherwise None."""
    os.makedirs(out_dir, exist_ok=True)
    wav = os.path.join(out_dir, "deep_check_sample.wav")
    if video and os.path.isfile(video):
        try:
            import wave

            import numpy as np
            from faster_whisper.audio import decode_audio
            audio = decode_audio(video, sampling_rate=16000)[: int(SAMPLE_S * 16000)]
            if len(audio) >= 16000:
                with wave.open(wav, "wb") as w:
                    w.setnchannels(1)
                    w.setsampwidth(2)
                    w.setframerate(16000)
                    w.writeframes((np.clip(audio, -1, 1) * 32767).astype("<i2").tobytes())
                return wav, f"the first {len(audio) / 16000:.0f} s of the open video ({os.path.basename(video)})"
        except Exception as e:
            print(f"[deepcheck] could not cut a sample from the video: {type(e).__name__}: {e}", flush=True)
    if os.name == "nt":
        text = "This is a short test of the caption generator. Every word should appear at the moment it is spoken. Yeh ek chhota sa test hai."
        ps = ("Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
              f"$s.SetOutputToWaveFile('{wav}'); $s.Speak('{text}'); $s.Dispose()")
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, timeout=60, creationflags=_NO_WINDOW)
            if os.path.isfile(wav) and os.path.getsize(wav) > 32000:
                return wav, "a spoken test sentence made by Windows (open a video first to test with real speech)"
        except Exception as e:
            print(f"[deepcheck] Windows speech sample failed: {type(e).__name__}: {e}", flush=True)
    return None, "no sample (open a video first)"


def child_command(sample: Optional[str], sample_desc: str) -> list[str]:
    return [sys.executable, "-u", "-m", "fcg_app.deepcheck", "--child", "--sample", sample or "", "--sample-desc", sample_desc]


def _kill(proc: subprocess.Popen) -> None:
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"], capture_output=True, timeout=30, creationflags=_NO_WINDOW)
        else:
            proc.kill()
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def run(job=None, video: Optional[str] = None, command: Optional[list] = None, stall_s: float = STALL_S, total_s: float = TOTAL_S,
        root: str = ROOT) -> dict:
    """Run the deep check (blocking). ``job`` gets live progress and its ``result`` is the growing report. ``command`` replaces the child (tests)."""
    report: dict = {"steps": [], "facts": {}, "overall": "ok", "running": True, "sample": ""}
    by_id: dict[str, dict] = {}

    def publish(msg: Optional[str] = None) -> None:
        if job is not None:
            done = sum(1 for s in report["steps"] if s["status"] not in ("running",))
            job.result = report
            job.set(min(0.97, done / max(1, len(TITLES))), msg)

    def upsert(ev: dict) -> dict:
        s = by_id.get(ev["id"])
        if s is None:
            s = {"id": ev["id"], "title": TITLES.get(ev["id"], ev["id"]), "status": "running", "detail": "", "fix": "", "fix_action": "", "seconds": None}
            by_id[ev["id"]] = s
            report["steps"].append(s)
        for k in ("status", "detail", "fix", "fix_action", "seconds", "title"):
            if ev.get(k) is not None:
                s[k] = ev[k]
        return s

    if command is None:
        sample, desc = make_sample(video, os.path.join(root, "work"))
        command = child_command(sample, desc)
    env = dict(os.environ, PYTHONPATH=os.pathsep.join([os.path.join(root, "app"), os.path.join(root, "engine"), os.path.join(root, "core")]),
               PYTHONIOENCODING="utf-8")
    publish("starting the deep check…")
    proc = subprocess.Popen(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, creationflags=_NO_WINDOW)
    events: "queue.Queue[Optional[dict]]" = queue.Queue()
    err_tail: list[str] = []

    def read_out() -> None:
        for raw in iter(proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith("{"):
                try:
                    events.put(json.loads(line))
                    continue
                except ValueError:
                    pass
            if line:
                err_tail.append(line)
        events.put(None)

    def read_err() -> None:
        for raw in iter(proc.stderr.readline, b""):
            err_tail.append(raw.decode("utf-8", "replace").rstrip())
            del err_tail[:-400]
    threading.Thread(target=read_out, daemon=True).start()
    threading.Thread(target=read_err, daemon=True).start()

    t0 = time.monotonic()
    last_activity, last_cpu = t0, 0.0
    current: Optional[dict] = None
    ended = False
    verdict = None
    while not ended:
        try:
            ev = events.get(timeout=1.0)
        except queue.Empty:
            ev = "tick"
        now = time.monotonic()
        if ev is None:
            ended = True
        elif ev != "tick":
            kind = ev.get("event")
            if kind == "beat":
                cpu = float(ev.get("cpu", 0.0))
                # still computing = processor time keeps growing by at least STALL_CPU_S per stall_s (about 1 % of one core); waiting uses almost none
                if cpu - last_cpu >= max(0.05, STALL_CPU_S * (now - last_activity) / max(stall_s, 1e-3)):
                    last_activity, last_cpu = now, cpu
            elif kind == "step":
                current = upsert(ev)
                last_activity = now
                publish(f"{current['title']}: {current['detail'] or current['status']}")
            elif kind == "facts":
                report["facts"].update(ev.get("facts") or {})
                last_activity = now
            elif kind == "sample":
                report["sample"] = ev.get("desc", "")
        if job is not None and getattr(job, "cancel_requested", False):
            verdict = "cancelled"
        elif now - last_activity >= stall_s:
            verdict = "stalled"
        elif now - t0 >= total_s:
            verdict = "timeout"
        if verdict:
            _kill(proc)
            break
    try:
        proc.wait(timeout=30)
    except Exception:
        pass
    trace = "\n".join(err_tail[-120:])
    if current is not None and current["status"] == "running":
        if verdict == "stalled":
            current.update(status="fail", detail=f"No progress for {stall_s:.0f} s and the program was hardly using the processor: it was WAITING here (for the network, "
                                                  "the disk, antivirus or the graphics driver), not working. The stack report below shows the exact call.",
                           fix="Send the report (Copy report) to the person who gave you the tool.")
        elif verdict == "timeout":
            current.update(status="fail", detail=f"The deep check ran longer than {total_s / 60:.0f} minutes and was stopped (this step was still running).",
                           fix="This computer is very slow for this step. Send the report.")
        elif verdict == "cancelled":
            current.update(status="warn", detail="Cancelled.")
        else:
            code = proc.returncode
            current.update(status="fail", detail=f"The test program stopped unexpectedly during this step (exit code {code}): a crash inside a speech library or the "
                                                  "graphics driver.", fix="Press 'Install the GPU libraries' / 'Repair components' in the system check, update the "
                                                  "NVIDIA driver, then run the deep check again. Send the report if it stays.")
    report["running"] = False
    report["stopped"] = verdict or ""
    report["trace"] = trace if (verdict in ("stalled", "timeout") or any(s["status"] == "fail" for s in report["steps"])) else ""
    report["overall"] = "fail" if any(s["status"] == "fail" for s in report["steps"]) else ("warn" if any(s["status"] == "warn" for s in report["steps"]) else "ok")
    if not report["steps"]:
        report["overall"] = "fail"
        report["steps"].append({"id": "start", "title": "Start the test program", "status": "fail", "seconds": None, "fix_action": "",
                                "detail": "The test program did not start: " + (trace[-400:] or "no message"), "fix": "Press 'Repair components' in the system check."})
    report["text"] = format_report(report)
    try:
        os.makedirs(os.path.join(root, "work"), exist_ok=True)
        with open(os.path.join(root, REPORT_FILE), "w", encoding="utf-8") as f:
            f.write(report["text"])
    except OSError:
        pass
    if job is not None:
        job.result = report
        job.set(1.0, {"ok": "Deep check finished: everything works.", "warn": "Deep check finished, with notes.",
                      "fail": "Deep check found a problem."}[report["overall"]])
    return report


def format_report(rep: dict) -> str:
    sym = {"ok": "[ OK ]", "warn": "[WARN]", "fail": "[FAIL]", "running": "[ .. ]", "skip": "[SKIP]"}
    lines = [f"FemeGus deep check  {time.strftime('%Y-%m-%d %H:%M:%S')}", f"sample: {rep.get('sample') or '-'}", ""]
    for s in rep["steps"]:
        lines.append(f"{sym.get(s['status'], s['status'])} {s['title']}" + (f"  ({s['seconds']:.0f} s)" if isinstance(s.get("seconds"), (int, float)) else ""))
        if s.get("detail"):
            lines.append("       " + s["detail"])
        if s.get("fix") and s["status"] != "ok":
            lines.append("       -> " + s["fix"])
    if rep.get("facts"):
        lines += ["", "facts: " + json.dumps(rep["facts"], ensure_ascii=False)]
    if rep.get("trace"):
        lines += ["", "---- where the test program was (stack report) ----", rep["trace"]]
    return "\n".join(lines)


# ================================================================================================================================ child (separate process)
_out_lock = threading.Lock()


def _emit(**ev) -> None:
    with _out_lock:
        sys.stdout.write(json.dumps(ev, ensure_ascii=False) + "\n")
        sys.stdout.flush()


class _Step:
    def __init__(self, sid: str):
        self.id, self.t0 = sid, time.monotonic()
        self.final = None
        _emit(event="step", id=sid, status="running")

    def detail(self, text: str) -> None:
        _emit(event="step", id=self.id, status="running", detail=text)

    def done(self, status: str, detail: str = "", fix: str = "", fix_action: str = "") -> None:
        self.final = status
        _emit(event="step", id=self.id, status=status, detail=detail, fix=fix, fix_action=fix_action, seconds=round(time.monotonic() - self.t0, 1))


def _ram() -> tuple[Optional[float], Optional[float]]:
    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong), ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong), ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong), ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        m = MS()
        m.dwLength = ctypes.sizeof(MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return m.ullTotalPhys / 1e9, m.ullAvailPhys / 1e9
    except Exception:
        return None, None


def _nvidia() -> Optional[dict]:
    try:
        out = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total,memory.free", "--format=csv,noheader,nounits"], capture_output=True,
                             text=True, timeout=15, creationflags=_NO_WINDOW).stdout.strip().splitlines()
        name, drv, tot, free = [x.strip() for x in out[0].split(",")]
        return {"name": name, "driver": drv, "vram_total_mb": int(tot), "vram_free_mb": int(free)}
    except Exception:
        return None


def _latin_share(words: list[dict]) -> float:
    import re
    real = [w["text"] for w in words if re.search(r"\w", w["text"])]
    return (sum(1 for t in real if re.fullmatch(r"[A-Za-z0-9'’.,!?\-]+", t)) / len(real)) if real else 0.0


def child_main(sample: str, sample_desc: str) -> int:
    import faulthandler
    import platform
    for sub in ("engine", "core"):
        p = os.path.join(ROOT, sub)
        if p not in sys.path:
            sys.path.insert(0, p)
    faulthandler.dump_traceback_later(STALL_S - 30, repeat=True, file=sys.stderr)       # a stall report always has a recent stack of every thread

    def beat() -> None:
        while True:
            _emit(event="beat", cpu=round(time.process_time(), 2))
            time.sleep(BEAT_S)
    threading.Thread(target=beat, daemon=True).start()
    _emit(event="sample", desc=sample_desc)
    facts: dict = {}

    # ---- computer
    st = _Step("computer")
    total, free = _ram()
    gpu = _nvidia()
    facts.update(python=sys.version.split()[0], windows=platform.platform(), cpu=platform.processor() or "?", cores=os.cpu_count(),
                 ram_total_gb=round(total, 1) if total else None, ram_free_gb=round(free, 1) if free else None, gpu=gpu)
    try:
        import shutil
        facts["disk_free_gb"] = round(shutil.disk_usage(ROOT).free / 1e9, 1)
    except OSError:
        pass
    notes = []
    status = "ok"
    if free is not None and free < 3.0:
        status, notes = "warn", notes + [f"only {free:.1f} GB of memory free (Hinglish keeps two speech models, about 3 GB): close other programs"]
    if facts.get("disk_free_gb") is not None and facts["disk_free_gb"] < 2.0:
        status, notes = "warn", notes + [f"only {facts['disk_free_gb']} GB free on the disk"]
    if gpu is None:
        status, notes = "warn", notes + ["no NVIDIA graphics card found: everything runs on the processor (Hinglish then takes several times the length of the video)"]
    desc = f"{facts['cores']} processor threads, {facts['ram_free_gb']} of {facts['ram_total_gb']} GB memory free" + (
        f", {gpu['name']} ({gpu['vram_free_mb']} of {gpu['vram_total_mb']} MB graphics memory free, driver {gpu['driver']})" if gpu else ", no NVIDIA graphics card")
    st.done(status, desc + ("; " + "; ".join(notes) if notes else ""))
    _emit(event="facts", facts=facts)

    # ---- packages against the tested set
    st = _Step("packages")
    try:
        from importlib import metadata
        locked = {}
        with open(os.path.join(ROOT, "requirements.lock.txt"), encoding="utf-8") as f:
            for line in f:
                if "==" in line and not line.lstrip().startswith("#"):
                    n, v = line.strip().split("==", 1)
                    locked[n.strip().lower().replace("_", "-")] = v.strip()
        wrong = []
        for n in ("faster-whisper", "ctranslate2", "av", "onnxruntime", "numpy", "tokenizers", "huggingface-hub"):
            try:
                have = metadata.version(n)
            except Exception:
                have = None
            if locked.get(n) and have != locked[n]:
                wrong.append(f"{n} {have or 'missing'} (tested: {locked[n]})")
        if wrong:
            st.done("fail", "different from the tested versions: " + ", ".join(wrong), "Press 'Repair components' in the system check.", "repair")
        else:
            st.done("ok", "all speech components have the tested versions")
    except Exception as e:
        st.done("warn", f"could not compare the versions ({type(e).__name__}: {e})")

    # ---- model files
    st = _Step("english_files")
    try:
        from faster_whisper.utils import download_model
        d = download_model("large-v3-turbo", local_files_only=True)
        st.done("ok", f"present ({d})")
    except Exception as e:
        st.done("fail", f"not on this computer ({type(e).__name__})", "Press 'Download the English speech model' in the system check.", "english_model")
    st = _Step("hinglish_files")
    hinglish_ok = False
    try:
        from fcg_engine import model_check
        from fcg_engine.transcribe import resolve_model
        path = resolve_model("hinglish-apex", os.path.join(ROOT, "engine", "models_local.json"))
        if not os.path.isdir(path):
            st.done("fail", "the Hinglish model is not set up (or the app does not know where it is)", "Press the Hinglish Fix button in the system check.", "hinglish_model")
        else:
            restored, left = model_check.prepare_local_model(path)
            same = model_check.matches_tested_build(path, full=True)
            if left:
                st.done("fail", "incomplete: " + "; ".join(left), "Press 'Set up the Hinglish model' in the system check.", "hinglish_model")
            elif same is False:
                hinglish_ok = True
                st.done("warn", "present, but converted with different tool versions than the tested model", "Press 'Rebuild the Hinglish model' in the system check.",
                        "rebuild_hinglish")
            else:
                hinglish_ok = True
                st.done("ok", "present and identical to the tested model" + (f" (restored {', '.join(restored)})" if restored else ""))
    except Exception as e:
        st.done("fail", f"could not check it ({type(e).__name__}: {e})")

    # ---- sample
    st = _Step("sample")
    if not sample or not os.path.isfile(sample):
        st.done("fail", "no test sample could be made", "Open a video in section 1, then run the deep check again.")
        return 0
    try:
        import wave
        with wave.open(sample, "rb") as w:
            sample_s = w.getnframes() / float(w.getframerate())
    except Exception:
        sample_s = SAMPLE_S
    st.done("ok", f"{sample_desc}, {sample_s:.0f} s")

    from fcg_engine import status as engine_status
    from fcg_engine.engine import Engine
    eng = Engine("auto", os.path.join(ROOT, "engine", "models_local.json"))
    gpu_present = gpu is not None

    def device_note(t) -> tuple[str, str, str, str]:
        warns = " ".join(getattr(t, "warnings", []) or [])
        if t.device == "cuda":
            return "ok", "on the graphics card (GPU)", "", ""
        if gpu_present:
            return ("warn", "on the PROCESSOR although an NVIDIA card is present (" + (warns[:200] or "the card could not be used") + ")",
                    "Press 'Install the GPU libraries' in the system check and update the NVIDIA driver.", "repair_gpu")
        return "warn", "on the processor (no NVIDIA card)", "", ""

    def timed_listen(sid: str, key: str):
        st = _Step(sid)
        try:
            t = eng._get(key)
            dev0 = t.device
            t1 = time.monotonic()
            res = t.transcribe(sample, "hinglish", initial_prompt="", batched=False)
            dt = time.monotonic() - t1
            stt, where, fix, fa = device_note(t)
            if dev0 == "cuda" and t.device != "cuda":
                stt, where = "warn", "started on the GPU but had to switch to the PROCESSOR: " + " ".join(t.warnings)[-200:]
                fix, fa = "Press 'Install the GPU libraries' in the system check and update the NVIDIA driver.", "repair_gpu"
            n = len(res["words"])
            if n == 0:
                stt = "fail" if "Windows" not in sample_desc else "warn"
            rep_note = " (it repeated itself here; a real transcription repairs that)" if n > 5.0 * sample_s else ""
            st.done(stt, (f"{n} words in {dt:.1f} s {where}; speed {sample_s / dt:.1f}x real time" if dt > 0 else f"{n} words") + rep_note, fix, fa)
            return res, dt
        except Exception as e:
            st.done("fail", f"{type(e).__name__}: {str(e)[:300]}", "Send the report (Copy report).")
            return None, None

    def timed_load(sid: str, key: str) -> bool:
        st = _Step(sid)
        try:
            t1 = time.monotonic()
            t = eng._get(key)
            stt, where, fix, fa = device_note(t)
            st.done(stt, f"loaded in {time.monotonic() - t1:.0f} s {where}", fix, fa)
            return True
        except Exception as e:
            st.done("fail", f"{type(e).__name__}: {str(e)[:300]}", "Press the Fix buttons in the system check, then run the deep check again.")
            return False

    if not timed_load("load_main", eng.english_model):
        return 0
    _r1, t_main = timed_listen("listen_main", eng.english_model)
    if not hinglish_ok or not eng.hinglish_model_available():
        _Step("load_hinglish").done("fail", "the Hinglish model is not usable: " + ("; ".join(getattr(eng, "hinglish_problems", []) or []) or "see 'Hinglish model files'"))
        return 0
    if not timed_load("load_hinglish", eng.hinglish_model):
        return 0
    _r2, t_hing = timed_listen("listen_hinglish", eng.hinglish_model)

    # ---- the real route, as a transcription runs it
    st = _Step("route")
    engine_status.set_listener(lambda m: st.detail(m[:160]))
    try:
        from fcg_engine.audio import compute_envelope
        t1 = time.monotonic()
        res = eng.transcribe(sample, "hinglish", envelope=compute_envelope(sample))
        dt = time.monotonic() - t1
        words = res["words"]
        skipped = (res.get("hybrid_stats") or {}).get("extras_skipped")
        latin = _latin_share(words)
        stt = "ok"
        notes = [f"{len(words)} words in {dt:.0f} s", f"{latin * 100:.0f} % in Roman letters"]
        if skipped:
            stt, notes = "warn", notes + ["the extra accuracy checks were cut short because this computer is slow (" + ", ".join(skipped) + ")"]
        if not words:
            stt, notes = ("fail" if "Windows" not in sample_desc else "warn"), notes + ["no words came out"]
        elif latin < 0.6:
            stt, notes = "warn", notes + ["many words are not in Roman letters"]
        text = " ".join(w["text"] for w in words)[:160]
        st.done(stt, "; ".join(notes) + (f'. Start: "{text}"' if text else ""))
    except Exception as e:
        dt = None
        st.done("fail", f"{type(e).__name__}: {str(e)[:300]}", "Send the report (Copy report).")
    finally:
        engine_status.set_listener(None)

    st = _Step("estimate")
    if dt:
        # lower end: as fast as this sample went; upper end: both passes for a minute of speech + the extra checks' time limit (coverage.Budget) for that minute
        from fcg_engine import coverage as cov
        low = dt / sample_s
        base = ((t_main or 0) + (t_hing or 0)) * 60.0 / sample_s
        # (+30 % for loading the models and the safety-net pass a real clip may need; measured: 40 s clip on the dev PC 4.2 min per minute vs 4.1 estimated)
        high = max(low, 1.3 * (base + min(cov.EXTRAS_FACTOR * base, max(cov.EXTRAS_CAP_MIN_S, cov.EXTRAS_PER_AUDIO_S * 60.0))) / 60.0)
        per_min = high
        eng_min = (t_main or 0) / sample_s
        msg = f"a 1-minute Hinglish clip takes about {low:.1f} to {high:.1f} minutes on this computer (English: about {max(eng_min, 0.1):.1f} min)"
        if per_min > SLOW_MIN_PER_MIN:
            st.done("warn", msg + ". That is very slow: the progress bar moves slowly, but it does finish.",
                    "A computer with an NVIDIA graphics card is much faster; on this one use short clips.")
        else:
            st.done("ok", msg)
    else:
        st.done("warn", "no estimate (the full test did not finish)")
    return 0


def main(argv: Optional[list] = None) -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--child", action="store_true")
    ap.add_argument("--sample", default="")
    ap.add_argument("--sample-desc", default="")
    a = ap.parse_args(argv)
    if a.child:
        try:
            return child_main(a.sample, a.sample_desc)
        finally:
            sys.stdout.flush()
    rep = run(None)
    print(rep["text"])
    return 0 if rep["overall"] != "fail" else 1


if __name__ == "__main__":
    sys.exit(main())
